import ArrheniusLean.Statements

/-!
# The debt-first axiology refutes Arrhenius's 2011 theorem as stated

V(X) = H − D + [D ≤ H] · L, where
* H = total welfare of lives at levels ≥ 4,
* D = total |welfare| of lives at negative levels,
* L = total welfare of lives at levels 1..3.
X is at least as good as Y iff V(X) ≥ V(Y).
-/

namespace Arrhenius

/-- sum of `f` over a population -/
def sumF (f : Int → Int) : Pop → Int
  | [] => 0
  | w :: p => f w + sumF f p

def hi (w : Int) : Int := if 4 ≤ w then w else 0
def debt (w : Int) : Int := if w < 0 then -w else 0
def lo (w : Int) : Int := if 1 ≤ w ∧ w ≤ 3 then w else 0

def H (p : Pop) : Int := sumF hi p
def D (p : Pop) : Int := sumF debt p
def L (p : Pop) : Int := sumF lo p

def V (p : Pop) : Int := H p - D p + (if D p ≤ H p then L p else 0)

def Rv (p q : Pop) : Prop := V q ≤ V p

theorem sumF_append (f : Int → Int) (p q : Pop) : sumF f (p ++ q) = sumF f p + sumF f q := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih => simp [sumF, ih]; omega

theorem sumF_replicate (f : Int → Int) (n : Nat) (x : Int) :
    sumF f (List.replicate n x) = (n : Int) * f x := by
  induction n with
  | zero => simp [sumF]
  | succ k ih =>
    simp only [List.replicate_succ, sumF, ih, Int.natCast_add, Int.add_mul, Int.one_mul]
    omega

theorem sumF_perm (f : Int → Int) {p q : Pop} (h : p.Perm q) : sumF f p = sumF f q := by
  induction h with
  | nil => rfl
  | cons x _ ih => simp [sumF, ih]
  | swap x y l => simp [sumF]; omega
  | trans _ _ ih1 ih2 => rw [ih1, ih2]

theorem sumF_nonneg (f : Int → Int) (h : ∀ w, 0 ≤ f w) (p : Pop) : 0 ≤ sumF f p := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih => have := h w; simp [sumF]; omega

theorem sumF_zero (f : Int → Int) (p : Pop) (h : ∀ w ∈ p, f w = 0) : sumF f p = 0 := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih =>
    have h1 := h w (by simp)
    have h2 := ih (fun v hv => h v (by simp [hv]))
    simp [sumF]; omega

theorem sumF_le (f : Int → Int) (c : Int) (p : Pop) (h : ∀ w ∈ p, f w ≤ c) :
    sumF f p ≤ (p.length : Int) * c := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih =>
    have h1 := h w (by simp)
    have h2 := ih (fun v hv => h v (by simp [hv]))
    simp only [sumF, List.length_cons, Int.natCast_add, Int.add_mul, Int.one_mul]
    omega

theorem sumF_ge (f : Int → Int) (c : Int) (p : Pop) (h : ∀ w ∈ p, c ≤ f w) :
    (p.length : Int) * c ≤ sumF f p := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih =>
    have h1 := h w (by simp)
    have h2 := ih (fun v hv => h v (by simp [hv]))
    simp only [sumF, List.length_cons, Int.natCast_add, Int.add_mul, Int.one_mul]
    omega

theorem sumF_add (f g : Int → Int) (p : Pop) :
    sumF (fun w => f w + g w) p = sumF f p + sumF g p := by
  induction p with
  | nil => simp [sumF]
  | cons w p ih => simp [sumF, ih]; omega

theorem hi_spec (w : Int) : (4 ≤ w ∧ hi w = w) ∨ (w < 4 ∧ hi w = 0) := by
  unfold hi; split <;> omega
theorem debt_spec (w : Int) : (w < 0 ∧ debt w = -w) ∨ (0 ≤ w ∧ debt w = 0) := by
  unfold debt; split <;> omega
theorem lo_spec (w : Int) :
    (1 ≤ w ∧ w ≤ 3 ∧ lo w = w) ∨ ((w < 1 ∨ 3 < w) ∧ lo w = 0) := by
  unfold lo; split <;> omega

theorem hi_nn (w : Int) : 0 ≤ hi w := by have := hi_spec w; omega
theorem debt_nn (w : Int) : 0 ≤ debt w := by have := debt_spec w; omega
theorem lo_nn (w : Int) : 0 ≤ lo w := by have := lo_spec w; omega

theorem rv_quasi : IsQuasiOrder Rv :=
  ⟨fun _ => Int.le_refl _, fun _ _ _ h1 h2 => Int.le_trans h2 h1⟩

theorem rv_perm : PermInvariant Rv := by
  intro p p' q q' hp hq
  have e1 : V p = V p' := by unfold V H D L; rw [sumF_perm hi hp, sumF_perm debt hp, sumF_perm lo hp]
  have e2 : V q = V q' := by unfold V H D L; rw [sumF_perm hi hq, sumF_perm debt hq, sumF_perm lo hq]
  simp only [Rv, e1, e2]

theorem rv_ED : ED Rv := by
  intro x N B hN hlen hlt
  have key : V B < V (List.replicate N x) := by
    have hD := sumF_nonneg debt debt_nn B
    have hL := sumF_nonneg lo lo_nn B
    have hN' : (0 : Int) < N := by omega
    by_cases hx : 1 ≤ x
    · have hb := sumF_le (fun w => hi w + lo w) (x - 1) B (by
        intro w hw
        have := hlt w hw; have := hi_spec w; have := lo_spec w; omega)
      rw [sumF_add, hlen, Int.mul_sub, Int.mul_one] at hb
      have hxn : 0 ≤ (N : Int) * x := Int.mul_nonneg (by omega) (by omega)
      have : (V B ≤ sumF hi B + sumF lo B) := by
        unfold V H L D; split <;> omega
      have hA : V (List.replicate N x) = (N : Int) * x := by
        have := hi_spec x; have := lo_spec x; have := debt_spec x
        simp only [V, H, D, L, sumF_replicate]
        rcases hi_spec x with ⟨_, h1⟩ | ⟨_, h1⟩ <;>
        rcases lo_spec x with ⟨_, _, h2⟩ | ⟨_, h2⟩ <;>
        rcases debt_spec x with ⟨_, h3⟩ | ⟨_, h3⟩ <;>
        simp only [h1, h2, h3, Int.mul_zero, Int.mul_neg] <;> split <;> omega
      omega
    · have h1 : sumF hi B = 0 := sumF_zero _ _ (fun w hw => by
        have := hlt w hw; have := hi_spec w; omega)
      have h2 : sumF lo B = 0 := sumF_zero _ _ (fun w hw => by
        have := hlt w hw; have := lo_spec w; omega)
      have h3 := sumF_ge debt (1 - x) B (fun w hw => by
        have := hlt w hw; have := debt_spec w; omega)
      rw [hlen, Int.mul_sub, Int.mul_one] at h3
      have hA : V (List.replicate N x) = (N : Int) * x := by
        have e1 : hi x = 0 := by have := hi_spec x; omega
        have e2 : lo x = 0 := by have := lo_spec x; omega
        have e3 : debt x = -x := by have := debt_spec x; omega
        simp only [V, H, D, L, sumF_replicate, e1, e2, e3, Int.mul_zero, Int.mul_neg]
        split <;> omega
      have : V B = - sumF debt B := by
        unfold V H L D; rw [h1, h2]; split <;> omega
      omega
  exact ⟨Int.le_of_lt key, fun h => absurd h (Int.not_le.mpr key)⟩

theorem rv_GNEP : GNEP Rv := by
  intro z
  refine ⟨5, 3, 1, by omega, by omega, by omega, ?_⟩
  intro x B E hx hB hR
  match B, hB with
  | [b], _ =>
    have hb := hR b (by simp)
    have e1 : hi b = 0 := by have := hi_spec b; omega
    have e2 : lo b = b := by have := lo_spec b; omega
    have e3 : debt b = 0 := by have := debt_spec b; omega
    have e4 : hi x = x := by have := hi_spec x; omega
    have n1 := sumF_nonneg hi hi_nn E
    have n2 := sumF_nonneg debt debt_nn E
    have n3 := sumF_nonneg lo lo_nn E
    have := hi_spec z; have := debt_spec z; have := lo_spec z
    have := hi_spec (z+1); have := debt_spec (z+1); have := lo_spec (z+1)
    have := lo_spec x; have := debt_spec x
    simp only [Rv, V, H, D, L, sumF_append, sumF_replicate, sumF, e1, e2, e3, e4]
    split <;> split <;> omega

theorem rv_NE : NE Rv := by
  intro x y hxy
  have main : ∀ (n : Nat) (E : Pop), InRange y x E →
      (n = 4 ∧ y < 0 ∨ n = 1 ∧ 0 ≤ y) →
      Rv (List.replicate (n + 1) (x - 1) ++ E) ([x] ++ List.replicate n y ++ E) := by
    intro n E hD hn
    have n1 := sumF_nonneg hi hi_nn E
    have n2 := sumF_nonneg debt debt_nn E
    have n3 := sumF_nonneg lo lo_nn E
    have hh : x ≤ 3 → sumF hi E = 0 := fun h => sumF_zero _ _ (fun w hw => by
      have := hD w hw; have := hi_spec w; omega)
    have hd : 0 ≤ y → sumF debt E = 0 := fun h => sumF_zero _ _ (fun w hw => by
      have := hD w hw; have := debt_spec w; omega)
    have := hi_spec x; have := debt_spec x; have := lo_spec x
    have := hi_spec (x-1); have := debt_spec (x-1); have := lo_spec (x-1)
    have := hi_spec y; have := debt_spec y; have := lo_spec y
    rcases hn with ⟨rfl, _⟩ | ⟨rfl, _⟩ <;>
    · simp only [Rv, V, H, D, L, sumF_append, sumF_replicate, sumF]
      split <;> split <;> omega
  by_cases hy : y < 0
  · exact ⟨4, by omega, fun E hD => main 4 E hD (Or.inl ⟨rfl, hy⟩)⟩
  · exact ⟨1, by omega, fun E hD => main 1 E hD (Or.inr ⟨rfl, by omega⟩)⟩

theorem rv_WNS : WNS Rv := by
  refine ⟨-1, 1, by omega, by omega, ?_⟩
  intro y k C hy
  have n1 := sumF_nonneg hi hi_nn C
  have n2 := sumF_nonneg debt debt_nn C
  have n3 := sumF_nonneg lo lo_nn C
  have e1 : 0 ≤ (k : Int) * hi y := Int.mul_nonneg (by omega) (hi_nn y)
  have e2 : 0 ≤ (k : Int) * lo y := Int.mul_nonneg (by omega) (lo_nn y)
  have e3 : debt y = 0 := by have := debt_spec y; omega
  have e4 : debt (-1) = 1 := by decide
  have e5 : hi (-1) = 0 := by decide
  have e6 : lo (-1) = 0 := by decide
  simp only [Rv, V, H, D, L, sumF_append, sumF_replicate, e3, e4, e5, e6, Int.mul_zero]
  split <;> split <;> omega

theorem rv_WQA : WQA Rv := by
  intro X
  have n1 := sumF_nonneg hi hi_nn X
  have n2 := sumF_nonneg debt debt_nn X
  have n3 := sumF_nonneg lo lo_nn X
  refine ⟨-(max (sumF hi X - sumF debt X) 0 + 1), 4, 3, 1, 1, by omega, by omega, by omega,
    by omega, by omega, ?_⟩
  intro z B hz hB
  have h1 : sumF hi B = 0 := sumF_zero _ _ (fun w hw => by
    have := hB w hw; have := hi_spec w; omega)
  have h2 : sumF debt B = 0 := sumF_zero _ _ (fun w hw => by
    have := hB w hw; have := debt_spec w; omega)
  have h3 := sumF_nonneg lo lo_nn B
  have e1 : hi z = z := by have := hi_spec z; omega
  have e2 : debt z = 0 := by have := debt_spec z; omega
  have e3 : lo z = 0 := by have := lo_spec z; omega
  have e4 : debt (-(max (sumF hi X - sumF debt X) 0 + 1)) = max (sumF hi X - sumF debt X) 0 + 1 := by
    have := debt_spec (-(max (sumF hi X - sumF debt X) 0 + 1)); omega
  have e5 : hi (-(max (sumF hi X - sumF debt X) 0 + 1)) = 0 := by
    have := hi_spec (-(max (sumF hi X - sumF debt X) 0 + 1)); omega
  have e6 : lo (-(max (sumF hi X - sumF debt X) 0 + 1)) = 0 := by
    have := lo_spec (-(max (sumF hi X - sumF debt X) 0 + 1)); omega
  simp only [Rv, V, H, D, L, sumF_append, sumF_replicate, e1, e2, e3, e4, e5, e6, h1, h2]
  split <;> split <;> omega

theorem rv_not_strong : ¬ StrongWQA Rv := by
  rintro ⟨a, m, ha, hm, h⟩
  obtain ⟨k, hk⟩ := Int.exists_eq_neg_ofNat (by omega : a ≤ 0)
  subst hk
  obtain ⟨u, y, n, hy3, hyu, hn, hall⟩ := h (List.replicate (m * k) 4)
  obtain ⟨u', rfl⟩ := Int.eq_ofNat_of_zero_le (by omega : 0 ≤ u)
  have hB : InRange 1 y (List.replicate (n * u' + m * k + 1) 1) := by
    intro w hw
    have := List.eq_of_mem_replicate hw
    omega
  have hR := hall u' _ (Int.le_refl _) hB
  have e1 : hi (u' : Int) = u' := by have := hi_spec (u' : Int); omega
  have e2 : debt (u' : Int) = 0 := by have := debt_spec (u' : Int); omega
  have e3 : lo (u' : Int) = 0 := by have := lo_spec (u' : Int); omega
  have e4 : debt (-(k : Int)) = k := by have := debt_spec (-(k : Int)); omega
  have e5 : hi (-(k : Int)) = 0 := by have := hi_spec (-(k : Int)); omega
  have e6 : lo (-(k : Int)) = 0 := by have := lo_spec (-(k : Int)); omega
  have e7 : hi 4 = 4 := by decide
  have e8 : debt 4 = 0 := by decide
  have e9 : lo 4 = 0 := by decide
  have e10 : hi 1 = 0 := by decide
  have e11 : debt 1 = 0 := by decide
  have e12 : lo 1 = 1 := by decide
  simp only [Rv, V, H, D, L, sumF_append, sumF_replicate, e1, e2, e3, e4, e5, e6, e7, e8, e9,
    e10, e11, e12, Int.natCast_add, Int.natCast_mul, Int.mul_zero] at hR
  have hmk : 0 ≤ (m : Int) * k := Int.mul_nonneg (by omega) (by omega)
  have hnu : 0 ≤ (n : Int) * u' := Int.mul_nonneg (by omega) (by omega)
  revert hR
  split <;> split <;> omega

theorem refutation : Refutation :=
  ⟨Rv, rv_quasi, rv_perm, rv_ED, rv_GNEP, rv_NE, rv_WNS, rv_WQA, rv_not_strong⟩

/-- The 2011 statement is false. -/
theorem arrhenius2011_false : ¬ ArrheniusTheorem2011 := by
  intro h
  obtain ⟨R, hq, _, hED, hG, hNE, hW, hQ, _⟩ := refutation
  exact h R hq ⟨hED, hG, hNE, hW, hQ⟩

end Arrhenius

#print axioms Arrhenius.arrhenius2011_false
