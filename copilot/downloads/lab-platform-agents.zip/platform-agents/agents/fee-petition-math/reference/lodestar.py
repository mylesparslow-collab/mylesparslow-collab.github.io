#!/usr/bin/env python3
"""Deterministic lodestar calculator: exactly what the agent's instructions ask the
Copilot code interpreter to do.

  lodestar.py TIME_ENTRIES.csv --out-dir OUT [--stated-total 123456.00] [--period 2026-01-01 2026-12-31]

 1. Read every entry; money is Decimal, hours are Decimal, nothing is rounded except
    to cents on the entry amount (hours x rate).
 2. Lodestar = hours x rate, summed by timekeeper, by phase, and timekeeper x phase.
 3. Flag block-billed and vague entries. Flags are REPORTED, NOT APPLIED: no reduction
    is taken. The exposure (hours and dollars on flagged entries) is shown so the
    attorney can decide.
 4. Cross-check: the three views and an independent running sum agree to the cent,
    hour totals agree, entry counts agree, one rate per timekeeper, no duplicate entry
    ids, hours in (0, 24], no timekeeper-day over 24 hours, optional stated total and
    period.
Exit code 1 if any ERROR check fails. WARN checks never fail the run.
The tool does not decide what is reasonable; an attorney does."""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import defaultdict
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

CENT = Decimal("0.01")
VAGUE_PHRASES = {
    "attention to file", "work on case", "review documents", "research", "various matters",
    "case management", "prep", "preparation", "miscellaneous", "misc", "file review",
    "review file", "review", "draft", "work on matter", "attention to matter",
}
REQUIRED = ["entry_id", "date", "timekeeper", "role", "rate", "hours", "phase", "narrative"]


def money(x: Decimal) -> Decimal:
    return x.quantize(CENT, rounding=ROUND_HALF_UP)


def is_block_billed(narr: str) -> bool:
    n = narr.strip()
    if len([s for s in n.split(";") if s.strip()]) >= 2:
        return True
    if len([s for s in n.split(",") if s.strip()]) >= 3:
        return True
    return bool(re.search(r"\(\s*[1-9]\s*\).*\(\s*[2-9]\s*\)", n))


def is_vague(narr: str) -> bool:
    n = re.sub(r"[^a-z ]", "", narr.lower()).strip()
    return n in VAGUE_PHRASES or len(n.split()) < 3


def load(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        missing = [c for c in REQUIRED if c not in (rd.fieldnames or [])]
        if missing:
            raise ValueError("missing columns: " + ", ".join(missing))
        rows = list(rd)
    for i, r in enumerate(rows, 2):
        try:
            r["_rate"] = Decimal(r["rate"])
            r["_hours"] = Decimal(r["hours"])
        except Exception as e:  # noqa: BLE001
            raise ValueError(f"line {i}: rate or hours not a number ({e})") from e
        r["_amount"] = money(r["_rate"] * r["_hours"])
    return rows


def compute(rows: list[dict], stated_total: Decimal | None = None, period: tuple[str, str] | None = None) -> dict:
    by_tk = defaultdict(lambda: {"hours": Decimal(0), "amount": Decimal(0), "rates": set(), "role": "", "n": 0})
    by_ph = defaultdict(lambda: {"hours": Decimal(0), "amount": Decimal(0), "n": 0})
    matrix = defaultdict(Decimal)
    for r in rows:
        t = by_tk[r["timekeeper"]]
        t["hours"] += r["_hours"]
        t["amount"] += r["_amount"]
        t["rates"].add(r["_rate"])
        t["role"] = r["role"]
        t["n"] += 1
        p = by_ph[r["phase"]]
        p["hours"] += r["_hours"]
        p["amount"] += r["_amount"]
        p["n"] += 1
        matrix[(r["timekeeper"], r["phase"])] += r["_amount"]

    flagged = []
    for r in rows:
        fl = []
        if is_block_billed(r["narrative"]):
            fl.append("BLOCK-BILLED")
        if is_vague(r["narrative"]):
            fl.append("VAGUE")
        if fl:
            flagged.append({"entry_id": r["entry_id"], "date": r["date"], "timekeeper": r["timekeeper"],
                            "phase": r["phase"], "hours": r["_hours"], "amount": r["_amount"],
                            "flags": " + ".join(fl), "narrative": r["narrative"],
                            "reduction_applied": "NONE (flag only; attorney decides)"})

    grand = sum((r["_amount"] for r in rows), Decimal(0))
    grand_hours = sum((r["_hours"] for r in rows), Decimal(0))
    checks = []

    def chk(name, ok, detail, severity="ERROR"):
        checks.append({"check": name, "result": "PASS" if ok else ("FAIL" if severity == "ERROR" else "WARN"),
                       "severity": severity, "detail": detail})

    s_tk = sum((v["amount"] for v in by_tk.values()), Decimal(0))
    s_ph = sum((v["amount"] for v in by_ph.values()), Decimal(0))
    s_mx = sum(matrix.values(), Decimal(0))
    chk("Timekeeper total equals grand total", s_tk == grand, f"{s_tk} vs {grand}")
    chk("Phase total equals grand total", s_ph == grand, f"{s_ph} vs {grand}")
    chk("Timekeeper x phase total equals grand total", s_mx == grand, f"{s_mx} vs {grand}")
    # independent recomputation in integer cents
    cents = sum(int((r["_hours"] * r["_rate"] * 100).to_integral_value(rounding=ROUND_HALF_UP)) for r in rows)
    chk("Independent integer-cent recomputation equals grand total", Decimal(cents) / 100 == grand,
        f"{Decimal(cents) / 100} vs {grand}")
    h_tk = sum((v["hours"] for v in by_tk.values()), Decimal(0))
    h_ph = sum((v["hours"] for v in by_ph.values()), Decimal(0))
    chk("Hours agree across timekeeper, phase and row views", h_tk == h_ph == grand_hours,
        f"{h_tk} / {h_ph} / {grand_hours}")
    n_tk = sum(v["n"] for v in by_tk.values())
    n_ph = sum(v["n"] for v in by_ph.values())
    chk("Entry count agrees across timekeeper and phase views", n_tk == n_ph == len(rows),
        f"{n_tk} / {n_ph} / {len(rows)} entries")
    multi = {k: sorted(str(x) for x in v["rates"]) for k, v in by_tk.items() if len(v["rates"]) > 1}
    chk("One rate per timekeeper", not multi, "rates differ for: " + json.dumps(multi) if multi else "ok", "ERROR")
    ids = defaultdict(int)
    for r in rows:
        ids[r["entry_id"]] += 1
    dups = sorted(k for k, c in ids.items() if c > 1)
    chk("No duplicate entry ids", not dups, "duplicated: " + ", ".join(dups) if dups else "ok")
    bad_h = [r["entry_id"] for r in rows if not (Decimal(0) < r["_hours"] <= 24)]
    chk("Every entry has hours above 0 and at most 24", not bad_h, ", ".join(bad_h) if bad_h else "ok")
    day = defaultdict(Decimal)
    for r in rows:
        day[(r["timekeeper"], r["date"])] += r["_hours"]
    over24 = [f"{k[0]} {k[1]} {v}h" for k, v in day.items() if v > 24]
    chk("No timekeeper-day over 24 hours", not over24, "; ".join(over24) if over24 else "ok")
    over12 = [f"{k[0]} {k[1]} {v}h" for k, v in sorted(day.items()) if 12 < v <= 24]
    chk("Timekeeper-days over 12 hours (for a person to look at)", not over12,
        "; ".join(over12) if over12 else "none", "WARN")
    if period:
        out = [r["entry_id"] for r in rows if not (period[0] <= r["date"] <= period[1])]
        chk("All entries fall inside the stated period", not out, ", ".join(out) if out else "ok")
    bad_dates = []
    for r in rows:
        try:
            date.fromisoformat(r["date"])
        except ValueError:
            bad_dates.append(r["entry_id"])
    chk("All dates are ISO dates", not bad_dates, ", ".join(bad_dates) if bad_dates else "ok")
    if stated_total is not None:
        chk("Computed total equals the total stated in the petition draft", grand == stated_total,
            f"computed {grand}, stated {stated_total}, difference {grand - stated_total}")
    fl_hours = sum((f["hours"] for f in flagged), Decimal(0))
    fl_amt = sum((f["amount"] for f in flagged), Decimal(0))
    return {
        "by_timekeeper": {k: {"role": v["role"], "rates": sorted(str(x) for x in v["rates"]),
                              "hours": v["hours"], "lodestar": v["amount"], "entries": v["n"]}
                          for k, v in sorted(by_tk.items())},
        "by_phase": {k: dict(v) for k, v in sorted(by_ph.items())},
        "matrix": {f"{a}|{b}": v for (a, b), v in sorted(matrix.items())},
        "grand_total": grand, "grand_hours": grand_hours, "entries": len(rows),
        "flagged": flagged, "flagged_hours": fl_hours, "flagged_amount": fl_amt,
        "reductions_applied": "NONE",
        "checks": checks,
        "errors": sum(1 for c in checks if c["result"] == "FAIL"),
    }


def _num(o):
    if isinstance(o, Decimal):
        return str(o)
    raise TypeError(type(o))


def write_outputs(res: dict, out_dir: Path) -> list[Path]:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    out_dir.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "By Timekeeper"
    ws.append(["Timekeeper", "Role", "Rate(s) billed", "Hours", "Lodestar (hours x rate)"])
    for k, v in res["by_timekeeper"].items():
        ws.append([k, v["role"], ", ".join(v["rates"]), float(v["hours"]), float(v["lodestar"])])
    ws.append(["TOTAL", "", "", float(res["grand_hours"]), float(res["grand_total"])])
    ws2 = wb.create_sheet("By Phase")
    ws2.append(["Phase", "Hours", "Lodestar"])
    for k, v in res["by_phase"].items():
        ws2.append([k, float(v["hours"]), float(v["amount"])])
    ws2.append(["TOTAL", float(res["grand_hours"]), float(res["grand_total"])])
    ws3 = wb.create_sheet("Timekeeper x Phase")
    phases = list(res["by_phase"])
    ws3.append(["Timekeeper"] + phases + ["Total"])
    for tk in res["by_timekeeper"]:
        vals = [res["matrix"].get(f"{tk}|{p}", Decimal(0)) for p in phases]
        ws3.append([tk] + [float(v) for v in vals] + [float(sum(vals, Decimal(0)))])
    ws3.append(["TOTAL"] + [float(res["by_phase"][p]["amount"]) for p in phases] + [float(res["grand_total"])])
    ws4 = wb.create_sheet("Flagged (not applied)")
    ws4.append(["Entry", "Date", "Timekeeper", "Phase", "Hours", "Amount", "Flags", "Narrative", "Reduction applied"])
    for f in res["flagged"]:
        ws4.append([f["entry_id"], f["date"], f["timekeeper"], f["phase"], float(f["hours"]), float(f["amount"]),
                    f["flags"], f["narrative"], f["reduction_applied"]])
    ws4.append([])
    ws4.append(["Total flagged exposure", "", "", "", float(res["flagged_hours"]), float(res["flagged_amount"]),
                "", "No reduction has been taken. An attorney decides.", ""])
    ws5 = wb.create_sheet("Checks")
    ws5.append(["Check", "Result", "Severity", "Detail"])
    for c in res["checks"]:
        ws5.append([c["check"], c["result"], c["severity"], c["detail"]])
    for w in wb.worksheets:
        for c in w[1]:
            c.font = Font(bold=True)
        w.freeze_panes = "A2"
        for col in w.columns:
            w.column_dimensions[col[0].column_letter].width = 22
    ws4.column_dimensions["H"].width = 70
    x = out_dir / "lodestar.xlsx"
    wb.save(x)
    c = out_dir / "lodestar_by_timekeeper_and_phase.csv"
    with open(c, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["timekeeper", "phase", "lodestar"])
        for k, v in res["matrix"].items():
            tk, ph = k.split("|")
            w.writerow([tk, ph, v])
    j = out_dir / "lodestar_summary.json"
    j.write_text(json.dumps({k: v for k, v in res.items() if k != "matrix"}, indent=2, default=_num) + "\n")
    return [x, c, j]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("entries", type=Path)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--stated-total", type=Decimal, help="total shown in the petition draft, to reconcile")
    ap.add_argument("--period", nargs=2, metavar=("START", "END"), help="ISO dates, inclusive")
    a = ap.parse_args(argv)
    res = compute(load(a.entries), a.stated_total, tuple(a.period) if a.period else None)
    for p in write_outputs(res, a.out_dir):
        print("wrote", p)
    print(f"entries {res['entries']}  hours {res['grand_hours']}  lodestar ${res['grand_total']:,}  "
          f"flagged entries {len(res['flagged'])} (${res['flagged_amount']:,}, NOT reduced)")
    for c in res["checks"]:
        print(f"  [{c['result']}] {c['check']}: {c['detail']}")
    return 1 if res["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
