#!/usr/bin/env python3
"""Generate sample-time-entries.csv: invented time entries for the invented matter
Harborline Freight Systems v. Redcliffe Logistics (deterministic, seeded). Fake data only."""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
rnd = random.Random(20261114)

TK = {  # name: (role, rate)
    "Priya Ramanathan": ("Partner", 725),
    "Marcus Odell": ("Partner", 690),
    "Elena Vasquez-Hart": ("Associate", 510),
    "Joel Pruitt": ("Paralegal", 235),
}
SPECIFIC = {
    "Pleadings": [
        "Draft first amended complaint adding breach of bailment count",
        "Revise opposition to demurrer section on economic loss rule",
        "Research choice-of-law clause in master carrier agreement",
        "Prepare proof of service for amended complaint",
        "Review defendant's answer and compile affirmative defenses chart",
    ],
    "Discovery": [
        "Draft responses to Redcliffe's first set of requests for production",
        "Review Harborline dispatch logs produced 4/12 for responsive entries",
        "Prepare privilege log entries for March correspondence",
        "Meet and confer call with G. Lindqvist re scope of ESI custodians",
        "Organize production volume 003 and confirm Bates ranges",
    ],
    "Depositions": [
        "Prepare outline for deposition of R. Kessel",
        "Attend deposition of R. Kessel (day one)",
        "Summarize Kessel transcript pages 1-120 for trial team",
        "Prepare S. Okonkwo for deposition",
    ],
    "Motions": [
        "Draft motion to compel supplemental responses to interrogatories",
        "Research standard for sanctions under CCP 2023.010",
        "Prepare reply declaration in support of motion to compel",
        "Cite-check motion for summary adjudication",
    ],
    "Trial Prep": [
        "Prepare witness binders for T. Brandvold",
        "Draft proposed jury instructions on bailment duties",
        "Assemble exhibit list with stipulated exhibits",
    ],
    "Fee Petition": [
        "Compile contemporaneous time records for fee petition",
        "Draft declaration of lead counsel on rates",
    ],
}
BLOCK = [
    "Draft discovery responses; confer with client; review production; email opposing counsel",
    "Prepare for deposition, review exhibits, call with expert, update chronology",
    "Research sanctions standard; revise motion; call with T. Brandvold; calendar review",
    "Review emails; update tracker; draft letter; team meeting",
]
VAGUE = ["Attention to file", "Review documents", "Work on case", "Research", "Various matters", "Case management", "Prep"]

rows = []
d = date(2026, 1, 12)
eid = 0


def add(dt, tk, hours, phase, narr, rate=None):
    global eid
    eid += 1
    rows.append({"entry_id": f"E{eid:04d}", "date": dt.isoformat(), "timekeeper": tk,
                 "role": TK[tk][0], "rate": rate if rate is not None else TK[tk][1],
                 "hours": f"{hours:.1f}", "phase": phase, "narrative": narr})


weights = {"Priya Ramanathan": 3, "Marcus Odell": 2, "Elena Vasquez-Hart": 6, "Joel Pruitt": 4}
pool = [k for k, w in weights.items() for _ in range(w)]
for i in range(110):
    tk = rnd.choice(pool)
    phase = rnd.choice(list(SPECIFIC))
    dt = d + timedelta(days=rnd.randint(0, 150))
    hours = rnd.choice([0.4, 0.7, 1.0, 1.3, 1.8, 2.5, 3.2, 4.0, 5.5, 6.8])
    if tk == "Joel Pruitt":
        hours = min(hours, 4.0)
    add(dt, tk, hours, phase, rnd.choice(SPECIFIC[phase]))
# plant the issues
rows[7].update(narrative=BLOCK[0], hours="6.5", phase="Discovery")
rows[19].update(narrative=BLOCK[1], hours="7.2", phase="Depositions")
rows[33].update(narrative=BLOCK[2], hours="5.8", phase="Motions")
rows[48].update(narrative=BLOCK[3], hours="4.1", phase="Pleadings")
for idx, v in zip([12, 27, 41, 60, 75, 90], VAGUE):
    rows[idx].update(narrative=v)
rows[55].update(rate=480)                                  # rate that differs from the timekeeper's usual rate
rows.append(dict(rows[22]))                                # exact duplicate entry (same id)
rows[22 + 0]["hours"] = rows[22]["hours"]
rows.append({**rows[5], "entry_id": "E0999", "hours": "0.0"})  # zero hours
rows.append({"entry_id": "E1000", "date": "2026-03-03", "timekeeper": "Elena Vasquez-Hart", "role": "Associate",
             "rate": 510, "hours": "13.5", "phase": "Motions", "narrative": "Draft motion to compel; finalize exhibits for filing"})
fields = list(rows[0].keys())
with open(HERE / "sample-time-entries.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
print(len(rows), "rows")
