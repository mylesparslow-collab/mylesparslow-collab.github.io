import csv
import json
from decimal import Decimal
from pathlib import Path

import pytest

import lodestar as ld

HERE = Path(__file__).resolve().parent


def r(eid="E1", date="2026-01-05", tk="Ann Atty", role="Partner", rate="500", hours="2.0", phase="Pleadings",
      narr="Draft complaint section on breach of contract"):
    d = {"entry_id": eid, "date": date, "timekeeper": tk, "role": role, "rate": rate, "hours": hours,
         "phase": phase, "narrative": narr}
    d["_rate"], d["_hours"] = Decimal(rate), Decimal(hours)
    d["_amount"] = ld.money(d["_rate"] * d["_hours"])
    return d


def test_lodestar_math_exact():
    res = ld.compute([r(hours="1.3", rate="725"), r("E2", tk="Bo Para", role="Paralegal", rate="235", hours="0.7")])
    assert res["grand_total"] == Decimal("942.50") + Decimal("164.50")
    assert res["by_timekeeper"]["Ann Atty"]["lodestar"] == Decimal("942.50")
    assert res["errors"] == 0


def test_views_reconcile():
    rows = [r("E1"), r("E2", phase="Motions", hours="3.3"), r("E3", tk="Bo", rate="200", phase="Motions")]
    res = ld.compute(rows)
    assert sum(v["amount"] for v in res["by_phase"].values()) == res["grand_total"]
    assert sum(res["matrix"].values()) == res["grand_total"]
    assert all(c["result"] == "PASS" for c in res["checks"] if c["severity"] == "ERROR")


def test_block_billing_detection():
    assert ld.is_block_billed("Draft motion; call client; email counsel")
    assert ld.is_block_billed("(1) review production (2) call expert")
    assert ld.is_block_billed("Review emails, update tracker, draft letter")
    assert not ld.is_block_billed("Review and revise opposition to demurrer")


def test_vague_detection():
    assert ld.is_vague("Attention to file")
    assert ld.is_vague("Review documents")
    assert ld.is_vague("Research")
    assert not ld.is_vague("Research choice-of-law clause in carrier agreement")


def test_flags_are_not_applied():
    res = ld.compute([r(narr="Attention to file"), r("E2", narr="Draft complaint count; call client")])
    assert len(res["flagged"]) == 2
    assert res["reductions_applied"] == "NONE"
    assert res["grand_total"] == Decimal("2000.00")  # unchanged by flags


def test_rate_mismatch_fails():
    res = ld.compute([r(), r("E2", rate="480")])
    assert any(c["check"] == "One rate per timekeeper" and c["result"] == "FAIL" for c in res["checks"])


def test_duplicate_id_and_zero_hours_fail():
    res = ld.compute([r(), r(), r("E3", hours="0.0")])
    failed = {c["check"] for c in res["checks"] if c["result"] == "FAIL"}
    assert "No duplicate entry ids" in failed
    assert "Every entry has hours above 0 and at most 24" in failed


def test_day_over_24_fails_and_over_12_warns():
    res = ld.compute([r("E1", hours="12.5"), r("E2", hours="12.0", phase="Motions")])
    names = {c["check"]: c["result"] for c in res["checks"]}
    assert names["No timekeeper-day over 24 hours"] == "FAIL"
    res = ld.compute([r("E1", hours="7.0"), r("E2", hours="6.0", phase="Motions")])
    names = {c["check"]: c["result"] for c in res["checks"]}
    assert names["Timekeeper-days over 12 hours (for a person to look at)"] == "WARN"
    assert res["errors"] == 0


def test_stated_total_mismatch():
    rows = [r()]
    assert ld.compute(rows, stated_total=Decimal("1000.00"))["errors"] == 0
    res = ld.compute(rows, stated_total=Decimal("999.00"))
    assert res["errors"] == 1


def test_period_check():
    res = ld.compute([r(date="2025-12-31")], period=("2026-01-01", "2026-12-31"))
    assert res["errors"] == 1


def test_load_rejects_missing_column(tmp_path):
    p = tmp_path / "x.csv"
    p.write_text("entry_id,date\nE1,2026-01-01\n")
    with pytest.raises(ValueError, match="missing columns"):
        ld.load(p)


def test_sample_end_to_end(tmp_path):
    rc = ld.main([str(HERE / "sample-time-entries.csv"), "--out-dir", str(tmp_path)])
    s = json.loads((tmp_path / "lodestar_summary.json").read_text())
    assert s["entries"] == 113
    assert rc == 1  # the sample plants a rate mismatch, duplicate id and zero-hour row on purpose
    failed = {c["check"] for c in s["checks"] if c["result"] == "FAIL"}
    assert failed == {"One rate per timekeeper", "No duplicate entry ids",
                      "Every entry has hours above 0 and at most 24"}
    assert len(s["flagged"]) == 11
    assert Decimal(s["grand_total"]) == Decimal("164816.50")
    rows = list(csv.DictReader(open(HERE / "sample-time-entries.csv")))
    assert sum(Decimal(x["rate"]) * Decimal(x["hours"]) for x in rows) == Decimal(s["grand_total"])
