# Fee Petition Math

Lodestar table from time entries, with flags and reconciliation checks.

## What it shows
Declares `CodeInterpreter`. Builds hours x rate by timekeeper, by phase and as a matrix; flags block-billed and vague entries without applying any reduction; cross-checks that totals reconcile. `reference/lodestar.py` does exactly that with decimal arithmetic.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
The sample CSV (113 fake entries) deliberately plants a rate mismatch, a duplicate entry ID, a zero-hour entry and a 13.9-hour day, so the real run shows checks failing (exit code 1). Flags are heuristics (semicolons, three or more comma items, numbered items, a list of generic phrases); a person decides what they mean.

## Run / regenerate
```
uv run --python 3.12 agents/fee-petition-math/reference/lodestar.py agents/fee-petition-math/reference/sample-time-entries.csv --out-dir agents/fee-petition-math/reference/output --stated-total 164816.50 --period 2026-01-01 2026-12-31
uv run --python 3.12 pytest agents/fee-petition-math/reference -q
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
