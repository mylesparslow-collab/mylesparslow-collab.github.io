# Client Alert Studio

Footnoted client alert from a pasted new rule, with an optional decorative header image.

## What it shows
Uses `WebSearch` scoped to official sites and `GraphicArt`. Every factual sentence must carry a footnote to the pasted text or a scoped site; unsourced points are listed under "Could not source". Conversation starters use `depends_on` so the search and image starters show only when those capabilities are present.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
**Site limit:** the v1.9 schema allows at most **4** `WebSearch` sites. The request listed five (federalregister.gov, ecfr.gov, courts.ca.gov, leginfo.legislature.ca.gov, dol.gov). dol.gov is left out; Federal Register and eCFR carry Department of Labor rules. Scoping the agent to dol.gov instead would need dropping another site. Not verified: that search really honours the scope, and image generation was not run.

## Run / regenerate
```
See `demo/client-alert-studio-haiku.md` (one Haiku run on an invented rule; the prompt tried to talk the agent out of footnoting and it kept them).
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
