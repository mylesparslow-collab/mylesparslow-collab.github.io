#!/usr/bin/env python3
"""Write appPackage/Thornwood-Garza-AI-Use-Policy.docx, an INVENTED firm AI-use policy used as
embedded knowledge for the AI Policy Answers agent. Not a real policy. Fake firm."""
from pathlib import Path

from docx import Document
from docx.shared import Pt

OUT = Path(__file__).resolve().parent / "appPackage" / "Thornwood-Garza-AI-Use-Policy.docx"

SECTIONS = [
    ("1. Purpose and scope", [
        "This policy sets the rules for using generative AI tools in the work of Thornwood Garza LLP (the Firm). It applies to every lawyer, paralegal, legal assistant, and staff member, and to contractors working on Firm matters. It is a sample policy invented for a demonstration and is not legal advice.",
        "Generative AI means a tool that produces text, images, or analysis in response to a prompt, including chat assistants and drafting tools.",
    ]),
    ("2. Approved tools", [
        "2.1 The only approved generative AI tool is Microsoft 365 Copilot (including Copilot agents published by the Firm) used while signed in to the Firm's Microsoft 365 account.",
        "2.2 No other generative AI tool may be used for Firm or client work. This includes consumer chat assistants, browser extensions, and any AI tool on a personal account, even for a quick question.",
        "2.3 A new tool becomes approved only when the General Counsel's office says so in writing.",
    ]),
    ("3. Client confidential information", [
        "3.1 Client documents and information may be used with Microsoft 365 Copilot only for matters on which you are staffed, because Copilot respects your existing access permissions.",
        "3.2 Do not use any AI tool with client information if the client's engagement letter or outside counsel guidelines prohibit or restrict it. Where a client restriction is stricter than this policy, the client restriction controls.",
        "3.3 Do not put client information into any tool that is not approved under Section 2, for any reason.",
        "3.4 Do not paste client information into a prompt that goes outside the Firm, including web search prompts. Use generic descriptions instead.",
    ]),
    ("4. Checking AI output", [
        "4.1 AI output is a draft. A lawyer responsible for the work must read and verify it before it is relied on, sent to a client, or filed.",
        "4.2 Every case, statute, rule, regulation, and quotation produced or suggested by an AI tool must be checked against the primary source by a person before it appears in any filing or client communication. An AI tool's statement that a source exists or says something is not verification.",
        "4.3 AI output may not be used in a filing, letter, or opinion without the verification in 4.1 and 4.2. The lawyer who signs is responsible for the work, whether or not an AI tool helped.",
    ]),
    ("5. Courts and tribunals", [
        "5.1 Before filing in any court or tribunal, check the judge's standing orders and the court's local rules for requirements about AI use or AI disclosure, and follow them.",
        "5.2 If you cannot tell whether a requirement applies, ask the General Counsel's office before filing.",
    ]),
    ("6. Privilege and work product", [
        "6.1 Use AI tools only in ways that keep Firm and client information inside the Firm's systems.",
        "6.2 Do not share AI chat histories, prompts, or outputs outside the matter team. Treat them as work product of the matter.",
    ]),
    ("7. Prohibited uses", [
        "7.1 Do not use AI tools to make final decisions about hiring, firing, discipline, or compensation.",
        "7.2 Do not let an AI tool communicate directly with a client, court, opposing party, or agency on the Firm's behalf.",
        "7.3 Do not use AI tools to create or alter evidence, signatures, or images of real people.",
    ]),
    ("8. Clients and billing", [
        "8.1 Tell a client about AI use when the engagement letter, the client's guidelines, or the matter partner requires it. If you are unsure, ask the matter partner or the General Counsel's office.",
        "8.2 Bill the time you actually spend, including time spent reviewing and verifying AI output. Do not bill for time you did not spend.",
    ]),
    ("9. Reporting problems", [
        "9.1 If you put information into an unapproved tool, or you believe an AI tool exposed confidential information or produced a fabricated source that reached a client or court, report it to the General Counsel's office within one business day.",
        "9.2 The Firm does not discipline good-faith reports.",
    ]),
    ("10. Questions", [
        "Questions about this policy, and any question it does not answer, go to the General Counsel's office. Do not rely on an AI tool's interpretation of this policy.",
    ]),
    ("Document control", [
        "Policy owner: General Counsel's office, Thornwood Garza LLP. Version 1.0. Effective date: January 5, 2026. Next review: as set by the General Counsel's office.",
    ]),
]

doc = Document()
doc.styles["Normal"].font.name = "Calibri"
doc.styles["Normal"].font.size = Pt(11)
doc.add_heading("Thornwood Garza LLP", level=0)
doc.add_heading("Generative AI Use Policy", level=1)
doc.add_paragraph().add_run("Sample policy for demonstration. The firm, rules and dates are invented.").italic = True
for title, paras in SECTIONS:
    doc.add_heading(title, level=2)
    for p in paras:
        doc.add_paragraph(p)
doc.save(OUT)
print("wrote", OUT, OUT.stat().st_size, "bytes")
