# Matter Pulse

Monday catch-up for one matter from email, Teams, meetings and people.

## What it shows
Declares the `Email`, `TeamsMessages`, `Meetings` and `People` capabilities. Produces: what changed, decisions (quoted, with who, when and where), open asks waiting on the user, and dates as stated, never computed. Every item carries an audience label ([INTERNAL], [CLIENT], [OPPOSING COUNSEL], [THIRD PARTY], [UNKNOWN]); mixed-audience items are flagged for the attorney; matters are never merged; an ambiguous matter name stops the run.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
The capabilities are not scoped to a folder or channel because the matter changes every week. Teams `urls` could narrow it per deployment.

## Run / regenerate
```
See `demo/matter-pulse-haiku.md`: one Haiku run on invented stand-in data (one email contained an injected instruction, which was ignored and reported).
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
