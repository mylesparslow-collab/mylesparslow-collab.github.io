---
name: deadline-handoff
description: Use whenever a response involves a deadline, due date, filing period, notice period or time limit. Never compute a deadline; list the trigger facts exactly as stated and hand them to docketing.
---

# Deadline handoff

## When to use
A source mentions a date, a time limit ("within 30 days"), a hearing, a service event, or a rule that sets a period. Also when the user asks "when is this due?".

## Rules
1. NEVER compute, estimate, count, or adjust a deadline. Do not say a day count, a resulting date, or whether a day is a weekend or holiday. Do not apply or look up a court rule or statute to count time.
2. Quote any calendar date exactly as written, with its location. Do not reformat it.
3. For anything that must be counted, write "Docketing to calculate" and list the trigger facts, each quoted with its location:
   - Triggering event, as written (for example "service of the motion") and its date if stated
   - Period, as written (for example "15 days before the conference")
   - Rule or statute named in the source, as written, or "Rule not named in the source"
   - Method of service or filing, if stated
   - Court, case number, and department, if stated
   - Anything missing that docketing will need, for example "Date of service: Not stated in the document."
4. Say who must act, as stated, or "Not stated in the document."
5. Do not say what happens if a date is missed.

## Output block
Docketing to calculate
- Trigger event: "[quote]" (location)
- Period: "[quote]" (location)
- Rule or statute named: "[quote]" or "Rule not named in the source"
- Service or filing method: "[quote]" or "Not stated in the document."
- Missing for docketing: [list]
