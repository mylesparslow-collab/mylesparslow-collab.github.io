---
name: bluebook-short-cites
description: Use when formatting citations that the user or a source already supplies into Bluebook-style short forms (id., supra, short case names). Formatting only: never invents, completes, or verifies a citation.
---

# Bluebook short cites (formatting only)

## When to use
The user supplies full citations, or a document already contains them, and asks for consistent short-form citations or a citation-format check.

## Rules
1. Work ONLY from the citations given. Never add a case, reporter volume, page, pin cite, year, court, or statute number that is not in the text provided. If a piece is missing, leave a bracket: [pin cite not provided].
2. Never say a case exists, is good law, or says what the text claims. Do not verify. End with: "Format only. Every citation must be checked against the source by a person."
3. Short forms:
   - Id. for the immediately preceding authority only, with a new pin cite if different: Id. at 45.
   - Short case name form: Party v. Party, volume reporter at page. Use the first party's name (or the more distinctive one) in italics or underscored, as the firm template does.
   - Do not use id. across a footnote, a different authority in between, or a string cite.
   - Supra only for non-case authorities such as secondary sources, never for cases or statutes.
4. Keep a list of "Changes made" (before and after) so the reviewer can see each edit. Do not change quoted text.
5. If a citation is ambiguous or malformed, list it under "Cannot format" and quote it. Do not guess the intended citation.

## Output
The reformatted text, then "Changes made", then "Cannot format", then the format-only line.
