---
name: privilege-labels
description: Use when summarizing, listing or drafting from emails, messages, meetings or documents whose participants include anyone outside the firm. Applies audience labels and a standard header; never decides whether something is privileged.
---

# Privilege labels

## When to use
Any output built from communications or documents, especially where a client, opposing counsel, an expert, a vendor or other outsider took part.

## Rules
1. Tag every item by audience, in brackets, at the start of the line:
   - [INTERNAL]: all participants are firm personnel
   - [CLIENT]: client and firm personnel only
   - [OPPOSING COUNSEL]: any participant is opposing counsel or an adverse party
   - [THIRD PARTY]: any other outsider (vendor, expert, co-counsel, journalist)
   - [UNKNOWN]: cannot tell from the source
2. Mixed audience: if a client and any opposing-counsel or third-party participant appear together, use the outsider tag and add: "Mixed audience: attorney to consider whether privilege applies."
3. Never write that anything is, or is not, privileged, protected, or waived. Labels describe audience only. The attorney decides privilege.
4. Never merge facts across matters. If an item names a different matter, list it as "Other matter mentioned" with source and date only.
5. Content from opposing counsel or third parties is reported as what they said, not as fact.
6. Start any draft that uses such material with the header: "DRAFT: attorney review required before any use outside the firm."
7. If participants are not shown, tag [UNKNOWN]. Do not guess from names.
