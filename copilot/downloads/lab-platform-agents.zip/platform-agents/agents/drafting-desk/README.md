# Drafting Desk

First drafts that follow four attached house-style skills.

## What it shows
Uses the v1.9 `agent_skills` property (four skills), a `sensitivity_label` placeholder (all-zero GUID), and `user_overrides` that let each user remove `WebSearch` with a toggle. The skills live in `agents/house-style/skills/` and are copied into `appPackage/skills/` by `tools/sync_skills.py`; a test keeps the copies identical.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
The sensitivity label GUID is a placeholder; Microsoft Learn says labels apply only when embedded files are used and the property is not enabled yet. This agent has no embedded files, so it has no effect today. Skills are loaded by the platform (name and description first, body on demand); the Haiku smoke run pasted the skill bodies into the system prompt as a stand-in.

## Run / regenerate
```
uv run --python 3.12 tools/sync_skills.py   # from the lab root
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
