# House Style skills pack

Four reusable agent skills for the v1.9 `agent_skills` property, each a folder with a `SKILL.md`:
`verbatim-quote-rule`, `deadline-handoff` (never compute; hand the trigger facts to docketing), `bluebook-short-cites` (formatting only, never invents or verifies a cite), `privilege-labels` (audience labels, never a privilege conclusion).

## Format used
Each `SKILL.md` starts with YAML frontmatter holding `name` (lowercase letters, digits, hyphens; same as the folder name) and `description` (what it does and when to use it), then Markdown instructions.
Sources: Microsoft Learn, [Declarative agent schema 1.9](https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/declarative-agent-manifest-1.9) (the "Agent skill object": a folder containing `SKILL.md`, following the Agent Skills standard, at most 8 skills, relative path, no `../`). Microsoft Learn does not publish a SKILL.md field list for Copilot agents that I could find; the `name`/`description` frontmatter and the rule that the name matches the folder come from the Copilot Camp lab [Skills in Agent Builder](https://microsoft.github.io/copilot-camp/pages/extend-m365-copilot/12-skills-da-agent-builder/) and the open Agent Skills convention, so treat those two as secondary sources. Microsoft Learn also documents `SKILL.md` for GitHub Copilot in Visual Studio ([Copilot agent skills](https://learn.microsoft.com/visualstudio/ide/copilot-agent-skills)), which is a different product.

## Use
`agents/drafting-desk/appPackage/skills/` holds copies (a package must be self-contained). Edit here, then `uv run --python 3.12 tools/sync_skills.py` from the lab root. A test fails if the copies drift.
