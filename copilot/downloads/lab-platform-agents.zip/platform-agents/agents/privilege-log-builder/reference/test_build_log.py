import csv
import json
from pathlib import Path

import pytest
from openpyxl import load_workbook

import build_log as bl

HERE = Path(__file__).resolve().parent
DOMAINS = ["firm.example", "client.example"]
ATT = {"pa@firm.example": "Pat Attorney"}


def row(cn, frm="", to="", cc="", subj="", typ="Email", md5=None, parent="", fname="", date="2026-01-01", bcc=""):
    return {"control_no": cn, "doc_date": date, "doc_type": typ, "custodian": "x", "from": frm, "to": to,
            "cc": cc, "bcc": bcc, "subject": subj, "file_name": fname, "md5": md5 or cn, "parent_control_no": parent}


A = "Pat Attorney <pa@firm.example>"
C = "Cleo Client <cc@client.example>"


def test_parse_people():
    assert bl.parse_people("Pat A <PA@Firm.example>; bare@x.example") == [
        ("Pat A", "pa@firm.example"), ("bare@x.example", "bare@x.example")]


def test_norm_subject_strips_prefixes():
    assert bl.norm_subject("RE: Fwd:  Re: Hello   World") == "hello world"


def test_dedup_keeps_lowest_and_records_copies():
    rows = [row("A1", A, C, md5="same"), row("A2", A, C, md5="same"), row("A3", A, C, md5="other")]
    r = bl.build(rows, ATT, DOMAINS)
    assert r["summary"]["documents_kept_after_dedup"] == 2
    assert [(d["control_no"], k) for d, k in r["collapsed"]] == [("A2", "A1")]
    assert r["summary"]["reconciles"]


def test_family_dedup_and_attachment_followed():
    rows = [row("P1", A, C, md5="m"), row("X1", typ="Attachment", md5="att", parent="P1", fname="f.docx"),
            row("P2", A, C, md5="m"), row("X2", typ="Attachment", md5="att", parent="P2", fname="f.docx")]
    r = bl.build(rows, ATT, DOMAINS)
    assert r["summary"]["documents_kept_after_dedup"] == 2
    assert {d["control_no"] for d, _ in r["collapsed"]} == {"P2", "X2"}
    assert {e["Control No."] for e in r["log"]} == {"P1", "X1"}
    x1 = next(e for e in r["log"] if e["Control No."] == "X1")
    assert x1["Family ID"] == "P1" and "FAMILY MEMBER" in x1["Review Flags"]


def test_same_attachment_in_different_family_is_not_collapsed():
    rows = [row("P1", A, C, md5="m1"), row("X1", typ="Attachment", md5="att", parent="P1"),
            row("P2", A, C, md5="m2"), row("X2", typ="Attachment", md5="att", parent="P2")]
    r = bl.build(rows, ATT, DOMAINS)
    assert r["summary"]["documents_collapsed_as_copies"] == 0


def test_threading_groups_by_subject():
    rows = [row("1", A, C, subj="Plan", date="2026-01-01"), row("2", C, A, subj="RE: Plan", date="2026-01-02"),
            row("3", A, C, subj="Other", date="2026-01-03")]
    r = bl.build(rows, ATT, DOMAINS)
    t = {e["Control No."]: e["Thread ID"] for e in r["log"]}
    assert t["1"] == t["2"] != t["3"]
    assert r["summary"]["threads"] == 2


def test_mixed_recipient_is_review_not_candidate():
    rows = [row("1", A, C, cc="Out Sider <o@third.example>")]
    e = bl.build(rows, ATT, DOMAINS)["log"][0]
    assert e["Status"].startswith("REVIEW")
    assert "o@third.example" in e["Outside Participants"]


def test_all_inside_is_candidate():
    e = bl.build([row("1", A, C)], ATT, DOMAINS)["log"][0]
    assert e["Status"].startswith("CANDIDATE") and e["Attorneys Involved"] == "Pat Attorney"


def test_bcc_attorney_counts():
    e = bl.build([row("1", C, C, bcc=A)], ATT, DOMAINS)["log"]
    assert len(e) == 1


def test_legal_title_is_not_an_attorney():
    rows = [row("1", "Dana W (Director of Legal Operations) <dw@client.example>", C),
            row("2", "Harborline Legal Department <legal@client.example>", C)]
    r = bl.build(rows, ATT, DOMAINS)
    assert r["log"] == []
    assert len(r["legal_word"]) == 2


def test_legal_word_flag_on_log_rows():
    rows = [row("1", "Legal Dept <legal@client.example>", A)]
    e = bl.build(rows, ATT, DOMAINS)["log"][0]
    assert "LEGAL WORD BUT NOT ON ATTORNEY LIST" in e["Review Flags"]


def test_decision_columns_blank():
    e = bl.build([row("1", A, C)], ATT, DOMAINS)["log"][0]
    assert all(e[c] == "" for c in bl.DECISION_COLUMNS)


def test_dates_carried_verbatim():
    e = bl.build([row("1", A, C, date="2026-03-05")], ATT, DOMAINS)["log"][0]
    assert e["Date"] == "2026-03-05"


def test_orphan_attachment_not_dropped():
    r = bl.build([row("X", typ="Attachment", parent="MISSING", fname="a.pdf")], ATT, DOMAINS)
    assert r["summary"]["orphan_attachments"] == ["X"] and r["summary"]["reconciles"]


def test_duplicate_control_numbers_rejected():
    with pytest.raises(ValueError):
        bl.build([row("1", A, C), row("1", A, C)], ATT, DOMAINS)


def test_sample_export_end_to_end(tmp_path):
    rc = bl.main([str(HERE / "sample-export.csv"), "--attorneys", str(HERE / "attorneys.csv"),
                  "--domains", "thornwoodgarza.example", "harborline-freight.example", "--out-dir", str(tmp_path)])
    assert rc == 0
    s = json.loads((tmp_path / "summary.json").read_text())
    assert s["rows_in_export"] == 155 and s["reconciles"]
    assert s["documents_collapsed_as_copies"] > 0
    assert s["log_review_outside_participant"] > 0
    log = list(csv.DictReader(open(tmp_path / "privilege_log.csv")))
    assert len(log) == s["log_entries"]
    # trap: nothing sent only by the Director of Legal Operations / legal@ mailbox without an attorney is logged
    for r in log:
        assert r["Attorneys Involved"]
    # the consultant-copied email is flagged
    assert any("rkessel@redcliffe-consulting.example" in r["Outside Participants"] for r in log)
    wb = load_workbook(tmp_path / "privilege_log.xlsx")
    assert wb.sheetnames == ["Privilege Log", "Copies Collapsed", "Not Logged (no attorney)",
                             "Legal Word, Not Attorney", "Summary"]
