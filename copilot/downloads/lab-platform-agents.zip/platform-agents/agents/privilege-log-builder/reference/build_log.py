#!/usr/bin/env python3
"""Deterministic privilege-log builder: exactly what the agent's instructions ask the
Copilot code interpreter to do.

  build_log.py EXPORT.csv --attorneys attorneys.csv --domains firm.example client.example \
      --out-dir OUT [--summary-json]

Steps (the same ones, in the same order, as in instructions.txt):
 1. Read the export. Parse every address out of from/to/cc/bcc.
 2. Group parent + attachments into families (parent_control_no).
 3. De-duplicate at family level: identical family = same parent hash + same sorted
    attachment hashes. Keep the lowest control number; record the copies.
 4. Thread emails by subject with Re:/RE:/Fwd:/FW: prefixes stripped. Attachments take
    their parent's thread.
 5. Flag attorneys by exact e-mail match against the supplied list. A title or a word
    such as "Legal" in a name or address NEVER makes someone an attorney.
 6. Anyone outside the supplied privileged domains is an outside participant. A document
    with an attorney and an outside participant is marked REVIEW, not CANDIDATE.
 7. Write the log (CSV and XLSX) with the basis columns blank for the attorney, plus
    sheets that show what was collapsed and what was left off the log.
 8. Reconcile: input rows == kept + collapsed. Exit non-zero if not.

Dates are carried through exactly as exported; nothing is computed from them except
ordering the ISO strings. The tool never decides privilege."""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ADDR = re.compile(r"<([^<>@\s]+@[^<>\s]+)>|([^<>;,\s]+@[^<>;,\s]+)")
PREFIX = re.compile(r"^\s*((re|fw|fwd)\s*:\s*)+", re.I)
LEGALISH = re.compile(r"\b(legal|counsel|attorney|law|lawyer|esq)\b", re.I)

DECISION_COLUMNS = ["Privilege Type (AC / WP / Other)", "Basis for Privilege Claim",
                    "Description for Log (attorney to write)", "Decision (Withhold / Produce / Redact)"]
LOG_COLUMNS = ["Log No.", "Control No.", "Family ID", "Thread ID", "Date", "Doc Type", "Author",
               "To", "CC", "BCC", "Attorneys Involved", "Outside Participants",
               "Subject or File Name (as exported; attorney to confirm it reveals nothing privileged)",
               "Copies Collapsed", "Status", "Review Flags"] + DECISION_COLUMNS


def parse_people(field: str) -> list[tuple[str, str]]:
    """Return [(display, address_lowercase)] from 'Name <a@b>; Name2 <c@d>'."""
    out = []
    for part in re.split(r";", field or ""):
        part = part.strip()
        if not part:
            continue
        m = ADDR.search(part)
        if not m:
            continue
        addr = (m.group(1) or m.group(2)).lower()
        display = part.replace(m.group(0), "").strip(" <>\"'")
        out.append((display or addr, addr))
    return out


def norm_subject(s: str) -> str:
    return re.sub(r"\s+", " ", PREFIX.sub("", s or "")).strip().lower()


def load_attorneys(path: Path) -> dict[str, str]:
    with open(path, newline="", encoding="utf-8") as fh:
        return {r["email"].strip().lower(): r["name"].strip() for r in csv.DictReader(fh)}


def build(rows: list[dict], attorneys: dict[str, str], domains: list[str]) -> dict:
    domains = [d.lower() for d in domains]
    by_cn = {r["control_no"]: r for r in rows}
    if len(by_cn) != len(rows):
        raise ValueError("duplicate control numbers in the export")

    # 2. families
    children = defaultdict(list)
    orphans = []
    for r in rows:
        p = r.get("parent_control_no", "").strip()
        if p:
            if p in by_cn:
                children[p].append(r)
            else:
                orphans.append(r)
    family_of = {}
    families = []  # list of lists, parent first
    for r in rows:
        if r.get("parent_control_no", "").strip() in by_cn:
            continue
        fam = [r] + sorted(children.get(r["control_no"], []), key=lambda x: x["control_no"])
        families.append(fam)
        for d in fam:
            family_of[d["control_no"]] = fam[0]["control_no"]

    # 3. family-level de-dup
    seen: dict[tuple, list] = {}
    for fam in sorted(families, key=lambda f: f[0]["control_no"]):
        key = (fam[0]["md5"], tuple(sorted(d["md5"] for d in fam[1:])))
        seen.setdefault(key, []).append(fam)
    kept_fams, collapsed = [], []  # collapsed: (dup_doc, kept_cn)
    copies = {}
    for fams in seen.values():
        keeper = fams[0]
        kept_fams.append(keeper)
        copies[keeper[0]["control_no"]] = [f[0]["control_no"] for f in fams[1:]]
        for f in fams[1:]:
            for d, k in zip(f, keeper):
                collapsed.append((d, k["control_no"]))

    # 4. threads (by earliest kept parent date, then control number)
    kept_fams.sort(key=lambda f: (f[0]["doc_date"], f[0]["control_no"]))
    thread_ids, thread_members = {}, defaultdict(list)
    for fam in kept_fams:
        if fam[0]["doc_type"].lower() == "email":
            ns = norm_subject(fam[0]["subject"])
            thread_ids.setdefault(ns, f"T{len(thread_ids) + 1:03d}")
            thread_members[ns].append(fam[0]["control_no"])

    log, off_log, legal_word = [], [], []
    for fam in kept_fams:
        parent = fam[0]
        people = {"from": parse_people(parent["from"]), "to": parse_people(parent["to"]),
                  "cc": parse_people(parent["cc"]), "bcc": parse_people(parent["bcc"])}
        everyone = {}
        for role in people.values():
            for disp, addr in role:
                everyone.setdefault(addr, disp)
        atts = sorted({attorneys[a] for a in everyone if a in attorneys})
        outside = sorted(f"{d} <{a}>" for a, d in everyone.items()
                         if a.rsplit("@", 1)[-1] not in domains)
        lw = sorted(f"{d} <{a}>" for a, d in everyone.items()
                    if a not in attorneys and LEGALISH.search(f"{d} {a}"))
        tid = thread_ids.get(norm_subject(parent["subject"]), "") if parent["doc_type"].lower() == "email" else ""
        for d in fam:
            is_member = d is not parent
            flags = []
            if is_member:
                flags.append("FAMILY MEMBER of " + parent["control_no"])
            if outside:
                flags.append("OUTSIDE PARTICIPANT: " + "; ".join(outside))
            if lw:
                flags.append("LEGAL WORD BUT NOT ON ATTORNEY LIST: " + "; ".join(lw))
            if tid and len(thread_members[norm_subject(parent["subject"])]) > 1 and not is_member:
                flags.append(f"THREAD {tid} has {len(thread_members[norm_subject(parent['subject'])])} messages")
            if copies.get(d["control_no"]):
                flags.append("COPIES COLLAPSED: " + ", ".join(copies[d["control_no"]]))
            rec = {
                "Control No.": d["control_no"], "Family ID": family_of[d["control_no"]],
                "Thread ID": tid, "Date": d["doc_date"], "Doc Type": d["doc_type"],
                "Author": parent["from"],
                "To": parent["to"], "CC": parent["cc"], "BCC": parent["bcc"],
                "Attorneys Involved": "; ".join(atts), "Outside Participants": "; ".join(outside),
                "Subject or File Name (as exported; attorney to confirm it reveals nothing privileged)":
                    d["file_name"] or d["subject"],
                "Copies Collapsed": len(copies.get(d["control_no"], [])),
                "Review Flags": " | ".join(flags),
            }
            if atts:
                rec["Status"] = ("REVIEW: outside participant (possible loss of privilege; attorney decides)"
                                 if outside else "CANDIDATE (attorney involved; attorney decides)")
                log.append(rec)
            else:
                rec["Status"] = "No attorney on the list: not logged"
                off_log.append(rec)
                if lw:
                    legal_word.append(rec)
    log.sort(key=lambda r: (r["Date"], r["Control No."]))
    for i, r in enumerate(log, 1):
        r["Log No."] = f"PL-{i:04d}"
        for c in DECISION_COLUMNS:
            r[c] = ""
    kept_docs = sum(len(f) for f in kept_fams)
    summary = {
        "rows_in_export": len(rows), "families": len(families), "orphan_attachments": [o["control_no"] for o in orphans],
        "documents_kept_after_dedup": kept_docs, "documents_collapsed_as_copies": len(collapsed),
        "threads": len(thread_ids), "log_entries": len(log),
        "log_candidates": sum(1 for r in log if r["Status"].startswith("CANDIDATE")),
        "log_review_outside_participant": sum(1 for r in log if r["Status"].startswith("REVIEW")),
        "kept_without_attorney": len(off_log), "legal_word_not_attorney_docs": len(legal_word),
        # orphan attachments are processed as one-document families, so none are dropped
        "reconciles": len(rows) == kept_docs + len(collapsed),
    }
    return {"log": log, "collapsed": collapsed, "off_log": off_log, "legal_word": legal_word,
            "summary": summary, "kept_fams": kept_fams}


def write_outputs(res: dict, out_dir: Path) -> list[Path]:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "privilege_log.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=LOG_COLUMNS)
        w.writeheader()
        w.writerows(res["log"])
    wb = Workbook()
    ws = wb.active
    ws.title = "Privilege Log"

    def sheet(ws, cols, rows):
        ws.append(cols)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in rows:
            ws.append([r.get(c, "") for c in cols])
        ws.freeze_panes = "A2"
        for i, col in enumerate(cols, 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = min(48, max(12, len(col) // 2 + 6))

    sheet(ws, LOG_COLUMNS, res["log"])
    amber = PatternFill("solid", fgColor="FFF2CC")
    blank = PatternFill("solid", fgColor="E7E6E6")
    for row in ws.iter_rows(min_row=2):
        status = row[LOG_COLUMNS.index("Status")].value or ""
        for c in row:
            if c.column > len(LOG_COLUMNS) - len(DECISION_COLUMNS):
                c.fill = blank
        if status.startswith("REVIEW"):
            for c in row[:len(LOG_COLUMNS) - len(DECISION_COLUMNS)]:
                c.fill = amber
    ws2 = wb.create_sheet("Copies Collapsed")
    sheet(ws2, ["Copy Control No.", "Kept Control No.", "Custodian of Copy", "Date"],
          [{"Copy Control No.": d["control_no"], "Kept Control No.": k, "Custodian of Copy": d["custodian"],
            "Date": d["doc_date"]} for d, k in res["collapsed"]])
    cols3 = ["Control No.", "Family ID", "Date", "Doc Type", "Author", "To", "CC", "Review Flags"]
    ws3 = wb.create_sheet("Not Logged (no attorney)")
    sheet(ws3, cols3, res["off_log"])
    ws4 = wb.create_sheet("Legal Word, Not Attorney")
    sheet(ws4, cols3, res["legal_word"])
    ws5 = wb.create_sheet("Summary")
    ws5.append(["Measure", "Value"])
    for k, v in res["summary"].items():
        ws5.append([k, json.dumps(v) if isinstance(v, list) else v])
    ws5.append([])
    ws5.append(["Note", "Basis and decision columns are blank on purpose. An attorney must review before anyone relies on this log."])
    xlsx_path = out_dir / "privilege_log.xlsx"
    wb.save(xlsx_path)
    sj = out_dir / "summary.json"
    sj.write_text(json.dumps(res["summary"], indent=2) + "\n")
    return [csv_path, xlsx_path, sj]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("export", type=Path)
    ap.add_argument("--attorneys", type=Path, required=True)
    ap.add_argument("--domains", nargs="+", required=True, help="privileged-circle domains (firm, client)")
    ap.add_argument("--out-dir", type=Path, required=True)
    a = ap.parse_args(argv)
    with open(a.export, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    res = build(rows, load_attorneys(a.attorneys), a.domains)
    for p in write_outputs(res, a.out_dir):
        print("wrote", p)
    print(json.dumps(res["summary"], indent=2))
    if not res["summary"]["reconciles"]:
        print("RECONCILIATION FAILED", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
