#!/usr/bin/env python3
"""Generate sample-export.csv and attorneys.csv: invented e-discovery metadata for the
invented matter Harborline Freight Systems v. Redcliffe Logistics. Deterministic (seeded).
Everything here is fake: no real people, firms or documents."""
import csv
import hashlib
import random
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
rnd = random.Random(20261113)

FIRM, CLIENT, CONSULT, OPP = ("thornwoodgarza.example", "harborline-freight.example",
                              "redcliffe-consulting.example", "vantagebrook-law.example")
P = {  # key: (display, address)
    "priya": ("Priya Ramanathan", f"pramanathan@{FIRM}"),
    "marcus": ("Marcus Odell", f"modell@{FIRM}"),
    "elena": ("Elena Vasquez-Hart", f"evasquezhart@{FIRM}"),
    "joel": ("Joel Pruitt (Paralegal)", f"jpruitt@{FIRM}"),
    "tomas": ("Tomas Brandvold", f"tbrandvold@{CLIENT}"),
    "wendy": ("Wendy Achterberg", f"wachterberg@{CLIENT}"),
    "dana": ("Dana Whitlock (Director of Legal Operations)", f"dwhitlock@{CLIENT}"),
    "legal": ("Harborline Legal Department", f"legal@{CLIENT}"),
    "sam": ("Sam Okonkwo", f"sokonkwo@{CLIENT}"),
    "ravi": ("Ravi Kessel", f"rkessel@{CONSULT}"),
    "gwen": ("Gwen Lindqvist", f"glindqvist@{OPP}"),
}
ATTORNEYS = ["priya", "marcus", "elena", "tomas"]


def a(*keys):
    return "; ".join(f"{P[k][0]} <{P[k][1]}>" for k in keys)


rows = []
n = 0


def add(dt, doc_type, custodian, frm, to, cc, subject, fname, md5src, parent="", bcc=""):
    global n
    n += 1
    rows.append({
        "control_no": f"TG-{n:06d}", "doc_date": dt.isoformat(), "doc_type": doc_type,
        "custodian": custodian, "from": frm, "to": to, "cc": cc, "bcc": bcc,
        "subject": subject, "file_name": fname,
        "md5": hashlib.md5(md5src.encode()).hexdigest(), "parent_control_no": parent,
    })
    return rows[-1]["control_no"]


d0 = date(2026, 3, 2)
day = lambda i: d0 + timedelta(days=i)  # noqa: E731

# (subject, participants-from, to, cc, attachments, n messages)
threads = [
    # privileged: attorney <-> client only
    ("Harborline v. Redcliffe: demand letter strategy", "priya", ["tomas", "wendy"], ["marcus"], ["Demand_Letter_DRAFT_v2.docx"], 5),
    ("Carrier audit exposure: call notes", "marcus", ["tomas"], [], [], 3),
    ("Re: Settlement authority range", "priya", ["tomas"], ["wendy"], ["Authority_Memo.pdf"], 4),
    # mixed recipient: attorney to client with consultant (outside) cc'd
    ("Rate analysis for expert report", "elena", ["wendy"], ["ravi"], ["Rate_Table_Q1.xlsx"], 3),
    # trap: non-attorney "legal" people only
    ("Contract renewal paperwork for Redcliffe", "dana", ["wendy", "sam"], ["legal"], ["Renewal_Terms.docx"], 4),
    ("Legal hold reminder (template)", "legal", ["sam", "wendy"], [], [], 2),
    # trap: legal@ shared mailbox mails an attorney (attorney IS present)
    ("Questions on bill of lading disputes", "legal", ["priya"], ["dana"], [], 3),
    # opposing counsel involved
    ("Meet and confer scheduling", "gwen", ["priya"], ["marcus"], [], 3),
    # attorney + paralegal internal work product
    ("Deposition outline: Kessel", "priya", ["joel"], ["elena"], ["Kessel_Depo_Outline.docx"], 3),
    # business only
    ("Q1 freight volume summary", "wendy", ["sam"], [], ["Volumes_Q1.xlsx"], 4),
    ("Warehouse lease renewals", "sam", ["wendy"], ["dana"], [], 3),
    ("Fuel surcharge schedule", "sam", ["wendy"], [], ["Surcharge_2026.xlsx"], 2),
    ("Re: Offsite agenda", "wendy", ["sam", "dana"], [], [], 3),
    ("Weekly dispatch metrics", "sam", ["wendy"], [], ["Metrics.xlsx"], 6),
    ("Carrier audit follow-up", "priya", ["tomas"], [], [], 4),
    ("Driver scheduling Q2", "sam", ["wendy"], [], ["Driver_Roster.xlsx"], 5),
    ("Insurance renewal quote", "wendy", ["sam", "dana"], [], ["Quote_2026.pdf"], 4),
    ("Port congestion update", "sam", ["wendy"], [], [], 5),
    ("Facility safety audit", "dana", ["sam"], ["wendy"], ["Audit_Findings.docx"], 4),
    ("Redcliffe account reconciliation", "wendy", ["sam"], [], ["Recon_Feb.xlsx"], 4),
    # attorney in bcc only
    ("Heads up on the Redcliffe invoice", "wendy", ["sam"], [], [], 1),
]

i = 0
all_msgs = []  # to duplicate later
for subj, frm, to, cc, atts, k in threads:
    for m in range(k):
        i += 3
        sender = frm if m % 2 == 0 else to[0]
        recips = to if m % 2 == 0 else [frm]
        prefix = "" if m == 0 else ("Re: " if m % 3 else "RE: ")
        s = prefix + subj
        cust = P[frm][1].split("@")[0]
        bcc = a("priya") if subj.startswith("Heads up") else ""
        cn = add(day(i), "Email", cust, a(sender), a(*recips), a(*cc), s, "", f"{subj}|{m}|{sender}", bcc=bcc)
        all_msgs.append((cn, subj, m, frm, to, cc, atts, sender, recips))
        if m == 0 and atts:
            for f in atts:
                add(day(i), "Attachment", cust, "", "", "", "", f, f"att|{f}", parent=cn)

# Standalone memos and files (some attorney authored)
for j, (title, who) in enumerate([
        ("Case chronology (work product).docx", "joel"), ("Witness list notes.docx", "priya"),
        ("Interview notes: Okonkwo.docx", "elena"), ("Billing rates comparison.xlsx", "wendy"),
        ("Org chart.pdf", "sam"), ("Warehouse photos index.xlsx", "sam")]):
    i += 2
    add(day(i), "Memo" if title.endswith("docx") else "Spreadsheet", P[who][1].split("@")[0],
        a(who), "", "", title.rsplit(".", 1)[0], title, f"memo|{title}")

# Exact duplicates: the same messages sitting in a second custodian's mailbox (same md5)
base = list(rows)
for r in base:
    if r["doc_type"] == "Email" and rnd.random() < 0.7:
        # second custodian copy; keeps its attachments as duplicate attachments too
        i += 0
        dup = dict(r)
        n += 1
        dup["control_no"] = f"TG-{n:06d}"
        dup["custodian"] = rnd.choice(["sokonkwo", "wachterberg", "joel.pruitt", "pramanathan"])
        rows.append(dup)
        for c in [x for x in base if x["parent_control_no"] == r["control_no"]]:
            n += 1
            cd = dict(c)
            cd["control_no"] = f"TG-{n:06d}"
            cd["parent_control_no"] = dup["control_no"]
            cd["custodian"] = dup["custodian"]
            rows.append(cd)

# Same attachment, different parent (not a family duplicate): forwarded to a new person
src = next(r for r in rows if r["file_name"] == "Rate_Table_Q1.xlsx")
n += 1
fw = {"control_no": f"TG-{n:06d}", "doc_date": day(200).isoformat(), "doc_type": "Email",
      "custodian": "wachterberg", "from": a("wendy"), "to": a("sam"), "cc": "",
      "bcc": "", "subject": "Fwd: Rate analysis for expert report", "file_name": "",
      "md5": hashlib.md5(b"fwd-rate").hexdigest(), "parent_control_no": ""}
rows.append(fw)
n += 1
rows.append({**src, "control_no": f"TG-{n:06d}", "doc_date": fw["doc_date"], "parent_control_no": fw["control_no"],
             "custodian": "wachterberg"})

rows.sort(key=lambda r: r["control_no"])
rows = rows[:]  # control numbers stay as assigned
fields = ["control_no", "doc_date", "doc_type", "custodian", "from", "to", "cc", "bcc",
          "subject", "file_name", "md5", "parent_control_no"]
with open(HERE / "sample-export.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
with open(HERE / "attorneys.csv", "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["name", "email"])
    for k in ATTORNEYS:
        w.writerow([P[k][0], P[k][1]])
print(len(rows), "rows")
