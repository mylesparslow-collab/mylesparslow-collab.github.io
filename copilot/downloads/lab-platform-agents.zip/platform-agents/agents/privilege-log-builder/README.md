# Privilege Log Builder

Draft privilege log from a metadata export, basis columns left to the attorney.

## What it shows
Declares `CodeInterpreter`. The instructions tell the model to de-duplicate families, thread emails, flag attorneys by exact address match, mark outside participants and write XLSX/CSV with four blank attorney columns. `reference/build_log.py` is a deterministic implementation of exactly those steps, with tests.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
The non-attorney trap: people titled "Director of Legal Operations" or sending from `legal@` are not on the attorney list, so they never make a document a candidate; they are flagged "LEGAL WORD BUT NOT ON ATTORNEY LIST". A mixed-recipient email (attorney, client, plus an outside consultant) is marked REVIEW rather than CANDIDATE. The code interpreter's own output was not run in Copilot; the reference script shows what correct output looks like.

## Run / regenerate
```
# from the lab root (platform-agents/)
uv run --python 3.12 agents/privilege-log-builder/reference/build_log.py agents/privilege-log-builder/reference/sample-export.csv --attorneys agents/privilege-log-builder/reference/attorneys.csv --domains thornwoodgarza.example harborline-freight.example --out-dir agents/privilege-log-builder/reference/output
uv run --python 3.12 pytest agents/privilege-log-builder/reference -q
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
