# Practice Desk

One front door that routes a request to the right specialist agent and says which one answered.

## What it shows
Uses `worker_agents` (connected agents, **preview**). Its instructions hold a routing table of all 27 kit agents, generated from `kit.json` by `build.py`; the manifest lists 27 `worker_agents`.

## Package
`appPackage/` holds `manifest.json`, `declarativeAgent.json` (manifest v1.9), `instructions.txt` (house style, with the firm safety rules), and the icons. Fake data only; the firm is the invented Thornwood Garza LLP. It passes `tools/validate.py` and the official `atk validate`.

## Notes and limits
**IDs, not files.** The v1.9 schema accepts `{"id": ...}` or `{"file": ...}`, but Microsoft Learn documents only `id` (the title ID returned when the specialist is published with the Agents Toolkit), and a `file` reference would have to point at a manifest inside this same package. So the 27 entries are **placeholder title IDs** (`P_` plus a GUID derived from each slug; see `routing-table.json`). Before use, publish each specialist, replace each placeholder with its real title ID, and have an admin register them (connected agents must also be acquired by users). Copilot picks the worker from each agent's name, description and starter text, so the routing table in the instructions is a hint, not the mechanism. Workers receive text only, so the agent tells users to paste text.

## Run / regenerate
```
python3 build.py   # regenerates instructions.txt and worker_agents from ../../../../kit.json
```

## Not verified
Nothing here has run in Microsoft 365 Copilot or any tenant. Capability behaviour (search results, code interpreter output, routing) is described from the manifest and Microsoft Learn, not observed.
