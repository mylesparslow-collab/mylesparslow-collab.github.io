# Platform agents lab

Seven Microsoft 365 Copilot agents that use the newer parts of the declarative agent platform (manifest v1.9) which the kit's 27 simple instruction-only agents do not: connected agents, capability scoping, a code interpreter, fixed editorial answers, embedded knowledge, agent skills, and user overrides. It also ships a validator that checks every agent package in the kit against Microsoft's published schemas plus the rules schemas cannot express. All data is invented (Thornwood Garza LLP); nothing was run in a tenant.

## Layout
- `tools/validate.py`: the validator. `tools/schemas/`: vendored schemas. `tools/tests/`: its tests and fixtures. `tools/make_manifest.py`, `tools/sync_skills.py`, `tools/safety_rules.txt`: build helpers.
- `agents/<slug>/`: one folder per agent with `appPackage/` and a README. `agents/house-style/` is the skills pack.
- `demo/`: real captured runs (see below).

## Agents
| Agent | Platform feature it shows |
|---|---|
| `practice-desk` | `worker_agents` (preview): routes to 27 specialists, says which answered |
| `matter-pulse` | `Email`, `TeamsMessages`, `Meetings`, `People` capabilities; privilege labelling |
| `privilege-log-builder` | `CodeInterpreter` + tested reference script and sample export |
| `fee-petition-math` | `CodeInterpreter` + tested reference script and sample time entries |
| `policy-answers` | `editorial_answers`, `discourage_model_knowledge`, `disclaimer`, `EmbeddedKnowledge` (.docx) |
| `house-style` + `drafting-desk` | `agent_skills` (four SKILL.md folders), `sensitivity_label`, `user_overrides` |
| `client-alert-studio` | scoped `WebSearch`, `GraphicArt`, starters with `depends_on` |

## Run it
```
cd copilot-kit/labs/platform-agents
uv run --python 3.12 pytest -q                                   # all tests
uv run --python 3.12 tools/validate.py agents                    # this lab's 7 packages
uv run --python 3.12 tools/validate.py ../../agents              # the kit's existing agents
uv run --python 3.12 tools/validate.py agents --json             # machine-readable
uv run --python 3.12 tools/validate.py --fetch-schemas           # re-download the vendored schemas
```
Per-agent commands are in each agent's README.

## Validator
Walks any folder for appPackages, expands `$[file('...')]`, validates `manifest.json` (the manifest version it declares), the agent manifest (v1.9), plugin manifests (v2.4) and Adaptive Card files against the vendored official schemas, then checks: instructions at most 8,000 characters; at most 12 starters; action files exist; every plugin function claimed by exactly one runtime; `agent_skills` folders contain a SKILL.md whose name matches the folder; EmbeddedKnowledge files exist, are at most 1 MB, at most 10, and of an allowed type; icon sizes (192 colour, 32 outline); no unknown top-level properties; no secret-looking strings; the firm name that must not appear, anywhere (including inside .docx files); plugin field length limits; conversation-starter `depends_on` points at a declared capability.
The schemas are vendored (downloaded from developer.microsoft.com and adaptivecards.io; all four downloads succeeded, 200). They declare draft-04; the validator uses a Draft 7 engine because draft 4 silently ignores the `const` keyword that pins `"version": "v1.9"`. If a download fails the validator says so and fails; it never substitutes its own schema. The Teams schema for another `manifestVersion` is fetched on first need.

## Verified here
- `uv run --python 3.12 pytest -q` from the lab root: 69 passed (38 validator tests on a good fixture and deliberately broken copies, 3 lab-wide checks, 16 for the privilege log script, 12 for the lodestar script).
- `tools/validate.py agents`: 7/7 packages pass. `tools/validate.py ../../agents`: 26/26 existing packages pass, 0 problems (details in `demo/validator-existing-agents.md`; `client-prep` has no package).
- `tools/validate.py ../*/agents ../../agents`: every package in the kit, 42/42 after fixing what it found. It caught real schema errors in the Lex Tools packages and one checker false alarm on Matter Desk's card templates; see `demo/validator-all-labs.md`.
- Official `atk validate` (Agents Toolkit CLI 1.1.19) via `npx -y`, no sign-in needed: all 7 lab packages plus order-reader and bill-check pass; two deliberately broken copies fail. Details and gaps in `demo/atk-validate.md`.
- `demo/privilege-log-builder-run.txt`: the real run on the 155-row sample (60 copies collapsed, 21 threads, 35 log entries, 7 flagged for an outside participant, counts reconcile). Outputs in `agents/privilege-log-builder/reference/output/`.
- `demo/fee-petition-math-run.txt`: the real run on 113 entries ($164,816.50, 325.2 hours, 11 flagged entries not reduced); the planted rate mismatch, duplicate id and zero-hour entry fail their checks (exit code 1); a second run shows a stated total that is $1,015.00 off failing.
- One Haiku smoke run each for matter-pulse, policy-answers, client-alert-studio and drafting-desk, with invented text standing in for capability data: `demo/*-haiku.md`. Three first attempts hit a temporary Cloudflare 403 and were rerun once; the others worked first time. The model followed the rules in each (matter-pulse ignored an instruction planted in an email; policy-answers said "Not covered by the policy. Ask the General Counsel's office." and refused the ethics question; client-alert-studio kept its footnotes when told to drop them; drafting-desk handed the deadline to docketing and refused to predict the motion).

## Not verified
- Nothing ran in Microsoft 365 Copilot. No tenant, licence or Agents Toolkit sign-in was used.
- Worker agents (preview): the IDs are placeholders; real routing, availability and any limit on the number of workers are untested. The `file` form of `worker_agents` is accepted by the schema but not documented by Learn.
- Editorial-answer matching and its thresholds, whether `WebSearch` honours its site scope, image generation, the code interpreter's actual behaviour, how skills are loaded, sensitivity labels (Learn says not enabled yet), and user-override toggles.
- The Haiku runs are single samples with stand-in data, not evidence the instructions work reliably.
- `WebSearch` allows at most 4 sites in v1.9, so dol.gov was dropped from Client Alert Studio (see its README).

## Part C: TypeSpec
Not attempted. The brief said to do it only if it worked within the time box, and the session was interrupted before it was started. Nothing was installed. To try it later: `npm i @typespec/compiler @microsoft/typespec-m365-copilot` in a `typespec/` folder, write one agent, compile, and diff the output against `declarativeAgent.json`.

## Findings on the existing 27 agents
No schema or rule violations. The only gap is that `client-prep` has no appPackage. None of them use capabilities, skills, actions or any other v1.9 feature.
