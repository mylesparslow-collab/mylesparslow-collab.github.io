"""Tests for tools/validate.py: one good fixture and deliberately broken copies of it."""
import json
import shutil
import struct
import sys
import zlib
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import validate as v  # noqa: E402

GOOD = Path(__file__).resolve().parent / "fixtures" / "good"
WORD = "Han" + "son"


@pytest.fixture
def pkg(tmp_path):
    d = tmp_path / "pkg"
    shutil.copytree(GOOD, d)
    return d


def run(p):
    return v.validate_package(p)


def errors(rep):
    return [f"{f}: {m}" for f, ms in rep.files.items() for m in ms]


def has(rep, text):
    return any(text in e for e in errors(rep))


def edit(path, fn):
    j = json.loads(path.read_text())
    fn(j)
    path.write_text(json.dumps(j, indent=2))


def test_good_fixture_passes():
    rep = run(GOOD)
    assert rep.ok, errors(rep)


def test_find_packages_walks_folders(tmp_path):
    shutil.copytree(GOOD, tmp_path / "a" / "appPackage")
    shutil.copytree(GOOD, tmp_path / "b" / "appPackage")
    assert len(v.find_packages([tmp_path])) == 2


def test_instructions_over_8000(pkg):
    (pkg / "instructions.txt").write_text("x" * 8001)
    assert has(run(pkg), "instructions are 8001 chars")


def test_instructions_exactly_8000_ok(pkg):
    (pkg / "instructions.txt").write_text("x" * 8000)
    assert run(pkg).ok


def test_missing_instructions_file(pkg):
    (pkg / "instructions.txt").unlink()
    assert has(run(pkg), "file not found")


def test_thirteen_starters(pkg):
    edit(pkg / "declarativeAgent.json",
         lambda j: j.update(conversation_starters=[{"title": str(i), "text": "t"} for i in range(13)]))
    assert has(run(pkg), "13 conversation starters")


def test_unknown_top_level_property(pkg):
    edit(pkg / "declarativeAgent.json", lambda j: j.update(bogus_property=True))
    assert has(run(pkg), "unknown top-level property 'bogus_property'")


def test_wrong_version_const_enforced(pkg):
    edit(pkg / "declarativeAgent.json", lambda j: j.update(version="v1.6"))
    assert has(run(pkg), "schema: version")


def test_missing_action_file(pkg):
    (pkg / "plugin.json").unlink()
    assert has(run(pkg), "action file 'plugin.json' does not exist")


def test_function_claimed_by_no_runtime(pkg):
    edit(pkg / "plugin.json", lambda j: j["runtimes"][0].update(run_for_functions=["getThing"]))
    assert has(run(pkg), "function 'listThings' is not claimed by any runtime")


def test_function_claimed_twice(pkg):
    def f(j):
        j["runtimes"].append({"type": "OpenApi", "auth": {"type": "None"}, "spec": {"url": "openapi.json"},
                              "run_for_functions": ["getThing"]})
    edit(pkg / "plugin.json", f)
    assert has(run(pkg), "claimed by 2 runtimes")


def test_runtime_names_unknown_function(pkg):
    edit(pkg / "plugin.json", lambda j: j["runtimes"][0].update(run_for_functions=["getThing", "listThings", "ghost"]))
    assert has(run(pkg), "'ghost', which is not a function")


def test_wildcard_claims_all(pkg):
    edit(pkg / "plugin.json", lambda j: j["runtimes"][0].update(run_for_functions=["*"]))
    assert run(pkg).ok


def test_plugin_schema_violation(pkg):
    edit(pkg / "plugin.json", lambda j: j.update(name_for_human="This name is far too long for the limit"))
    assert has(run(pkg), "name_for_human is 39 chars, limit 20")
    edit(pkg / "plugin.json", lambda j: j.update(name_for_human="ok", namespace="bad namespace!"))
    assert has(run(pkg), "plugin.json: schema")


def test_missing_openapi_spec_file(pkg):
    (pkg / "openapi.json").unlink()
    assert has(run(pkg), "openapi.json' which does not exist")


def test_adaptive_card_invalid(pkg):
    edit(pkg / "adaptive-cards" / "card.json", lambda j: j.update(version=5))
    assert has(run(pkg), "adaptive-cards/card.json: schema")


def test_missing_card_file(pkg):
    (pkg / "adaptive-cards" / "card.json").unlink()
    assert has(run(pkg), "file not found")


def test_skill_folder_without_skill_md(pkg):
    (pkg / "skills" / "demo-skill" / "SKILL.md").unlink()
    assert has(run(pkg), "has no SKILL.md")


def test_skill_name_must_match_folder(pkg):
    (pkg / "skills" / "demo-skill" / "SKILL.md").write_text("---\nname: other\ndescription: x\n---\n")
    assert has(run(pkg), "does not match folder")


def test_skill_missing_folder(pkg):
    shutil.rmtree(pkg / "skills")
    assert has(run(pkg), "does not exist")


def test_embedded_knowledge_missing(pkg):
    (pkg / "knowledge.txt").unlink()
    assert has(run(pkg), "EmbeddedKnowledge file 'knowledge.txt' does not exist")


def test_embedded_knowledge_too_big(pkg):
    (pkg / "knowledge.txt").write_bytes(b"x" * (1024 * 1024 + 1))
    assert has(run(pkg), "limit 1 MB")


def test_embedded_knowledge_bad_type(pkg):
    (pkg / "knowledge.md").write_text("hi")
    edit(pkg / "declarativeAgent.json", lambda j: j["capabilities"][1].update(files=[{"file": "knowledge.md"}]))
    assert has(run(pkg), "has type .md")


def test_embedded_knowledge_eleven_files(pkg):
    files = []
    for i in range(11):
        (pkg / f"k{i}.txt").write_text("k")
        files.append({"file": f"k{i}.txt"})
    edit(pkg / "declarativeAgent.json", lambda j: j["capabilities"][1].update(files=files))
    assert has(run(pkg), "11 EmbeddedKnowledge files")


def _png(path, w, h):
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    raw = b"".join(b"\x00" + b"\x00\x00\x00" * w for _ in range(h))
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def test_icon_wrong_sizes(pkg):
    _png(pkg / "color.png", 100, 100)
    _png(pkg / "outline.png", 64, 64)
    rep = run(pkg)
    assert has(rep, "icon color 'color.png' is 100x100, must be 192x192")
    assert has(rep, "icon outline 'outline.png' is 64x64, must be 32x32")


def test_icon_missing_and_not_png(pkg):
    (pkg / "color.png").unlink()
    (pkg / "outline.png").write_text("not a png")
    rep = run(pkg)
    assert has(rep, "icon color 'color.png' does not exist")
    assert has(rep, "is not a valid PNG")


def test_secret_like_strings(pkg):
    (pkg / "instructions.txt").write_text("Use key sk-" + "a" * 30 + " for the call.")
    assert has(run(pkg), "looks like a secret")
    (pkg / "instructions.txt").write_text("api_key = Zm9vYmFyYmF6cXV4MTIzNDU2")
    assert has(run(pkg), "key/secret assignment")


def test_placeholder_secret_not_flagged(pkg):
    (pkg / "instructions.txt").write_text("api_key = your-api-key-here-please\nPASSWORD=changeme-changeme-123")
    assert run(pkg).ok


def test_forbidden_word_in_text_and_docx(pkg):
    (pkg / "instructions.txt").write_text(f"Prepared for {WORD} Bridgett partners.")
    assert has(run(pkg), "forbidden word")
    (pkg / "instructions.txt").write_text("fine")
    from docx import Document
    d = Document()
    d.add_paragraph(f"Memo from {WORD.upper()}")
    d.save(pkg / "memo.docx")
    assert has(run(pkg), "memo.docx: contains the forbidden word")


def test_invalid_json(pkg):
    (pkg / "declarativeAgent.json").write_text("{not json")
    assert has(run(pkg), "invalid JSON")


def test_duplicate_capability(pkg):
    edit(pkg / "declarativeAgent.json", lambda j: j["capabilities"].append({"name": "WebSearch"}))
    assert has(run(pkg), "declared 2 times")


def test_depends_on_undeclared_capability(pkg):
    edit(pkg / "declarativeAgent.json",
         lambda j: j["conversation_starters"][0].update(depends_on=[{"name": "capabilities", "id": "GraphicArt"}]))
    assert has(run(pkg), "depends_on capability 'GraphicArt' which is not declared")


def test_manifest_wrong_version_schema_error(pkg):
    edit(pkg / "manifest.json", lambda j: j.update(version=1))
    assert has(run(pkg), "manifest.json: schema")


def test_cli_exit_codes_and_json(pkg, tmp_path, capsys):
    assert v.main([str(GOOD)]) == 0
    (pkg / "instructions.txt").write_text("x" * 9000)
    assert v.main([str(pkg), "--json"]) == 1
    assert v.main([str(tmp_path / "nothing-here")]) == 2


def test_json_output_shape(pkg, capsys):
    (pkg / "instructions.txt").write_text("x" * 9000)
    v.main([str(pkg), "--json"])
    j = json.loads(capsys.readouterr().out)
    assert j["ok"] is False and j["packages"][0]["errors"][0]["file"] == "declarativeAgent.json"


def test_vendored_schemas_present():
    for f in ("da-1.9.json", "plugin-2.4.json", "teams-1.24.json", "adaptive-card.json"):
        assert (v.SCHEMA_DIR / f).is_file()


def test_unavailable_schema_fails_loudly(pkg, monkeypatch, tmp_path):
    monkeypatch.setattr(v, "SCHEMA_DIR", tmp_path / "empty")
    monkeypatch.setattr(v, "_schema_cache", {})
    monkeypatch.setattr(v, "_download", lambda url, dest: (_ for _ in ()).throw(v.SchemaUnavailable("offline")))
    rep = run(pkg)
    assert has(rep, "schema unavailable")


def test_card_template_keys_are_ignored_but_bad_cards_still_fail():
    from validate import strip_template_keys, schema_for, schema_errors
    tmpl = {"type": "AdaptiveCard", "version": "1.5", "body": [
        {"type": "TextBlock", "text": "None", "$when": "${count == 0}"},
        {"type": "TextBlock", "text": "${x}", "$data": "${items}"}]}
    assert schema_errors(schema_for("ac"), strip_template_keys(tmpl)) == []
    bad = {"type": "AdaptiveCard", "version": "1.5", "body": [{"type": "TextBlock", "text": "x", "notAProp": 1, "$when": "${a}"}]}
    assert schema_errors(schema_for("ac"), strip_template_keys(bad)) != []
