"""Checks that tie the lab together: every agent package validates, the skills pack and the
Drafting Desk copies match, and Practice Desk's routing table matches kit.json."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import validate as v  # noqa: E402

LAB = Path(__file__).resolve().parents[2]
AGENTS = LAB / "agents"


def test_all_lab_packages_validate():
    pkgs = v.find_packages([AGENTS])
    assert len(pkgs) == 7
    for p in pkgs:
        rep = v.validate_package(p)
        assert rep.ok, (p, [m for ms in rep.files.values() for m in ms])


def test_skills_pack_matches_drafting_desk_copy():
    src, dst = AGENTS / "house-style" / "skills", AGENTS / "drafting-desk" / "appPackage" / "skills"
    names = sorted(p.name for p in src.iterdir())
    assert names == ["bluebook-short-cites", "deadline-handoff", "privilege-labels", "verbatim-quote-rule"]
    for n in names:
        assert (src / n / "SKILL.md").read_text() == (dst / n / "SKILL.md").read_text()


def test_practice_desk_routes_every_kit_agent():
    kit = json.loads((LAB.parents[1] / "kit.json").read_text())["agents"]
    da = json.loads((AGENTS / "practice-desk" / "appPackage" / "declarativeAgent.json").read_text())
    instr = (AGENTS / "practice-desk" / "appPackage" / "instructions.txt").read_text()
    assert len(da["worker_agents"]) == len(kit) == 27
    assert len({w["id"] for w in da["worker_agents"]}) == 27
    for a in kit:
        assert f"- {a['name']} [{a['area']}]: {a['tagline']}" in instr
