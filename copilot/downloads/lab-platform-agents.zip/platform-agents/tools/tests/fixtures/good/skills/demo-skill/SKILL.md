---
name: demo-skill
description: A demo skill for the fixture.
---

# Demo
