#!/usr/bin/env python3
"""Validate Microsoft 365 Copilot agent packages (appPackage folders).

Usage:
  uv run --python 3.12 tools/validate.py <path...> [--json] [--fetch-schemas]

Schemas are vendored in tools/schemas/. They are downloaded once from Microsoft
(and adaptivecards.io) with --fetch-schemas or on first need; if a download
fails the validator reports it and fails. It never substitutes a hand-written
schema.
"""
from __future__ import annotations

import argparse
import json
import re
import struct
import sys
import urllib.request
import zipfile
from pathlib import Path

from jsonschema import Draft7Validator
from jsonschema.exceptions import best_match

HERE = Path(__file__).resolve().parent
SCHEMA_DIR = HERE / "schemas"

DA_URL = "https://developer.microsoft.com/json-schemas/copilot/declarative-agent/v1.9/schema.json"
PLUGIN_URL = "https://developer.microsoft.com/json-schemas/copilot/plugin/v2.4/schema.json"
AC_URL = "http://adaptivecards.io/schemas/adaptive-card.json"
TEAMS_URL = "https://developer.microsoft.com/json-schemas/teams/v{ver}/MicrosoftTeams.schema.json"

SCHEMA_FILES = {
    "da": ("da-1.9.json", DA_URL),
    "plugin": ("plugin-2.4.json", PLUGIN_URL),
    "ac": ("adaptive-card.json", AC_URL),
}

MAX_INSTRUCTIONS = 8000
MAX_STARTERS = 12
MAX_EMBEDDED_FILES = 10
MAX_EMBEDDED_BYTES = 1024 * 1024
EMBEDDED_EXT = {".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".pdf"}
DA_TOP_LEVEL = {
    "id", "version", "name", "description", "disclaimer", "instructions", "capabilities",
    "behavior_overrides", "conversation_starters", "actions", "user_overrides",
    "editorial_answers", "worker_agents", "$schema", "sensitivity_label", "agent_skills",
}
FORBIDDEN_WORD = "Han" + "son"  # built in pieces so this file stays clean of the word itself
SKIP_DIRS = {"node_modules", "schemas", ".git", "build", "dist", "__pycache__", ".venv", "env"}
TEXT_EXT = {".json", ".txt", ".md", ".yml", ".yaml", ".csv", ".tsp", ".py"}

SECRET_PATTERNS = [
    ("OpenAI/Anthropic-style key", re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}")),
    ("AWS access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")),
    ("bearer token", re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]{24,}=*")),
    ("key/secret assignment", re.compile(
        r"(?i)\b(api[_-]?key|client[_-]?secret|secret|password|passwd|access[_-]?token)\b[\"']?\s*[:=]\s*[\"']?(?!your|example|placeholder|changeme|<|\$|\{)[A-Za-z0-9/+_\-]{16,}")),
]

FILE_REF = re.compile(r"^\$\[file\('([^']+)'\)\]$")


# ---------------------------------------------------------------- schemas

class SchemaUnavailable(Exception):
    pass


def _download(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            data = r.read()
        json.loads(data)  # must at least be JSON
    except Exception as e:  # noqa: BLE001
        raise SchemaUnavailable(f"could not download {url}: {e}") from e
    dest.write_bytes(data)


_schema_cache: dict[str, Draft7Validator] = {}


def _load_schema(fname: str, url: str) -> Draft7Validator:
    if fname in _schema_cache:
        return _schema_cache[fname]
    path = SCHEMA_DIR / fname
    if not path.exists():
        _download(url, path)
    schema = json.loads(path.read_text(encoding="utf-8"))
    # The Microsoft schemas declare draft-04; Draft 7 is a superset for what they
    # use and, unlike draft 4, actually enforces `const`.
    v = Draft7Validator(schema)
    _schema_cache[fname] = v
    return v


def schema_for(kind: str, version: str | None = None) -> Draft7Validator:
    if kind == "teams":
        return _load_schema(f"teams-{version}.json", TEAMS_URL.format(ver=version))
    f, u = SCHEMA_FILES[kind]
    return _load_schema(f, u)


def fetch_all() -> list[str]:
    msgs = []
    for kind, (f, u) in SCHEMA_FILES.items():
        try:
            _download(u, SCHEMA_DIR / f)
            msgs.append(f"ok   {u} -> schemas/{f}")
        except SchemaUnavailable as e:
            msgs.append(f"FAIL {e}")
    return msgs


# ---------------------------------------------------------------- helpers

class Report:
    def __init__(self, package: Path):
        self.package = package
        self.files: dict[str, list[str]] = {}

    def touch(self, f: str):
        self.files.setdefault(f, [])

    def err(self, f: str, msg: str):
        self.files.setdefault(f, []).append(msg)

    @property
    def ok(self) -> bool:
        return not any(self.files.values())


def _path(error) -> str:
    p = "/".join(str(x) for x in error.absolute_path)
    return p or "(root)"


def schema_errors(validator: Draft7Validator, doc, skip=lambda e: False) -> list[str]:
    out = []
    for e in sorted(validator.iter_errors(doc), key=lambda e: list(map(str, e.absolute_path))):
        if skip(e):
            continue
        deep = best_match(e.context) if e.context else None
        msg = (deep or e).message
        if len(msg) > 220:
            msg = msg[:217] + "..."
        out.append(f"schema: {_path(e)}: {msg}")
    return out


def load_json(path: Path, rep: Report, rel: str):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        rep.err(rel, "file not found")
    except json.JSONDecodeError as e:
        rep.err(rel, f"invalid JSON: {e}")
    return None


def resolve_refs(node, base: Path, rep: Report, rel: str):
    """Replace string values of the form $[file('x')] with the file's text."""
    if isinstance(node, dict):
        return {k: resolve_refs(v, base, rep, rel) for k, v in node.items()}
    if isinstance(node, list):
        return [resolve_refs(v, base, rep, rel) for v in node]
    if isinstance(node, str):
        m = FILE_REF.match(node)
        if m:
            ref = (base / m.group(1))
            try:
                ref.resolve().relative_to(base.resolve())
            except ValueError:
                rep.err(rel, f"$[file('{m.group(1)}')] points outside the package")
                return ""
            if not ref.is_file():
                rep.err(rel, f"$[file('{m.group(1)}')] file not found")
                return ""
            return ref.read_text(encoding="utf-8")
    return node


def png_size(path: Path):
    b = path.read_bytes()[:24]
    if b[:8] != b"\x89PNG\r\n\x1a\n" or b[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", b[16:24])


# ---------------------------------------------------------------- checks

def check_manifest(pkg: Path, rep: Report) -> list[Path]:
    rel = "manifest.json"
    rep.touch(rel)
    m = load_json(pkg / rel, rep, rel)
    if m is None:
        return []
    m = resolve_refs(m, pkg, rep, rel)
    ver = str(m.get("manifestVersion", ""))
    if not ver:
        rep.err(rel, "no manifestVersion")
        return []
    try:
        rep.files[rel] += schema_errors(schema_for("teams", ver), m)
    except SchemaUnavailable as e:
        rep.err(rel, f"schema unavailable: {e}")
    for key, want in (("color", (192, 192)), ("outline", (32, 32))):
        name = (m.get("icons") or {}).get(key)
        if not name:
            continue
        p = pkg / name
        if not p.is_file():
            rep.err(rel, f"icon {key} '{name}' does not exist")
            continue
        size = png_size(p)
        if size is None:
            rep.err(rel, f"icon {key} '{name}' is not a valid PNG")
        elif size != want:
            rep.err(rel, f"icon {key} '{name}' is {size[0]}x{size[1]}, must be {want[0]}x{want[1]}")
    out = []
    for d in (m.get("copilotAgents") or {}).get("declarativeAgents", []) or []:
        f = d.get("file")
        if not f:
            rep.err(rel, "declarativeAgents entry has no file")
        else:
            out.append(pkg / f)
    if not out and "copilotAgents" not in m:
        rep.err(rel, "no copilotAgents.declarativeAgents: not an agent package")
    return out


def check_skill(pkg: Path, folder: str, rep: Report, rel: str):
    if ".." in Path(folder).parts:
        rep.err(rel, f"agent_skills folder '{folder}' uses '..'")
        return
    d = pkg / folder
    if not d.is_dir():
        rep.err(rel, f"agent_skills folder '{folder}' does not exist")
        return
    sk = d / "SKILL.md"
    if not sk.is_file():
        rep.err(rel, f"agent_skills folder '{folder}' has no SKILL.md")
        return
    text = sk.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    srel = f"{folder.strip('./')}/SKILL.md"
    rep.touch(srel)
    if not m:
        rep.err(srel, "SKILL.md has no YAML frontmatter")
        return
    fm = dict(re.findall(r"^([A-Za-z_-]+):\s*(.+)$", m.group(1), re.M))
    name = fm.get("name", "").strip().strip("\"'")
    desc = fm.get("description", "").strip()
    if not name:
        rep.err(srel, "frontmatter has no name")
    else:
        if name != d.name:
            rep.err(srel, f"frontmatter name '{name}' does not match folder '{d.name}'")
        if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name) or len(name) > 64:
            rep.err(srel, f"name '{name}' must be lowercase letters, digits and hyphens, at most 64 chars")
    if not desc:
        rep.err(srel, "frontmatter has no description")
    elif len(desc) > 1024:
        rep.err(srel, "description over 1024 chars")


def check_plugin(pkg: Path, action: dict, rep: Report):
    f = action.get("file", "")
    rel = f
    rep.touch(rel)
    p = pkg / f
    doc = load_json(p, rep, rel)
    if doc is None:
        return
    doc = resolve_refs(doc, p.parent, rep, rel)
    try:
        rep.files[rel] += schema_errors(schema_for("plugin"), doc)
    except SchemaUnavailable as e:
        rep.err(rel, f"schema unavailable: {e}")
    for key, lim in (("name_for_human", 20), ("description_for_human", 100), ("description_for_model", 2048)):
        val = doc.get(key)
        if isinstance(val, str) and len(val) > lim:
            rep.err(rel, f"{key} is {len(val)} chars, limit {lim}")
    fnames = [fn.get("name") for fn in doc.get("functions", []) or []]
    if len(fnames) != len(set(fnames)):
        rep.err(rel, "duplicate function names")
    claims: dict[str, int] = {n: 0 for n in fnames}
    for i, rt in enumerate(doc.get("runtimes", []) or []):
        spec = rt.get("spec") or {}
        local = [spec.get("url")] if isinstance(spec.get("url"), str) and not spec["url"].startswith(("http://", "https://")) else []
        mtd = spec.get("mcp_tool_description")
        if isinstance(mtd, dict) and "file" in mtd:
            local.append(mtd["file"])
        for lf in local:
            if not (p.parent / lf).is_file():
                rep.err(rel, f"runtimes/{i} references file '{lf}' which does not exist")
        rf = rt.get("run_for_functions", []) or []
        if "*" in rf:
            for n in claims:
                claims[n] += 1
        for n in rf:
            if n == "*":
                continue
            if n not in claims:
                rep.err(rel, f"runtimes/{i} run_for_functions names '{n}', which is not a function")
            else:
                claims[n] += 1
    for n, c in claims.items():
        if c == 0:
            rep.err(rel, f"function '{n}' is not claimed by any runtime")
        elif c > 1:
            rep.err(rel, f"function '{n}' is claimed by {c} runtimes (must be exactly one)")
    # adaptive cards
    for i, fn in enumerate(doc.get("functions", []) or []):
        rs = ((fn.get("capabilities") or {}).get("response_semantics") or {})
        st = rs.get("static_template")
        if isinstance(st, dict):
            card, crel = st, f"{rel}#functions/{i}/static_template"
            if set(st.keys()) == {"file"}:
                cp = p.parent / st["file"]
                crel = st["file"]
                rep.touch(crel)
                card = load_json(cp, rep, crel)
            if card is not None:
                rep.touch(crel)
                try:
                    rep.files[crel] += schema_errors(schema_for("ac"), strip_template_keys(card))
                except SchemaUnavailable as e:
                    rep.err(crel, f"schema unavailable: {e}")


TEMPLATE_KEYS = ("$when", "$data")


def strip_template_keys(node):
    """Copilot's static_template is an Adaptive Card *template*: the templating language adds
    $when and $data, which the plain card schema does not know. Drop them before validating."""
    if isinstance(node, dict):
        return {k: strip_template_keys(v) for k, v in node.items() if k not in TEMPLATE_KEYS}
    if isinstance(node, list):
        return [strip_template_keys(v) for v in node]
    return node


def check_agent(pkg: Path, apath: Path, rep: Report):
    rel = str(apath.relative_to(pkg))
    rep.touch(rel)
    raw = load_json(apath, rep, rel)
    if raw is None:
        return
    base = apath.parent
    doc = resolve_refs(raw, base, rep, rel)
    if not isinstance(doc, dict):
        rep.err(rel, "agent manifest is not a JSON object")
        return

    def skip(e):
        p = list(map(str, e.absolute_path))
        return e.validator in ("maxLength", "maxItems") and (
            p == ["instructions"] or p == ["conversation_starters"] or p[-1:] == ["files"])

    try:
        rep.files[rel] += schema_errors(schema_for("da"), doc, skip)
    except SchemaUnavailable as e:
        rep.err(rel, f"schema unavailable: {e}")

    for k in doc:
        if k not in DA_TOP_LEVEL:
            rep.err(rel, f"unknown top-level property '{k}'")
    ins = doc.get("instructions")
    if isinstance(ins, str) and len(ins) > MAX_INSTRUCTIONS:
        rep.err(rel, f"instructions are {len(ins)} chars, limit {MAX_INSTRUCTIONS}")
    cs = doc.get("conversation_starters") or []
    if len(cs) > MAX_STARTERS:
        rep.err(rel, f"{len(cs)} conversation starters, limit {MAX_STARTERS}")

    caps = doc.get("capabilities") or []
    names = [c.get("name") for c in caps if isinstance(c, dict)]
    for n in set(names):
        if names.count(n) > 1:
            rep.err(rel, f"capability '{n}' declared {names.count(n)} times (one per type)")
    for i, s in enumerate(cs):
        for d in (s.get("depends_on") or []) if isinstance(s, dict) else []:
            if d.get("name") == "capabilities" and d.get("id") not in names:
                rep.err(rel, f"conversation_starters/{i} depends_on capability '{d.get('id')}' which is not declared")

    for c in caps:
        if isinstance(c, dict) and c.get("name") == "EmbeddedKnowledge":
            files = c.get("files") or []
            if len(files) > MAX_EMBEDDED_FILES:
                rep.err(rel, f"{len(files)} EmbeddedKnowledge files, limit {MAX_EMBEDDED_FILES}")
            for f in files:
                fp = base / f.get("file", "")
                if not f.get("file") or not fp.is_file():
                    rep.err(rel, f"EmbeddedKnowledge file '{f.get('file')}' does not exist")
                    continue
                if fp.stat().st_size > MAX_EMBEDDED_BYTES:
                    rep.err(rel, f"EmbeddedKnowledge file '{f['file']}' is {fp.stat().st_size} bytes, limit 1 MB")
                if fp.suffix.lower() not in EMBEDDED_EXT:
                    rep.err(rel, f"EmbeddedKnowledge file '{f['file']}' has type {fp.suffix}; allowed: {', '.join(sorted(EMBEDDED_EXT))}")

    for sk in doc.get("agent_skills") or []:
        check_skill(base, sk.get("folder", ""), rep, rel)

    for w in doc.get("worker_agents") or []:
        if "file" in w and not (base / w["file"]).is_file():
            rep.err(rel, f"worker_agents file '{w['file']}' does not exist")

    for a in doc.get("actions") or []:
        if not (base / a.get("file", "")).is_file():
            rep.err(rel, f"action file '{a.get('file')}' does not exist")
        else:
            check_plugin(base, a, rep)


def read_text_for_scan(p: Path) -> str | None:
    suf = p.suffix.lower()
    try:
        if suf in TEXT_EXT or p.name == "SKILL.md":
            return p.read_text(encoding="utf-8", errors="replace")
        if suf in (".docx", ".xlsx"):
            with zipfile.ZipFile(p) as z:
                return "\n".join(z.read(n).decode("utf-8", "replace")
                                 for n in z.namelist() if n.endswith(".xml"))
    except Exception:  # noqa: BLE001
        return None
    return None


def scan_package(pkg: Path, rep: Report):
    for p in sorted(pkg.rglob("*")):
        if not p.is_file() or any(part in SKIP_DIRS for part in p.relative_to(pkg).parts):
            continue
        rel = str(p.relative_to(pkg))
        text = read_text_for_scan(p)
        if text is None:
            continue
        rep.touch(rel)
        if FORBIDDEN_WORD.lower() in text.lower():
            rep.err(rel, f"contains the forbidden word '{FORBIDDEN_WORD}'")
        for label, rx in SECRET_PATTERNS:
            m = rx.search(text)
            if m:
                rep.err(rel, f"looks like a secret ({label}): '{m.group(0)[:12]}...'")


def validate_package(pkg: Path) -> Report:
    rep = Report(pkg)
    agent_files = check_manifest(pkg, rep)
    for a in agent_files:
        check_agent(pkg, a, rep)
    scan_package(pkg, rep)
    return rep


def find_packages(paths: list[Path]) -> list[Path]:
    found = []
    for root in paths:
        root = root.resolve()
        if (root / "manifest.json").is_file():
            found.append(root)
            continue
        for m in sorted(root.rglob("manifest.json")):
            d = m.parent
            if any(part in SKIP_DIRS for part in d.relative_to(root).parts):
                continue
            try:
                j = json.loads(m.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                j = {}
            if "manifestVersion" in j or d.name == "appPackage":
                found.append(d)
    return found


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="*", type=Path)
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--fetch-schemas", action="store_true", help="(re)download the vendored schemas and exit")
    a = ap.parse_args(argv)
    if a.fetch_schemas:
        msgs = fetch_all()
        print("\n".join(msgs))
        return 1 if any(m.startswith("FAIL") for m in msgs) else 0
    if not a.paths:
        ap.error("give at least one path")
    pkgs = find_packages(a.paths)
    if not pkgs:
        print("no appPackage folders found", file=sys.stderr)
        return 2
    reports = [validate_package(p) for p in pkgs]
    failed = [r for r in reports if not r.ok]
    if a.json:
        print(json.dumps({
            "ok": not failed,
            "packages": [{
                "package": str(r.package), "ok": r.ok,
                "files": {f: errs for f, errs in r.files.items()},
                "errors": [{"file": f, "message": m} for f, errs in r.files.items() for m in errs],
            } for r in reports],
        }, indent=2))
    else:
        for r in reports:
            print(f"{'PASS' if r.ok else 'FAIL'}  {r.package}")
            for f, errs in r.files.items():
                if errs:
                    for m in errs:
                        print(f"   FAIL {f}: {m}")
        print(f"\n{len(reports) - len(failed)}/{len(reports)} packages passed"
              f"; {sum(len(e) for r in reports for e in r.files.values())} problems")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
