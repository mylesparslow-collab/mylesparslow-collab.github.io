#!/usr/bin/env python3
"""Copy agents/house-style/skills/* into agents/drafting-desk/appPackage/skills/ (the package
must be self-contained, so the skills are copied, not linked). The test suite checks they match."""
import shutil
from pathlib import Path

A = Path(__file__).resolve().parents[1] / "agents"
src, dst = A / "house-style" / "skills", A / "drafting-desk" / "appPackage" / "skills"
if dst.exists():
    shutil.rmtree(dst)
shutil.copytree(src, dst)
print("synced", sorted(p.name for p in dst.iterdir()))
