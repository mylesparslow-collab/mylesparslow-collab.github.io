#!/usr/bin/env python3
"""Write appPackage/manifest.json and copy the icons for one agent, in the same
shape as copilot-kit/agents/order-reader/appPackage/manifest.json.

  make_manifest.py <agent-dir> "<Name>" "<short description (<=80)>" "<full description>"
"""
import json
import shutil
import sys
import uuid
from pathlib import Path

KIT = Path(__file__).resolve().parents[3]
SRC = KIT / "agents" / "order-reader" / "appPackage"


def main():
    d = Path(sys.argv[1]).resolve()
    name, short, full = sys.argv[2:5]
    pkg = d / "appPackage"
    slug = d.name
    m = json.loads((SRC / "manifest.json").read_text())
    m["id"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"thornwood-garza-labs/platform-agents/{slug}"))
    m["name"] = {"short": name, "full": f"{name} (Thornwood Garza sample)"}
    m["description"] = {"short": short, "full": full}
    m["copilotAgents"]["declarativeAgents"] = [
        {"id": f"{slug.replace('-', '_')}_{m['id'][:8]}", "file": "declarativeAgent.json"}]
    pkg.mkdir(parents=True, exist_ok=True)
    (pkg / "manifest.json").write_text(json.dumps(m, indent=2) + "\n")
    for f in ("color.png", "outline.png"):
        shutil.copy(SRC / f, pkg / f)


main()
