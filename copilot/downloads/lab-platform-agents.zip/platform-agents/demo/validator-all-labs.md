# tools/validate.py run over every package in the kit (2026-11-13)

    uv run --python 3.12 tools/validate.py ../*/agents ../../agents

First run: 2 of 9 lab packages passed, 23 problems.

- **Lex Tools (4 packages), real errors:** each plugin function carried `security_info` directly, but the plugin v2.4 schema only allows it under `capabilities`. Three app manifests had a short description over the schema's length limit. Fixed in `labs/lex-mcp/scripts/gen_agents.py`, packages regenerated, Lex Tools tests re-run (pass).
- **Matter Desk (3 packages), checker false alarm:** its card files are Adaptive Card *templates*, which use the templating keys `$when` and `$data`. The plain card schema does not know those keys. The checker now drops only those two keys before validating a template (regression test added; a card with a genuinely unknown property still fails).

Final run: **42 of 42 packages passed, 0 problems.**
