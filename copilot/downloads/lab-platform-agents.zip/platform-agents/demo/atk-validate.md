# Official Agents Toolkit validator: what it did

Tool: `@microsoft/m365agentstoolkit-cli` 1.1.19 (binary `atk`), run through `npx -y` with the npm cache pointed at a scratch folder. No sign-in, no tenant, no prompt, no browser. It never asked for a login. Run from inside each `appPackage/` folder:

    npx -y @microsoft/m365agentstoolkit-cli validate --manifest-file manifest.json </dev/null

| Package | Result |
|---|---|
| copilot-kit/agents/order-reader | exit 0, "All passed." |
| copilot-kit/agents/bill-check | exit 0, "All passed." |
| all 7 packages in this lab (practice-desk, matter-pulse, privilege-log-builder, fee-petition-math, policy-answers, drafting-desk, client-alert-studio) | each exit 0, "All passed." |
| a copy of drafting-desk with `"version": 1` (number) in manifest.json | exit 1, `JSONSyntaxError ... Invalid value for key "version". Expected string but got number.` |
| a copy of drafting-desk with `"bogus": 1` and `"version": "v9"` in declarativeAgent.json | exit 1, 3 failures: unknown property `bogus`, property name not valid, `/version must be equal to constant` (allowed value `v1.9`) |

Findings:
- It works fully offline of any tenant. It does check the declarative agent manifest (the file the app manifest points to) against the v1.9 schema, not only manifest.json.
- It validates schemas only. It does not check that instructions fit 8,000 characters after `$[file()]` expansion, that referenced files exist, icon sizes, skills folders, plugin function claims, secrets, or that a name is absent. Those are the gaps tools/validate.py fills.
- It stops at the first manifest-level syntax error (the `version: 1` case) instead of listing everything.
- It wrote nothing into the package folders (no build/ folder or zip appeared).
