# tools/validate.py run over the 27 existing agents

Command (from the lab folder):

    uv run --python 3.12 tools/validate.py ../../agents
    uv run --python 3.12 tools/validate.py ../../agents --json > demo/validator-existing-agents.json

Result: **26 of 26 appPackages passed, 0 problems.** Exit code 0. No file in copilot-kit/agents was changed.

Findings and observations (nothing to fix for validity):
- `kit.json` lists 27 agents but only 26 have an appPackage. `client-prep` is documented only (README, agent-instructions.md, a swagger file); it needs the Firm Facts MCP server and is built in Copilot Studio. The validator has nothing to check there. Practice Desk still lists it as a specialist, with a placeholder ID.
- All 26 packages use manifest 1.24 and declarative agent v1.9, 5 conversation starters each, no capabilities, no actions, no skills, no editorial answers, no sensitivity label. They exercise none of the newer v1.9 features, which is the gap this lab fills.
- Every package's instructions length equals `instructions_chars` in kit.json; all are well under 8,000.
- Icons are 192x192 and 32x32 everywhere; no secret-like strings; the forbidden firm name appears nowhere.
- `starters.json` and `instructions.txt` copies outside appPackage are not validated (the tool checks packages only).
