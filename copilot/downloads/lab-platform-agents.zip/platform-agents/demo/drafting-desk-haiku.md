**DRAFT: attorney review required before any use outside the firm.**

**Subject:** Update on motion to compel: [matter name and case number not provided]

Dear Tomas Brandvold,

We are writing with an update on the motion to compel in [case name and number not provided].

**Court order.** The minute order dated November 2, 2026 states: "Defendant shall serve supplemental responses no later than 15 days before the hearing on the motion to compel." [Source: attorney notes. The order itself was not provided.] [Whether the Defendant named in the order is you: Not stated in the document.]

**Hearing date.** The hearing is set for "December 14, 2026," per the clerk. [Source: attorney notes. The clerk's notice was not provided.]

**Deadline for supplemental responses.** [To be confirmed by docketing before this email is sent.]

**Extension offer.** On November 3, opposing counsel Gwen Lindqvist of Vantagebrook Law offered a one-week extension. [Summary from attorney notes; the email text was not provided. Year not stated in the notes.] [Whether the extension has been accepted or confirmed: Not stated in the document.]

**Next steps.** [Not provided. Attorney to complete.]

[Assessment of the motion: not included. Attorney to decide whether and what to share.]

Please contact us with any questions.

[Attorney name and signature block not provided.]

---

**Open items**

**Missing from the material**
- Case name, number, court and department: Not stated in the document.
- Copy of the minute order and clerk's notice of hearing (both quoted from notes only).
- Text of Ms. Lindqvist's November 3 email, and the year of that email.
- Whether the extension was accepted or made part of any order: Not stated in the document.
- Whether the client is the Defendant named in the minute order: Not stated in the document.
- Next steps, attorney name, and signature block.

**Deadline handoff: Docketing to calculate**
- Trigger event: "the hearing on the motion to compel" (minute order, dated November 2, 2026 per attorney notes). Hearing date: "December 14, 2026" (attorney notes, citing the clerk; no document provided).
- Period: "no later than 15 days before the hearing on the motion to compel" (minute order, per attorney notes).
- Rule or statute named: Rule not named in the source.
- Who must act: "Defendant shall serve supplemental responses" (minute order, per attorney notes).
- Service or filing method: Not stated in the document.
- Court, case number, department: Not stated in the document.
- Extension: "one-week extension" offered in Nov 3 email (summary from attorney notes only). Status: Not stated in the document. Docketing should not treat it as applied until confirmed.

**Chances on the motion:** Not drafted. I do not predict outcomes or give legal conclusions. The responsible attorney decides what, if anything, to tell the client.

**Citations (format only)**
- Given: *Smith v. Jones*, 123 Cal.App.4th 456, 460 (2004). Formatted as supplied. Not used in the client email.
- Given: "the same case again at 462." Formatted as *Smith v. Jones*, 123 Cal.App.4th at 462. Use *Id.* at 462 instead only if no other authority sits between it and the prior cite.
- Given: "Cal. Code Civ. Proc. section 2031.310." Not changed. Cannot format: the firm's citation style (Bluebook or California Style Manual) is not stated. Attorney to choose.

Changes made:
- "the same case again at 462" → *Smith v. Jones*, 123 Cal.App.4th at 462.

Cannot format:
- "Cal. Code Civ. Proc. section 2031.310": style not stated (see above).

Format only. Every citation must be checked against the source by a person.

**Privilege labels (audience only; attorney decides privilege)**
- [OPPOSING COUNSEL] Nov 3 email from Gwen Lindqvist (Vantagebrook Law): one-week extension offer, reported as what she said.
- [THIRD PARTY] Nov 4 draft: Ravi Kessel (Redcliffe Consulting), client's outside consultant, was cc'd. Whether the client and other participants were also on it: Not stated in the document.
- [CLIENT] Proposed email to Tomas Brandvold. If Ravi Kessel or opposing counsel is copied, the audience is mixed. Mixed audience: attorney to consider whether privilege applies.
- [UNKNOWN] Minute order and clerk's date: a court document with no participants shown.

An attorney must review this before anyone relies on it.
