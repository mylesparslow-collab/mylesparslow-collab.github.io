Not covered by the policy. Ask the General Counsel's office.

The closest sections are these, quoted for reference only: "No other generative AI tool may be used for Firm or client work." (Section 2.2), and "Do not put client information into any tool that is not approved under Section 2, for any reason." (Section 3.3).

Whether using one is ethical is not covered by the policy. Ask the General Counsel's office.

An attorney must review this before anyone relies on it.
