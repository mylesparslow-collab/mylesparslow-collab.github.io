import type { Server } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { startMockToolServer } from "../mock-tools/server.js";
import { startAgent } from "../src/server.js";
import { BRIEF, portOf, RECORD, scripted } from "./fixtures.js";

// Posts Bot Framework message activities to the real /api/messages route, in the SDK's anonymous local-dev mode
// (no clientId configured, NODE_ENV != production). deliveryMode "expectReplies" makes the SDK return the agent's
// replies in the HTTP response body, so no Bot Connector or tenant is needed to capture them.
let mock: Server, agent: Server, model = scripted(), base = "";
beforeAll(async () => {
  mock = await startMockToolServer(0);
  agent = await startAgent({ port: 0, model, lexMcpUrl: `http://127.0.0.1:${portOf(mock)}/mcp` });
  base = `http://127.0.0.1:${portOf(agent)}`;
});
afterAll(async () => {
  await Promise.all([agent, mock].map((s) => new Promise<void>((ok) => s.close(() => ok()))));
});

let id = 0;
async function say(conversation: string, text: string, extra: Record<string, unknown> = {}) {
  const res = await fetch(`${base}/api/messages`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      type: "message", id: `m${++id}`, channelId: "test", serviceUrl: "http://127.0.0.1:1/",
      deliveryMode: "expectReplies", timestamp: new Date().toISOString(),
      from: { id: "user-1", name: "Test User" }, recipient: { id: "brief-bench", name: "Brief Bench" },
      conversation: { id: conversation }, locale: "en-US", text, ...extra,
    }),
  });
  const body = (await res.json().catch(() => ({}))) as { activities?: { type: string; text?: string; attachments?: { contentType: string; content: any }[] }[] };
  return { status: res.status, activities: body.activities ?? [] };
}

describe("HTTP: Bot Framework activities to /api/messages", () => {
  it("health route answers", async () => {
    expect((await (await fetch(`${base}/health`)).json()).ok).toBe(true);
  });

  it("review: sends typing + step messages, then the report with an Adaptive Card", async () => {
    const r = await say("conv-A", `Please review.\n--- BRIEF ---\n${BRIEF}\n--- RECORD ---\n${RECORD}`);
    expect(r.status).toBe(200);
    const types = r.activities.map((a) => a.type);
    expect(types.filter((t) => t === "typing")).toHaveLength(5); // one per step
    const texts = r.activities.filter((a) => a.type === "message").map((a) => a.text!);
    expect(texts[0]).toMatch(/^Step 1 of 5/);
    expect(texts.some((t) => /^Done: 29 sentences/.test(t))).toBe(true);
    const final = r.activities[r.activities.length - 1];
    expect(final.text).toMatch(/Sentence 4: Not supported/);
    expect(final.text).toMatch(/attorney must review/i);
    const card = final.attachments!.find((a) => a.contentType === "application/vnd.microsoft.card.adaptive")!.content;
    expect(card.type).toBe("AdaptiveCard");
    expect(card.version).toBe("1.5");
  });

  it("follow-ups use the stored state: no re-run, and re-check calls the model once", async () => {
    const calls = model.calls.length;
    const shown = await say("conv-A", "show me the unsupported ones");
    const t = shown.activities.map((a) => a.text).join("\n");
    expect(t).toMatch(/Sentence 4:/);
    expect(t).toMatch(/Sentence 12:/);
    expect(model.calls.length).toBe(calls); // nothing re-run

    const re = await say("conv-A", "re-check sentence 12");
    expect(re.activities.map((a) => a.text).join("\n")).toMatch(/Re-checked sentence 12 only/);
    expect(model.calls.length).toBe(calls + 1);
  });

  it("a different conversation has its own (empty) state", async () => {
    const r = await say("conv-B", "show unsupported");
    expect(r.activities.map((a) => a.text).join("\n")).toMatch(/no review in this conversation yet/);
  });

  it("an unrecognised message gets help text", async () => {
    const r = await say("conv-C", "hello");
    expect(r.activities.map((a) => a.text).join("\n")).toMatch(/--- BRIEF ---/);
  });

  it("reads the brief and record from inline text attachments", async () => {
    const att = (name: string, content: string) => ({ contentType: "text/plain", name, content });
    const r = await say("conv-D", "review these", { attachments: [att("brief.txt", BRIEF), att("record.txt", RECORD)] });
    const final = r.activities[r.activities.length - 1];
    expect(final.text).toMatch(/Sentence 7: Quote differs/);
  });
});

// Streaming path: on webchat/Teams-style channels the SDK sends "informative" typing updates and then a final message
// through the Bot Connector. A local stand-in for the connector (the serviceUrl) records what the agent sends.
import { createServer } from "node:http";
describe("HTTP: streaming channel with a stand-in connector", () => {
  it("sends informative updates per step, then one final message carrying the card", async () => {
    const sent: any[] = [];
    const connector = createServer(async (req, res) => {
      const chunks: Buffer[] = [];
      for await (const c of req) chunks.push(c as Buffer);
      try { sent.push(JSON.parse(Buffer.concat(chunks).toString() || "null")); } catch { /* ignore */ }
      res.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify({ id: `r${sent.length}` }));
    });
    await new Promise<void>((ok) => connector.listen(0, "127.0.0.1", ok));
    try {
      const res = await fetch(`${base}/api/messages`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({
          type: "message", id: "s1", channelId: "webchat", serviceUrl: `http://127.0.0.1:${portOf(connector)}/`,
          from: { id: "u" }, recipient: { id: "brief-bench" }, conversation: { id: "conv-S" },
          text: `--- BRIEF ---\n${BRIEF}\n--- RECORD ---\n${RECORD}`,
        }),
      });
      expect([200, 202]).toContain(res.status);
      for (let i = 0; i < 100 && !sent.some((a) => a?.type === "message"); i++) await new Promise((ok) => setTimeout(ok, 50));
      const informative = sent.filter((a) => a?.type === "typing" && a.entities?.some((e: any) => e.streamType === "informative"));
      expect(informative.map((a) => a.text)).toEqual(expect.arrayContaining([expect.stringMatching(/^Step 1 of 5/), expect.stringMatching(/^Step 5 of 5/)]));
      const final = sent.filter((a) => a?.type === "message").pop();
      expect(final.text).toMatch(/Sentence 4: Not supported/);
      expect(final.attachments[0].content.version).toBe("1.5");
    } finally {
      await new Promise<void>((ok) => connector.close(() => ok()));
    }
  });
});
