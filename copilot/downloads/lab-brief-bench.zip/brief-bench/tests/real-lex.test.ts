import { describe, expect, it } from "vitest";
import { verifyCfr } from "../src/mcpClient.js";
import { split } from "../src/split.js";
import { BRIEF, RECORD } from "./fixtures.js";

// Opt-in: runs the CFR step against a REAL lex-mcp server (it calls the live eCFR). Start it with
//   cd ../lex-mcp && uv run --python 3.12 python -m lex_tools.server      (port 8721)
// then: LEX_MCP_URL=http://127.0.0.1:8721/mcp npx vitest run tests/real-lex.test.ts
describe.skipIf(!process.env.LEX_MCP_URL)("real lex-mcp server", () => {
  it("flags the stale 483.70(n) sentence from the demo brief as heading_differs", async () => {
    const out = await verifyCfr(split({ brief: BRIEF, record: RECORD }), process.env.LEX_MCP_URL, 60_000);
    const stale = out.find((f) => f.citation === "42 CFR 483.70(n)")!;
    expect(stale.status).toBe("heading_differs");
    expect(stale.heading_today).toBe("Hospice services");
  }, 90_000);

  it("confirms 483.70(m) as found when the sentence is about arbitration", async () => {
    const brief = "The regulation bars a facility from requiring a resident to sign a binding arbitration agreement as a condition of admission (42 C.F.R. § 483.70(m)).";
    const out = await verifyCfr(split({ brief, record: RECORD }), process.env.LEX_MCP_URL, 60_000);
    expect(out[0]).toMatchObject({ citation: "42 CFR 483.70(m)", status: "found", heading_today: "Binding arbitration agreements" });
  }, 90_000);
});
