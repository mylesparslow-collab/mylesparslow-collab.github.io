import { describe, expect, it } from "vitest";
import { split } from "../src/split.js";
import { verifyQuotes } from "../src/verifyQuotes.js";
import { BRIEF, RECORD } from "./fixtures.js";

const rec = "[1 CT 41] ARBITRATION AGREEMENT. The Resident may rescind this Agreement within thirty (30) days of signing by written notice to the Administrator.\n[1 CT 50] The nurse noted the resident was calm and oriented on admission day.";

const run = (brief: string) => verifyQuotes(split({ brief, record: rec }));

describe("verify-quotes (deterministic)", () => {
  it("passes an exact quote", () => {
    const [q] = run('It says "within thirty (30) days of signing" (1 CT 41).');
    expect(q).toMatchObject({ status: "verbatim", matchedIn: "1 CT 41" });
  });

  it("reports a near-miss as 'differs' with a diff and the record's words", () => {
    const [q] = run('It says "may rescind this Agreement within sixty (60) days of signing" (1 CT 41).');
    expect(q.status).toBe("differs");
    expect(q.diff).toContain("[-thirty-]{+sixty+}");
    expect(q.diff).toContain("[-(30)-]{+(60)+}");
    expect(q.recordText).toContain("thirty (30)");
    expect(q.distance).toBe(2);
  });

  it("reports a quote that is not in the record at all", () => {
    const [q] = run('The nurse wrote "resident was agitated and refused all care" (1 CT 50).');
    expect(q.status).toBe("not_found");
  });

  it("notes when the exact words are in the record but at another cite", () => {
    const [q] = run('The nurse wrote "calm and oriented on admission day" (1 CT 41).');
    expect(q).toMatchObject({ status: "verbatim_elsewhere", matchedIn: "1 CT 50" });
  });

  it("does not check quotes in regulation sentences against the record", () => {
    const [q] = run('The rule says "shall not require the resident to sign" (42 C.F.R. § 483.70(n)).');
    expect(q.status).toBe("not_checked");
  });

  it("on the demo brief: exactly one altered quote, five exact", () => {
    const out = verifyQuotes(split({ brief: BRIEF, record: RECORD }));
    expect(out.filter((q) => q.status === "verbatim")).toHaveLength(5);
    expect(out.filter((q) => q.status === "differs").map((q) => q.sentence)).toEqual([7]);
  });
});
