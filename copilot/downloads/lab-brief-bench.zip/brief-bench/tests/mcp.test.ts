import { createServer, type Server } from "node:http";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { startMockToolServer } from "../mock-tools/server.js";
import { callCfrCiteCheck, verifyCfr } from "../src/mcpClient.js";
import { split } from "../src/split.js";
import { BRIEF, portOf, RECORD } from "./fixtures.js";

let srv: Server, url: string;
beforeAll(async () => { srv = await startMockToolServer(0); url = `http://127.0.0.1:${portOf(srv)}/mcp`; });
afterAll(() => new Promise<void>((ok) => srv.close(() => ok())));

describe("cfr_cite_check over Streamable HTTP", () => {
  it("returns the real lex-mcp shape and maps the real statuses", async () => {
    const r = await callCfrCiteCheck(url, [
      { citation: "42 CFR 483.70(m)", context: "Federal regulations bar a facility from requiring that a resident sign an arbitration agreement as a condition of admission." },
      { citation: "29 CFR 825.300(z)", context: "" },
      { citation: "42 CFR 999.999(a)", context: "" },
    ]);
    expect(r.map((x) => x.status)).toEqual(["found", "paragraph_not_found", "not_found"]);
    expect(r[0]).toMatchObject({ heading_today: "Binding arbitration agreements", last_amended: expect.any(String), human_url: expect.stringContaining("ecfr.gov") });
    expect(r[1].note).toMatch(/No paragraph/);
    expect(r[1].paragraphs_that_exist?.length).toBeGreaterThan(0);
  });

  it("an unknown status string fails closed to 'Could not check'", async () => {
    const mk = () => {
      const s = new McpServer({ name: "odd", version: "1" });
      s.registerTool("cfr_cite_check", { inputSchema: { citations: z.array(z.string()), context: z.array(z.string()).optional() } }, async ({ citations }) => ({
        content: [{ type: "text" as const, text: JSON.stringify({ status: "ok", results: citations.map((c) => ({ citation: c, normalized: c, status: "Looks fine to me", reason: "x" })) }) }],
      }));
      return s;
    };
    const odd = createServer(async (req, res) => {
      if (req.method !== "POST") { res.writeHead(405).end(); return; }
      const chunks: Buffer[] = [];
      for await (const c of req) chunks.push(c as Buffer);
      const t = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
      await mk().connect(t);
      await t.handleRequest(req, res, JSON.parse(Buffer.concat(chunks).toString()));
    });
    await new Promise<void>((ok) => odd.listen(0, "127.0.0.1", ok));
    try {
      const out = await verifyCfr(split({ brief: BRIEF, record: RECORD }), `http://127.0.0.1:${portOf(odd)}/mcp`, 3000);
      expect(out.every((f) => f.status === "could_not_check" && /unrecognised status/.test(f.note))).toBe(true);
    } finally {
      await new Promise<void>((ok) => odd.close(() => ok()));
    }
  });

  it("verify-cfr maps results onto the sentences that cite them", async () => {
    const out = await verifyCfr(split({ brief: BRIEF, record: RECORD }), url);
    expect(out.map((f) => [f.sentence, f.status])).toEqual([[22, "heading_differs"], [23, "heading_differs"]]);
    expect(out[0]).toMatchObject({ heading_today: "Hospice services", human_url: expect.stringContaining("ecfr.gov") });
  });

  it("server down: reports 'Could not check' for every cite and never guesses", async () => {
    const dead = await startMockToolServer(0);
    const deadUrl = `http://127.0.0.1:${portOf(dead)}/mcp`;
    await new Promise<void>((ok) => dead.close(() => ok()));
    const out = await verifyCfr(split({ brief: BRIEF, record: RECORD }), deadUrl, 3000);
    expect(out).toHaveLength(2);
    for (const f of out) { expect(f.status).toBe("could_not_check"); expect(f.note).toMatch(/^Could not check/); }
  });

  it("no URL configured: also 'Could not check'", async () => {
    const out = await verifyCfr(split({ brief: BRIEF, record: RECORD }), undefined);
    expect(out.every((f) => f.status === "could_not_check" && /LEX_MCP_URL/.test(f.note))).toBe(true);
  });
});

describe("topic-not-checked status (lex-mcp, 2026-11-13)", () => {
  it("maps 'Paragraph exists (topic not checked)' to topic_not_checked, never to found", async () => {
    const { REAL_STATUS } = await import("../src/mcpClient.js");
    expect(REAL_STATUS["Paragraph exists (topic not checked)"]).toBe("topic_not_checked");
    expect(Object.entries(REAL_STATUS).filter(([, v]) => v === "found").map(([k]) => k)).toEqual(["Confirmed current"]);
  });
});
