import { describe, expect, it } from "vitest";
import { extractCfrCites, extractDates, extractQuotes, extractRecordCites, split, splitSentences } from "../src/split.js";
import { containsVerbatim, parseCite, parseRecord, resolveCite } from "../src/record.js";
import { BRIEF, RECORD } from "./fixtures.js";

describe("splitter and extractors", () => {
  it("does not split on abbreviations, initials or reporter cites", () => {
    const s = splitSentences("Mr. Alvarez of Acme Inc. signed No. 5 on Jan. 3. He left. See Dr. J. Smith's note (2 CT 415). Done.");
    expect(s).toEqual(["Mr. Alvarez of Acme Inc. signed No. 5 on Jan. 3.", "He left.", "See Dr. J. Smith's note (2 CT 415).", "Done."]);
  });

  it("attaches a trailing citation sentence to the sentence before it", () => {
    expect(splitSentences("The rule applies. (42 C.F.R. § 483.12(a)(1).) Next fact (1 CT 5).")).toEqual([
      "The rule applies. (42 C.F.R. § 483.12(a)(1).)",
      "Next fact (1 CT 5).",
    ]);
  });

  it("extracts record cites in several forms", () => {
    expect(extractRecordCites("x (2 CT 415) y (RT 88:4-12) z (See 1 CT 41-42; 3 RT 9:1-3.) (not a cite)")).toEqual(["2 CT 415", "RT 88:4-12", "1 CT 41-42", "3 RT 9:1-3"]);
  });

  it("extracts and normalises CFR cites", () => {
    expect(extractCfrCites("See 42 C.F.R. § 483.70(n) and 42 CFR 483.12(a)(1); also 29 CFR Part 1910.")).toEqual(["42 CFR 483.70(n)", "42 CFR 483.12(a)(1)", "29 CFR 1910"]);
  });

  it("extracts quoted passages of four or more words only", () => {
    expect(extractQuotes('The "facility" said “the care plan called for an alarm” and "no".')).toEqual(["the care plan called for an alarm"]);
  });

  it("extracts dates as written", () => {
    expect(extractDates("On June 14, 2022 and 3/4/2023, also 2023-05-18 and in May 2021.")).toEqual(["June 14, 2022", "3/4/2023", "2023-05-18", "May 2021"]);
  });

  it("splits the demo brief into 29 numbered sentences with the expected cites", () => {
    const sp = split({ brief: BRIEF, record: RECORD });
    expect(sp.totals).toMatchObject({ sentences: 29, cfrCites: 2, quotes: 6 });
    expect(sp.sentences[0].n).toBe(1);
    expect(sp.sentences[21].cfrCites).toEqual(["42 CFR 483.70(n)"]);
    expect(sp.recordBlocks).toHaveLength(15);
  });

  it("parses record blocks and resolves cites, including line ranges", () => {
    const blocks = parseRecord("[2 CT 415-417] a\n[RT 88:1-25]\nb\nc\n[RT 90:1-9] d");
    expect(blocks.map((b) => b.key)).toEqual(["2 CT 415-417", "RT 88:1-25", "RT 90:1-9"]);
    expect(blocks[1].text).toBe("b c");
    expect(resolveCite("2 CT 416", blocks)).toHaveLength(1);
    expect(resolveCite("RT 88:4-12", blocks)[0].key).toBe("RT 88:1-25");
    expect(resolveCite("RT 88:20-30", blocks)).toHaveLength(0);
    expect(parseCite("garbage")).toBeNull();
  });

  it("containsVerbatim honours ellipses and ignores curly-quote and whitespace differences", () => {
    expect(containsVerbatim("The  “Court” finds the Agreement valid and enforceable.", 'The "Court" finds')).toBe(true);
    expect(containsVerbatim("alpha beta gamma delta", "alpha ... delta")).toBe(true);
    expect(containsVerbatim("alpha beta gamma delta", "delta ... alpha")).toBe(false);
    expect(containsVerbatim("alpha beta", "alpha gamma")).toBe(false);
  });
});
