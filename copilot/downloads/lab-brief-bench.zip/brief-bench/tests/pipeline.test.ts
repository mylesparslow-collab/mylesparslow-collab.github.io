import type { Server } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { startMockToolServer } from "../mock-tools/server.js";
import { recheckSentence, runPipeline, type StepEvent } from "../src/pipeline.js";
import { BRIEF, portOf, RECORD, scripted } from "./fixtures.js";

let srv: Server, url: string;
beforeAll(async () => { srv = await startMockToolServer(0); url = `http://127.0.0.1:${portOf(srv)}/mcp`; });
afterAll(() => new Promise<void>((ok) => srv.close(() => ok())));

describe("pipeline end to end (ScriptedClient + mock MCP server)", () => {
  it("runs the five steps in order and finds every planted problem", async () => {
    const events: string[] = [];
    const st = await runPipeline({ brief: BRIEF, record: RECORD }, { model: scripted(), lexMcpUrl: url }, (e: StepEvent) => void events.push(`${e.step}:${e.phase}`));
    expect(st.steps.map((s) => s.step)).toEqual(["split", "verify-quotes", "verify-cfr", "support-check", "report"]);
    expect(events).toEqual(["split", "verify-quotes", "verify-cfr", "support-check", "report"].flatMap((s) => [`${s}:start`, `${s}:done`]));
    expect(st.steps.every((s) => s.status === "ok" && s.ms >= 0)).toBe(true);

    expect(st.support!.filter((f) => f.verdict === "unsupported").map((f) => f.sentence)).toEqual([4, 12]);
    expect(st.quotes!.filter((q) => q.status === "differs").map((q) => q.sentence)).toEqual([7]);
    expect(st.cfr!.find((c) => c.sentence === 22)).toMatchObject({ status: "heading_differs", heading_today: "Hospice services" });

    const md = st.report!.markdown;
    expect(md).toMatch(/Sentence 4: Not supported/);
    expect(md).toMatch(/Sentence 7: Quote differs/);
    expect(md).toMatch(/483\.70\(n\)/);
    expect(md).toMatch(/attorney must review/i);

    const card = st.report!.card as { version: string; $schema: string; body: { text?: string }[] };
    expect(card.version).toBe("1.5");
    expect(card.$schema).toBe("http://adaptivecards.io/schemas/adaptive-card.json");
    expect(JSON.stringify(card)).toMatch(/attorney must review/i);
  });

  it("tool server down: the run completes, step 3 is partial, nothing about the cites is guessed", async () => {
    const st = await runPipeline({ brief: BRIEF, record: RECORD }, { model: scripted(), lexMcpUrl: "http://127.0.0.1:9/mcp", cfrTimeoutMs: 2000 });
    expect(st.steps.find((s) => s.step === "verify-cfr")!.status).toBe("partial");
    expect(st.cfr!.every((c) => c.status === "could_not_check")).toBe(true);
    expect(st.report!.markdown).toMatch(/Could not check 42 CFR 483\.70\(n\)/);
  });

  it("re-check re-runs exactly one sentence", async () => {
    const m = scripted();
    const st = await runPipeline({ brief: BRIEF, record: RECORD }, { model: m, lexMcpUrl: url });
    const before = m.calls.length;
    expect(await recheckSentence(st, 12, { model: m, lexMcpUrl: url })).toBe(true);
    expect(m.calls.length - before).toBe(1);
    expect(await recheckSentence(st, 999, { model: m })).toBe(false);
  });
});
