# Brief Bench agent

A custom engine agent (our own orchestration and model), not a declarative agent, so it has no `declarativeAgent.json`
or `instructions.txt`. The app package is at `../../appPackage/` (manifest with a `bots` entry and
`copilotAgents.customEngineAgents`). The safety rules live in code: see `../../src/supportCheck.ts` (`SUPPORT_SYSTEM`)
and `../../src/report.ts` (every output ends with the attorney-review line). See the lab README for everything else.
