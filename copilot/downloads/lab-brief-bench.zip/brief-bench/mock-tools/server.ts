// Tiny MCP server (Streamable HTTP, stateless) with canned cfr_cite_check answers.
// Answers are replayed real lex-mcp results (see below); not legal advice.
import { readFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

// Replays results captured from the REAL lex-mcp server (tests/fixtures/cfr_cite_check_real.json), in its exact shape,
// so the mock cannot drift from the contract. Match: same cite and same context; else same cite; else "Could not check".
const fixture = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), "..", "tests", "fixtures", "cfr_cite_check_real.json"), "utf8")) as {
  calls: { arguments: { citations: string[]; context: string[] }; response: { results: Record<string, any>[]; [k: string]: unknown } }[];
};
const captured = fixture.calls.flatMap((c) => c.response.results.map((r, i) => ({ r, context: c.arguments.context[i] ?? "", wrapper: c.response })));
const key = (s: string) => s.replace(/\s+/g, " ").trim().toLowerCase();

export function checkCites(citations: string[], context: string[] = []) {
  return citations.map((citation, i) => {
    const hits = captured.filter((c) => key(c.r.normalized ?? c.r.citation) === key(citation));
    const hit = hits.find((c) => c.context === (context[i] ?? "")) ?? hits[0];
    return hit
      ? { ...hit.r, citation }
      : { citation, normalized: citation, status: "Could not check", reason: "mock: no captured real result for this citation", evidence: {} };
  });
}

function buildServer(): McpServer {
  const s = new McpServer({ name: "mock-lex-tools", version: "0.1.0" });
  s.registerTool(
    "cfr_cite_check",
    {
      description: "Check whether each CFR citation exists as written (title, part, section, paragraph). Returns one result per citation.",
      inputSchema: { citations: z.array(z.string()), context: z.array(z.string()).optional(), as_of_date: z.string().optional() },
    },
    async ({ citations, context }) => {
      const wrapper = fixture.calls[0].response;
      return { content: [{ type: "text", text: JSON.stringify({ ...wrapper, results: checkCites(citations, context) }) }] };
    },
  );
  return s;
}

export function startMockToolServer(port = 8725): Promise<Server> {
  const http = createServer(async (req, res) => {
    if (req.url !== "/mcp") { res.writeHead(404).end(); return; }
    if (req.method !== "POST") { res.writeHead(405, { allow: "POST" }).end(); return; }
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    let body: unknown;
    try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { res.writeHead(400).end(); return; }
    const server = buildServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    res.on("close", () => { void transport.close(); void server.close(); });
    await server.connect(transport);
    await transport.handleRequest(req, res, body);
  });
  return new Promise((resolve) => http.listen(port, "127.0.0.1", () => resolve(http)));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.MOCK_PORT || 8725);
  await startMockToolServer(port);
  console.log(`mock cfr_cite_check MCP server on http://127.0.0.1:${port}/mcp`);
}
