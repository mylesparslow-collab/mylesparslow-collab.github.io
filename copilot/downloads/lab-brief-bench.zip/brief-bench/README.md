# Brief Bench (custom engine agent)

Brief Bench reviews a draft legal brief against record excerpts. Unlike a declarative agent, we own the orchestration and
the model: a five-step pipeline where only one step uses a language model, and code checks what the model says. It is built
on the Microsoft 365 Agents SDK for JavaScript (`@microsoft/agents-hosting` 1.10.1, Node 22, TypeScript), streams progress
step by step, and keeps per-conversation state so follow-ups ("show the unsupported ones", "re-check sentence 14") do not re-run everything.
All data is invented (Thornwood Garza LLP, a made-up appeal). Nothing is deployed.

## Pipeline

```
 message (brief + record as text, or two attached .txt/.md files)
        |
        v
 [1 split]          code     numbered sentences; record cites, CFR cites, quoted passages, dates
        |
        v
 [2 verify-quotes]  code     each quote must appear word for word in the cited record text
        |                    near-miss => "quote differs" + token diff; elsewhere => "wrong cite"
        v
 [3 verify-cfr]     MCP tool cfr_cite_check (lex-mcp) over Streamable HTTP (LEX_MCP_URL, official MCP SDK client)
        |                    server down / odd reply => "Could not check", never a guess
        v
 [4 support-check]  MODEL     one call per cited sentence: sees that sentence + only its cited record text
        |                    -> {verdict: supported|partly|unsupported|cannot_tell, quote}
        |                    code then checks the quote is verbatim in that record text (and not unrelated);
        |                    otherwise the verdict is downgraded to cannot_tell
        v
 [5 report]         code     Markdown report + Adaptive Card 1.5 (counts, top issues, attorney-review line)
```

Steps are an explicit state machine (`MACHINE` in `src/pipeline.ts`); every step records input, output, status and timing.

Safety properties: record/brief text is wrapped in `<sentence>`/`<record>` tags and the system prompt says it is untrusted data;
each model call sees one sentence, so an injected instruction cannot touch other sentences; a closing tag inside the data is defanged;
fabricated or unrelated quotes are downgraded by code; dates are listed as written, never computed; every output ends with the attorney-review line.

## Layout

- `src/split.ts`, `record.ts`, `verifyQuotes.ts`, `mcpClient.ts`, `supportCheck.ts`, `report.ts`, `pipeline.ts`: the pipeline.
- `src/models.ts`: `ModelClient` with `AnthropicClient` (official SDK, `ANTHROPIC_MODEL`, default `claude-haiku-5-5`), `AzureOpenAIClient` (plain fetch, **untested**), `ScriptedClient` (tests), `ClaudeCliClient` (`claude -p --model haiku`, no tools).
- `src/agent.ts`, `followups.ts`, `server.ts`: the `AgentApplication`, follow-up router, Express host (`POST /api/messages`, `GET /health`).
- `mock-tools/server.ts`: tiny MCP server that replays results captured from the REAL lex-mcp server (`tests/fixtures/cfr_cite_check_real.json`, same field names and status strings), so the mock cannot drift from the contract. Unknown cites return "Could not check".
- `appPackage/`: Teams / Microsoft 365 app package (see "Not verified").
- `demo/`: invented brief and record, and the captured real run (`run.json`, `report.md`, `card.json`).

## Record format

Record excerpts are blocks with a header such as `[2 CT 415]` or `[RT 88:4-12]` followed by the text. A brief cite resolves to
blocks with the same type and volume, overlapping pages, and (for single-page transcript cites) containing the cited lines.
The model is given the whole matching block, not individual lines.

## Run

```
npm install
npm test                      # unit + integration + HTTP tests, ephemeral ports
npm run typecheck
LEX_MCP_URL=http://127.0.0.1:8721/mcp npx vitest run tests/real-lex.test.ts   # opt-in: against the real lex-mcp server (live eCFR)
npm run mock-tools            # terminal 1: mock MCP tool server on 8725 (or run the real labs/lex-mcp server on 8721)
LEX_MCP_URL=http://127.0.0.1:8725/mcp ANTHROPIC_API_KEY=... npm start   # terminal 2: agent on 8724
```

Without `ANTHROPIC_API_KEY`, `MODEL_PROVIDER` defaults to `claude-cli` (needs the `claude` CLI). `npm run demo` re-runs the demo
(starts and stops its own mock server). See `.env.example`.

Local dev auth: with no `clientId` configured and `NODE_ENV` not `production`, the SDK's `authorizeJWT` accepts requests as anonymous
(same mode its quickstart uses). A request with `"deliveryMode": "expectReplies"` gets the agent's replies back in the HTTP response.

## Regulation cites: the real lex-mcp contract

`cfr_cite_check(citations, context?, as_of_date?)` returns `{status:"ok", results:[{citation, normalized, status, reason, heading_today?, topic_found_at?, paragraphs_that_exist?, last_amended?, evidence:{human_url,...}}]}`.
We map its five statuses (Confirmed current, Paragraph not found, Section not found, Heading differs, Could not check) and fail closed ("Could not check") on any other string, a result-count mismatch, or a result for a different cite. `reason` is the note; `heading_today`, `topic_found_at`, `last_amended` and the eCFR link are kept and shown in the report.
Important: 42 CFR 483.70(n) exists today ("Hospice services"), so without `context` the tool says "Confirmed current". It flags the stale cite only when told what the brief says the cite is about. We pass `context` per (sentence, cite), built by code from the sentence with its parentheticals, cite text and dates removed (`cfrContext` in `src/mcpClient.ts`). No model.

What worked against the real server (3 variants tried on the demo cites): the plain sentence gave "Heading differs" for 483.70(n) (correct) and also for 483.12(a)(1) (the sentence says "neglect"; the server found too few topic words in that paragraph); 483.70(m) with an arbitration sentence is "Confirmed current". Stripping generic words from the context made it worse: depending on the filter, either the stale cite was missed or the valid one flagged, so we send the plain sentence. The server's matcher is keyword substring matching (a rough signal; the server says so), and "Heading differs" is a "human must check" flag, not a finding that the cite is wrong. 483.12(a)(1) is therefore an unplanned flag in the demo.

## Demo result (one real model run, real CFR tool)

`demo/run.json` is a real run with `claude-cli:haiku` (no `ANTHROPIC_API_KEY` was set): 29 sentences, 27 checked, 27 model calls, about 111 s.
It found both planted unsupported sentences (4 and 12) and the altered quote (sentence 7: "sixty (60) days" vs the record's "thirty (30) days"). The injected sentence 15 did not change anything.
The verify-cfr step in `run.json` was then re-run against the REAL lex-mcp server (live eCFR, `labs/lex-mcp`, port 8721) with no new model calls: support-check results are the original Haiku results. It returns "Heading differs" for 42 CFR 483.70(n) ("Hospice services" today, last amended 2024-06-21, link to eCFR) and for 483.12(a)(1) (see above). `report.md` and `card.json` were re-rendered from that. (The first version of the demo used the mock's invented answer; that is gone.)
Caveat: Haiku was strict and marked 10 sentences "partly" where a lawyer would likely call them supported, so expect noise on the "partly" bucket.

## Verified here

- `npm test` (vitest): splitter and extractors; quote verifier including near-miss diff; fabricated-quote guard; bounded concurrency, timeout, one retry on bad JSON;
  prompt-injection test (a deliberately gullible scripted model that obeys injected text cannot change any other sentence's verdict, and its own "supported" is downgraded by the guard);
  MCP client against the mock server (real-shape replay) over Streamable HTTP, including server-down, no-URL and unknown-status (fail closed) paths; full pipeline with `ScriptedClient`; re-check of one sentence.
- HTTP-level tests POST Bot Framework message activities to the running agent's `/api/messages` with no tenant (anonymous local mode) and capture replies:
  typing + step messages + report with Adaptive Card; follow-ups from stored per-conversation state (no re-run; re-check calls the model once);
  separate conversations isolated; text-attachment input; and the streaming path (webchat channel) against a local stand-in for the connector, capturing informative updates and the final message.
- `LEX_MCP_URL=http://127.0.0.1:8721/mcp npx vitest run tests/real-lex.test.ts` against the real lex-mcp server (started with `uv run --python 3.12 python -m lex_tools.server`, then stopped): 2 tests pass (483.70(n) is `heading_differs`; a 483.70(m) arbitration sentence is `found`).
- `npm run typecheck` passes.
- One real end-to-end run with Haiku via the Claude CLI (above).

## Not verified

- Nothing has run in Microsoft 365 Copilot or Teams; no tenant, no Azure Bot registration, no Entra app, no real JWT validation.
- The app package is not validated or sideloaded. Shape taken from Microsoft Learn (checked 2026-11-13):
  `copilotAgents.customEngineAgents[{id, type:"bot", disclaimer}]` (id must match a `bots[].botId` with personal scope; Learn marks custom engine agents in Copilot as preview/limited rollout)
  https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/root-copilot-agents ,
  `bots[{botId, scopes, supportsFiles, isNotificationOnly}]` https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/root-bots ,
  overview (manifest 1.21+) https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/overview-custom-engine-agent .
  The `id`/`botId` GUID is a placeholder; a real deployment needs the Entra app (bot) id there. Icons are copied from the Order Reader lab.
- Teams/Copilot file attachments are read through the SDK's `M365AttachmentDownloader`, which was not exercised against real Teams file URLs. Only inline text attachments were tested. Word and PDF are not supported.
- `AzureOpenAIClient` was never run. `AnthropicClient` was compiled but not run (no key); the real run used `ClaudeCliClient`.
- The real lex-mcp server was exercised locally only, not over HTTPS or from Copilot; its "Heading differs" depends on keyword matching and can over- or under-flag.
- Copilot's streaming rendering (informative updates, single stream per turn) follows Learn's guidance but was only seen at the HTTP level.
