import { Activity } from "@microsoft/agents-activity";
import { AgentApplication, M365AttachmentDownloader, MemoryStorage, TurnContext, TurnState } from "@microsoft/agents-hosting";
import { answerFollowUp, classify, HELP, parseInput } from "./followups.js";
import { MACHINE, runPipeline, type PipelineDeps } from "./pipeline.js";
import { ATTORNEY_LINE, type PipelineInput, type PipelineState, type StepName } from "./types.js";

const STEP_ORDER: StepName[] = ["split", "verify-quotes", "verify-cfr", "support-check", "report"];
const CARD_TYPE = "application/vnd.microsoft.card.adaptive";
const SESSION_KEY = "conversation.briefBench";

/** Read the brief and record from the message text, or from two attached text files (brief first, record second). */
async function readInput(context: TurnContext): Promise<{ input?: PipelineInput; problem?: string }> {
  const text = context.activity.text ?? "";
  const fromText = parseInput(text);
  if (fromText) return { input: fromText };
  const atts = (context.activity.attachments ?? []).filter((a) => a.contentType !== "text/html");
  if (!atts.length) return {};
  const bodies: { name: string; body: string }[] = [];
  let needDownload = false;
  for (const a of atts) {
    if (typeof a.content === "string") bodies.push({ name: a.name ?? "", body: a.content });
    else needDownload = true;
  }
  if (needDownload) {
    const files = await new M365AttachmentDownloader().downloadFiles(context);
    files.forEach((f, i) => {
      if (/^text\//.test(f.contentType) || /json|markdown/.test(f.contentType)) bodies.push({ name: atts[i]?.name ?? "", body: f.content.toString("utf8") });
    });
  }
  if (bodies.length < 2) return { problem: "I could not read two text attachments. Attach the brief and the record as .txt or .md files (Word and PDF are not supported yet)." };
  const rec = bodies.find((b) => /record/i.test(b.name)) ?? bodies[1];
  const brief = bodies.find((b) => b !== rec && /brief/i.test(b.name)) ?? bodies.find((b) => b !== rec)!;
  return { input: { brief: brief.body, record: rec.body } };
}

const stepSummary = (st: PipelineState, step: StepName): string => {
  switch (step) {
    case "split": return `${st.split!.totals.sentences} sentences, ${st.split!.totals.recordCites} record cites, ${st.split!.totals.cfrCites} regulation cites, ${st.split!.totals.quotes} quotations`;
    case "verify-quotes": return `${st.quotes!.filter((q) => q.status === "differs" || q.status === "not_found").length} quotation problems`;
    case "verify-cfr": return st.cfr!.some((c) => c.status === "could_not_check") ? "could not check regulation cites" : `${st.cfr!.length} regulation cites checked`;
    case "support-check": return `${st.support!.length} sentences checked`;
    case "report": return "report ready";
  }
};

export function createBriefBenchAgent(deps: PipelineDeps): AgentApplication<TurnState> {
  const app = new AgentApplication<TurnState>({ storage: new MemoryStorage(), startTypingTimer: false });

  app.onConversationUpdate("membersAdded", async (context) => {
    await context.sendActivity(`Brief Bench reviews a draft brief against record excerpts.\n\n${HELP}`);
  });

  app.onActivity("message", async (context, state) => {
    const existing = state.getValue<PipelineState | undefined>(SESSION_KEY);
    const { input, problem } = await readInput(context);

    if (!input) {
      if (problem) return void (await context.sendActivity(problem + "\n\n" + ATTORNEY_LINE));
      const f = classify(context.activity.text ?? "");
      if (!f) return void (await context.sendActivity(HELP));
      if (f.kind === "help") return void (await context.sendActivity(HELP));
      if (!existing?.report) return void (await context.sendActivity("There is no review in this conversation yet.\n\n" + HELP));
      const reply = await answerFollowUp(existing, f, deps);
      state.setValue(SESSION_KEY, existing);
      return void (await context.sendActivity(reply));
    }

    // Fresh review. Streaming channels (Teams, Copilot) get informative updates; others get typing + one message per step.
    const sr = context.streamingResponse;
    const streaming = sr.isStreamingChannel;
    const st = await runPipeline(input, deps, async (e) => {
      const i = STEP_ORDER.indexOf(e.step) + 1;
      if (e.phase === "start") {
        const line = `Step ${i} of ${STEP_ORDER.length}: ${MACHINE[e.step].label}`;
        if (streaming) sr.queueInformativeUpdate(line);
        else {
          await context.sendActivity(Activity.fromObject({ type: "typing" }));
          await context.sendActivity(line);
        }
      } else if (!streaming && e.trace && e.step !== "report") {
        await context.sendActivity(`Done: ${stepSummary(e.state, e.step)}`);
      }
    }).catch(async (err) => {
      await context.sendActivity(`The review stopped at an error: ${(err as Error).message}. Nothing was concluded. ${ATTORNEY_LINE}`);
      return null;
    });
    if (!st) return;
    state.setValue(SESSION_KEY, st);
    const attachments = [{ contentType: CARD_TYPE, content: st.report!.card }];
    if (streaming) {
      sr.setAttachments(attachments);
      sr.queueTextChunk(st.report!.markdown);
      await sr.endStream();
    } else {
      await context.sendActivity(Activity.fromObject({ type: "message", text: st.report!.markdown, attachments }));
    }
  });

  // This SDK version only persists turn state when at least one 'afterTurn' handler exists and returns true.
  app.onTurn("afterTurn", async () => true);

  return app;
}
