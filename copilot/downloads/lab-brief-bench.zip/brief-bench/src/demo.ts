// One real run of the full pipeline over demo/brief.txt + demo/record.txt. Writes demo/run.json, report.md, card.json.
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { startMockToolServer } from "../mock-tools/server.js";
import { AnthropicClient, ClaudeCliClient, type ModelClient, type ModelRequest } from "./models.js";
import { runPipeline } from "./pipeline.js";

const dir = join(dirname(fileURLToPath(import.meta.url)), "..", "demo");
const input = { brief: readFileSync(join(dir, "brief.txt"), "utf8").trim(), record: readFileSync(join(dir, "record.txt"), "utf8").trim() };

const calls: { sentence: unknown; ms: number; system?: string; prompt: string; reply?: string; error?: string }[] = [];
function recording(inner: ModelClient): ModelClient {
  return {
    name: inner.name,
    async complete(req: ModelRequest) {
      const t0 = Date.now();
      try {
        const reply = await inner.complete(req);
        calls.push({ sentence: req.meta?.sentence, ms: Date.now() - t0, prompt: req.user, reply });
        return reply;
      } catch (e) {
        calls.push({ sentence: req.meta?.sentence, ms: Date.now() - t0, prompt: req.user, error: (e as Error).message });
        throw e;
      }
    },
  };
}

const base: ModelClient = process.env.ANTHROPIC_API_KEY ? new AnthropicClient() : new ClaudeCliClient();
const model = recording(base);
const mock = await startMockToolServer(8725);
const lexMcpUrl = process.env.LEX_MCP_URL ?? "http://127.0.0.1:8725/mcp"; // real lex-mcp if set, else the mock
try {
  const t0 = Date.now();
  const st = await runPipeline(input, { model, lexMcpUrl, support: { concurrency: 3, timeoutMs: 90_000 } }, (e) => {
    if (e.phase === "done") console.log(`${e.step}: ${e.trace!.status} in ${e.trace!.ms} ms`);
  });
  writeFileSync(join(dir, "run.json"), JSON.stringify({
    ran_at: new Date().toISOString(), model: model.name, total_ms: Date.now() - t0,
    system_prompt_note: "The support-check system prompt is in src/supportCheck.ts (SUPPORT_SYSTEM); each call's user prompt is below.",
    steps: st.steps, model_calls: calls.sort((a, b) => Number(a.sentence) - Number(b.sentence)),
  }, null, 2));
  writeFileSync(join(dir, "report.md"), st.report!.markdown);
  writeFileSync(join(dir, "card.json"), JSON.stringify(st.report!.card, null, 2));
  console.log(`model ${model.name}; ${calls.length} model calls; wrote demo/run.json, report.md, card.json`);
} finally {
  mock.close();
}
