export type Verdict = "supported" | "partly" | "unsupported" | "cannot_tell";

export interface RecordBlock {
  key: string; // header as written, e.g. "2 CT 415" or "RT 88:4-12"
  type: "CT" | "RT";
  vol?: number;
  pageStart: number;
  pageEnd: number;
  lineStart?: number;
  lineEnd?: number;
  text: string;
}

export interface Sentence {
  n: number;
  text: string;
  recordCites: string[];
  cfrCites: string[];
  quotes: string[];
  dates: string[];
}

export interface SplitOutput {
  sentences: Sentence[];
  recordBlocks: RecordBlock[];
  totals: { sentences: number; recordCites: number; cfrCites: number; quotes: number; dates: number };
}

export type QuoteStatus = "verbatim" | "verbatim_elsewhere" | "differs" | "not_found" | "not_checked";

export interface QuoteFinding {
  sentence: number;
  quote: string;
  status: QuoteStatus;
  matchedIn?: string; // record block key
  recordText?: string; // nearest record text for "differs"
  diff?: string; // token diff, record vs brief
  distance?: number;
  note?: string;
}

/** Maps the real lex-mcp statuses: Confirmed current, Paragraph not found, Section not found, Heading differs, Could not check. */
export type CfrStatus = "found" | "paragraph_not_found" | "not_found" | "heading_differs" | "topic_not_checked" | "could_not_check";

export interface CfrFinding {
  sentence: number;
  citation: string;
  status: CfrStatus;
  note: string;
  context?: string; // what we told the tool the brief says the cite is about
  heading_today?: string;
  topic_found_at?: string[];
  paragraphs_that_exist?: string[];
  last_amended?: string;
  human_url?: string;
}

export interface SupportFinding {
  sentence: number;
  cites: string[];
  verdict: Verdict;
  quote: string; // verified verbatim record text, or ""
  modelVerdict?: Verdict; // what the model said before the code's guard
  guard?: string; // why the code changed the verdict
  note?: string;
  attempts: number;
}

export interface StepTrace {
  step: StepName;
  status: "ok" | "partial" | "error";
  startedAt: string;
  ms: number;
  input: unknown;
  output: unknown;
}

export type StepName = "split" | "verify-quotes" | "verify-cfr" | "support-check" | "report";

export interface PipelineInput {
  brief: string;
  record: string;
}

export interface PipelineState {
  input: PipelineInput;
  split?: SplitOutput;
  quotes?: QuoteFinding[];
  cfr?: CfrFinding[];
  support?: SupportFinding[];
  report?: { markdown: string; card: Record<string, unknown> };
  steps: StepTrace[];
  model?: string;
}

export const ATTORNEY_LINE =
  "An attorney must review every finding and the underlying record before anything is filed or relied on.";
