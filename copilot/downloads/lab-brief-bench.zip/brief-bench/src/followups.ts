import { collectIssues, counts } from "./report.js";
import { recheckSentence, type PipelineDeps } from "./pipeline.js";
import { ATTORNEY_LINE, type PipelineInput, type PipelineState } from "./types.js";

/** Pull the brief and record out of one message: "--- BRIEF ---" / "--- RECORD ---" marker lines. */
export function parseInput(text: string): PipelineInput | null {
  const re = /^[ \t]*[-=#]{2,}[ \t]*(BRIEF|RECORD)[ \t]*[-=#]*[ \t]*$/gim;
  const marks = [...text.matchAll(re)].map((m) => ({ kind: m[1].toUpperCase(), at: m.index!, end: m.index! + m[0].length }));
  if (!marks.length) return null;
  const part = (kind: string) => {
    const i = marks.findIndex((m) => m.kind === kind);
    if (i < 0) return "";
    return text.slice(marks[i].end, marks[i + 1]?.at ?? text.length).trim();
  };
  const brief = part("BRIEF"), record = part("RECORD");
  return brief && record ? { brief, record } : null;
}

export const HELP =
  "Send me a draft brief and the record excerpts. Either paste them in one message, with a line '--- BRIEF ---' before the brief and '--- RECORD ---' before the record, or attach two text files (the brief first, then the record). " +
  "Record excerpts are blocks that start with a header such as [2 CT 415] or [RT 88:4-12].\n\n" +
  "After a review you can ask: 'show unsupported', 'show partly supported', 'show quote problems', 'show regulation cites', 'show sentence 14', 're-check sentence 14', or 'full report'.\n\n" +
  ATTORNEY_LINE;

export type FollowUp =
  | { kind: "show"; filter: "unsupported" | "partly" | "cannot_tell" | "supported" | "quotes" | "cfr" | "issues" }
  | { kind: "sentence"; n: number }
  | { kind: "recheck"; n: number }
  | { kind: "report" }
  | { kind: "help" };

export function classify(text: string): FollowUp | null {
  const t = text.trim().toLowerCase();
  let m = /re-?\s?check\s+(?:sentence\s+)?#?(\d+)/.exec(t);
  if (m) return { kind: "recheck", n: Number(m[1]) };
  m = /(?:show|what about|explain|details?)(?:\s+me)?\s+(?:for\s+)?sentence\s+#?(\d+)/.exec(t);
  if (m) return { kind: "sentence", n: Number(m[1]) };
  if (/\b(full report|whole report|report)\b/.test(t) && !/show/.test(t)) return { kind: "report" };
  if (/\b(full report|whole report)\b/.test(t)) return { kind: "report" };
  if (/\b(quote|quotes|quotation)/.test(t)) return { kind: "show", filter: "quotes" };
  if (/\b(cfr|regulation|reg cite)/.test(t)) return { kind: "show", filter: "cfr" };
  if (/\bpartly|partially\b/.test(t)) return { kind: "show", filter: "partly" };
  if (/\bunsupported|not supported\b/.test(t)) return { kind: "show", filter: "unsupported" };
  if (/\bcannot tell|can't tell|cannot_tell\b/.test(t)) return { kind: "show", filter: "cannot_tell" };
  if (/\bsupported\b/.test(t)) return { kind: "show", filter: "supported" };
  if (/\b(issues|problems|everything)\b/.test(t)) return { kind: "show", filter: "issues" };
  if (/\bhelp\b/.test(t)) return { kind: "help" };
  return null;
}

const sentenceText = (st: PipelineState, n: number) => st.split?.sentences.find((s) => s.n === n)?.text ?? "";

export function describeSentence(st: PipelineState, n: number): string {
  const s = st.split?.sentences.find((x) => x.n === n);
  if (!s) return `There is no sentence ${n} (the brief has ${st.split?.totals.sentences ?? 0}).`;
  const L = [`Sentence ${n}: ${s.text}`, `Record cites: ${s.recordCites.join("; ") || "none"}`];
  const f = st.support?.find((x) => x.sentence === n);
  if (f) {
    L.push(`Verdict: ${f.verdict}${f.guard ? ` (the model said ${f.modelVerdict}; code downgraded it: ${f.guard})` : ""}`);
    if (f.quote) L.push(`Record text relied on: "${f.quote}"`);
    if (f.note) L.push(f.note);
  } else L.push(s.recordCites.length ? "Verdict: not checked." : "Verdict: none, the sentence has no record cite.");
  for (const q of st.quotes?.filter((x) => x.sentence === n) ?? []) L.push(`Quote check (${q.status}): "${q.quote}"${q.diff ? `\n  Diff: ${q.diff}` : ""}${q.note ? `\n  ${q.note}` : ""}`);
  for (const c of st.cfr?.filter((x) => x.sentence === n) ?? []) L.push(`Regulation cite ${c.citation} (${c.status}): ${c.note}`);
  return L.join("\n");
}

/** Answer a follow-up from stored state. Only "re-check" calls the model, and only for one sentence. */
export async function answerFollowUp(st: PipelineState, f: FollowUp, deps: PipelineDeps): Promise<string> {
  switch (f.kind) {
    case "help": return HELP;
    case "report": return st.report!.markdown;
    case "sentence": return describeSentence(st, f.n) + `\n\n${ATTORNEY_LINE}`;
    case "recheck": {
      if (!(await recheckSentence(st, f.n, deps))) return `There is no sentence ${f.n} (the brief has ${st.split?.totals.sentences ?? 0}).`;
      return `Re-checked sentence ${f.n} only; nothing else was re-run.\n\n${describeSentence(st, f.n)}\n\n${ATTORNEY_LINE}`;
    }
    case "show": {
      let lines: string[];
      if (f.filter === "unsupported" || f.filter === "partly" || f.filter === "cannot_tell" || f.filter === "supported") {
        const hits = (st.support ?? []).filter((x) => x.verdict === f.filter);
        lines = hits.map((x) => `Sentence ${x.sentence}: ${sentenceText(st, x.sentence)} [${x.cites.join("; ")}]${x.guard ? ` (downgraded: ${x.guard})` : ""}`);
      } else if (f.filter === "quotes") {
        lines = (st.quotes ?? []).filter((q) => q.status !== "verbatim").map((q) => `Sentence ${q.sentence} (${q.status}): "${q.quote}"${q.diff ? `\n  Diff: ${q.diff}` : ""}${q.note ? `\n  ${q.note}` : ""}`);
      } else if (f.filter === "cfr") {
        lines = (st.cfr ?? []).map((c) => `Sentence ${c.sentence}: ${c.citation} is ${c.status.replace(/_/g, " ")}. ${c.note}${c.heading_today ? ` Heading there today: "${c.heading_today}".` : ""}${c.topic_found_at?.length ? ` Topic words appear at ${c.topic_found_at.join("; ")}.` : ""}${c.human_url ? ` ${c.human_url}` : ""}`);
      } else {
        lines = collectIssues(st).map((i) => `Sentence ${i.sentence}: ${i.title}.`);
      }
      const c = counts(st);
      return `${lines.length ? lines.join("\n") : "None."}\n\n(Counts: ${c.supported} supported, ${c.partly} partly, ${c.unsupported} unsupported, ${c.cannot_tell} cannot tell.)\n\n${ATTORNEY_LINE}`;
    }
  }
}
