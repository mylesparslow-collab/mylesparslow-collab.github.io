import Anthropic from "@anthropic-ai/sdk";
import { spawn } from "node:child_process";
import { tmpdir } from "node:os";

export interface ModelRequest {
  system: string;
  user: string;
  maxTokens?: number;
  signal?: AbortSignal;
  /** Free-form tags (e.g. {sentence: 14}); real clients ignore them, ScriptedClient keys on them. */
  meta?: Record<string, unknown>;
}

export interface ModelClient {
  readonly name: string;
  complete(req: ModelRequest): Promise<string>;
}

/** Official Anthropic SDK. Model from ANTHROPIC_MODEL (default claude-haiku-5-5), key from ANTHROPIC_API_KEY. */
export class AnthropicClient implements ModelClient {
  readonly name: string;
  private client: Anthropic;
  constructor(private model = process.env.ANTHROPIC_MODEL || "claude-haiku-5-5", apiKey = process.env.ANTHROPIC_API_KEY) {
    if (!apiKey) throw new Error("ANTHROPIC_API_KEY is not set");
    this.client = new Anthropic({ apiKey });
    this.name = `anthropic:${model}`;
  }
  async complete(req: ModelRequest): Promise<string> {
    const msg = await this.client.messages.create(
      { model: this.model, max_tokens: req.maxTokens ?? 600, system: req.system, messages: [{ role: "user", content: req.user }] },
      { signal: req.signal },
    );
    return msg.content.map((b) => (b.type === "text" ? b.text : "")).join("");
  }
}

/** Azure OpenAI chat completions over plain fetch. UNTESTED: written from the public REST shape, never run against a real resource. */
export class AzureOpenAIClient implements ModelClient {
  readonly name: string;
  constructor(
    private endpoint = process.env.AZURE_OPENAI_ENDPOINT,
    private deployment = process.env.AZURE_OPENAI_DEPLOYMENT,
    private apiKey = process.env.AZURE_OPENAI_API_KEY,
    private apiVersion = process.env.AZURE_OPENAI_API_VERSION || "2024-10-21",
  ) {
    if (!endpoint || !deployment || !apiKey) throw new Error("AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT and AZURE_OPENAI_API_KEY are required");
    this.name = `azure-openai:${deployment}`;
  }
  async complete(req: ModelRequest): Promise<string> {
    const url = `${this.endpoint!.replace(/\/$/, "")}/openai/deployments/${encodeURIComponent(this.deployment!)}/chat/completions?api-version=${this.apiVersion}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", "api-key": this.apiKey! },
      body: JSON.stringify({
        messages: [{ role: "system", content: req.system }, { role: "user", content: req.user }],
        max_tokens: req.maxTokens ?? 600,
        temperature: 0,
      }),
      signal: req.signal,
    });
    if (!res.ok) throw new Error(`Azure OpenAI HTTP ${res.status}`);
    const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return j.choices?.[0]?.message?.content ?? "";
  }
}

/** Deterministic client for tests. `script` sees the request and returns the raw model text. */
export class ScriptedClient implements ModelClient {
  readonly name = "scripted";
  calls: ModelRequest[] = [];
  constructor(private script: (req: ModelRequest) => string | object | Promise<string | object>) {}
  async complete(req: ModelRequest): Promise<string> {
    this.calls.push(req);
    const r = await this.script(req);
    return typeof r === "string" ? r : JSON.stringify(r);
  }
}

/** Shells out to `claude -p --model haiku`. Used for the one real demo run when no API key is available. No tools allowed. */
export class ClaudeCliClient implements ModelClient {
  readonly name: string;
  constructor(private model = "haiku", private bin = "claude") {
    this.name = `claude-cli:${model}`;
  }
  complete(req: ModelRequest): Promise<string> {
    return new Promise((resolve, reject) => {
      const p = spawn(
        this.bin,
        [
          "-p", "--model", this.model,
          "--system-prompt", req.system,
          "--disallowedTools", "Bash,Read,Write,Edit,Glob,Grep,WebFetch,WebSearch,Agent",
          "--setting-sources", "",
          "--no-session-persistence",
        ],
        { cwd: tmpdir(), stdio: ["pipe", "pipe", "pipe"], signal: req.signal },
      );
      let out = "", err = "";
      p.stdout.on("data", (d) => (out += d));
      p.stderr.on("data", (d) => (err += d));
      p.on("error", reject);
      p.on("close", (code) => (code === 0 ? resolve(out.trim()) : reject(new Error(`claude exited ${code}: ${err.slice(0, 200)}`))));
      p.stdin.end(req.user);
    });
  }
}

export function modelFromEnv(): ModelClient {
  const which = process.env.MODEL_PROVIDER || (process.env.ANTHROPIC_API_KEY ? "anthropic" : "claude-cli");
  if (which === "azure") return new AzureOpenAIClient();
  if (which === "claude-cli") return new ClaudeCliClient();
  return new AnthropicClient();
}
