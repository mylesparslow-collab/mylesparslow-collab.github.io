import type { ModelClient } from "./models.js";
import { verifyCfr } from "./mcpClient.js";
import { buildCard, buildMarkdown } from "./report.js";
import { split } from "./split.js";
import { supportCheck, type SupportOptions } from "./supportCheck.js";
import { verifyQuotes } from "./verifyQuotes.js";
import type { PipelineInput, PipelineState, StepName, StepTrace } from "./types.js";

export interface PipelineDeps {
  model: ModelClient;
  lexMcpUrl?: string;
  support?: SupportOptions;
  cfrTimeoutMs?: number;
}

export type StepEvent = { step: StepName; phase: "start" | "done"; trace?: StepTrace; state: PipelineState };

/** The state machine: each state names the step to run and the state that follows. */
export const MACHINE: Record<StepName, { next: StepName | null; label: string }> = {
  split: { next: "verify-quotes", label: "Splitting the brief into sentences and pulling out cites, quotes and dates" },
  "verify-quotes": { next: "verify-cfr", label: "Checking every quotation against the record (no model)" },
  "verify-cfr": { next: "support-check", label: "Checking regulation cites with the cite-check tool" },
  "support-check": { next: "report", label: "Checking each cited sentence against its record text" },
  report: { next: null, label: "Assembling the report" },
};

type Handler = (st: PipelineState, deps: PipelineDeps) => Promise<{ input: unknown; output: unknown; status?: StepTrace["status"] }>;

const HANDLERS: Record<StepName, Handler> = {
  async split(st) {
    st.split = split(st.input);
    return { input: { briefChars: st.input.brief.length, recordChars: st.input.record.length }, output: st.split };
  },
  async "verify-quotes"(st) {
    st.quotes = verifyQuotes(st.split!);
    return { input: { quotes: st.split!.totals.quotes, recordBlocks: st.split!.recordBlocks.length }, output: st.quotes };
  },
  async "verify-cfr"(st, deps) {
    const cites = [...new Set(st.split!.sentences.flatMap((s) => s.cfrCites))];
    st.cfr = await verifyCfr(st.split!, deps.lexMcpUrl, deps.cfrTimeoutMs);
    return { input: { url: deps.lexMcpUrl ?? null, tool: "cfr_cite_check", citations: cites }, output: st.cfr, status: st.cfr.some((f) => f.status === "could_not_check") ? "partial" : "ok" };
  },
  async "support-check"(st, deps) {
    const todo = st.split!.sentences.filter((s) => s.recordCites.length).map((s) => s.n);
    st.support = await supportCheck(deps.model, st.split!, deps.support);
    return { input: { model: deps.model.name, sentences: todo, concurrency: deps.support?.concurrency ?? 4, timeoutMs: deps.support?.timeoutMs ?? 60000 }, output: st.support };
  },
  async report(st) {
    st.report = { markdown: buildMarkdown(st), card: buildCard(st) };
    return { input: { sections: ["split", "quotes", "cfr", "support"] }, output: { markdownChars: st.report.markdown.length } };
  },
};

export async function runStep(st: PipelineState, step: StepName, deps: PipelineDeps, onEvent?: (e: StepEvent) => void | Promise<void>): Promise<void> {
  await onEvent?.({ step, phase: "start", state: st });
  const t0 = Date.now();
  const startedAt = new Date(t0).toISOString();
  let trace: StepTrace;
  try {
    const r = await HANDLERS[step](st, deps);
    trace = { step, status: r.status ?? "ok", startedAt, ms: Date.now() - t0, input: r.input, output: r.output };
  } catch (e) {
    trace = { step, status: "error", startedAt, ms: Date.now() - t0, input: null, output: { error: (e as Error).message } };
    st.steps.push(trace);
    await onEvent?.({ step, phase: "done", trace, state: st });
    throw e;
  }
  st.steps.push(trace);
  await onEvent?.({ step, phase: "done", trace, state: st });
}

export async function runPipeline(input: PipelineInput, deps: PipelineDeps, onEvent?: (e: StepEvent) => void | Promise<void>): Promise<PipelineState> {
  const st: PipelineState = { input, steps: [], model: deps.model.name };
  let cur: StepName | null = "split";
  while (cur) {
    await runStep(st, cur, deps, onEvent);
    cur = MACHINE[cur].next;
  }
  return st;
}

/** Follow-up: re-run the model step and the quote check for one sentence, then rebuild the report. */
export async function recheckSentence(st: PipelineState, n: number, deps: PipelineDeps): Promise<boolean> {
  const sp = st.split;
  const s = sp?.sentences.find((x) => x.n === n);
  if (!sp || !s) return false;
  const t0 = Date.now();
  if (s.recordCites.length) {
    const fresh = await supportCheck(deps.model, sp, deps.support, [n]);
    st.support = [...(st.support ?? []).filter((f) => f.sentence !== n), ...fresh].sort((a, b) => a.sentence - b.sentence);
    st.steps.push({ step: "support-check", status: "ok", startedAt: new Date(t0).toISOString(), ms: Date.now() - t0, input: { recheck: n }, output: fresh });
  }
  st.quotes = verifyQuotes(sp);
  st.report = { markdown: buildMarkdown(st), card: buildCard(st) };
  return true;
}
