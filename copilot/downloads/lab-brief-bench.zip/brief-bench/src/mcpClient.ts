import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import type { CfrFinding, CfrStatus, Sentence, SplitOutput } from "./types.js";

/** One result of the real lex-mcp `cfr_cite_check` (fields we use; the server sends more). */
export interface CfrResult {
  citation: string;
  normalized?: string;
  status: CfrStatus;
  note: string; // the tool's `reason`
  heading_today?: string;
  topic_found_at?: string[];
  paragraphs_that_exist?: string[];
  last_amended?: string;
  human_url?: string;
}

/** The six status strings the real server returns. Anything else fails closed. */
export const REAL_STATUS: Record<string, CfrStatus> = {
  "Confirmed current": "found",
  "Paragraph not found": "paragraph_not_found",
  "Section not found": "not_found",
  "Heading differs": "heading_differs",
  "Paragraph exists (topic not checked)": "topic_not_checked",
  "Could not check": "could_not_check",
};

/**
 * Deterministic "what the brief says this cite is about": the sentence itself, minus its parentheticals (cites),
 * CFR cite text and dates. No model, no word filtering. We tried filtering generic words and it was worse: the server
 * counts a cite as on-topic when at least half of the context's 4+ letter keywords occur (as substrings) in the paragraph,
 * and every filter we tried flipped one of the two demo cites the wrong way. See the README.
 */
export function cfrContext(s: Sentence): string {
  let t = s.text.replace(/\([^()]*(?:\([^()]*\))*[^()]*\)/g, " ");
  t = t.replace(/\b\d{1,2}\s*C\.?F\.?R\.?\s*§*\s*[\d.]+\S*/gi, " ");
  for (const d of s.dates) t = t.replace(d, " ");
  return t.replace(/§+/g, " ").replace(/\s+/g, " ").trim();
}

export interface CfrItem { citation: string; context: string }

/** Call cfr_cite_check on the lex-mcp server (Streamable HTTP). Never guesses: any failure or surprise throws. */
export async function callCfrCiteCheck(url: string, items: CfrItem[], timeoutMs = 20_000): Promise<CfrResult[]> {
  const client = new Client({ name: "brief-bench", version: "0.1.0" });
  const transport = new StreamableHTTPClientTransport(new URL(url));
  try {
    await client.connect(transport, { timeout: timeoutMs });
    const res = await client.callTool(
      { name: "cfr_cite_check", arguments: { citations: items.map((i) => i.citation), context: items.map((i) => i.context) } },
      undefined, { timeout: timeoutMs },
    );
    if (res.isError) throw new Error("tool returned an error result");
    let payload: unknown = res.structuredContent;
    if (!payload) {
      const text = (res.content as { type: string; text?: string }[] | undefined)?.find((c) => c.type === "text")?.text;
      if (text === undefined) throw new Error("tool returned no text content");
      payload = JSON.parse(text);
    }
    const p = payload as { status?: string; results?: Record<string, any>[] };
    if (p?.status !== "ok" || !Array.isArray(p.results)) throw new Error(`unrecognised response (status ${JSON.stringify(p?.status)})`);
    if (p.results.length !== items.length) throw new Error("result count does not match citations sent");
    return p.results.map((r) => {
      const status = REAL_STATUS[String(r.status)];
      if (!status) throw new Error(`unrecognised status ${JSON.stringify(r.status)}`);
      return {
        citation: String(r.citation ?? ""), normalized: r.normalized, status, note: String(r.reason ?? ""),
        heading_today: r.heading_today ?? undefined, topic_found_at: r.topic_found_at, paragraphs_that_exist: r.paragraphs_that_exist,
        last_amended: r.last_amended ?? undefined, human_url: r.evidence?.human_url,
      };
    });
  } finally {
    await client.close().catch(() => {});
  }
}

/** Step 3: one call, one entry per (sentence, cite) so each cite gets its own sentence's context. Failure: "Could not check". */
export async function verifyCfr(sp: SplitOutput, url = process.env.LEX_MCP_URL, timeoutMs = 20_000): Promise<CfrFinding[]> {
  const rows = sp.sentences.flatMap((s) => s.cfrCites.map((citation) => ({ sentence: s.n, citation, context: cfrContext(s) })));
  if (!rows.length) return [];
  let results: CfrResult[] | undefined;
  let why = "";
  if (!url) why = "LEX_MCP_URL is not set";
  else {
    try {
      results = await callCfrCiteCheck(url, rows, timeoutMs);
      // fail closed if the server answered about a different cite than we asked, at any position
      const bad = results.findIndex((r, i) => (r.normalized ?? r.citation).replace(/\s+/g, " ").toLowerCase() !== rows[i].citation.toLowerCase());
      if (bad >= 0) { results = undefined; why = `result ${bad + 1} is for a different citation than the one sent`; }
    } catch (e) { why = (e as Error).message; }
  }
  return rows.map((row, i) => {
    const r = results?.[i];
    return r
      ? { sentence: row.sentence, citation: row.citation, status: r.status, note: r.note, context: row.context, heading_today: r.heading_today,
          topic_found_at: r.topic_found_at, paragraphs_that_exist: r.paragraphs_that_exist, last_amended: r.last_amended, human_url: r.human_url }
      : { sentence: row.sentence, citation: row.citation, status: "could_not_check", note: `Could not check: ${why}`, context: row.context };
  });
}
