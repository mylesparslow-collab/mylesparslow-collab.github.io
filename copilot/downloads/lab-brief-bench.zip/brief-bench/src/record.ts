import type { RecordBlock } from "./types.js";

// Cite grammar (California appellate style, simplified):
//   2 CT 415   2 CT 415-417   RT 88   RT 88:4-12   1 RT 88:4-12
const CT = /^(\d+)\s+CT\s+(\d+)(?:\s*[-–]\s*(\d+))?$/i;
const RT = /^(?:(\d+)\s+)?RT\s+(\d+)(?::(\d+)(?:\s*[-–]\s*(\d+))?)?(?:\s*[-–]\s*(\d+)(?::(\d+))?)?$/i;

export interface ParsedCite {
  type: "CT" | "RT";
  vol?: number;
  pageStart: number;
  pageEnd: number;
  lineStart?: number;
  lineEnd?: number;
}

export function parseCite(raw: string): ParsedCite | null {
  const s = raw.trim().replace(/\.$/, "");
  let m = CT.exec(s);
  if (m) {
    const a = Number(m[2]);
    return { type: "CT", vol: Number(m[1]), pageStart: a, pageEnd: m[3] ? Number(m[3]) : a };
  }
  m = RT.exec(s);
  if (m) {
    const page = Number(m[2]);
    const vol = m[1] ? Number(m[1]) : undefined;
    if (m[5]) {
      // page-range form "RT 88:20-89:3" or "RT 88-89"
      return { type: "RT", vol, pageStart: page, pageEnd: Number(m[5]), lineStart: m[3] ? Number(m[3]) : undefined, lineEnd: m[6] ? Number(m[6]) : undefined };
    }
    return {
      type: "RT", vol, pageStart: page, pageEnd: page,
      lineStart: m[3] ? Number(m[3]) : undefined,
      lineEnd: m[4] ? Number(m[4]) : m[3] ? Number(m[3]) : undefined,
    };
  }
  return null;
}

/** Record excerpt format: a header line "[2 CT 415]" or "[RT 88:4-12]" followed by the text. */
export function parseRecord(text: string): RecordBlock[] {
  const blocks: RecordBlock[] = [];
  let cur: { key: string; lines: string[] } | null = null;
  const flush = () => {
    if (!cur) return;
    const p = parseCite(cur.key);
    if (p) blocks.push({ key: cur.key, ...p, text: cur.lines.join(" ").replace(/\s+/g, " ").trim() });
    cur = null;
  };
  for (const line of text.split(/\r?\n/)) {
    const h = /^\s*\[([^\]]+)\]\s*(.*)$/.exec(line);
    if (h && parseCite(h[1])) {
      flush();
      cur = { key: h[1].trim(), lines: h[2] ? [h[2]] : [] };
    } else if (cur) cur.lines.push(line);
  }
  flush();
  return blocks;
}

/** A cite resolves to every block of the same type/volume whose pages overlap and whose lines contain the cited lines. */
export function resolveCite(cite: string, blocks: RecordBlock[]): RecordBlock[] {
  const c = parseCite(cite);
  if (!c) return [];
  return blocks.filter((b) => {
    if (b.type !== c.type) return false;
    if (b.vol !== undefined && c.vol !== undefined && b.vol !== c.vol) return false;
    if (b.pageEnd < c.pageStart || b.pageStart > c.pageEnd) return false;
    if (b.lineStart !== undefined && c.lineStart !== undefined && b.pageStart === b.pageEnd && c.pageStart === c.pageEnd) {
      return c.lineStart >= b.lineStart && (c.lineEnd ?? c.lineStart) <= (b.lineEnd ?? b.lineStart);
    }
    return true;
  });
}

/** Normalise for verbatim comparison: whitespace, curly quotes, dashes. Case and wording are untouched. */
export function norm(s: string): string {
  return s
    .replace(/[‘’‛]/g, "'")
    .replace(/[“”‟]/g, '"')
    .replace(/[–—]/g, "-")
    .replace(/ /g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** True if every ellipsis-separated segment of `quote` appears, in order, in `hay` (verbatim after norm). */
export function containsVerbatim(hay: string, quote: string): boolean {
  const h = norm(hay);
  const segs = norm(quote).split(/\s*(?:\.\.\.|…)\s*/).map((x) => x.trim()).filter(Boolean);
  if (!segs.length) return false;
  let from = 0;
  for (const seg of segs) {
    const i = h.indexOf(seg, from);
    if (i < 0) return false;
    from = i + seg.length;
  }
  return true;
}
