import { parseCite, parseRecord } from "./record.js";
import type { PipelineInput, Sentence, SplitOutput } from "./types.js";

const ABBREV = new Set([
  "mr", "mrs", "ms", "dr", "no", "nos", "v", "vs", "inc", "co", "corp", "ltd", "llp", "llc", "st", "cal", "cir",
  "cf", "e.g", "i.e", "jr", "sr", "ct", "app", "supp", "fed", "op", "subd", "subds", "sec", "art", "p", "pp",
  "u.s", "c.f.r", "u.s.c", "dep't", "exh", "fig", "ch", "div", "pt", "vol", "rev", "stat", "reg", "regs", "eg", "ie", "id", "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec",
]);

/** Split prose into sentences. Handles abbreviations, initials, "No. 5", reporter cites and closing quotes/parens. */
export function splitSentences(text: string): string[] {
  const t = text.replace(/\s+/g, " ").trim();
  const out: string[] = [];
  let start = 0;
  const re = /[.?!]["'”’)\]]*\s+(?=["'“(\[]?[A-Z0-9])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(t))) {
    const end = m.index + m[0].length;
    const before = t.slice(start, m.index + 1);
    const lastTok = (before.match(/(\S+)$/)?.[1] ?? "").replace(/^[("'“\[]+/, "");
    const bare = lastTok.replace(/[.?!]+["'”’)\]]*$/, "").toLowerCase();
    const isTerminalPunct = t[m.index] === ".";
    if (isTerminalPunct && (ABBREV.has(bare) || /^[a-z]$/i.test(bare))) continue;
    out.push(t.slice(start, m.index + m[0].trimEnd().length).trim());
    start = end;
  }
  const rest = t.slice(start).trim();
  if (rest) out.push(rest);
  // A citation sentence like "(2 CT 415.)" or "(42 C.F.R. § 483.12.)" belongs to the sentence before it.
  const merged: string[] = [];
  for (const x of out) {
    if (merged.length && /^\([^()]*(?:\([^()]*\))*[^()]*\)\.?$/.test(x)) merged[merged.length - 1] += " " + x;
    else merged.push(x);
  }
  return merged;
}

export function extractRecordCites(s: string): string[] {
  const out: string[] = [];
  for (const g of s.matchAll(/\(([^()]+)\)/g)) {
    for (let part of g[1].split(";")) {
      part = part.trim().replace(/^see(?:\s+also)?\s+/i, "").replace(/^id\.\s*at\s+/i, "").replace(/\.$/, "");
      if (parseCite(part)) out.push(part);
    }
  }
  return out;
}

export function extractCfrCites(s: string): string[] {
  const out = new Set<string>();
  for (const m of s.matchAll(/\b(\d{1,2})\s*C\.?F\.?R\.?\s*(?:§+\s*|sections?\s+|part\s+)?(\d+(?:\.\d+)?(?:\([A-Za-z0-9]+\))*)/gi)) {
    out.add(`${m[1]} CFR ${m[2]}`);
  }
  return [...out];
}

export function extractQuotes(s: string): string[] {
  const out: string[] = [];
  for (const m of s.matchAll(/“([^”]+)”|"([^"]+)"/g)) {
    const q = (m[1] ?? m[2]).trim();
    if (q.split(/\s+/).length >= 4) out.push(q); // shorter fragments are defined terms, not quoted passages
  }
  return out;
}

const MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December";
export function extractDates(s: string): string[] {
  const out: string[] = [];
  const re = new RegExp(`\\b(?:(?:${MONTHS})\\.?\\s+\\d{1,2}(?:st|nd|rd|th)?,\\s+\\d{4}|(?:${MONTHS})\\s+\\d{4}|\\d{1,2}/\\d{1,2}/\\d{2,4}|\\d{4}-\\d{2}-\\d{2})\\b`, "g");
  for (const m of s.matchAll(re)) out.push(m[0]);
  return out;
}

export function split(input: PipelineInput): SplitOutput {
  const sentences: Sentence[] = splitSentences(input.brief).map((text, i) => ({
    n: i + 1,
    text,
    recordCites: extractRecordCites(text),
    cfrCites: extractCfrCites(text),
    quotes: extractQuotes(text),
    dates: extractDates(text),
  }));
  return {
    sentences,
    recordBlocks: parseRecord(input.record),
    totals: {
      sentences: sentences.length,
      recordCites: sentences.reduce((a, s) => a + s.recordCites.length, 0),
      cfrCites: sentences.reduce((a, s) => a + s.cfrCites.length, 0),
      quotes: sentences.reduce((a, s) => a + s.quotes.length, 0),
      dates: sentences.reduce((a, s) => a + s.dates.length, 0),
    },
  };
}
