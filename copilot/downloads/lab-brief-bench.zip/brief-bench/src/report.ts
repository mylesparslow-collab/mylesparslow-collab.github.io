import { ATTORNEY_LINE, type PipelineState, type Verdict } from "./types.js";

export interface Issue { kind: "quote" | "cfr" | "support"; sentence: number; severity: number; title: string; detail: string }

const short = (s: string, n = 140) => (s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s);

export function collectIssues(st: PipelineState): Issue[] {
  const sent = (n: number) => st.split?.sentences.find((s) => s.n === n)?.text ?? "";
  const out: Issue[] = [];
  for (const q of st.quotes ?? []) {
    if (q.status === "differs")
      out.push({ kind: "quote", sentence: q.sentence, severity: 1, title: "Quote differs from the record", detail: `Brief: "${q.quote}"\nRecord (${q.matchedIn}): "${q.recordText}"\nDiff (record vs brief): ${q.diff}` });
    else if (q.status === "not_found")
      out.push({ kind: "quote", sentence: q.sentence, severity: 1, title: "Quoted words not found in the record", detail: `"${q.quote}"` });
    else if (q.status === "verbatim_elsewhere")
      out.push({ kind: "quote", sentence: q.sentence, severity: 3, title: "Quote is accurate but at a different cite", detail: q.note ?? "" });
  }
  for (const c of st.cfr ?? []) {
    const extra = [
      c.heading_today ? `Heading there today: "${c.heading_today}".` : "",
      c.topic_found_at?.length ? `Words from the sentence appear at: ${c.topic_found_at.join("; ")}.` : "",
      c.last_amended ? `Section last amended ${c.last_amended}.` : "",
      c.human_url ? `Check: ${c.human_url}` : "",
    ].filter(Boolean).join(" ");
    const detail = [c.note, extra].filter(Boolean).join(" ");
    if (c.status === "heading_differs")
      out.push({ kind: "cfr", sentence: c.sentence, severity: 1, title: `Regulation cite may be the wrong provision: ${c.citation}`, detail });
    else if (c.status === "paragraph_not_found" || c.status === "not_found")
      out.push({ kind: "cfr", sentence: c.sentence, severity: 1, title: `Regulation cite does not check out: ${c.citation}`, detail });
    else if (c.status === "topic_not_checked")
      out.push({ kind: "cfr", sentence: c.sentence, severity: 2, title: `Regulation cite exists, but its subject was not checked: ${c.citation}`, detail });
    else if (c.status === "could_not_check")
      out.push({ kind: "cfr", sentence: c.sentence, severity: 3, title: `Could not check ${c.citation}`, detail });
  }
  for (const f of st.support ?? []) {
    if (f.verdict === "unsupported")
      out.push({ kind: "support", sentence: f.sentence, severity: 1, title: "Not supported by the cited record", detail: short(sent(f.sentence), 220) });
    else if (f.verdict === "partly")
      out.push({ kind: "support", sentence: f.sentence, severity: 2, title: "Only partly supported", detail: `${short(sent(f.sentence), 160)}\nRecord relied on: "${f.quote}"` });
    else if (f.verdict === "cannot_tell")
      out.push({ kind: "support", sentence: f.sentence, severity: 3, title: "Cannot tell from the cited record", detail: [f.guard, f.note].filter(Boolean).join(" ") || short(sent(f.sentence), 160) });
  }
  return out.sort((a, b) => a.severity - b.severity || a.sentence - b.sentence);
}

export function counts(st: PipelineState): Record<Verdict, number> & { uncited: number; quoteIssues: number; cfrIssues: number } {
  const c = { supported: 0, partly: 0, unsupported: 0, cannot_tell: 0 } as Record<Verdict, number>;
  for (const f of st.support ?? []) c[f.verdict]++;
  return {
    ...c,
    uncited: st.split?.sentences.filter((s) => !s.recordCites.length).length ?? 0,
    quoteIssues: (st.quotes ?? []).filter((q) => q.status === "differs" || q.status === "not_found").length,
    cfrIssues: (st.cfr ?? []).filter((x) => x.status !== "found").length,
  };
}

export function buildMarkdown(st: PipelineState): string {
  const c = counts(st);
  const L: string[] = ["# Brief Bench review", ""];
  L.push(`Sentences: ${st.split?.totals.sentences ?? 0}. Checked against the record: ${(st.support ?? []).length}. Model: ${st.model ?? "n/a"}.`, "");
  L.push("## Summary", "", "| Verdict | Count |", "|---|---|");
  for (const v of ["supported", "partly", "unsupported", "cannot_tell"] as Verdict[]) L.push(`| ${v} | ${c[v]} |`);
  L.push(`| quote problems | ${c.quoteIssues} |`, `| regulation cites not confirmed | ${c.cfrIssues} |`, "");
  const issues = collectIssues(st);
  L.push("## Issues, most serious first", "");
  if (!issues.length) L.push("No issues found by these checks.", "");
  for (const i of issues) L.push(`- **Sentence ${i.sentence}: ${i.title}.** ${i.detail.split("\n").join("\n  ")}`);
  L.push("", "## Every sentence", "", "| # | Sentence | Record cites | Verdict |", "|---|---|---|---|");
  for (const s of st.split?.sentences ?? []) {
    const f = st.support?.find((x) => x.sentence === s.n);
    const cfr = st.cfr?.filter((c) => c.sentence === s.n).map((c) => `${c.citation}: ${c.status}`).join("; ");
    const verdict = f ? f.verdict + (f.guard ? " (downgraded by code)" : "") : cfr ? `regulation cite, ${cfr}` : s.recordCites.length ? "not checked" : "no record cite";
    L.push(`| ${s.n} | ${short(s.text, 110).replace(/\|/g, "\\|")} | ${s.recordCites.join("; ") || "none"} | ${verdict} |`);
  }
  if (st.split?.sentences.some((s) => s.dates.length)) {
    L.push("", "## Dates found in the brief (listed as written; not computed)", "");
    for (const s of st.split.sentences) if (s.dates.length) L.push(`- Sentence ${s.n}: ${s.dates.join(", ")}`);
  }
  L.push("", `**${ATTORNEY_LINE}**`, "");
  return L.join("\n");
}

export function buildCard(st: PipelineState): Record<string, unknown> {
  const c = counts(st);
  const col = (label: string, n: number, color: string) => ({
    type: "Column", width: "stretch",
    items: [
      { type: "TextBlock", text: String(n), size: "ExtraLarge", weight: "Bolder", color, horizontalAlignment: "Center" },
      { type: "TextBlock", text: label, size: "Small", isSubtle: true, horizontalAlignment: "Center", wrap: true },
    ],
  });
  const top = collectIssues(st).slice(0, 5);
  return {
    type: "AdaptiveCard",
    $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
    version: "1.5",
    body: [
      { type: "TextBlock", text: "Brief Bench review", size: "Large", weight: "Bolder" },
      { type: "TextBlock", text: `${st.split?.totals.sentences ?? 0} sentences, ${(st.support ?? []).length} checked against the record`, isSubtle: true, wrap: true },
      {
        type: "ColumnSet",
        columns: [col("supported", c.supported, "Good"), col("partly", c.partly, "Warning"), col("unsupported", c.unsupported, "Attention"), col("cannot tell", c.cannot_tell, "Default")],
      },
      { type: "TextBlock", text: `Quote problems: ${c.quoteIssues}. Regulation cites not confirmed: ${c.cfrIssues}.`, wrap: true, spacing: "Medium" },
      { type: "TextBlock", text: "Top issues", weight: "Bolder", spacing: "Medium" },
      ...(top.length
        ? top.map((i) => ({ type: "TextBlock", text: `Sentence ${i.sentence}: ${i.title}`, wrap: true, spacing: "Small" }))
        : [{ type: "TextBlock", text: "None found by these checks.", wrap: true }]),
      { type: "TextBlock", text: ATTORNEY_LINE, wrap: true, weight: "Bolder", color: "Attention", spacing: "Medium" },
    ],
    actions: [
      { type: "Action.Submit", title: "Show unsupported", data: { msteams: { type: "imBack", value: "show unsupported" } } },
      { type: "Action.Submit", title: "Show quote problems", data: { msteams: { type: "imBack", value: "show quote problems" } } },
      { type: "Action.Submit", title: "Full report", data: { msteams: { type: "imBack", value: "full report" } } },
    ],
  };
}
