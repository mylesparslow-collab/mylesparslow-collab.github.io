import { containsVerbatim, norm, resolveCite } from "./record.js";
import type { QuoteFinding, RecordBlock, SplitOutput } from "./types.js";

type Op = { t: "eq" | "sub" | "ins" | "del"; rec?: string; brief?: string };

/**
 * Semi-global token alignment (Sellers): find the stretch of `rec` closest to `q`.
 * Free start and end in the record; cost 1 per substitution/insertion/deletion.
 */
const key = (w: string) => w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");

export function nearestStretch(rec: string[], q: string[]): { dist: number; start: number; end: number; ops: Op[] } {
  const m = q.length, n = rec.length;
  const rk = rec.map(key), qk = q.map(key); // trailing punctuation outside the quote marks is not a difference
  const D: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++) D[i][0] = i;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      D[i][j] = Math.min(D[i - 1][j - 1] + (qk[i - 1] === rk[j - 1] ? 0 : 1), D[i - 1][j] + 1, D[i][j - 1] + 1);
  let end = 0;
  for (let j = 1; j <= n; j++) if (D[m][j] < D[m][end]) end = j;
  const dist = D[m][end];
  const ops: Op[] = [];
  let i = m, j = end;
  while (i > 0) {
    if (j > 0 && D[i][j] === D[i - 1][j - 1] + (qk[i - 1] === rk[j - 1] ? 0 : 1)) {
      ops.push(qk[i - 1] === rk[j - 1] ? { t: "eq", rec: rec[j - 1], brief: q[i - 1] } : { t: "sub", rec: rec[j - 1], brief: q[i - 1] });
      i--; j--;
    } else if (D[i][j] === D[i - 1][j] + 1) {
      ops.push({ t: "ins", brief: q[i - 1] }); // in the brief, not in the record
      i--;
    } else {
      ops.push({ t: "del", rec: rec[j - 1] }); // in the record, dropped from the brief
      j--;
    }
  }
  ops.reverse();
  return { dist, start: j, end, ops };
}

function renderDiff(ops: Op[]): string {
  return ops
    .map((o) => (o.t === "eq" ? o.rec : o.t === "sub" ? `[-${o.rec}-]{+${o.brief}+}` : o.t === "ins" ? `{+${o.brief}+}` : `[-${o.rec}-]`))
    .join(" ");
}

function findNear(quote: string, blocks: RecordBlock[]) {
  const q = norm(quote).split(" ");
  let best: { block: RecordBlock; r: ReturnType<typeof nearestStretch>; rec: string[] } | null = null;
  for (const b of blocks) {
    const rec = norm(b.text).split(" ");
    const r = nearestStretch(rec, q);
    if (!best || r.dist < best.r.dist) best = { block: b, r, rec };
  }
  if (!best) return null;
  const allowed = Math.max(1, Math.floor(q.length * 0.25));
  if (best.r.dist > allowed) return null;
  return { ...best, recordText: best.rec.slice(best.r.start, best.r.end).join(" ") };
}

export function verifyQuotes(sp: SplitOutput): QuoteFinding[] {
  const out: QuoteFinding[] = [];
  for (const s of sp.sentences) {
    for (const quote of s.quotes) {
      const cited = s.recordCites.flatMap((c) => resolveCite(c, sp.recordBlocks));
      if (!s.recordCites.length && s.cfrCites.length) {
        out.push({ sentence: s.n, quote, status: "not_checked", note: "Quote sits in a sentence citing a regulation, not the record; not checked against the record." });
        continue;
      }
      const hit = (cited.length ? cited : sp.recordBlocks).find((b) => containsVerbatim(b.text, quote));
      if (hit) {
        out.push({ sentence: s.n, quote, status: "verbatim", matchedIn: hit.key });
        continue;
      }
      const elsewhere = sp.recordBlocks.find((b) => containsVerbatim(b.text, quote));
      if (elsewhere) {
        out.push({ sentence: s.n, quote, status: "verbatim_elsewhere", matchedIn: elsewhere.key, note: `Exact words appear at ${elsewhere.key}, not at the cited location.` });
        continue;
      }
      const near = findNear(quote, cited.length ? cited : sp.recordBlocks) ?? findNear(quote, sp.recordBlocks);
      if (near) {
        out.push({
          sentence: s.n, quote, status: "differs", matchedIn: near.block.key,
          recordText: near.recordText, diff: renderDiff(near.r.ops), distance: near.r.dist,
          note: "Quote differs from the record text.",
        });
      } else {
        out.push({ sentence: s.n, quote, status: "not_found", note: "Quoted words were not found in the record excerpts provided." });
      }
    }
  }
  return out;
}
