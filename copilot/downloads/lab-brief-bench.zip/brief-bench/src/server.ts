import { createAgentRequestHandler } from "@microsoft/agents-hosting-express";
import express from "express";
import type { Server } from "node:http";
import { createBriefBenchAgent } from "./agent.js";
import { modelFromEnv, type ModelClient } from "./models.js";
import type { PipelineDeps } from "./pipeline.js";

export interface StartOptions {
  port?: number;
  model?: ModelClient;
  lexMcpUrl?: string;
  support?: PipelineDeps["support"];
}

/**
 * Express host for the agent. We use createAgentRequestHandler (documented in the SDK) instead of startServer
 * so we get the http.Server back and can stop it. JWT auth is applied inside the handler: with no clientId configured
 * and NODE_ENV != "production" the SDK treats the caller as anonymous (the same local-dev mode its quickstart relies on).
 */
export function startAgent(opts: StartOptions = {}): Promise<Server> {
  const deps: PipelineDeps = { model: opts.model ?? modelFromEnv(), lexMcpUrl: opts.lexMcpUrl ?? process.env.LEX_MCP_URL, support: opts.support };
  const app = express();
  app.use(express.json({ limit: "5mb" }));
  app.get("/health", (_q, r) => void r.json({ ok: true, model: deps.model.name }));
  app.post("/api/messages", createAgentRequestHandler(createBriefBenchAgent(deps)));
  const port = opts.port ?? Number(process.env.PORT || 8724);
  return new Promise((resolve) => {
    const srv = app.listen(port, "127.0.0.1", () => resolve(srv));
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  await startAgent();
  console.log(`Brief Bench agent on http://127.0.0.1:${process.env.PORT || 8724}/api/messages`);
}
