"""mcp-tools.json (and every agent's copy) must equal the live server's tools/list."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import dump_tools  # noqa: E402


def norm(tools):
    return sorted(tools, key=lambda t: t["name"])


@pytest.fixture(scope="module")
def live():
    return norm(dump_tools.live_tools())


def test_pinned_file_matches_server(live):
    assert json.loads((ROOT / "mcp-tools.json").read_text()) == live, "run scripts/dump_tools.py"


def test_agent_copies_match_and_manifests_valid(live):
    names = {t["name"] for t in live}
    agents = sorted((ROOT / "agents").glob("*/appPackage"))
    assert len(agents) == 4
    for ap in agents:
        assert json.loads((ap / "mcp-tools.json").read_text()) == live, ap
        plugin = json.loads((ap / "lex-tools-plugin.json").read_text())
        assert plugin["schema_version"] == "v2.4"
        rt = plugin["runtimes"][0]
        assert rt["type"] == "RemoteMCPServer" and rt["auth"] == {"type": "None"}
        assert rt["spec"]["url"] == "https://YOUR-HOST/mcp"
        assert rt["spec"]["mcp_tool_description"] == {"file": "mcp-tools.json"}
        fn = [f["name"] for f in plugin["functions"]]
        assert fn == rt["run_for_functions"] and set(fn) <= names and len(fn) < len(names)
        da = json.loads((ap / "declarativeAgent.json").read_text())
        assert da["version"] == "v1.9" and 6 <= len(da["conversation_starters"]) <= 8
        assert da["actions"][0]["file"] == "lex-tools-plugin.json"
        ins = (ap / "instructions.txt").read_text()
        assert len(ins) <= 8000 and "An attorney must review" in ins and "Docketing to calculate" in ins
        assert len(da["description"]) <= 1000 and len(da["name"]) <= 100
        assert (ap / "color.png").exists() and (ap / "outline.png").exists()


def test_all_tools_have_descriptions_and_schemas(live):
    assert len(live) == 8
    for t in live:
        assert t["description"] and t["inputSchema"]["type"] == "object"
