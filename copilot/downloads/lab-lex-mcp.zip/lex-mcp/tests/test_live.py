"""Live smoke tests: a few real calls to eCFR, Federal Register and EDGAR. Run with: pytest -m live"""
import asyncio

import pytest

from lex_tools import ecfr
from lex_tools.citecheck import cfr_cite_check
from lex_tools.fedreg import federal_register_search
from lex_tools.sec import sec_filing_search

pytestmark = pytest.mark.live


def run(c):
    return asyncio.run(c)


def test_ecfr_section_and_history():
    r = run(ecfr.cfr_section(42, "483.70"))
    assert r["status"] == "ok" and r["heading"].startswith("§ 483.70")
    markers = [t["marker"] for t in r["top_level_paragraphs"]]
    assert markers[:3] == ["a", "b", "c"] and "m" in markers and r["source_url"] and r["retrieved_at"]
    h = run(ecfr.cfr_history(42, "483.70"))
    assert h["status"] == "ok" and "2024-06-21" in h["amendment_dates"]


def test_483_70_n_moved_to_m():
    r = run(cfr_cite_check(["42 CFR § 483.70(n)", "42 CFR § 483.70(m)"],
                           context=["binding arbitration agreements", "binding arbitration agreements"]))
    n, m = r["results"]
    assert n["heading_today"] == "Hospice services" and n["status"] == "Heading differs"
    assert any("(m) Binding arbitration agreements" in x for x in n["topic_found_at"])
    assert m["status"] == "Confirmed current" and m["heading_today"] == "Binding arbitration agreements"
    bare = run(cfr_cite_check(["42 CFR 483.70(n)"]))["results"][0]
    assert bare["status"] == "Paragraph exists (topic not checked)"
    r2 = run(cfr_cite_check(["42 CFR 483.70(n)"], as_of_date="2019-01-01"))["results"][0]
    assert r2["heading_at_as_of_date"] == "Binding arbitration agreements" and r2["status"] == "Heading differs"


def test_missing_paragraph_and_section():
    r = run(cfr_cite_check(["29 CFR 825.300(z)", "42 CFR 999.99(a)"]))["results"]
    assert r[0]["status"] == "Paragraph not found" and r[0]["paragraphs_that_exist"]
    assert r[1]["status"] == "Section not found"


def test_federal_register():
    r = run(federal_register_search("nursing home staffing", doc_type="proposed rule", since="2020-01-01"))
    assert r["status"] == "ok" and r["returned"] > 0
    d = r["results"][0]
    assert d["html_url"].startswith("https://www.federalregister.gov/") and "comments_close_on" in d


def test_edgar():
    r = run(sec_filing_search('"tender offer"', forms=["8-K"], date_from="2025-01-01"))
    assert r["status"] == "ok" and r["returned"] > 0
    x = r["results"][0]
    assert x["form"].startswith("8-K") and x["link"].startswith("https://www.sec.gov/Archives/") and x["filed"] >= "2025-01-01"
