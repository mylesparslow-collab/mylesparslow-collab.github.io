"""Start the server and talk to it with the official MCP client over Streamable HTTP (offline tools only)."""
import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import dump_tools  # noqa: E402
from mcp import ClientSession  # noqa: E402
from mcp.client.streamable_http import streamablehttp_client  # noqa: E402


async def _session(url, fn):
    async with streamablehttp_client(url) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            return await fn(s)


def _payload(res):
    assert not res.isError
    return json.loads(res.content[0].text)


def test_end_to_end_deadlines():
    port = dump_tools.free_port()
    proc = dump_tools.start_server(port)
    try:
        async def go(s):
            tools = await s.list_tools()
            m = await s.call_tool("ca_motion_deadlines", {"hearing_date": "2026-12-18", "service_method": "Personal"})
            h = await s.call_tool("ca_court_holidays", {"year": 2026})
            bad = await s.call_tool("ca_response_deadline", {"service_date": "2031-01-01", "period_days": 30, "service_method": "Personal"})
            return tools, _payload(m), _payload(h), _payload(bad)

        tools, m, h, bad = asyncio.run(_session(f"http://127.0.0.1:{port}/mcp", go))
    finally:
        proc.terminate()
        proc.wait(5)
    assert len(tools.tools) == 8
    assert m["result"]["serve_by"] == "2026-11-24" and m["source_url"] and m["retrieved_at"]
    assert h["status"] == "ok" and len(h["holidays"]) > 10
    assert bad["status"] == "error" and "Docketing to calculate" in bad["note"]
