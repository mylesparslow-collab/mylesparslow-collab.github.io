import pytest

from lex_tools.cites import parse_cite

OK = [
    ("42 CFR § 483.70(n)", 42, "483.70", ["n"]),
    ("42 C.F.R. § 483.70(n)", 42, "483.70", ["n"]),
    ("29 C.F.R. 825.300(b)(1)", 29, "825.300", ["b", "1"]),
    ("29 CFR 825.300(b)(1)(i)", 29, "825.300", ["b", "1", "i"]),
    ("17 CFR 240.10b-5", 17, "240.10b-5", []),
    ("45 CFR §164.512(e)(1)(ii)(A)", 45, "164.512", ["e", "1", "ii", "A"]),
    ("  21 C.F.R. § 314.50.", 21, "314.50", []),
    ("12 cfr 1026.36(d)(1)", 12, "1026.36", ["d", "1"]),
    ("42 CFR 483.70 (m)", 42, "483.70", ["m"]),
    ("40 C.F.R. Part 60", 40, "60", []),
    ("5 CFR § 2635.101(b)(14)", 5, "2635.101", ["b", "14"]),
    ("42 Code of Federal Regulations 483.70(m)", 42, "483.70", ["m"]),
]


@pytest.mark.parametrize("raw,title,section,paras", OK)
def test_parses(raw, title, section, paras):
    c = parse_cite(raw)
    assert c is not None, raw
    assert (c.title, c.section, c.paragraphs) == (title, section, paras)


@pytest.mark.parametrize("raw", ["", "Smith v. Jones, 5 U.S. 1", "42 U.S.C. § 1983", "Cal. Code Regs. tit. 22, § 72516",
                                 "483.70(n)", "CFR 483.70", "see 42 CFR 483.70(n) and"])
def test_rejects(raw):
    assert parse_cite(raw) is None


def test_normalized():
    assert parse_cite("42 C.F.R. § 483.70(n)").normalized == "42 CFR 483.70(n)"
