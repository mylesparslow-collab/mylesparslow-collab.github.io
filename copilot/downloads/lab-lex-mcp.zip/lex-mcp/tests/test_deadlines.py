"""The tool must equal what the original glue.py returns, and match frozen results (computed by glue.py on 2026-11-13)."""
import hashlib
import os
import json
from pathlib import Path

import pytest

from lex_tools import deadlines as d

LAB_ROOT = Path(__file__).resolve().parent.parent
ORIGINAL = Path(os.environ.get("CATALA_DEADLINES_DIR") or (LAB_ROOT / "../../../catala-deadlines")).resolve() / "web" / "glue.py"
VENDORED = Path(d.VENDOR / "glue.py")

MOTION = [
    ("2026-12-18", "Personal", {"base_day": "2026-11-24", "serve_by": "2026-11-24", "opposition_by": "2026-12-07", "reply_by": "2026-12-11"}),
    ("2026-12-18", "MailWithinCalifornia", {"base_day": "2026-11-24", "serve_by": "2026-11-19", "opposition_by": "2026-12-07", "reply_by": "2026-12-11"}),
    ("2027-03-09", "Electronic", {"base_day": "2027-02-11", "serve_by": "2027-02-09", "opposition_by": "2027-02-24", "reply_by": "2027-03-02"}),
    ("2027-01-19", "OvernightOrExpress", {"base_day": "2026-12-23", "serve_by": "2026-12-21", "opposition_by": "2027-01-05", "reply_by": "2027-01-11"}),
]
SERVED = [
    ("2026-03-02", 30, "Personal", False, "2026-04-01"),
    ("2026-12-10", 30, "MailOutOfState", False, "2027-01-19"),
    ("2027-06-01", 30, "Electronic", False, "2027-07-06"),
    ("2026-08-03", 30, "OvernightOrExpress", True, "2026-09-02"),
]


def test_vendored_glue_is_unmodified():
    if not ORIGINAL.exists():
        pytest.skip(f"original glue.py not found at {ORIGINAL}; set CATALA_DEADLINES_DIR to the catala-deadlines checkout")
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == hashlib.sha256(VENDORED.read_bytes()).hexdigest()


@pytest.mark.parametrize("hearing,method,want", MOTION)
def test_motion_matches_glue(hearing, method, want):
    r = d.ca_motion_deadlines(hearing, method)
    raw = json.loads(d.glue.compute(json.dumps({"mode": "motion", "hearing_date": hearing, "service_method": method})))
    assert r["status"] == "ok" and r["result"] == raw
    for k, v in want.items():
        assert raw[k] == v
    assert "CCP 1005(b)" in r["statute_basis"]["moving_papers"]
    assert "2026-01-01 to 2027-12-31" in r["scope"] and "Not legal advice" in r["disclaimer"]
    assert r["source_url"] and r["retrieved_at"]


@pytest.mark.parametrize("sd,days,method,barred,want", SERVED)
def test_served_matches_glue(sd, days, method, barred, want):
    r = d.ca_response_deadline(sd, days, method, barred)
    raw = json.loads(d.glue.compute(json.dumps({"mode": "served", "service_date": sd, "period_days": days,
                                                "service_method": method, "extension_barred": barred})))
    assert r["status"] == "ok" and r["result"] == raw and raw["deadline"] == want
    assert "CCP 12a" in r["statute_basis"]["deadline"]


def test_non_court_day_hearing_is_not_computed():
    r = d.ca_motion_deadlines("2026-12-25", "Personal")
    assert r["result"]["serve_by"] is None and "Docketing to calculate" in r["result"]["note"]


def test_out_of_scope_says_docketing():
    r = d.ca_response_deadline("2027-12-20", 30, "Personal")
    assert r["status"] == "error" and "Docketing to calculate" in r["note"]
    r = d.ca_motion_deadlines("2028-02-01", "Personal")
    assert r["status"] == "error"


def test_bad_method_and_aliases():
    assert d.ca_motion_deadlines("2026-12-18", "carrier pigeon")["status"] == "error"
    assert d.ca_motion_deadlines("2026-12-18", "email")["result"] == d.ca_motion_deadlines("2026-12-18", "Electronic")["result"]


def test_holidays():
    r = d.ca_court_holidays(2027)
    assert r["status"] == "ok" and all(h["date"].startswith("2027") for h in r["holidays"]) and len(r["holidays"]) > 10
    assert d.ca_court_holidays(2030)["status"] == "error"
