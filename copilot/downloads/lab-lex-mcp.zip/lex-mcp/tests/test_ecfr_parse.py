from lex_tools.citecheck import keywords
from lex_tools.ecfr import parse_section_xml

XML = """<DIV8 N="9.9" TYPE="SECTION"><HEAD>§ 9.9 Sample.</HEAD>
<P>Intro text.</P>
<P>(a) <I>First.</I> (1) Inline first child.</P>
<P>(2) Second child:</P>
<P>(i) Roman one;</P>
<P>(ii) Roman two.</P>
<P>(b) <I>Second.</I> Text.</P>
<P>(1) Child of b.</P>
</DIV8>"""


def test_structure():
    p = parse_section_xml(XML)
    assert p["heading"].startswith("§ 9.9")
    assert [t["marker"] for t in p["top_level"]] == ["a", "b"]
    assert p["top_level"][0]["heading"] == "First"
    for path in ("a/1", "a/2", "a/2/i", "a/2/ii", "b/1"):
        assert path in p["paragraphs"], path


def test_keywords():
    assert "arbitration" in keywords("binding arbitration agreements with residents")
    assert "resident" not in keywords("residents")  # generic words are ignored


def test_non_xml_200_fails_closed(monkeypatch):
    import asyncio
    import httpx
    import pytest
    from lex_tools import ecfr
    from lex_tools.citecheck import cfr_cite_check

    async def fake_get(url, **kw):
        return httpx.Response(200, text="<html><body>Service temporarily unavailable</body></html>",
                              request=httpx.Request("GET", url))

    async def fake_date(title, date):
        return "2026-11-01"

    monkeypatch.setattr(ecfr, "get", fake_get)
    monkeypatch.setattr(ecfr, "resolve_date", fake_date)
    with pytest.raises(ValueError):
        asyncio.run(ecfr.fetch_section(42, "483.70"))
    r = asyncio.run(cfr_cite_check(["42 CFR 483.70(m)"]))["results"][0]
    assert r["status"] == "Could not check"
