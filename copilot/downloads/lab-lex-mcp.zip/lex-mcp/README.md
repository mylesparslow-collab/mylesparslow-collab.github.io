# Lex Tools: legal lookups as an MCP server

Lex Tools is a small remote MCP server (Streamable HTTP, Python) that gives Microsoft 365 Copilot agents deterministic legal lookups, so the model never guesses a regulation's text or computes a date itself. Every result carries `source_url` and `retrieved_at`; a network failure returns a structured error, never a guess. Four declarative agents (Reg Cite Check, Deadline Desk, Reg Watch, Filing Finder) are wired to it. All data is public; the firm in the samples is the invented Thornwood Garza LLP.

## Tools (all read-only)

| Tool | Source |
|---|---|
| `cfr_section` | eCFR: current or as-of-date text of a CFR section, with its lettered top-level paragraphs |
| `cfr_cite_check` | eCFR: does the cited section and paragraph exist today, last amended date, heading found, where the paragraphs went if missing |
| `cfr_history` | eCFR versions endpoint: amendment dates |
| `federal_register_search` | federalregister.gov API: title, type, agencies, publication date, comment-close date as published, link |
| `sec_filing_search` | SEC EDGAR full-text search: company, form, filed date, link |
| `ca_motion_deadlines`, `ca_response_deadline`, `ca_court_holidays` | the Catala rule engine from `catala-deadlines`, vendored; 2026-2027 only; statute basis, scope and "not legal advice" in every result |

`cfr_cite_check` never says what a regulation means. It reports existence and headings. Optional `context` (what the brief says each cite is about) and `as_of_date` let it flag a cite whose paragraph exists but is a different provision today. Example: 42 CFR 483.70(n) held the nursing-home arbitration rule in 2019; it is now at 483.70(m), and (n) is "Hospice services". The tool returns "Heading differs" for (n) and points to (m). See `demo/transcript.md`.

The moved-paragraph flag needs the brief's topic (`context`) or an `as_of_date`. A bare check with neither cannot tell that (n) is the wrong provision, so an existing paragraph returns "Paragraph exists (topic not checked)" and a human must check it; "Confirmed current" is returned only when topic keywords were checked and found, or the heading matches the as-of date. A 200 response from eCFR that is not the expected XML returns "Could not check", never "Section not found".

## Run

```
cd copilot-kit/labs/lex-mcp
uv run --python 3.12 python -m lex_tools.server        # http://127.0.0.1:8721/mcp
uv run --python 3.12 pytest                             # offline tests (unit, deadlines vs glue.py [set CATALA_DEADLINES_DIR if catala-deadlines is not at ../../../catala-deadlines; otherwise that check is skipped], manifests, end-to-end)
uv run --python 3.12 pytest -m live                     # a few real calls to eCFR, Federal Register, EDGAR
uv run --python 3.12 python scripts/dump_tools.py       # regenerate mcp-tools.json + every agent's copy
uv run --python 3.12 python scripts/capture_demo.py     # regenerate demo/transcript.json and .md
```

No keys are needed (`.env.example` lists optional overrides). EDGAR gets a generic User-Agent, `copilot-kit-demo`.

## Layout

- `src/lex_tools/`: the server (`server.py`) and one module per source.
- `vendor/`: the Catala-generated Python and `glue.py` (byte-identical to `catala-deadlines/web/glue.py`; a test checks this) plus `holidays.json`. The original project is untouched.
- `mcp-tools.json`: the server's `tools/list`, pinned. Each plugin manifest points to it as `mcp_tool_description`, and a test fails if it differs from the live server.
- `agents/<slug>/appPackage/`: Teams app manifest, declarative agent v1.9, plugin v2.4 (`RemoteMCPServer`, auth None, `https://YOUR-HOST/mcp`), instructions, icons, pinned tool file. Each agent lists only the functions it needs. `scripts/gen_agents.py` generates them.
- `demo/`: a real run of four calls through the official MCP client.

## Verified here

- Server starts on port 8721 and answers an MCP `initialize` over Streamable HTTP; stopped afterwards. Command: `uv run --python 3.12 python -m lex_tools.server`.
- `uv run --python 3.12 pytest`: offline suite passes (cite parser formats, paragraph parser, 4 motion and 4 response results equal to what `glue.py` returns, scope and out-of-range errors, manifests and pinned tool file equal to the live `tools/list`, end-to-end over Streamable HTTP with the official MCP client).
- `uv run --python 3.12 pytest -m live`: real calls pass, including 483.70(n) flagged and (m) confirmed, a missing paragraph and a missing section, a Federal Register search with comment-close dates, and an EDGAR search.
- `demo/transcript.md` and `.json`: the 483.70 cite check, a motion deadline, a Federal Register search and an EDGAR search, as raw results.

## Not verified

- Nothing has run in a Microsoft 365 tenant. The agents, the plugin manifests and the `RemoteMCPServer` runtime have not been loaded in Copilot Studio or the Agents Toolkit; the manifests were written to the schema facts in `labs/CONVENTIONS.md` and not validated by Microsoft's tooling.
- The server is not deployed. `YOUR-HOST` must be replaced with an HTTPS host; Copilot requires a reachable server.
- The agent instructions were not run against a model in this lab.
- Nested paragraph paths such as `(b)(1)(i)` are inferred from eCFR's flat markup; top-level paragraphs are reliable (checked on 42 CFR 483.70 now and as of 2019), but deeply nested cites in unusual sections may be reported as "Paragraph not found" when they exist. A human opens the link.
- Topic matching in `cfr_cite_check` is keyword matching, a rough signal and not a reading of the law.
- Deadline statute text was captured from Wayback Machine, not live leginfo (see `catala-deadlines/SOURCES.md`).
