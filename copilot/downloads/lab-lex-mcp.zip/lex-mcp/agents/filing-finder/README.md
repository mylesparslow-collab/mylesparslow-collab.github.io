# Filing Finder

EDGAR full-text search for deal lawyers. Ask for the 8-Ks or other forms that mention a term, in a date range, and get a table with company, form, filing date and link. It finds and lists filings; it does not summarize or interpret them.

- Functions used: sec_filing_search (from the Lex Tools MCP server in `../../`).
- `appPackage/lex-tools-plugin.json` points at `https://YOUR-HOST/mcp` with auth None. Replace the host before packaging.
- `appPackage/mcp-tools.json` is a pinned copy of the server's `tools/list`; regenerate with `uv run --python 3.12 python scripts/dump_tools.py` from the lab folder. A test fails if it drifts.
- Instructions: `appPackage/instructions.txt` (2782 characters, limit 8000).

Not run in a Microsoft 365 tenant. See the lab README.
