# Reg Watch

A Federal Register monitor for a practice group's topics. It lists recent rules, proposed rules and notices with agency, publication date, comment-close date exactly as published, and a link. It does not interpret them or tell you what to do.

- Functions used: federal_register_search (from the Lex Tools MCP server in `../../`).
- `appPackage/lex-tools-plugin.json` points at `https://YOUR-HOST/mcp` with auth None. Replace the host before packaging.
- `appPackage/mcp-tools.json` is a pinned copy of the server's `tools/list`; regenerate with `uv run --python 3.12 python scripts/dump_tools.py` from the lab folder. A test fails if it drifts.
- Instructions: `appPackage/instructions.txt` (2903 characters, limit 8000).

Not run in a Microsoft 365 tenant. See the lab README.
