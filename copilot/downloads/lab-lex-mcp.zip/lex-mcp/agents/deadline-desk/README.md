# Deadline Desk

Tell it a service date or a hearing date in plain words. It asks for anything missing (like how the papers were served), calls a rule engine for California civil deadlines, and shows each date with the statute basis the engine returned. It refuses to compute anything the engine does not cover and says Docketing to calculate.

- Functions used: ca_motion_deadlines, ca_response_deadline, ca_court_holidays (from the Lex Tools MCP server in `../../`).
- `appPackage/lex-tools-plugin.json` points at `https://YOUR-HOST/mcp` with auth None. Replace the host before packaging.
- `appPackage/mcp-tools.json` is a pinned copy of the server's `tools/list`; regenerate with `uv run --python 3.12 python scripts/dump_tools.py` from the lab folder. A test fails if it drifts.
- Instructions: `appPackage/instructions.txt` (3856 characters, limit 8000).

Not run in a Microsoft 365 tenant. See the lab README.
