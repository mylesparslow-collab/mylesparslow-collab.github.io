# Reg Cite Check

Paste a brief or memo. It finds every Code of Federal Regulations cite, checks each one against the official eCFR, and returns a table of what exists today, when the section was last amended, and the exact tool evidence. It never says a cite is correct law, only whether the text exists at that location today.

- Functions used: cfr_cite_check, cfr_section, cfr_history (from the Lex Tools MCP server in `../../`).
- `appPackage/lex-tools-plugin.json` points at `https://YOUR-HOST/mcp` with auth None. Replace the host before packaging.
- `appPackage/mcp-tools.json` is a pinned copy of the server's `tools/list`; regenerate with `uv run --python 3.12 python scripts/dump_tools.py` from the lab folder. A test fails if it drifts.
- Instructions: `appPackage/instructions.txt` (3923 characters, limit 8000).

Not run in a Microsoft 365 tenant. See the lab README.
