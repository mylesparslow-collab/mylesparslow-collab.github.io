"""cfr_cite_check: does the cited section / paragraph exist today, and does it look like the same provision?

Deterministic evidence only. The tool never says what a regulation means; it reports whether text
exists at a location, what the heading there is today, and (optionally) whether a keyword from the
citing document appears in that paragraph.
"""
import asyncio
import re

from . import ecfr
from .cites import parse_cite
from .common import stamp

STOP = {"that", "this", "with", "from", "rule", "section", "regulation", "requirement", "requirements",
        "under", "which", "shall", "must", "federal", "state", "have", "their", "agreement", "agreements",
        "resident", "facility", "party", "parties"}


def keywords(context: str):
    words = re.findall(r"[a-z]{4,}", (context or "").lower())
    stems = {w[:-1] if w.endswith("s") else w for w in words}
    return sorted(w for w in stems if w not in STOP and w + "s" not in STOP)


def _hit(words, text):
    t = text.lower()
    return [w for w in words if w in t]


def _label(path):
    return "(" + ")(".join(path.split("/")) + ")"


def _elsewhere(parsed, w):
    return [f"{_label(k)} {v['heading']}".strip() for k, v in parsed["paragraphs"].items()
            if "/" not in k and len(_hit(w, v["heading"] + " " + v["text"][:400])) * 2 >= len(w)]


async def _one(cite_str, context, as_of_date, cache):
    c = parse_cite(cite_str)
    base = {"citation": cite_str}
    if not c:
        return {**base, "status": "Could not check", "reason": "Not a recognizable CFR citation (expected like '42 CFR § 483.70(m)').",
                "last_amended": None, "evidence": {}}
    base["normalized"] = c.normalized
    key = (c.title, c.section)
    try:
        if key not in cache:
            cache[key] = await asyncio.gather(ecfr.fetch_versions(c.title, c.section),
                                              ecfr.fetch_section(c.title, c.section, None))
        (vs, vurl), (parsed, as_of, surl) = cache[key]
        then = None
        if as_of_date:
            tk = (c.title, c.section, as_of_date)
            if tk not in cache:
                cache[tk] = await ecfr.fetch_section(c.title, c.section, as_of_date)
            then = cache[tk]
    except Exception as e:
        return {**base, "status": "Could not check", "reason": f"eCFR request failed: {type(e).__name__}: {e}",
                "last_amended": None, "evidence": {}}
    dates = ecfr.amendment_dates(vs)
    last = dates[-1] if dates else None
    ev = {"versions_url": vurl, "section_url": surl, "ecfr_up_to_date_as_of": as_of,
          "human_url": f"https://www.ecfr.gov/current/title-{c.title}/section-{c.section}"}
    removed = bool(vs and vs[-1].get("removed"))
    if not vs or parsed is None or removed:
        return {**base, "status": "Section not found", "last_amended": last, "evidence": ev,
                "reason": f"eCFR has no current text for {c.title} CFR {c.section}"
                          + (" (the section is marked removed)." if removed else ".")}
    out = {**base, "section_heading": parsed["heading"], "last_amended": last, "evidence": ev,
           "top_level_paragraphs": [f"({t['marker']}) {t['heading']}".strip() for t in parsed["top_level"]]}
    if not c.paragraphs:
        return {**out, "status": "Confirmed current", "paragraph_checked": None,
                "reason": "Section exists today. No paragraph was cited, so only the section was checked."}
    path = "/".join(c.paragraphs)
    p = parsed["paragraphs"].get(path)
    w = keywords(context) if context else []
    if p is None:
        parts = c.paragraphs
        anc = next(("/".join(parts[:i]) for i in range(len(parts) - 1, 0, -1)
                    if "/".join(parts[:i]) in parsed["paragraphs"]), None)
        if anc:
            kids = [k for k in parsed["order"] if k.startswith(anc + "/") and k.count("/") == anc.count("/") + 1]
            existing = [f"{_label(k)} {parsed['paragraphs'][k]['text'][:80]}" for k in kids]
            where = f"under {_label(anc)}"
        else:
            existing, where = out["top_level_paragraphs"], "at the top level"
        res = {**out, "status": "Paragraph not found", "paragraph_checked": _label(path),
               "paragraphs_that_exist": existing,
               "reason": f"No paragraph {_label(path)} exists in {c.section} today. The paragraphs that do exist {where} are listed."}
        if w:
            res["topic_keywords"] = w
            res["topic_found_at"] = _elsewhere(parsed, w)
        return res
    ptext = " ".join(parsed["paragraphs"][k]["text"] for k in parsed["order"] if k == path or k.startswith(path + "/"))
    out.update(paragraph_checked=_label(path), heading_today=p["heading"] or None,
               paragraph_text_start=p["text"][:200])
    flags, asof_notes = [], []
    if then is not None:
        tp = then[0]["paragraphs"].get(path) if then[0] else None
        out.update(as_of_date=as_of_date, heading_at_as_of_date=(tp["heading"] or None) if tp else None,
                   paragraph_existed_at_as_of_date=tp is not None,
                   amended_since_as_of_date=bool(last and last > as_of_date))
        if tp is not None and (tp["heading"] or "") != (p["heading"] or ""):
            asof_notes.append(f"Heading at {as_of_date} was '{tp['heading']}' but today it is '{p['heading']}'.")
        elif tp is not None and p["text"] != tp["text"]:
            asof_notes.append("Opening text of this paragraph differs from the as-of date.")
    if w:
        hits = _hit(w, p["heading"] + " " + ptext)
        out.update(topic_keywords=w, topic_keywords_found_in_paragraph=hits)
        if w and len(hits) * 2 < len(w):
            out["topic_found_at"] = _elsewhere(parsed, w)
            flags.append(f"None of the topic keywords {w} appear in {_label(path)} today"
                         + (f"; they do appear at {', '.join(out['topic_found_at'])}." if out["topic_found_at"] else "."))
    # A changed heading is a flag unless the citing document's own topic words are found in today's paragraph.
    topic_ok = bool(w) and len(out.get("topic_keywords_found_in_paragraph", [])) * 2 >= len(w)
    (out.setdefault("notes", []) if topic_ok else flags).extend(asof_notes)
    out["flags"] = flags
    if flags:
        return {**out, "status": "Heading differs",
                "reason": "The paragraph exists today but the evidence does not support that it is the same provision. A human must check."}
    same_as_then = then is not None and out.get("paragraph_existed_at_as_of_date") and not asof_notes
    if w or same_as_then:
        return {**out, "status": "Confirmed current",
                "reason": "Section and paragraph exist today"
                          + (" and the topic keywords were found there." if w else " with the same heading as at the as-of date.")
                          + " This is an existence check, not a statement of what the law means."}
    return {**out, "status": "Paragraph exists (topic not checked)",
            "reason": "The paragraph exists today, but no topic was supplied and no as-of date comparison was possible, so it was not checked "
                      "whether this is the provision the brief means. Supply what the brief says this cite is about (context) "
                      "or an as_of_date, or a human must open the link and check."}


async def cfr_cite_check(citations, context=None, as_of_date=None) -> dict:
    ctx = list(context or [])
    cache = {}
    res = [await _one(cs, ctx[i] if i < len(ctx) else None, as_of_date, cache) for i, cs in enumerate(citations)]
    return stamp("https://www.ecfr.gov/api/versioner/v1/", status="ok", results=res,
                 scope_note="Checks that text exists at the cited location today and reports headings and amendment dates. "
                            "It does not say what a regulation means or whether a cite is correct law.")
