"""eCFR access: section text, paragraph structure, amendment history.

Endpoints (https://www.ecfr.gov/api/versioner/v1/):
  titles.json                          -> per-title up_to_date_as_of
  full/{date}/title-N.xml?section=X    -> section XML (needs compressed transfer)
  versions/title-N.json?section=X      -> amendment history
"""
import re
import xml.etree.ElementTree as ET

from .common import error, get, stamp

BASE = "https://www.ecfr.gov/api/versioner/v1"
_ROMAN = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii", "xiii", "xiv", "xv",
          "xvi", "xvii", "xviii", "xix", "xx"]
_MARK = re.compile(r"^\(([A-Za-z0-9]{1,4})\)\s*")


def _roman_idx(s: str):
    return _ROMAN.index(s.lower()) if s.lower() in _ROMAN else None


def _kind(marker: str, level: int):
    """Index of marker within the sequence used at this nesting level, or None."""
    if level == 1:
        return ord(marker) - 96 if marker.isalpha() and marker.islower() and len(marker) == 1 else None
    if level == 2:
        return int(marker) if marker.isdigit() else None
    if level == 3:
        return (_roman_idx(marker) + 1) if marker.islower() and _roman_idx(marker) is not None else None
    if level == 4:
        return ord(marker) - 64 if marker.isalpha() and marker.isupper() and len(marker) == 1 else None
    if level == 5:
        return (_roman_idx(marker.lower()) + 1) if marker.isupper() and _roman_idx(marker) is not None else None
    return None


def _text(el) -> str:
    return re.sub(r"\s+", " ", "".join(el.itertext())).strip()


def parse_section_xml(xml: str) -> dict:
    """Flat <P> list -> heading, intro, and a path-keyed map of paragraphs.

    Paths look like 'n' or 'b/1/i'. Nesting is inferred from the (a)/(1)/(i)/(A)/(I)
    marker sequence, which is how eCFR flattens it. Where a marker like (i) could be
    a top-level letter or a roman numeral, the preceding paragraph ending in ':' means
    it opens a sub-list; otherwise the marker that continues a sequence wins.
    """
    root = ET.fromstring(xml)
    heading = _text(root.find("HEAD")) if root.find("HEAD") is not None else ""
    paras = {}  # path -> {"heading", "text"}
    order = []
    intro = []
    last = {}   # level -> index of last marker seen at that level
    stack = []  # [(level, marker)]
    prev_text = ""
    for p in root.iter("P"):
        t = _text(p)
        m = _MARK.match(t)
        if not m:
            if stack:
                paras[order[-1]]["text"] += "\n" + t
            else:
                intro.append(t)
            prev_text = t
            continue
        mk = m[1]
        cur = stack[-1][0] if stack else 0
        cont, child = [], []
        for level in range(1, 6):
            idx = _kind(mk, level)
            if idx is None:
                continue
            if level <= cur and idx == last.get(level, 0) + 1:
                cont.append(level)
            elif level > cur and idx == 1 and level <= cur + 2:
                child.append(level)
        if cont and child:
            level = child[0] if prev_text.rstrip().endswith((":", "—", "-")) else cont[-1]
        elif cont or child:
            level = (cont or child)[0] if cont else child[0]
        else:  # sequence broken: attach at the shallowest level this marker can take
            level = next((lv for lv in range(1, 6) if _kind(mk, lv) is not None), cur + 1)
        stack = [x for x in stack if x[0] < level] + [(level, mk)]
        last = {lv: v for lv, v in last.items() if lv <= level}
        last[level] = _kind(mk, level) or last.get(level, 0) + 1
        path = "/".join(x[1] for x in stack)
        h = p.find("I")
        hd = _text(h).rstrip(".") if h is not None and _text(p).startswith(f"({mk}) {_text(h)}") else ""
        if path not in paras:  # eCFR restarts (1),(2) inside one lettered paragraph; keep the first
            paras[path] = {"marker": mk, "heading": hd, "text": t}
            order.append(path)
        # An inline first sub-paragraph: "(b) Heading. (1) text ..." in the same <P>.
        rest = t[m.end():]
        if hd and rest.startswith(hd):
            rest = rest[len(hd):].lstrip(". ")
        while True:
            im = _MARK.match(rest)
            nl = stack[-1][0] + 1
            lv = next((lv for lv in range(nl, nl + 2) if im and _kind(im[1], lv) == 1), None)
            if not im or lv is None:
                break
            stack.append((lv, im[1]))
            last[lv] = 1
            cpath = "/".join(x[1] for x in stack)
            if cpath not in paras:
                paras[cpath] = {"marker": im[1], "heading": "", "text": rest}
                order.append(cpath)
            rest = rest[im.end():]
        prev_text = t
    top = [pth for pth in order if "/" not in pth]
    return {"heading": heading, "intro": " ".join(intro), "paragraphs": paras, "order": order,
            "top_level": [{"marker": p, "heading": paras[p]["heading"]} for p in top]}


async def titles():
    r = await get(f"{BASE}/titles.json")
    r.raise_for_status()
    return {t["number"]: t for t in r.json()["titles"]}


async def resolve_date(title: int, date):
    if date:
        return date
    return (await titles())[title]["up_to_date_as_of"]


async def fetch_section(title: int, section: str, date=None):
    """Returns (parsed|None, as_of_date, url). parsed is None when the section has no text."""
    d = await resolve_date(title, date)
    url = f"{BASE}/full/{d}/title-{title}.xml?section={section}"
    r = await get(url)
    if r.status_code in (400, 404):
        return None, d, url
    r.raise_for_status()
    if "<DIV" not in r.text[:400]:
        # A 200 that is not the expected XML is an upstream problem, not "section not found": fail closed.
        raise ValueError(f"eCFR returned an unexpected (non-XML) response with status {r.status_code}")
    try:
        return parse_section_xml(r.text), d, url
    except ET.ParseError as e:
        raise ValueError(f"eCFR returned XML that could not be parsed: {e}") from e


async def fetch_versions(title: int, section: str):
    url = f"{BASE}/versions/title-{title}.json?section={section}"
    r = await get(url)
    r.raise_for_status()
    vs = [v for v in r.json().get("content_versions", []) if v.get("identifier") == section]
    return vs, url


def amendment_dates(versions):
    return sorted({v["amendment_date"] for v in versions if v.get("amendment_date")})


async def cfr_section(title: int, section: str, date: str | None = None) -> dict:
    try:
        parsed, d, url = await fetch_section(title, section, date)
    except Exception as e:  # network / API failure: never guess
        return error(f"{BASE}/full/{date or 'current'}/title-{title}.xml?section={section}",
                     f"eCFR request failed: {type(e).__name__}: {e}")
    if parsed is None:
        return stamp(url, status="not_found", title=title, section=section, as_of=d,
                     message="eCFR returned no text for this section on that date.")
    body = [parsed["intro"]] if parsed["intro"] else []
    body += [parsed["paragraphs"][k]["text"] for k in parsed["order"] if "/" not in k]
    nested = [k for k in parsed["order"] if "/" in k]
    # Full text: every paragraph in document order (nested paragraphs included).
    full = "\n".join(([parsed["intro"]] if parsed["intro"] else []) +
                     [parsed["paragraphs"][k]["text"] for k in parsed["order"]])
    return stamp(f"https://www.ecfr.gov/current/title-{title}/section-{section}" if not date
                 else f"https://www.ecfr.gov/on/{date}/title-{title}/section-{section}",
                 status="ok", title=title, section=section, as_of=d, heading=parsed["heading"],
                 top_level_paragraphs=parsed["top_level"], nested_paragraph_count=len(nested),
                 text=full, api_url=url)


async def cfr_history(title: int, section: str) -> dict:
    try:
        vs, url = await fetch_versions(title, section)
    except Exception as e:
        return error(f"{BASE}/versions/title-{title}.json?section={section}",
                     f"eCFR request failed: {type(e).__name__}: {e}")
    if not vs:
        return stamp(url, status="not_found", title=title, section=section, amendment_dates=[])
    return stamp(url, status="ok", title=title, section=section, amendment_dates=amendment_dates(vs),
                 removed=bool(vs[-1].get("removed")), heading=vs[-1].get("name"))
