"""Lex Tools: read-only, deterministic legal lookups as a remote MCP server (Streamable HTTP)."""
import os

from mcp.server.fastmcp import FastMCP

from . import deadlines, ecfr
from .citecheck import cfr_cite_check as _cite_check
from .fedreg import federal_register_search as _fr
from .sec import sec_filing_search as _sec

mcp = FastMCP("Lex Tools", host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "8721")),
              stateless_http=True,
              instructions="Read-only legal lookups. Every result has source_url and retrieved_at. "
                           "Never guess when a result is an error; report that the lookup failed.")
RO = {"readOnlyHint": True, "openWorldHint": True}
LOCAL = {"readOnlyHint": True, "openWorldHint": False}


@mcp.tool(annotations=RO)
async def cfr_section(title: int, section: str, date: str | None = None) -> dict:
    """Get the text of one section of the Code of Federal Regulations from the official eCFR, current or as of a past date. Returns the section heading, full text and the lettered top-level paragraphs present. title is the CFR title number (42 for 42 CFR); section is like '483.70'; date is optional YYYY-MM-DD for the text as of that date. Quote the text verbatim; do not paraphrase it as legal advice."""
    return await ecfr.cfr_section(title, section, date)


@mcp.tool(annotations=RO)
async def cfr_cite_check(citations: list[str], context: list[str] | None = None, as_of_date: str | None = None) -> dict:
    """Check whether CFR citations exist TODAY, e.g. '42 CFR § 483.70(n)' or '29 C.F.R. 825.300(b)(1)'. For each cite reports: section exists, cited paragraph exists, date the section was last amended, the heading at the cited paragraph, and, when a paragraph is missing, the paragraphs that do exist. Optional context is a list parallel to citations holding a few words on what the brief says each cite is about (e.g. 'binding arbitration agreements'); if its keywords are not in the cited paragraph the status is 'Heading differs' and the paragraphs where they do appear are listed. Optional as_of_date (YYYY-MM-DD) also compares the paragraph heading on that date to today. 'Confirmed current' is returned only when topic keywords were checked and found, or the heading matches the as-of date; with neither, an existing paragraph returns 'Paragraph exists (topic not checked)' and a human must check it. Status values: Confirmed current, Paragraph exists (topic not checked), Paragraph not found, Section not found, Heading differs, Could not check. This is an existence check; it never says what a regulation means or that a cite is correct law."""
    return await _cite_check(citations, context, as_of_date)


@mcp.tool(annotations=RO)
async def cfr_history(title: int, section: str) -> dict:
    """List the dates a CFR section was amended, from the eCFR versions endpoint. title is the CFR title number; section is like '483.70'."""
    return await ecfr.cfr_history(title, section)


@mcp.tool(annotations=RO)
async def federal_register_search(term: str, agency: str | None = None, doc_type: str | None = None,
                                  since: str | None = None) -> dict:
    """Search the Federal Register (federalregister.gov API), newest first. Returns title, document type, agencies, publication date, the comment-close date exactly as published, document number and html_url. term is a search phrase; agency is an agency name or slug (e.g. 'centers-for-medicare-medicaid-services'); doc_type is one of rule, proposed rule, notice, presidential; since is YYYY-MM-DD (publication date on or after)."""
    return await _fr(term, agency, doc_type, since)


@mcp.tool(annotations=RO)
async def sec_filing_search(query: str, forms: list[str] | None = None, date_from: str | None = None,
                            date_to: str | None = None) -> dict:
    """Full-text search of SEC EDGAR filings. Returns company, form type, filing date and a link to each matching document. query is the text to find (use quotes for exact phrases); forms is an optional list such as ['8-K'] or ['SC 13D']; date_from and date_to are optional YYYY-MM-DD bounds. The total match count may be a lower bound."""
    return await _sec(query, forms, date_from, date_to)


@mcp.tool(annotations=LOCAL)
def ca_motion_deadlines(hearing_date: str, service_method: str) -> dict:
    """Compute California civil motion deadlines (CCP 1005(b)) counting backward from a hearing date: serve-by date for moving papers, opposition-due and reply-due dates, each with its statute basis. hearing_date is YYYY-MM-DD and must be a court day within 2026-2027. service_method is one of Personal, MailWithinCalifornia, MailOutOfState, MailAddressConfidentiality, MailOutOfCountry, OvernightOrExpress, Fax, Electronic. Computed by a rule engine, not by the model. Covers 2026-2027 only; for anything else the answer is 'Docketing to calculate'. Not legal advice; verify."""
    return deadlines.ca_motion_deadlines(hearing_date, service_method)


@mcp.tool(annotations=LOCAL)
def ca_response_deadline(service_date: str, period_days: int, service_method: str, extension_barred: bool = False) -> dict:
    """Compute a California civil response deadline counted forward from the date of service: the stated number of calendar days plus the service-method extension (CCP 1013, 1010.6), rolled to the next court day (CCP 12a). service_date is YYYY-MM-DD within 2026-2027; period_days (1-365) must come from the rule or order that sets the period, not from the model; service_method is one of Personal, MailWithinCalifornia, MailOutOfState, MailAddressConfidentiality, MailOutOfCountry, OvernightOrExpress, Fax, Electronic; extension_barred is true when a rule or order says the service extension does not apply. Covers 2026-2027 only; for anything else the answer is 'Docketing to calculate'. Not legal advice; verify."""
    return deadlines.ca_response_deadline(service_date, period_days, service_method, extension_barred)


@mcp.tool(annotations=LOCAL)
def ca_court_holidays(year: int) -> dict:
    """List California judicial (court) holidays for a year as published by the Judicial Council. Only 2026 and 2027 are available."""
    return deadlines.ca_court_holidays(year)


def main():
    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
