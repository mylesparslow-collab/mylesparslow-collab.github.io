"""SEC EDGAR full-text search (https://efts.sec.gov/LATEST/search-index)."""
from datetime import date

from .common import error, get, sec_user_agent, stamp

URL = "https://efts.sec.gov/LATEST/search-index"


def doc_link(cik: str, adsh: str, filename: str) -> str:
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{adsh.replace('-', '')}/{filename}"


async def sec_filing_search(query, forms=None, date_from=None, date_to=None, limit=10) -> dict:
    params = {"q": query}
    if forms:
        params["forms"] = ",".join(forms) if isinstance(forms, list) else forms
    if date_from or date_to:
        params["dateRange"] = "custom"
        # EDGAR silently ignores startdt unless enddt is also present (observed 2026-11-13), so fill the missing end.
        params["startdt"] = date_from or "2001-01-01"
        params["enddt"] = date_to or date.today().isoformat()
    try:
        r = await get(URL, params=params, headers={"User-Agent": sec_user_agent(), "Accept": "application/json"})
        if r.status_code >= 400:
            return error(str(r.url), f"EDGAR returned HTTP {r.status_code}: {r.text[:300]}")
        j = r.json()
    except Exception as e:
        return error(URL, f"EDGAR request failed: {type(e).__name__}: {e}")
    hits = j.get("hits", {}).get("hits", [])
    out = []
    for h in hits[:max(1, min(limit, 25))]:
        s = h["_source"]
        adsh, _, fname = h["_id"].partition(":")
        cik = (s.get("ciks") or ["0"])[0]
        out.append({"company": (s.get("display_names") or [None])[0], "form": s.get("form"),
                    "filed": s.get("file_date"), "period_ending": s.get("period_ending"),
                    "accession_number": adsh, "link": doc_link(cik, adsh, fname) if fname else None,
                    "filing_index": f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{adsh.replace('-', '')}/"})
    total = j.get("hits", {}).get("total", {})
    return stamp(str(r.url), status="ok", total_matches=total.get("value"),
                 total_is_lower_bound=total.get("relation") == "gte", returned=len(out), results=out)
