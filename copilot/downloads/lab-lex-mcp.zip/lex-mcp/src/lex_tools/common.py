"""Shared helpers: timestamps, HTTP client, structured errors."""
import os
from datetime import datetime, timezone

import httpx

TIMEOUT = httpx.Timeout(30.0, connect=10.0)


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def stamp(source_url: str, **fields) -> dict:
    """Every result carries source_url and retrieved_at."""
    return {**fields, "source_url": source_url, "retrieved_at": now_iso()}


def error(source_url: str, message: str, **fields) -> dict:
    return {"status": "error", "error": message, "source_url": source_url,
            "retrieved_at": now_iso(),
            "note": "The lookup failed. Do not guess the answer; report that it could not be checked.",
            **fields}


def sec_user_agent() -> str:
    return os.environ.get("SEC_USER_AGENT", "copilot-kit-demo")


async def get(url: str, *, params=None, headers=None) -> httpx.Response:
    async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as c:
        return await c.get(url, params=params, headers=headers)
