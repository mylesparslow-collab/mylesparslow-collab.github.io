"""Federal Register search (https://www.federalregister.gov/api/v1/documents.json)."""
import re

from .common import error, get, stamp

URL = "https://www.federalregister.gov/api/v1/documents.json"
TYPES = {"rule": "RULE", "final rule": "RULE", "proposed rule": "PRORULE", "proposed": "PRORULE",
         "prorule": "PRORULE", "notice": "NOTICE", "presidential": "PRESDOCU", "presdocu": "PRESDOCU"}


def slugify(agency: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", agency.lower()).strip("-")


async def federal_register_search(term, agency=None, doc_type=None, since=None, limit=10) -> dict:
    params = [("conditions[term]", term), ("per_page", min(max(limit, 1), 25)), ("order", "newest"),
              ("fields[]", "title"), ("fields[]", "type"), ("fields[]", "agencies"),
              ("fields[]", "publication_date"), ("fields[]", "comments_close_on"),
              ("fields[]", "html_url"), ("fields[]", "document_number")]
    if agency:
        params.append(("conditions[agencies][]", slugify(agency)))
    if doc_type:
        t = TYPES.get(doc_type.strip().lower())
        if not t:
            return error(URL, f"doc_type must be one of {sorted(set(TYPES))}.")
        params.append(("conditions[type][]", t))
    if since:
        params.append(("conditions[publication_date][gte]", since))
    try:
        r = await get(URL, params=params)
        if r.status_code >= 400:
            return error(str(r.url), f"Federal Register API returned HTTP {r.status_code}: {r.text[:300]}")
        j = r.json()
    except Exception as e:
        return error(URL, f"Federal Register request failed: {type(e).__name__}: {e}")
    docs = [{"title": d.get("title"), "type": d.get("type"),
             "agencies": [a.get("name") for a in d.get("agencies", [])],
             "publication_date": d.get("publication_date"),
             "comments_close_on": d.get("comments_close_on"),
             "comments_close_note": "As published in the document metadata; not recalculated.",
             "document_number": d.get("document_number"), "html_url": d.get("html_url")}
            for d in j.get("results", [])]
    return stamp(str(r.url), status="ok", total_matches=j.get("count"), returned=len(docs), results=docs)
