"""California civil deadlines, computed by the Catala-generated engine (vendored in /vendor).

Input validation is the original web/glue.py (vendored unmodified); this module only maps
friendly inputs to glue's contract and attaches statute basis, scope and disclaimer.
"""
import json
import sys
from pathlib import Path

VENDOR = Path(__file__).resolve().parents[2] / "vendor"
# Same flat layout as catala-deadlines/web/build.py: package dir on sys.path for `import catala_runtime`.
for p in (str(VENDOR / "deadlines"), str(VENDOR)):
    if p not in sys.path:
        sys.path.insert(0, p)

import glue  # noqa: E402  (vendored, unmodified)

from .common import now_iso  # noqa: E402

METHODS = glue.METHODS
ALIASES = {"personal": "Personal", "hand": "Personal", "hand delivery": "Personal",
           "electronic": "Electronic", "email": "Electronic", "e-service": "Electronic", "efile": "Electronic",
           "fax": "Fax", "facsimile": "Fax", "overnight": "OvernightOrExpress", "express": "OvernightOrExpress"}

SCOPE = ("Scope: California civil procedure, 2026-01-01 to 2027-12-31 only (the court-holiday table covers only those years). "
         "Not covered: month/year periods, statutes of limitation, summary judgment (CCP 437c), discovery, orders shortening time, "
         "local rules, court orders, Section 12b closures. For anything else: Docketing to calculate.")
DISCLAIMER = "Not legal advice. Computed by a rule engine from statute text captured by Wayback Machine, not checked against live leginfo. Verify against the statute, local rules and any court order. An attorney must review."

EXT = {"Personal": "no extension", "MailWithinCalifornia": "+5 calendar days (CCP 1005(b)/1013(a))",
       "MailOutOfState": "+10 calendar days (CCP 1005(b)/1013(a))",
       "MailAddressConfidentiality": "+12 calendar days (CCP 1005(b)/1013(a))",
       "MailOutOfCountry": "+20 calendar days (CCP 1005(b)/1013(a))",
       "OvernightOrExpress": "+2 calendar days for a motion (CCP 1005(b)); +2 court days for a response period (CCP 1013(c))",
       "Fax": "+2 calendar days for a motion (CCP 1005(b)); +2 court days for a response period (CCP 1013(e))",
       "Electronic": "+2 court days (CCP 1010.6(a)(3)(B), interpretive reading)"}


def _method(m):
    if m in METHODS:
        return m
    if isinstance(m, str):
        k = m.strip().lower()
        for x in METHODS:
            if x.lower() == k:
                return x
        if k in ALIASES:
            return ALIASES[k]
    return m  # glue will reject with its own message


def _wrap(tool, inputs, res, basis, source_url):
    base = {"tool": tool, "inputs": inputs, "scope": SCOPE, "disclaimer": DISCLAIMER,
            "source_url": source_url, "retrieved_at": now_iso()}
    if "error" in res:
        return {**base, "status": "error", "error": res["error"],
                "note": "No date was computed. Docketing to calculate."}
    return {**base, "status": "ok", "result": res, "statute_basis": basis,
            "holiday_source": "Judicial Council of California court holidays, retrieved 2026-11-12 (vendor/data/holidays.json)"}


def ca_motion_deadlines(hearing_date: str, service_method: str) -> dict:
    inp = {"hearing_date": hearing_date, "service_method": _method(service_method)}
    res = json.loads(glue.compute(json.dumps({"mode": "motion", **inp})))
    basis = {
        "moving_papers": "CCP 1005(b): served and filed at least 16 court days before the hearing; count backward excluding the hearing day (CCP 12c); "
                         "service-method extension: " + EXT.get(inp["service_method"], "n/a"),
        "serve_by_statutory": "Raw count-back date before any move to a court day.",
        "serve_by": "Preceding court day if the count-back lands on a non-court day (conservative practice, not statute text).",
        "opposition_by": "CCP 1005(b): at least nine court days before the hearing; CCP 1013 extensions do not apply (CCP 1005(b)).",
        "reply_by": "CCP 1005(b): at least five court days before the hearing.",
        "court_days": "CCP 10 (Sundays), CCP 135 and Gov. Code 6700 (judicial holidays), CCP 12a (roll forward)."}
    if res.get("hearing_is_court_day") is False:
        res["note"] = "The hearing date is not a court day, so no dates were computed. Docketing to calculate."
    return _wrap("ca_motion_deadlines", inp, res, basis, "https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=CCP&sectionNum=1005.")


def ca_response_deadline(service_date: str, period_days: int, service_method: str, extension_barred: bool = False) -> dict:
    inp = {"service_date": service_date, "period_days": period_days,
           "service_method": _method(service_method), "extension_barred": extension_barred}
    res = json.loads(glue.compute(json.dumps({"mode": "served", **inp})))
    basis = {
        "period": "Period of the stated number of calendar days, counted forward excluding the day of service and including the last day (CCP 12).",
        "extension": "Service-method extension: " + EXT.get(inp["service_method"], "n/a")
                     + ("; barred by the caller (extension_barred = true)" if extension_barred else ""),
        "deadline": "If the last day is a holiday (Sundays, judicial holidays), it rolls to the next court day (CCP 12a, 135, Gov. Code 6700-6701). "
                    "Interpretive choice: the extension is added to the period and the roll-forward is applied once at the end.",
        "note": "period_days is supplied by the caller from the rule or order that sets the response time; this tool does not look it up."}
    return _wrap("ca_response_deadline", inp, res, basis, "https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=CCP&sectionNum=1013.")


def ca_court_holidays(year: int) -> dict:
    data = json.loads((VENDOR / "data" / "holidays.json").read_text())
    base = {"tool": "ca_court_holidays", "inputs": {"year": year}, "disclaimer": DISCLAIMER,
            "source_url": data["source"], "retrieved_at": now_iso(), "data_retrieved": data["retrieved"]}
    if year not in (2026, 2027):
        return {**base, "status": "error", "error": "Holiday data exists for 2026 and 2027 only. Docketing to calculate."}
    hs = [h for h in data["holidays"] if h["date"].startswith(str(year))]
    return {**base, "status": "ok", "holidays": hs,
            "note": "Dates are as published by the Judicial Council; names are descriptive labels added by this project."}
