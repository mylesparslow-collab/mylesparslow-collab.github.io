"""Parse CFR citations such as '42 CFR § 483.70(n)' or '29 C.F.R. 825.300(b)(1)'."""
import re
from dataclasses import dataclass

_CITE = re.compile(
    r"""^\s*(?P<title>\d{1,2})\s*
        (?:C\.?\s*F\.?\s*R\.?|Code\s+of\s+Federal\s+Regulations)\s*
        (?:§§?|sec(?:tion)?s?\.?|part)?\s*
        (?P<section>\d{1,4}(?:\.\d{1,4}[A-Za-z]?(?:-\d+)?)?)
        (?P<paras>(?:\s*\([A-Za-z0-9]{1,5}\))*)
        \s*[.,;]?\s*$""",
    re.I | re.X)
_PARA = re.compile(r"\(([A-Za-z0-9]{1,5})\)")


@dataclass
class Cite:
    raw: str
    title: int
    section: str
    paragraphs: list  # e.g. ["n"] or ["b", "1"]

    @property
    def normalized(self) -> str:
        return f"{self.title} CFR {self.section}" + "".join(f"({p})" for p in self.paragraphs)


def parse_cite(raw: str):
    """Return a Cite or None when the string is not a recognizable CFR cite."""
    m = _CITE.match(raw or "")
    if not m:
        return None
    return Cite(raw=raw, title=int(m["title"]), section=m["section"],
                paragraphs=_PARA.findall(m["paras"] or ""))
