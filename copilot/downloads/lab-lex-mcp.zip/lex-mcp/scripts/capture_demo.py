"""Start the server, run the demo calls through the official MCP client, save demo/transcript.json and demo/transcript.md."""
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import dump_tools  # noqa: E402
from mcp import ClientSession  # noqa: E402
from mcp.client.streamable_http import streamablehttp_client  # noqa: E402

DEMO = Path(__file__).resolve().parents[1] / "demo"
CALLS = [
    ("A brief cites 42 CFR 483.70(n) as the nursing-home arbitration rule (and 483.70(m) for comparison, plus one cite with a missing paragraph). Does the text exist there today?",
     "cfr_cite_check", {"citations": ["42 CFR § 483.70(n)", "42 C.F.R. 483.70(m)", "29 C.F.R. 825.300(z)"],
                        "context": ["binding arbitration agreements", "binding arbitration agreements", ""],
                        "as_of_date": "2019-01-01"}),
    ("A hearing is set for 2026-12-18 and the moving papers will be served electronically. What are the motion dates?",
     "ca_motion_deadlines", {"hearing_date": "2026-12-18", "service_method": "Electronic"}),
    ("What proposed rules about nursing home staffing has the Federal Register published since 2023?",
     "federal_register_search", {"term": "nursing home staffing", "doc_type": "proposed rule", "since": "2023-01-01"}),
    ("Which 8-Ks since 2026-09-01 mention \"tender offer\"?",
     "sec_filing_search", {"query": "\"tender offer\"", "forms": ["8-K"], "date_from": "2026-09-01"}),
]


async def run(url):
    out = []
    async with streamablehttp_client(url) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            for q, name, args in CALLS:
                res = await s.call_tool(name, args)
                out.append({"user_question": q, "tool": name, "arguments": args, "is_error": res.isError,
                            "raw_result": json.loads(res.content[0].text)})
    return out


def md(entries):
    L = ["# Lex Tools: real end-to-end transcript", "",
         "Produced by `scripts/capture_demo.py`: the server was started locally, and each call below went through the official MCP Python client over Streamable HTTP. Results are the raw tool output. No language model was involved; this shows the tools, not a Copilot conversation.", ""]
    for i, e in enumerate(entries, 1):
        L += [f"## {i}. {e['tool']}", "", f"Question: {e['user_question']}", "", "Tool call:", "```json",
              json.dumps({"name": e["tool"], "arguments": e["arguments"]}, indent=2, ensure_ascii=False), "```", "", "Raw result:", "```json",
              json.dumps(e["raw_result"], indent=2, ensure_ascii=False), "```", ""]
    return "\n".join(L)


def main():
    port = dump_tools.free_port()
    p = dump_tools.start_server(port)
    try:
        entries = asyncio.run(run(f"http://127.0.0.1:{port}/mcp"))
    finally:
        p.terminate()
        p.wait(5)
    DEMO.mkdir(exist_ok=True)
    (DEMO / "transcript.json").write_text(json.dumps(entries, indent=2, ensure_ascii=False) + "\n")
    (DEMO / "transcript.md").write_text(md(entries))
    print("saved", [e["tool"] for e in entries], [e["is_error"] for e in entries])


if __name__ == "__main__":
    main()
