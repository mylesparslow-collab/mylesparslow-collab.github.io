"""Start the server, call MCP tools/list, write mcp-tools.json (and copy it into every agent's appPackage).

Usage: uv run --python 3.12 python scripts/dump_tools.py
"""
import asyncio
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "mcp-tools.json"


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


async def list_tools(url: str):
    async with streamablehttp_client(url) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            res = await s.list_tools()
            return [{"name": t.name, "description": t.description, "inputSchema": t.inputSchema} for t in res.tools]


def start_server(port: int) -> subprocess.Popen:
    env = {**os.environ, "PORT": str(port), "PYTHONPATH": str(ROOT / "src")}
    p = subprocess.Popen([sys.executable, "-m", "lex_tools.server"], env=env, cwd=ROOT,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        try:
            socket.create_connection(("127.0.0.1", port), 0.2).close()
            return p
        except OSError:
            time.sleep(0.25)
    p.kill()
    raise RuntimeError("server did not start")


def live_tools():
    port = free_port()
    p = start_server(port)
    try:
        return asyncio.run(list_tools(f"http://127.0.0.1:{port}/mcp"))
    finally:
        p.terminate()
        p.wait(5)


def main():
    tools = sorted(live_tools(), key=lambda t: t["name"])
    OUT.write_text(json.dumps(tools, indent=2) + "\n")
    n = 0
    for d in (ROOT / "agents").glob("*/appPackage"):
        shutil.copyfile(OUT, d / "mcp-tools.json")
        n += 1
    print(f"wrote {OUT} ({len(tools)} tools) and {n} agent copies")


if __name__ == "__main__":
    main()
