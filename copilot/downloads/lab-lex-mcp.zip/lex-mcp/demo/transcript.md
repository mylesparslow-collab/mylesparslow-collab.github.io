# Lex Tools: real end-to-end transcript

Produced by `scripts/capture_demo.py`: the server was started locally, and each call below went through the official MCP Python client over Streamable HTTP. Results are the raw tool output. No language model was involved; this shows the tools, not a Copilot conversation.

## 1. cfr_cite_check

Question: A brief cites 42 CFR 483.70(n) as the nursing-home arbitration rule (and 483.70(m) for comparison, plus one cite with a missing paragraph). Does the text exist there today?

Tool call:
```json
{
  "name": "cfr_cite_check",
  "arguments": {
    "citations": [
      "42 CFR § 483.70(n)",
      "42 C.F.R. 483.70(m)",
      "29 C.F.R. 825.300(z)"
    ],
    "context": [
      "binding arbitration agreements",
      "binding arbitration agreements",
      ""
    ],
    "as_of_date": "2019-01-01"
  }
}
```

Raw result:
```json
{
  "status": "ok",
  "results": [
    {
      "citation": "42 CFR § 483.70(n)",
      "normalized": "42 CFR 483.70(n)",
      "section_heading": "§ 483.70 Administration.",
      "last_amended": "2024-06-21",
      "evidence": {
        "versions_url": "https://www.ecfr.gov/api/versioner/v1/versions/title-42.json?section=483.70",
        "section_url": "https://www.ecfr.gov/api/versioner/v1/full/2026-11-10/title-42.xml?section=483.70",
        "ecfr_up_to_date_as_of": "2026-11-10",
        "human_url": "https://www.ecfr.gov/current/title-42/section-483.70"
      },
      "top_level_paragraphs": [
        "(a) Licensure",
        "(b) Compliance with Federal, State, and local laws and professional standards",
        "(c) Relationship to other HHS regulations",
        "(d) Governing body",
        "(e) Staff qualifications",
        "(f) Use of outside resources",
        "(g) Medical director",
        "(h) Medical records",
        "(i) Transfer agreement",
        "(j) Disclosure of ownership",
        "(k) Facility closure-Administrator",
        "(l) Facility closure",
        "(m) Binding arbitration agreements",
        "(n) Hospice services",
        "(o) Social worker",
        "(p) Mandatory submission of staffing information based on payroll data in a uniform format"
      ],
      "paragraph_checked": "(n)",
      "heading_today": "Hospice services",
      "paragraph_text_start": "(n) Hospice services. (1) A long-term care (LTC) facility may do either of the following:",
      "as_of_date": "2019-01-01",
      "heading_at_as_of_date": "Binding arbitration agreements",
      "paragraph_existed_at_as_of_date": true,
      "amended_since_as_of_date": true,
      "topic_keywords": [
        "arbitration",
        "binding"
      ],
      "topic_keywords_found_in_paragraph": [],
      "topic_found_at": [
        "(m) Binding arbitration agreements"
      ],
      "flags": [
        "None of the topic keywords ['arbitration', 'binding'] appear in (n) today; they do appear at (m) Binding arbitration agreements.",
        "Heading at 2019-01-01 was 'Binding arbitration agreements' but today it is 'Hospice services'."
      ],
      "status": "Heading differs",
      "reason": "The paragraph exists today but the evidence does not support that it is the same provision. A human must check."
    },
    {
      "citation": "42 C.F.R. 483.70(m)",
      "normalized": "42 CFR 483.70(m)",
      "section_heading": "§ 483.70 Administration.",
      "last_amended": "2024-06-21",
      "evidence": {
        "versions_url": "https://www.ecfr.gov/api/versioner/v1/versions/title-42.json?section=483.70",
        "section_url": "https://www.ecfr.gov/api/versioner/v1/full/2026-11-10/title-42.xml?section=483.70",
        "ecfr_up_to_date_as_of": "2026-11-10",
        "human_url": "https://www.ecfr.gov/current/title-42/section-483.70"
      },
      "top_level_paragraphs": [
        "(a) Licensure",
        "(b) Compliance with Federal, State, and local laws and professional standards",
        "(c) Relationship to other HHS regulations",
        "(d) Governing body",
        "(e) Staff qualifications",
        "(f) Use of outside resources",
        "(g) Medical director",
        "(h) Medical records",
        "(i) Transfer agreement",
        "(j) Disclosure of ownership",
        "(k) Facility closure-Administrator",
        "(l) Facility closure",
        "(m) Binding arbitration agreements",
        "(n) Hospice services",
        "(o) Social worker",
        "(p) Mandatory submission of staffing information based on payroll data in a uniform format"
      ],
      "paragraph_checked": "(m)",
      "heading_today": "Binding arbitration agreements",
      "paragraph_text_start": "(m) Binding arbitration agreements. If a facility chooses to ask a resident or his or her representative to enter into an agreement for binding arbitration, the facility must comply with all of the re",
      "as_of_date": "2019-01-01",
      "heading_at_as_of_date": "Facility closure",
      "paragraph_existed_at_as_of_date": true,
      "amended_since_as_of_date": true,
      "topic_keywords": [
        "arbitration",
        "binding"
      ],
      "topic_keywords_found_in_paragraph": [
        "arbitration",
        "binding"
      ],
      "notes": [
        "Heading at 2019-01-01 was 'Facility closure' but today it is 'Binding arbitration agreements'."
      ],
      "flags": [],
      "status": "Confirmed current",
      "reason": "Section and paragraph exist today. This is an existence check, not a statement of what the law means."
    },
    {
      "citation": "29 C.F.R. 825.300(z)",
      "normalized": "29 CFR 825.300(z)",
      "section_heading": "§ 825.300 Employer notice requirements.",
      "last_amended": "2025-01-15",
      "evidence": {
        "versions_url": "https://www.ecfr.gov/api/versioner/v1/versions/title-29.json?section=825.300",
        "section_url": "https://www.ecfr.gov/api/versioner/v1/full/2026-11-10/title-29.xml?section=825.300",
        "ecfr_up_to_date_as_of": "2026-11-10",
        "human_url": "https://www.ecfr.gov/current/title-29/section-825.300"
      },
      "top_level_paragraphs": [
        "(a) General notice",
        "(b) Eligibility notice",
        "(c) Rights and responsibilities notice",
        "(d) Designation notice",
        "(e) Consequences of failing to provide notice"
      ],
      "status": "Paragraph not found",
      "paragraph_checked": "(z)",
      "paragraphs_that_exist": [
        "(a) General notice",
        "(b) Eligibility notice",
        "(c) Rights and responsibilities notice",
        "(d) Designation notice",
        "(e) Consequences of failing to provide notice"
      ],
      "reason": "No paragraph (z) exists in 825.300 today. The paragraphs that do exist at the top level are listed."
    }
  ],
  "scope_note": "Checks that text exists at the cited location today and reports headings and amendment dates. It does not say what a regulation means or whether a cite is correct law.",
  "source_url": "https://www.ecfr.gov/api/versioner/v1/",
  "retrieved_at": "2026-11-13T10:08:06Z"
}
```

## 2. ca_motion_deadlines

Question: A hearing is set for 2026-12-18 and the moving papers will be served electronically. What are the motion dates?

Tool call:
```json
{
  "name": "ca_motion_deadlines",
  "arguments": {
    "hearing_date": "2026-12-18",
    "service_method": "Electronic"
  }
}
```

Raw result:
```json
{
  "tool": "ca_motion_deadlines",
  "inputs": {
    "hearing_date": "2026-12-18",
    "service_method": "Electronic"
  },
  "scope": "Scope: California civil procedure, 2026-01-01 to 2027-12-31 only (the court-holiday table covers only those years). Not covered: month/year periods, statutes of limitation, summary judgment (CCP 437c), discovery, orders shortening time, local rules, court orders, Section 12b closures. For anything else: Docketing to calculate.",
  "disclaimer": "Not legal advice. Computed by a rule engine from statute text captured by Wayback Machine, not checked against live leginfo. Verify against the statute, local rules and any court order. An attorney must review.",
  "source_url": "https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=CCP&sectionNum=1005.",
  "retrieved_at": "2026-11-13T10:08:06Z",
  "status": "ok",
  "result": {
    "hearing_is_court_day": true,
    "base_day": "2026-11-24",
    "serve_by_statutory": "2026-11-20",
    "serve_by": "2026-11-20",
    "opposition_by": "2026-12-07",
    "reply_by": "2026-12-11"
  },
  "statute_basis": {
    "moving_papers": "CCP 1005(b): served and filed at least 16 court days before the hearing; count backward excluding the hearing day (CCP 12c); service-method extension: +2 court days (CCP 1010.6(a)(3)(B), interpretive reading)",
    "serve_by_statutory": "Raw count-back date before any move to a court day.",
    "serve_by": "Preceding court day if the count-back lands on a non-court day (conservative practice, not statute text).",
    "opposition_by": "CCP 1005(b): at least nine court days before the hearing; CCP 1013 extensions do not apply (CCP 1005(b)).",
    "reply_by": "CCP 1005(b): at least five court days before the hearing.",
    "court_days": "CCP 10 (Sundays), CCP 135 and Gov. Code 6700 (judicial holidays), CCP 12a (roll forward)."
  },
  "holiday_source": "Judicial Council of California court holidays, retrieved 2026-11-12 (vendor/data/holidays.json)"
}
```

## 3. federal_register_search

Question: What proposed rules about nursing home staffing has the Federal Register published since 2023?

Tool call:
```json
{
  "name": "federal_register_search",
  "arguments": {
    "term": "nursing home staffing",
    "doc_type": "proposed rule",
    "since": "2023-01-01"
  }
}
```

Raw result:
```json
{
  "status": "ok",
  "total_matches": 151,
  "returned": 10,
  "results": [
    {
      "title": "Medicare and Medicaid Programs; Cutting Administrative Requirements for Excellence in Patient Care",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-11-10",
      "comments_close_on": "2027-01-11",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-22812",
      "html_url": "https://www.federalregister.gov/documents/2026/11/10/2026-22812/medicare-and-medicaid-programs-cutting-administrative-requirements-for-excellence-in-patient-care"
    },
    {
      "title": "Pipeline Safety: Amendments to Liquefied Natural Gas Facilities",
      "type": "Proposed Rule",
      "agencies": [
        "Transportation Department",
        "Pipeline and Hazardous Materials Safety Administration"
      ],
      "publication_date": "2026-11-03",
      "comments_close_on": "2027-01-04",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-22396",
      "html_url": "https://www.federalregister.gov/documents/2026/11/03/2026-22396/pipeline-safety-amendments-to-liquefied-natural-gas-facilities"
    },
    {
      "title": "Medicare Program; Implementation of Sections 6219, 6220, and 6224 of the Consolidated Appropriations Act, 2026",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-10-20",
      "comments_close_on": "2026-12-15",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-21420",
      "html_url": "https://www.federalregister.gov/documents/2026/10/20/2026-21420/medicare-program-implementation-of-sections-6219-6220-and-6224-of-the-consolidated-appropriations"
    },
    {
      "title": "Clinical Laboratory Improvement Amendments of 1988 (CLIA); Virtual Access, Gynecologic Cytology Proficiency Testing (PT), Personnel Qualifications, and Other Changes",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-10-08",
      "comments_close_on": "2026-12-07",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-20613",
      "html_url": "https://www.federalregister.gov/documents/2026/10/08/2026-20613/clinical-laboratory-improvement-amendments-of-1988-clia-virtual-access-gynecologic-cytology"
    },
    {
      "title": "Takes of Marine Mammals Incidental to Specified Activities; Taking Marine Mammals Incidental to the Washington State Parks and Recreation Commission's Marine Facilities Replacement Program in North Puget Sound, Washington",
      "type": "Proposed Rule",
      "agencies": [
        "Commerce Department",
        "National Oceanic and Atmospheric Administration"
      ],
      "publication_date": "2026-08-11",
      "comments_close_on": "2026-09-10",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-16329",
      "html_url": "https://www.federalregister.gov/documents/2026/08/11/2026-16329/takes-of-marine-mammals-incidental-to-specified-activities-taking-marine-mammals-incidental-to-the"
    },
    {
      "title": "Medicare and Medicaid Programs; CY 2027 Payment Policies Under the Physician Fee Schedule and Other Changes to Part B Payment and Coverage Policies; Medicare Shared Savings Program Requirements; and Medicare Prescription Drug Inflation Rebate Program",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-07-16",
      "comments_close_on": "2026-09-14",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-14327",
      "html_url": "https://www.federalregister.gov/documents/2026/07/16/2026-14327/medicare-and-medicaid-programs-cy-2027-payment-policies-under-the-physician-fee-schedule-and-other"
    },
    {
      "title": "Reforming and Modernizing the NRC's Radiation Protection Framework",
      "type": "Proposed Rule",
      "agencies": [
        "Nuclear Regulatory Commission"
      ],
      "publication_date": "2026-07-15",
      "comments_close_on": "2026-08-31",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-14208",
      "html_url": "https://www.federalregister.gov/documents/2026/07/15/2026-14208/reforming-and-modernizing-the-nrcs-radiation-protection-framework"
    },
    {
      "title": "Rescission of Floodplain Management and Protection of Wetlands; Minimum Property Standards for Flood Hazard Exposure; Building to the Federal Flood Risk Management Standard",
      "type": "Proposed Rule",
      "agencies": [
        "Housing and Urban Development Department"
      ],
      "publication_date": "2026-07-10",
      "comments_close_on": "2026-09-08",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-13939",
      "html_url": "https://www.federalregister.gov/documents/2026/07/10/2026-13939/rescission-of-floodplain-management-and-protection-of-wetlands-minimum-property-standards-for-flood"
    },
    {
      "title": "Medicare Program: Hospital Outpatient Prospective Payment and Ambulatory Surgical Center Payment Systems; and Quality Reporting Programs; Including the Hospital Outpatient Quality Reporting Program and Ambulatory Surgical Center Quality Program; Request for Information on Strengthening the Standardization and Comparability of Hospital Price Transparency (HPT) Data; Prior Authorization; Accrediting Organization (AO) Deeming for Emergency Medical Treatment and Labor Act (EMTALA); and Notices of Closure of Teaching Hospitals and Opportunities To Apply for Available Slots",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-07-07",
      "comments_close_on": "2026-08-31",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-13656",
      "html_url": "https://www.federalregister.gov/documents/2026/07/07/2026-13656/medicare-program-hospital-outpatient-prospective-payment-and-ambulatory-surgical-center-payment"
    },
    {
      "title": "Calendar Year 2027 Home Health Prospective Payment System (HH PPS) Rate Update; Requirements for the HH Quality Reporting Program and the Expanded HH Value-Based Purchasing Model; Medicare Provider Enrollment, Durable Medical Equipment (DME), and DME, Prosthetics, Orthotics, and Supplies (DMEPOS) Policies",
      "type": "Proposed Rule",
      "agencies": [
        "Health and Human Services Department",
        "Centers for Medicare & Medicaid Services"
      ],
      "publication_date": "2026-07-06",
      "comments_close_on": "2026-08-31",
      "comments_close_note": "As published in the document metadata; not recalculated.",
      "document_number": "2026-13602",
      "html_url": "https://www.federalregister.gov/documents/2026/07/06/2026-13602/calendar-year-2027-home-health-prospective-payment-system-hh-pps-rate-update-requirements-for-the-hh"
    }
  ],
  "source_url": "https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=nursing+home+staffing&per_page=10&order=newest&fields%5B%5D=title&fields%5B%5D=type&fields%5B%5D=agencies&fields%5B%5D=publication_date&fields%5B%5D=comments_close_on&fields%5B%5D=html_url&fields%5B%5D=document_number&conditions%5Btype%5D%5B%5D=PRORULE&conditions%5Bpublication_date%5D%5Bgte%5D=2023-01-01",
  "retrieved_at": "2026-11-13T10:08:06Z"
}
```

## 4. sec_filing_search

Question: Which 8-Ks since 2026-09-01 mention "tender offer"?

Tool call:
```json
{
  "name": "sec_filing_search",
  "arguments": {
    "query": "\"tender offer\"",
    "forms": [
      "8-K"
    ],
    "date_from": "2026-09-01"
  }
}
```

Raw result:
```json
{
  "status": "ok",
  "total_matches": 1074,
  "total_is_lower_bound": false,
  "returned": 10,
  "results": [
    {
      "company": "INVE Technologies, Inc.  (INVE)  (CIK 0001036044)",
      "form": "8-K",
      "filed": "2026-10-21",
      "period_ending": "2026-10-21",
      "accession_number": "0001213900-26-111181",
      "link": "https://www.sec.gov/Archives/edgar/data/1036044/000121390026111181/ea030911901ex99-1.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1036044/000121390026111181/"
    },
    {
      "company": "Sabre Corp  (SABR)  (CIK 0001597033)",
      "form": "8-K",
      "filed": "2026-09-15",
      "period_ending": "2026-09-14",
      "accession_number": "0001193125-26-392129",
      "link": "https://www.sec.gov/Archives/edgar/data/1597033/000119312526392129/d179319dex993.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1597033/000119312526392129/"
    },
    {
      "company": "Sabre Corp  (SABR)  (CIK 0001597033)",
      "form": "8-K",
      "filed": "2026-09-28",
      "period_ending": "2026-09-24",
      "accession_number": "0001193125-26-405576",
      "link": "https://www.sec.gov/Archives/edgar/data/1597033/000119312526405576/d435567dex992.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1597033/000119312526405576/"
    },
    {
      "company": "OPEN TEXT CORP  (OTEX)  (CIK 0001002638)",
      "form": "8-K",
      "filed": "2026-09-23",
      "period_ending": "2026-09-23",
      "accession_number": "0001002638-26-000077",
      "link": "https://www.sec.gov/Archives/edgar/data/1002638/000100263826000077/exhibit992-pressreleasesep.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1002638/000100263826000077/"
    },
    {
      "company": "Hudson Pacific Properties, Inc.  (HPP, HPP-PC)  (CIK 0001482512)",
      "form": "8-K",
      "filed": "2026-10-05",
      "period_ending": "2026-10-05",
      "accession_number": "0001482512-26-000077",
      "link": "https://www.sec.gov/Archives/edgar/data/1482512/000148251226000077/pr090526.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1482512/000148251226000077/"
    },
    {
      "company": "SkyAI, Inc.  (SKYA, SKYAW)  (CIK 0001737995)",
      "form": "8-K",
      "filed": "2026-10-28",
      "period_ending": "2026-10-28",
      "accession_number": "0001493152-26-048827",
      "link": "https://www.sec.gov/Archives/edgar/data/1737995/000149315226048827/ex10-1.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1737995/000149315226048827/"
    },
    {
      "company": "Cavitation Technologies, Inc.  (CVAT)  (CIK 0001376793)",
      "form": "8-K",
      "filed": "2026-10-13",
      "period_ending": "2026-10-13",
      "accession_number": "0001683168-26-007778",
      "link": "https://www.sec.gov/Archives/edgar/data/1376793/000168316826007778/cavitation_8k.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1376793/000168316826007778/"
    },
    {
      "company": "ULTRALIFE CORP  (ULBI)  (CIK 0000875657)",
      "form": "8-K",
      "filed": "2026-10-28",
      "period_ending": "2026-10-27",
      "accession_number": "0001437749-26-033731",
      "link": "https://www.sec.gov/Archives/edgar/data/875657/000143774926033731/ex_1032342.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/875657/000143774926033731/"
    },
    {
      "company": "OPEN TEXT CORP  (OTEX)  (CIK 0001002638)",
      "form": "8-K",
      "filed": "2026-10-01",
      "period_ending": "2026-09-30",
      "accession_number": "0001002638-26-000087",
      "link": "https://www.sec.gov/Archives/edgar/data/1002638/000100263826000087/exhibit991-pressreleasesep.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1002638/000100263826000087/"
    },
    {
      "company": "EnerSys  (ENS)  (CIK 0001289308)",
      "form": "8-K",
      "filed": "2026-10-27",
      "period_ending": "2026-10-27",
      "accession_number": "0001193125-26-434415",
      "link": "https://www.sec.gov/Archives/edgar/data/1289308/000119312526434415/d143472dex991.htm",
      "filing_index": "https://www.sec.gov/Archives/edgar/data/1289308/000119312526434415/"
    }
  ],
  "source_url": "https://efts.sec.gov/LATEST/search-index?q=%22tender+offer%22&forms=8-K&dateRange=custom&startdt=2026-09-01&enddt=2026-11-13",
  "retrieved_at": "2026-11-13T10:08:06Z"
}
```
