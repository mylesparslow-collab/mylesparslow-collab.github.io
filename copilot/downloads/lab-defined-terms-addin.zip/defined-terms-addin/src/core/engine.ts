import type { Definition, Finding, FindingKind, Paragraph, Severity } from "./types.ts";
import { findDefinitions } from "./definitions.ts";
import { buildRegistry } from "./numbering.ts";
import { checkReferences } from "./xrefs.ts";
import { AMBIGUOUS_LOWER, DETERMINERS, STOP_WORDS, UBIQUITOUS } from "./stoplist.ts";
import { escapeRegExp, forms, inRanges, keyOf, normBody, normalizeQuotes, quotedRanges } from "./text.ts";

export interface AnalyzeOptions {
  /** A capitalised phrase must appear at least this many times before it is called undefined. */
  minUndefinedUses?: number;
}

export interface Analysis {
  findings: Finding[];
  definitions: Definition[];
}

const CODE: Record<FindingKind, string> = {
  "undefined-term": "UND",
  "unused-definition": "UNU",
  "duplicate-definition": "DUP",
  "used-before-definition": "PRE",
  "inconsistent-capitalisation": "CAP",
  "broken-reference": "REF",
  "reference-direction": "DIR",
};

const SEVERITY: Record<FindingKind, Severity> = {
  "undefined-term": "warning",
  "unused-definition": "info",
  "duplicate-definition": "error",
  "used-before-definition": "info",
  "inconsistent-capitalisation": "warning",
  "broken-reference": "error",
  "reference-direction": "warning",
};

interface Hit { para: number; start: number; end: number; text: string }

function allHits(norm: string[], re: RegExp, skipHeadings: Paragraph[] | null, skipQuoted: boolean, quoted: Array<Array<[number, number]>>): Hit[] {
  const out: Hit[] = [];
  norm.forEach((t, i) => {
    if (skipHeadings && skipHeadings[i].headingLevel) return;
    const r = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
    let m: RegExpExecArray | null;
    while ((m = r.exec(t))) {
      if (m[0].length === 0) { r.lastIndex++; continue; }
      if (skipQuoted && inRanges(m.index, quoted[i])) continue;
      out.push({ para: i, start: m.index, end: m.index + m[0].length, text: m[0] });
    }
  });
  return out;
}

/** The spelling a derived form (plural/singular) should have, copying the capital letters of the defined term word by word. */
function casedForm(defined: string, lowerForm: string): string {
  const dw = defined.trim().split(/\s+/);
  return lowerForm
    .split(" ")
    .map((w, n) => {
      const ref = dw[Math.min(n, dw.length - 1)];
      return /^[A-Z]/.test(ref) ? w.charAt(0).toUpperCase() + w.slice(1) : w;
    })
    .join(" ");
}

const wordRe = (phrase: string, flags = "") => new RegExp(String.raw`(?<![A-Za-z0-9])${escapeRegExp(phrase).replace(/ /g, String.raw`\s+`)}(?![A-Za-z0-9])`, flags);

function isSentenceStart(norm: string, pos: number): boolean {
  const before = norm.slice(0, pos).trimEnd();
  if (before === "") return true;
  if (/[.!?:;]["')\]]*$/.test(before)) return true;
  if (/^\(?[a-z0-9]{1,4}\)$/i.test(before)) return true;
  return false;
}

function previousWord(norm: string, pos: number): string {
  const m = /([A-Za-z]+)[\s"'(]*$/.exec(norm.slice(Math.max(0, pos - 30), pos));
  return m ? m[1].toLowerCase() : "";
}

export function analyze(paragraphs: Paragraph[], opts: AnalyzeOptions = {}): Analysis {
  const minUses = opts.minUndefinedUses ?? 2;
  const norm = paragraphs.map((p) => normalizeQuotes(p.text));
  const quoted = norm.map(quotedRanges);
  const defs = findDefinitions(paragraphs);
  const raw: Array<Omit<Finding, "id">> = [];
  const add = (kind: FindingKind, para: number, start: number, end: number, message: string, suggestion?: string) => {
    raw.push({ kind, severity: SEVERITY[kind], paragraphIndex: para, start, end, quote: paragraphs[para].text.slice(start, end), message, ...(suggestion ? { suggestion } : {}) });
  };

  // Group definitions by term.
  const byKey = new Map<string, Definition[]>();
  for (const d of defs) {
    const list = byKey.get(d.key) ?? [];
    list.push(d);
    byKey.set(d.key, list);
  }

  // 1. Duplicate definitions with different wording.
  for (const [key, list] of byKey) {
    const real = list.filter((d) => d.style !== "pointer");
    if (real.length < 2) continue;
    const first = real[0];
    for (const d of real.slice(1)) {
      if (!d.body || !first.body || d.body === first.body) continue;
      add("duplicate-definition", d.paragraphIndex, d.start, d.end,
        `"${d.term}" is defined more than once with different wording. The first definition is in paragraph ${first.paragraphIndex + 1}. Check which one is meant to govern.`);
    }
    void key;
  }

  // Defined-term vocabulary: every spelling of every term, for the checks below.
  const allForms = new Set<string>();
  for (const key of byKey.keys()) for (const f of forms(key)) allForms.add(f);

  // 2. Defined but never used.
  for (const [key, list] of byKey) {
    const first = list[0];
    const fs = forms(key);
    const re = new RegExp(fs.map((f) => wordRe(f).source).join("|"), "gi");
    // A term repeated inside its own definition paragraph ("Knowledge: the actual knowledge of...") is not a use.
    const ownParas = new Set(list.map((x) => x.paragraphIndex));
    const hits = allHits(norm, re, null, false, quoted).filter((h) => !ownParas.has(h.para));
    if (hits.length === 0) {
      add("unused-definition", first.paragraphIndex, first.start, first.end,
        `"${first.term}" is defined here but the term does not appear anywhere else in the document.`);
    }
  }

  // 3. Used before its definition (informational). Only for terms defined in the body, not in a Definitions section.
  for (const [key, list] of byKey) {
    const d = list[0];
    if (d.inDefinitionsSection || d.style === "listed") continue;
    const head = d.term.split(/\s+/)[0];
    if (UBIQUITOUS.has(head) || UBIQUITOUS.has(d.term)) continue;
    const cased = forms(key).map((f) => casedForm(d.term, f));
    const re = new RegExp(cased.map((f) => wordRe(f).source).join("|"), "g");
    const hit = allHits(norm, re, paragraphs, true, quoted).find((h) => h.para < d.paragraphIndex);
    if (hit) {
      add("used-before-definition", hit.para, hit.start, hit.end,
        `"${d.term}" is used here, but it is not defined until paragraph ${d.paragraphIndex + 1}. This is informational: it is common to define a term where it first matters.`);
    }
  }

  // 4. Inconsistent capitalisation of a defined term.
  for (const [key, list] of byKey) {
    const d = list[0];
    const single = !key.includes(" ");
    if (single && AMBIGUOUS_LOWER.has(key)) continue;
    const spellings = single ? [key] : forms(key);
    const defParas = new Set(list.map((x) => x.paragraphIndex));
    for (const f of spellings) {
      const expected = casedForm(d.term, f);
      const re = wordRe(f, "gi");
      for (const h of allHits(norm, re, paragraphs, true, quoted)) {
        if (defParas.has(h.para)) continue;
        const text = paragraphs[h.para].text.slice(h.start, h.end).replace(/\s+/g, " ");
        if (text === expected || (text.length > 1 && text === text.toUpperCase())) continue;
        if (single && !["the", "such", "each", "said"].includes(previousWord(norm[h.para], h.start))) continue;
        // A capitalised first word at the start of a sentence is not the slip; the other words still count.
        add("inconsistent-capitalisation", h.para, h.start, h.end,
          `"${d.term}" is a defined term, but here it is written "${text}". Use the defined capitalisation: "${expected}".`, expected);
      }
    }
  }

  // 5. Capitalised terms used but never defined.
  const defWordLists = [...allForms].map((f) => f.split(" "));
  const containsSeq = (hay: string[], needle: string[]) => {
    for (let i = 0; i + needle.length <= hay.length; i++) if (needle.every((w, k) => hay[i + k] === w)) return true;
    return false;
  };
  const candidates = new Map<string, { hit: Hit; count: number }>();
  const runRe = /(?<![A-Za-z0-9'])[A-Z][a-z]+(?:-[A-Z][a-z]+)?(?: [A-Z][a-z]+(?:-[A-Z][a-z]+)?)*(?![A-Za-z0-9])/g;
  norm.forEach((t, i) => {
    if (paragraphs[i].headingLevel) return;
    runRe.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = runRe.exec(t))) {
      const run = m[0];
      if (inRanges(m.index, quoted[i])) continue;
      if (isSentenceStart(t, m.index)) continue;
      if (!DETERMINERS.has(previousWord(t, m.index))) continue;
      const ws = run.split(/[ -]/);
      if (ws.some((w) => STOP_WORDS.has(w))) continue;
      const lower = ws.map((w) => w.toLowerCase());
      if (defWordLists.some((dw) => containsSeq(lower, dw) || containsSeq(dw, lower))) continue;
      const k = keyOf(run);
      const cur = candidates.get(k);
      if (cur) cur.count++;
      else candidates.set(k, { hit: { para: i, start: m.index, end: m.index + run.length, text: run }, count: 1 });
    }
  });
  for (const [k, c] of candidates) {
    // Count every capitalised appearance of the exact phrase, wherever it sits.
    const total = allHits(norm, wordRe(c.hit.text), paragraphs, true, quoted).length;
    if (total < minUses) continue;
    add("undefined-term", c.hit.para, c.hit.start, c.hit.end,
      `"${c.hit.text}" is capitalised like a defined term and appears ${total} times, but the document never defines it.`);
    void k;
  }

  // 6. Cross-references.
  const reg = buildRegistry(paragraphs);
  for (const x of checkReferences(paragraphs, reg)) raw.push(x);

  const findings: Finding[] = raw
    .sort((a, b) => a.paragraphIndex - b.paragraphIndex || a.start - b.start || a.kind.localeCompare(b.kind))
    .map((f) => ({ id: `${CODE[f.kind]}-${f.paragraphIndex}-${f.start}`, ...f }));
  void normBody;
  return { findings, definitions: defs };
}
