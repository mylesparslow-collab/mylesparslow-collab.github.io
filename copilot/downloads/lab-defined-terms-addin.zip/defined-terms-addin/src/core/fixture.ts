import type { Paragraph } from "./types.ts";

/**
 * Plain-text contract format used by fixtures and the demo. One paragraph per line.
 *   # Heading            (## = level 2)
 *   [4.2] Body text      (the bracket holds the numbering label, kept apart from the text as Word does)
 * Blank lines and lines starting with "//" are skipped.
 */
export function parseFixture(src: string): Paragraph[] {
  const out: Paragraph[] = [];
  for (const line of src.split(/\r?\n/)) {
    if (!line.trim() || line.startsWith("//")) continue;
    let rest = line;
    const p: Paragraph = { text: "" };
    const h = /^(#{1,6})\s+(.*)$/.exec(rest);
    if (h) {
      p.headingLevel = h[1].length;
      rest = h[2];
    }
    const l = /^\[([^\]]+)\]\s*(.*)$/.exec(rest);
    if (l) {
      p.label = l[1];
      rest = l[2];
    }
    p.text = rest;
    out.push(p);
  }
  return out;
}
