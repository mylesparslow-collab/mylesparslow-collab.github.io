import type { Finding, Paragraph } from "./types.ts";
import { articleKey, attachmentKey, buildRegistry, resolveSection, type Registry } from "./numbering.ts";
import { normalizeQuotes } from "./text.ts";

const NUM = String.raw`\d+(?:\.\d+)*(?:\([a-zA-Z0-9]{1,4}\))*`;
const NUM_END = String.raw`(?![A-Za-z0-9])`; // "409A" is not a section number
const SECTION_RE = new RegExp(String.raw`\b(?:Sections?|Clauses?|Subsections?|§§?)\s*(${NUM}${NUM_END}(?:\s*(?:,|and|or|and/or|through|to|,\s*and|,\s*or)\s*${NUM}${NUM_END})*)`, "g");
const ARTICLE_RE = /\bArticles?\s+((?:[IVXLCDM]+|\d+)(?:\s*(?:,|and|or|through|to)\s*(?:[IVXLCDM]+|\d+))*)\b/g;
const ATTACH_RE = new RegExp(String.raw`\b(Exhibit|Schedule|Annex|Appendix)(?:es|s)?\s+((?:[A-Z](?:-\d+)?|\d+(?:\.\d+)*)(?:\s*(?:,|and|or|through|to)\s*(?:[A-Z](?:-\d+)?|\d+(?:\.\d+)*))*)\b`, "g");

/** After the reference: "of the Securities Act", "of the Code" and similar point at another document. */
function pointsElsewhere(after: string): boolean {
  const m = /^\s*(?:\([a-zA-Z0-9]{1,4}\))*\s*,?\s*(?:of|in|under)\s+(?!this\s)(?:the\s+)?([A-Z][\w&.-]*)/.exec(after);
  if (!m) return false;
  return true;
}

function direction(after: string): "above" | "below" | null {
  const m = /^(?:\s*\([^)]{0,30}\))?\s*(above|below)\b/i.exec(after);
  return m ? (m[1].toLowerCase() as "above" | "below") : null;
}

interface Token { raw: string; start: number; end: number }

function tokens(list: string, offset: number, tokenRe: RegExp): Token[] {
  const out: Token[] = [];
  let m: RegExpExecArray | null;
  const re = new RegExp(tokenRe.source, "g");
  while ((m = re.exec(list))) out.push({ raw: m[0], start: offset + m.index, end: offset + m.index + m[0].length });
  return out;
}

export interface XrefFinding extends Omit<Finding, "id"> {}

export function checkReferences(paragraphs: Paragraph[], reg: Registry = buildRegistry(paragraphs)): XrefFinding[] {
  const out: XrefFinding[] = [];
  const haveNumbering = reg.sections.size > 0;
  const haveArticles = reg.articles.size > 0;
  const families = new Set([...reg.attachments.keys()].map((k) => k.split(":")[0]));

  paragraphs.forEach((p, i) => {
    if (p.headingLevel) return;
    const text = normalizeQuotes(p.text);
    const here = reg.paths[i] ?? "";

    // Sections and clauses
    if (haveNumbering) {
      SECTION_RE.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = SECTION_RE.exec(text))) {
        const listStart = m.index + m[0].length - m[1].length;
        const after = text.slice(m.index + m[0].length);
        if (pointsElsewhere(after)) continue;
        const toks = tokens(m[1], listStart, new RegExp(NUM));
        const dir = toks.length === 1 ? direction(after) : null;
        for (const [n, t] of toks.entries()) {
          // "Section 4.2 and 30 days": a bare integer after "and" followed by a unit is a number, not a section.
          if (n > 0 && /^\d+$/.test(t.raw) && /^\s*(?:days?|months?|years?|hours?|business|calendar|percent|%|dollars?|times)\b/i.test(text.slice(t.end))) continue;
          const target = resolveSection(reg, t.raw);
          if (target === undefined) {
            out.push({
              kind: "broken-reference", severity: "error", paragraphIndex: i, start: t.start, end: t.end, quote: p.text.slice(t.start, t.end),
              message: `Section ${t.raw} is referred to here, but nothing in the document is numbered ${t.raw}.`,
            });
          } else if (dir && !(here && (here === t.raw || here.startsWith(t.raw + ".") || here.startsWith(t.raw + "(")))) {
            const wrong = (dir === "above" && target > i) || (dir === "below" && target < i);
            if (wrong) {
              out.push({
                kind: "reference-direction", severity: "warning", paragraphIndex: i, start: t.start, end: t.end,
                quote: p.text.slice(t.start, t.end),
                message: `This says Section ${t.raw} is ${dir}, but Section ${t.raw} is actually ${dir === "above" ? "below" : "above"} this paragraph.`,
              });
            }
          }
        }
      }
    }

    // Articles
    if (haveArticles) {
      ARTICLE_RE.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = ARTICLE_RE.exec(text))) {
        const listStart = m.index + m[0].length - m[1].length;
        const after = text.slice(m.index + m[0].length);
        if (pointsElsewhere(after)) continue;
        const toks = tokens(m[1], listStart, /[IVXLCDM]+|\d+/);
        const dir = toks.length === 1 ? direction(after) : null;
        for (const t of toks) {
          const target = reg.articles.get(articleKey(t.raw));
          if (target === undefined) {
            out.push({
              kind: "broken-reference", severity: "error", paragraphIndex: i, start: t.start, end: t.end, quote: p.text.slice(t.start, t.end),
              message: `Article ${t.raw} is referred to here, but the document has no Article ${t.raw}.`,
            });
          } else if (dir && target !== i) {
            const wrong = (dir === "above" && target > i) || (dir === "below" && target < i);
            if (wrong) {
              out.push({
                kind: "reference-direction", severity: "warning", paragraphIndex: i, start: t.start, end: t.end, quote: p.text.slice(t.start, t.end),
                message: `This says Article ${t.raw} is ${dir}, but Article ${t.raw} is actually ${dir === "above" ? "below" : "above"} this paragraph.`,
              });
            }
          }
        }
      }
    }

    // Exhibits, schedules, annexes, appendices: only checked for a family the document itself lists.
    ATTACH_RE.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = ATTACH_RE.exec(text))) {
      const family = m[1].toLowerCase();
      if (!families.has(family)) continue;
      if (pointsElsewhere(text.slice(m.index + m[0].length))) continue;
      const listStart = m.index + m[0].length - m[2].length;
      for (const t of tokens(m[2], listStart, /[A-Z](?:-\d+)?|\d+(?:\.\d+)*/)) {
        if (!/^[A-Z0-9]/.test(t.raw)) continue;
        if (!reg.attachments.has(attachmentKey(family, t.raw))) {
          out.push({
            kind: "broken-reference", severity: "error", paragraphIndex: i, start: t.start, end: t.end, quote: p.text.slice(t.start, t.end),
            message: `${m[1]} ${t.raw} is referred to here, but the document lists no ${m[1]} ${t.raw}.`,
          });
        }
      }
    }
  });
  return out;
}
