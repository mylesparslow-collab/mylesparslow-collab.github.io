/** Same length as the input, so character offsets stay valid: curly quotes become straight, nbsp becomes a space. */
export function normalizeQuotes(s: string): string {
  return s
    .replace(/[“”„‟«»]/g, '"')
    .replace(/[‘’‚‛]/g, "'")
    .replace(/ /g, " ");
}

export function keyOf(term: string): string {
  return term.toLowerCase().replace(/\s+/g, " ").trim();
}

export function normBody(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

/** Singular and plural spellings of a defined term (lower case). */
export function forms(term: string): string[] {
  const t = keyOf(term);
  const out = new Set<string>([t]);
  const words = t.split(" ");
  const last = words[words.length - 1];
  const head = words.slice(0, -1).join(" ");
  const join = (w: string) => (head ? head + " " + w : w);
  if (last.endsWith("ies") && last.length > 4) out.add(join(last.slice(0, -3) + "y"));
  else if (last.endsWith("sses")) out.add(join(last.slice(0, -2)));
  else if (last.endsWith("s") && !last.endsWith("ss") && last.length > 3) out.add(join(last.slice(0, -1)));
  if (last.endsWith("y") && !/[aeiou]y$/.test(last)) out.add(join(last.slice(0, -1) + "ies"));
  else if (/(s|x|z|ch|sh)$/.test(last)) out.add(join(last + "es"));
  else out.add(join(last + "s"));
  return [...out];
}

export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Ranges of text sitting between straight double quotes (already normalised). */
export function quotedRanges(text: string): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  const re = /"[^"\n]{1,80}"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) out.push([m.index, m.index + m[0].length]);
  return out;
}

export function inRanges(pos: number, ranges: Array<[number, number]>): boolean {
  return ranges.some(([a, b]) => pos >= a && pos < b);
}
