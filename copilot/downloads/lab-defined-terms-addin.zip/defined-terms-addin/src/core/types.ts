/** One paragraph of the document, in order. Numbering label is kept apart from the text, as Word keeps it. */
export interface Paragraph {
  text: string;
  /** Numbering label as Word shows it, e.g. "4.2", "(b)", "ARTICLE IX". Absent for unnumbered paragraphs. */
  label?: string;
  /** 1 to 9 when the paragraph is a heading. */
  headingLevel?: number;
}

export type FindingKind =
  | "undefined-term"
  | "unused-definition"
  | "duplicate-definition"
  | "used-before-definition"
  | "inconsistent-capitalisation"
  | "broken-reference"
  | "reference-direction";

export type Severity = "error" | "warning" | "info";

export interface Finding {
  /** Stable for a given document text: code-paragraph-start. */
  id: string;
  kind: FindingKind;
  severity: Severity;
  paragraphIndex: number;
  /** Character range inside paragraph.text (end exclusive). */
  start: number;
  end: number;
  /** Exact text of the range. */
  quote: string;
  /** Plain-words message. */
  message: string;
  /** Only for inconsistent-capitalisation: the text the range should read. */
  suggestion?: string;
}

export type DefinitionStyle = "means" | "inline" | "pointer" | "listed";

export interface Definition {
  term: string;
  key: string;
  style: DefinitionStyle;
  paragraphIndex: number;
  /** Range of the quoted term (without the quotes). */
  start: number;
  end: number;
  /** Normalised wording used to compare two definitions of the same term. */
  body: string;
  inDefinitionsSection: boolean;
}
