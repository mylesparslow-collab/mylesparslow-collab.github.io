/**
 * Words that look like defined terms when capitalised mid-sentence but are not.
 * A candidate phrase is skipped when ANY of its words is in this list. Kept deliberately broad:
 * a missed undefined term costs less than a false alarm on an ordinary name.
 */
const words = (s: string) => s.split(/\s+/).filter(Boolean);

export const MONTHS = new Set(words("January February March April May June July August September October November December"));
export const DAYS = new Set(words("Monday Tuesday Wednesday Thursday Friday Saturday Sunday"));

export const US_STATES = new Set(words(`Alabama Alaska Arizona Arkansas California Colorado Connecticut Delaware Florida Georgia
  Hawaii Idaho Illinois Indiana Iowa Kansas Kentucky Louisiana Maine Maryland Massachusetts Michigan Minnesota Mississippi
  Missouri Montana Nebraska Nevada Ohio Oklahoma Oregon Pennsylvania Tennessee Texas Utah Vermont Virginia Washington
  Wisconsin Wyoming Columbia Dakota Hampshire Jersey Mexico Carolina Island Rhode York`));

export const PLACES = new Set(words(`United State States America American Canada Canadian England English London Kingdom Europe European
  Asia Africa Mexico China France Germany Japan India Ireland Scotland Wales Philadelphia Chicago Boston Houston Dallas Denver
  Seattle Atlanta Angeles Francisco Diego Miami Phoenix Portland County City Town Village Township Federal`));

export const TITLES = new Set(words(`Mr Ms Mrs Dr Esq President Vice Chair Chairman Chairperson Chief Officer Director Directors
  Secretary Treasurer Executive Board Partner Associate Counsel Attorney Judge Justice Honorable Senior Managing Principal Trustee`));

export const ENTITY_WORDS = new Set(words(`Inc Corp Corporation LLC LLP LP Ltd Co Incorporated Limited Partnership Trust Bank
  Foundation Association University College Institute Group Holdings`));

/** Statutes, courts and agencies: proper names that are not defined in the contract. */
export const LEGAL_PROPER = new Set(words(`Act Acts Code Rules Regulations Regulation Constitution Court Courts Commission
  Department Bureau Agency Congress Senate Legislature Supreme Circuit District Bankruptcy Securities Exchange Internal Revenue
  Uniform Commercial Civil Procedure Evidence Treasury Register Gazette Restatement Amendment`));

/** Words in every contract that need no definition (or whose definition is the document itself). */
export const UBIQUITOUS = new Set(words(`Agreement Section Sections Article Articles Exhibit Exhibits Schedule Schedules Annex
  Appendix Appendices Recitals Whereas Now Therefore Witness Notice Notices Party Parties Clause Clauses Paragraph Preamble
  Signature Page Pages Attachment Attachments Addendum Table Contents`));

/** Ordinary words that are capitalised as the first word of a heading-like fragment or by habit. */
export const COMMON = new Set(words(`The This That These Those Such Any Each Every All No Not If In On At To For Of By With
  Without From Upon Unless Except Subject Provided Notwithstanding Pursuant Whether Either Neither Both And Or But As Per Via
  Hereby Herein Hereof Thereof Therein Thereto Hereto Hereunder Thereunder Yes Re Attn Attention Dear Sincerely`));

export const STOP_WORDS = new Set<string>([
  ...MONTHS, ...DAYS, ...US_STATES, ...PLACES, ...TITLES, ...ENTITY_WORDS, ...LEGAL_PROPER, ...UBIQUITOUS, ...COMMON,
]);

/** Determiners that normally lead a use of a defined term: "the Purchase Price", "each Party", "such Losses". */
export const DETERMINERS = new Set(words("the such each any said all no both either neither its their this that these those every"));

/** Single words too common in lower case to be flagged as a capitalisation slip. */
export const AMBIGUOUS_LOWER = new Set(words(`term terms party parties law laws day days month months year years person persons
  business control notice notices date time rent price fee fees cause event events work works use party's`));
