import type { Definition, Paragraph } from "./types.ts";
import { keyOf, normBody, normalizeQuotes } from "./text.ts";

const TERM = String.raw`"([A-Z0-9][^"\n]{0,70}?)"`;

/** Paragraph indexes that sit inside a "Definitions" section (heading text, or the heading's own numbered label). */
export function definitionsSectionMap(paragraphs: Paragraph[]): boolean[] {
  const flags = new Array<boolean>(paragraphs.length).fill(false);
  let level = 0;
  paragraphs.forEach((p, i) => {
    if (p.headingLevel) {
      if (level && p.headingLevel <= level) level = 0;
      if (!level && /\bdefinitions?\b|\binterpretation\b/i.test(p.text) && p.text.length < 80) level = p.headingLevel;
    }
    flags[i] = level > 0;
  });
  return flags;
}

const ALLOWED = new Set(
  "the this these such a an each collectively together individually jointly either both and or hereinafter herein referred to as also sometimes called defined".split(" "),
);

/** True when the words before a quoted term inside a parenthesis say "this is what we call it". */
function isDefiningPrefix(prefix: string): boolean {
  const tokens = prefix.toLowerCase().split(/[\s,]+/).filter(Boolean);
  let k = tokens.length;
  while (k > 0 && ALLOWED.has(tokens[k - 1])) k--;
  if (k === 0) return true;
  if (k > 14) return false;
  // Something precedes the allowed words: only fine when a comma separates them ("together with its Affiliates, the").
  return /,\s*(?:(?:the|this|these|such|a|an|each|collectively|together|individually|jointly|either|both|and|or|hereinafter|herein|referred to as|as|also|sometimes|called|defined)\b[\s,]*)*$/i.test(prefix);
}

function sentenceBody(norm: string, from: number): string {
  let rest = norm.slice(from);
  const cut = rest.search(/;|\.(?=\s|$)/);
  if (cut >= 0) rest = rest.slice(0, cut);
  return normBody(rest.slice(0, 240));
}

export function findDefinitions(paragraphs: Paragraph[]): Definition[] {
  const defsSection = definitionsSectionMap(paragraphs);
  const out: Definition[] = [];
  const seen = new Set<string>();
  const push = (d: Definition) => {
    const k = `${d.paragraphIndex}:${d.start}`;
    if (!seen.has(k)) {
      seen.add(k);
      out.push(d);
    }
  };

  paragraphs.forEach((p, i) => {
    if (p.headingLevel) return;
    const norm = normalizeQuotes(p.text);
    const inDefs = defsSection[i];

    // 1. "Term" means / shall mean / has the meaning ...
    const means = new RegExp(
      String.raw`${TERM}(?:\s+(?:of|to|in|under)\s+[^"\n]{1,40}?)?,?\s+(?:shall\s+mean|means|mean|shall\s+have\s+the\s+meanings?|has\s+the\s+meaning|have\s+the\s+meanings?|is\s+defined|are\s+defined|shall\s+refer\s+to|refers\s+to)\b`,
      "g",
    );
    let m: RegExpExecArray | null;
    while ((m = means.exec(norm))) {
      // The quote must open a clause: paragraph start, or after ; : . or "and"/"or" separators.
      const before = norm.slice(0, m.index).trimEnd();
      if (before && !/[;:.,]$/.test(before) && !/\b(?:and|or)$/.test(before)) continue;
      const term = m[1].trim();
      const tail = norm.slice(m.index + m[0].length, m.index + m[0].length + 60);
      const style = /meaning/i.test(m[0]) && /^\s*(?:given|set\s+forth|ascribed|assigned|specified|in\s+(?:Section|Article|the\s+preamble|this))/i.test(tail) ? "pointer" : "means";
      const start = m.index + 1;
      push({
        term, key: keyOf(term), style,
        paragraphIndex: i, start, end: start + m[1].length,
        body: sentenceBody(norm, m.index + m[0].length), inDefinitionsSection: inDefs,
      });
    }

    // 2. Inside a Definitions section a paragraph that opens with a quoted term is a definition, whatever the verb.
    if (inDefs) {
      const lead = new RegExp(String.raw`^\s*${TERM}`).exec(norm);
      if (lead) {
        const start = lead.index + lead[0].indexOf('"') + 1;
        push({
          term: lead[1].trim(), key: keyOf(lead[1]), style: "listed",
          paragraphIndex: i, start, end: start + lead[1].length,
          body: sentenceBody(norm, lead[0].length), inDefinitionsSection: true,
        });
      }
    }

    // 3. Inline: (the "Term"), (each, a "Term"), (collectively, the "Terms"), (hereinafter "Term")
    const paren = /\(([^()\n]{0,160})\)/g;
    while ((m = paren.exec(norm))) {
      const inner = m[1];
      // Every quoted term in the parenthesis, as long as each one is introduced by defining words.
      const qre = new RegExp(TERM, "g");
      let q: RegExpExecArray | null;
      let prevEnd = 0;
      while ((q = qre.exec(inner))) {
        if (!isDefiningPrefix(inner.slice(prevEnd, q.index))) break;
        prevEnd = q.index + q[0].length;
        const start = m.index + 1 + q.index + 1;
        const pre = norm.slice(Math.max(0, m.index - 90), m.index);
        push({
          term: q[1].trim(), key: keyOf(q[1]), style: "inline",
          paragraphIndex: i, start, end: start + q[1].length,
          body: normBody(pre), inDefinitionsSection: inDefs,
        });
      }
    }
  });

  return out.sort((a, b) => a.paragraphIndex - b.paragraphIndex || a.start - b.start);
}
