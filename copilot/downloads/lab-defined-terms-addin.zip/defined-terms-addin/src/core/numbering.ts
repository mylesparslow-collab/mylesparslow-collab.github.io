import type { Paragraph } from "./types.ts";

export interface Registry {
  /** "4.2", "4.2(b)", "4.2(b)(ii)" to the first paragraph that carries it. */
  sections: Map<string, number>;
  /** "IX" or "9" to first paragraph. */
  articles: Map<string, number>;
  /** "exhibit:C", "schedule:2.1" to first paragraph. */
  attachments: Map<string, number>;
  /** Full numbering path of each paragraph ("" when unnumbered). */
  paths: string[];
}

const ROMAN = /^(?:i{1,3}|iv|v|vi{1,3}|ix|x{1,3})$/;
const ATTACH = "Exhibit|Schedule|Annex|Appendix";

function nextLetter(l: string | undefined): string {
  return l ? String.fromCharCode(l.charCodeAt(0) + 1) : "a";
}

/** Strip the dressing Word puts around a label: "1." to "1", "a)" to "(a)", "Section 1.01" to "1.01". */
export function cleanLabel(raw: string): string {
  let l = raw.trim();
  l = l.replace(/^(?:Section|Sec\.|§)\s*/i, "");
  const paren = /^\(?([a-zA-Z]{1,4}|\d{1,2})\)$|^\(([a-zA-Z]{1,4}|\d{1,2})\)?$/.exec(l);
  if (paren) return `(${(paren[1] ?? paren[2]).toLowerCase()})`;
  const lone = /^([a-z])[.)]$/.exec(l);
  if (lone) return `(${lone[1]})`;
  return l.replace(/\.$/, "");
}

/** "IX" and "9" are the same article. */
export function articleKey(raw: string): string {
  const u = raw.toUpperCase();
  if (!/^[IVXLCDM]+$/.test(u)) return u;
  const v: Record<string, number> = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let n = 0;
  for (let i = 0; i < u.length; i++) n += v[u[i]] < (v[u[i + 1]] ?? 0) ? -v[u[i]] : v[u[i]];
  return String(n);
}

export function attachmentKey(family: string, id: string): string {
  return `${family.toLowerCase()}:${id.toUpperCase()}`;
}

export function buildRegistry(paragraphs: Paragraph[]): Registry {
  const sections = new Map<string, number>();
  const articles = new Map<string, number>();
  const attachments = new Map<string, number>();
  const paths: string[] = [];
  const reg = (m: Map<string, number>, k: string, i: number) => {
    if (!m.has(k)) m.set(k, i);
  };

  let cur = "";
  let letter: string | undefined;
  let lastLetterLabel = "";

  paragraphs.forEach((p, i) => {
    const text = p.text.trim();
    let label = p.label ? cleanLabel(p.label) : "";

    // Typed-in numbers: "4.2 Fees." with no list numbering behind it.
    if (!label) {
      const typed = /^(\d{1,2}(?:\.\d{1,3})+|\d{1,2})\.?\s+[A-Z]/.exec(text);
      if (typed && !p.headingLevel) label = typed[1];
    }

    // Articles: label or heading text "ARTICLE IX" / "Article 9".
    const art = /^(?:ARTICLE|Article)\s+([IVXLCDM]+|\d+)\b/.exec(label || text);
    if (art && (p.headingLevel || p.label)) reg(articles, articleKey(art[1]), i);

    // Exhibits and schedules: headings, or index entries like "Exhibit A - Statement of Work".
    const att = new RegExp(String.raw`^(${ATTACH})\s+([A-Z](?:-\d+)?|\d+(?:\.\d+)*)\s*(?:$|[-–—:]\s*\S|\.\s+\S)`, "i").exec(text);
    if (att && att[2] === att[2].toUpperCase()) reg(attachments, attachmentKey(att[1], att[2]), i);

    if (label) {
      if (/^\d{1,3}(?:\.\d{1,3})*$/.test(label)) {
        cur = label;
        letter = undefined;
        lastLetterLabel = "";
        const parts = label.split(".");
        for (let n = 1; n <= parts.length; n++) reg(sections, parts.slice(0, n).join("."), i);
        paths[i] = label;
        return;
      }
      const lm = /^\(([a-z]+|\d+)\)$/.exec(label);
      if (lm && cur) {
        const v = lm[1];
        const asLetter = v.length === 1 && v === nextLetter(letter);
        if (asLetter || (!ROMAN.test(v) && /^[a-z]+$/.test(v) && v.length === 1)) {
          letter = v;
          lastLetterLabel = `(${v})`;
            const full = cur + lastLetterLabel;
          reg(sections, full, i);
          paths[i] = full;
          return;
        }
        if (ROMAN.test(v)) {
          const full = cur + lastLetterLabel + `(${v})`;
          reg(sections, full, i);
          paths[i] = full;
          return;
        }
      }
    }
    paths[i] = "";
  });

  return { sections, articles, attachments, paths };
}

/** Does a reference like 4.2(b)(ii) resolve? Falls back for (i) that is a letter or a numeral. */
export function resolveSection(reg: Registry, ref: string): number | undefined {
  const direct = reg.sections.get(ref);
  if (direct !== undefined) return direct;
  const m = /^(.*?)(\([a-z]+\))$/.exec(ref);
  if (m) {
    for (const [k, v] of reg.sections) if (k.startsWith(m[1]) && k.endsWith(m[2])) return v;
  }
  return undefined;
}
