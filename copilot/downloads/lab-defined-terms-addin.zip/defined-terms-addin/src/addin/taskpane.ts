import { DefinedTermsActions, type ScanResult } from "./actions.ts";
import { WordPort } from "./wordPort.ts";

const actions = new DefinedTermsActions(new WordPort());
const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;

const KIND_LABEL: Record<string, string> = {
  "undefined-term": "Used but never defined",
  "unused-definition": "Defined but never used",
  "duplicate-definition": "Defined twice, different wording",
  "used-before-definition": "Used before its definition",
  "inconsistent-capitalisation": "Inconsistent capitalisation",
  "broken-reference": "Reference points to nothing",
  "reference-direction": "Wrong way: above / below",
};

function status(msg: string) {
  $("status").textContent = msg;
}

function render(scan: ScanResult) {
  const list = $("findings");
  list.innerHTML = "";
  if (scan.total === 0) {
    status("No findings. The checks are limited to the seven kinds listed in the help text.");
    return;
  }
  status(`${scan.total} finding(s) in ${scan.paragraphCount} paragraphs.`);
  for (const f of scan.findings) {
    const li = document.createElement("li");
    li.className = `sev-${f.severity}`;
    const kind = document.createElement("div");
    kind.className = "kind";
    kind.textContent = `${KIND_LABEL[f.kind] ?? f.kind} · paragraph ${f.paragraphNumber}`;
    const quote = document.createElement("div");
    quote.className = "quote";
    quote.textContent = f.quote;
    const msg = document.createElement("div");
    msg.textContent = f.message;
    const row = document.createElement("div");
    row.className = "row";
    const mk = (label: string, run: () => Promise<unknown>) => {
      const b = document.createElement("button");
      b.textContent = label;
      b.onclick = async () => {
        const r = (await run()) as { ok: boolean; message?: string; error?: string };
        status(r.ok ? (r.message ?? "Done.") : (r.error ?? "Failed."));
      };
      row.append(b);
    };
    mk("Go to", () => actions.goToFinding({ id: f.id }));
    mk("Comment", () => actions.addCommentForFinding({ id: f.id }));
    if (f.suggestion) {
      mk("Fix (tracked)", async () => {
        const r = await actions.fixCapitalisation({ id: f.id });
        if (r.ok) render(await actions.scanDocument());
        return r;
      });
    }
    li.append(kind, quote, msg, row);
    list.append(li);
  }
}

Office.onReady(() => {
  $("scan").onclick = async () => {
    status("Scanning…");
    render(await actions.scanDocument());
  };
  $("markAll").onclick = async () => {
    const r = await actions.markAllFindings({});
    status(r.ok ? (r.message ?? "Done.") : (r.error ?? "Failed."));
  };
  $("clear").onclick = async () => {
    const r = await actions.clearAddinComments();
    status(r.message);
  };
});
