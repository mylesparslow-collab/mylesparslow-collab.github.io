import { registerActions } from "./register.ts";

Office.onReady(() => {
  registerActions();
});
