import { DefinedTermsActions } from "./actions.ts";
import { WordPort } from "./wordPort.ts";

/** The ids here must equal manifest extensions.runtimes.actions[].id and plugin functions[].name exactly. */
export const ACTION_IDS = [
  "scanDocument",
  "goToFinding",
  "addCommentForFinding",
  "markAllFindings",
  "fixCapitalisation",
  "clearAddinComments",
] as const;

/**
 * Agent actions receive one string: JSON of the parameters the model filled in. They return a string.
 * (https://learn.microsoft.com/microsoft-365/copilot/extensibility/plugin-manifest-2.4 and the
 * archived "Add a Copilot agent to an add-in" article; see README.)
 */
/** What Office hands an agent action (a JSON string) in, and what goes back (a JSON string). No Office code here. */
export async function dispatch(actions: DefinedTermsActions, id: (typeof ACTION_IDS)[number], message?: string): Promise<string> {
  let args: Record<string, unknown> = {};
  try {
    if (message) args = JSON.parse(message);
  } catch {
    return JSON.stringify({ ok: false, error: "The parameters were not valid JSON." });
  }
  const fn = actions[id] as (a?: unknown) => Promise<unknown>;
  return JSON.stringify(await fn.call(actions, args));
}

export function registerActions(actions: DefinedTermsActions = new DefinedTermsActions(new WordPort())) {
  for (const id of ACTION_IDS) Office.actions.associate(id, (message?: string) => dispatch(actions, id, message));
  return actions;
}
