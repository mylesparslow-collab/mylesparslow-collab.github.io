import type { Paragraph } from "../core/types.ts";

/** Where to act: a paragraph and a character range inside it. `text` lets the port check it still reads the same. */
export interface RangeRef {
  paragraphIndex: number;
  start: number;
  end: number;
  text: string;
}

export interface CommentInfo {
  id: string;
  content: string;
  anchorText: string;
}

/**
 * The only door between the action logic and the document. Two implementations:
 * WordPort (Office.js, real Word) and FakePort (in memory, for tests and the demo).
 */
export interface DocumentPort {
  readParagraphs(): Promise<Paragraph[]>;
  /** Scroll to and select the range. Throws if the text there no longer matches `range.text`. */
  select(range: RangeRef): Promise<void>;
  /** Anchor a Word comment on the range. Returns the comment id. */
  addComment(range: RangeRef, content: string): Promise<string>;
  listComments(): Promise<CommentInfo[]>;
  deleteComment(id: string): Promise<void>;
  /** Ids of the comments this add-in created, kept inside the document (not just in memory). */
  readOwnCommentIds(): Promise<string[]>;
  writeOwnCommentIds(ids: string[]): Promise<void>;
  /** Replace the range's text as a tracked change (track changes on for this edit only, then restored). */
  replaceTracked(range: RangeRef, newText: string): Promise<void>;
}
