import { analyze } from "../core/engine.ts";
import type { Finding, FindingKind } from "../core/types.ts";
import type { DocumentPort, RangeRef } from "./port.ts";

export const COMMENT_PREFIX = "[Defined Terms] ";

export interface ScanResult {
  ok: true;
  paragraphCount: number;
  total: number;
  byKind: Partial<Record<FindingKind, number>>;
  findings: Array<Finding & { paragraphNumber: number }>;
  note: string;
}
export interface ActionError { ok: false; error: string }
export interface ActionDone { ok: true; message: string; [k: string]: unknown }

const ALL_KINDS: FindingKind[] = [
  "undefined-term", "unused-definition", "duplicate-definition", "used-before-definition",
  "inconsistent-capitalisation", "broken-reference", "reference-direction",
];

const fail = (error: string): ActionError => ({ ok: false, error });
const refTag = (id: string) => `(ref ${id})`;

/**
 * The six actions the Copilot agent (and the task pane) can call. They hold no Office code:
 * everything that touches the document goes through the DocumentPort.
 */
export class DefinedTermsActions {
  /** Findings as the caller last saw them in scanDocument, so an old id can be traced to what it meant. */
  private known = new Map<string, Finding>();

  constructor(private port: DocumentPort) {}

  private toRange(f: Finding): RangeRef {
    return { paragraphIndex: f.paragraphIndex, start: f.start, end: f.end, text: f.quote };
  }

  private async freshScan() {
    const paragraphs = await this.port.readParagraphs();
    return { paragraphs, findings: analyze(paragraphs).findings };
  }

  /**
   * Every write goes through here: rescan the document as it reads now and return the matching finding from
   * that scan. A finding matches by kind + quoted text + paragraph (ids can shift when text moves), so a
   * finding the user has since resolved is refused rather than acted on.
   */
  private async lookup(id: unknown): Promise<Finding | ActionError> {
    if (typeof id !== "string" || !id) return fail("An id is required, for example UND-10-115. Run scanDocument to get the ids.");
    const { findings } = await this.freshScan();
    const ref = this.known.get(id) ?? findings.find((f) => f.id === id);
    if (!ref) return fail(`No finding ${id} in the document as it reads now. Run scanDocument again and use an id from the new list.`);
    const same = findings.filter((f) => f.kind === ref.kind && f.quote === ref.quote && f.paragraphIndex === ref.paragraphIndex);
    const hit = same.find((f) => f.id === id) ?? same[0];
    return hit ?? fail(`Finding ${id} (${ref.kind}, "${ref.quote}", paragraph ${ref.paragraphIndex + 1}) is already resolved: it no longer appears in the document as it reads now. Nothing was changed.`);
  }

  async scanDocument(): Promise<ScanResult> {
    const { paragraphs, findings } = await this.freshScan();
    this.known = new Map(findings.map((f) => [f.id, f]));
    const byKind: ScanResult["byKind"] = {};
    for (const f of findings) byKind[f.kind] = (byKind[f.kind] ?? 0) + 1;
    return {
      ok: true,
      paragraphCount: paragraphs.length,
      total: findings.length,
      byKind,
      findings: findings.map((f) => ({ ...f, paragraphNumber: f.paragraphIndex + 1 })),
      note: "Findings come from fixed rules, not from a model. They are candidates for an attorney to review, not conclusions.",
    };
  }

  async goToFinding(args: { id?: string } = {}): Promise<ActionDone | ActionError> {
    const f = await this.lookup(args.id);
    if ("ok" in f) return f;
    try {
      await this.port.select(this.toRange(f));
    } catch (e) {
      return fail((e as Error).message);
    }
    return { ok: true, message: `Selected "${f.quote}" in paragraph ${f.paragraphIndex + 1}.`, id: f.id };
  }

  private async comment(f: Finding): Promise<"added" | "exists"> {
    const existing = await this.port.listComments();
    if (existing.some((c) => c.content.startsWith(COMMENT_PREFIX) && c.content.includes(refTag(f.id)))) return "exists";
    const commentId = await this.port.addComment(this.toRange(f), `${COMMENT_PREFIX}${f.message} ${refTag(f.id)}`);
    // Remember the id inside the document so clearAddinComments never touches anyone else's comment.
    await this.port.writeOwnCommentIds([...(await this.port.readOwnCommentIds()), commentId]);
    return "added";
  }

  async addCommentForFinding(args: { id?: string } = {}): Promise<ActionDone | ActionError> {
    const f = await this.lookup(args.id);
    if ("ok" in f) return f;
    try {
      const r = await this.comment(f);
      return { ok: true, id: f.id, message: r === "added" ? `Comment added on "${f.quote}".` : `A comment for ${f.id} is already in the document; nothing added.` };
    } catch (e) {
      return fail((e as Error).message);
    }
  }

  async markAllFindings(args: { kinds?: FindingKind[] } = {}): Promise<ActionDone | ActionError> {
    const kinds = Array.isArray(args.kinds) && args.kinds.length ? args.kinds : ALL_KINDS;
    const bad = kinds.filter((k) => !ALL_KINDS.includes(k));
    if (bad.length) return fail(`Unknown kind: ${bad.join(", ")}. Valid kinds: ${ALL_KINDS.join(", ")}.`);
    const scan = await this.scanDocument(); // always against the document as it reads now
    let added = 0;
    let skipped = 0;
    const errors: string[] = [];
    for (const f of scan.findings) {
      if (!kinds.includes(f.kind)) continue;
      try {
        (await this.comment(f)) === "added" ? added++ : skipped++;
      } catch (e) {
        errors.push(`${f.id}: ${(e as Error).message}`);
      }
    }
    return { ok: true, added, alreadyPresent: skipped, failed: errors.length, errors, message: `Added ${added} comment(s); ${skipped} already present; ${errors.length} failed.` };
  }

  async fixCapitalisation(args: { id?: string } = {}): Promise<ActionDone | ActionError> {
    const f = await this.lookup(args.id);
    if ("ok" in f) return f;
    if (f.kind !== "inconsistent-capitalisation" || !f.suggestion) {
      return fail(`${f.id} is a "${f.kind}" finding. Only inconsistent-capitalisation findings can be fixed here; the others need a person to decide.`);
    }
    try {
      await this.port.replaceTracked(this.toRange(f), f.suggestion);
    } catch (e) {
      return fail((e as Error).message);
    }
    await this.scanDocument(); // offsets have moved; ids must be fresh
    return { ok: true, id: f.id, message: `Tracked change made: "${f.quote}" to "${f.suggestion}". Scan again before using other ids.` };
  }

  async clearAddinComments(): Promise<ActionDone> {
    const own = new Set(await this.port.readOwnCommentIds());
    const all = await this.port.listComments();
    let removed = 0;
    for (const c of all) {
      // Both must hold: the id is one this add-in recorded, and the text still carries its prefix.
      if (own.has(c.id) && c.content.startsWith(COMMENT_PREFIX)) {
        await this.port.deleteComment(c.id);
        own.delete(c.id);
        removed++;
      }
    }
    const present = new Set(all.map((c) => c.id));
    await this.port.writeOwnCommentIds([...own].filter((id) => present.has(id))); // drop ids of comments that are gone
    return { ok: true, removed, message: `Removed ${removed} comment(s) written by this add-in. Other comments were not touched.` };
  }
}
