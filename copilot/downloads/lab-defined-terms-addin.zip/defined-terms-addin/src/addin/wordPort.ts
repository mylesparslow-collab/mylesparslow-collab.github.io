/// <reference types="office-js" />
import type { Paragraph } from "../core/types.ts";
import type { CommentInfo, DocumentPort, RangeRef } from "./port.ts";

const OWN_IDS_KEY = "definedTerms.ownCommentIds";

/**
 * DocumentPort for real Word, written against the Office JavaScript library (WordApi 1.4 for comments and
 * tracked changes). NEVER RUN inside Word: it type-checks against @types/office-js and nothing more.
 */
export class WordPort implements DocumentPort {
  async readParagraphs(): Promise<Paragraph[]> {
    return Word.run(async (context) => {
      const paras = context.document.body.paragraphs;
      paras.load("items/text,items/isListItem,items/styleBuiltIn");
      await context.sync();

      const lists = paras.items.map((p) => {
        if (!p.isListItem) return null;
        const li = p.listItemOrNullObject;
        li.load("listString,isNullObject");
        return li;
      });
      await context.sync();

      return paras.items.map((p, i): Paragraph => {
        const out: Paragraph = { text: p.text };
        const li = lists[i];
        if (li && !li.isNullObject && li.listString) out.label = li.listString;
        const h = /^Heading([1-9])$/.exec(String(p.styleBuiltIn));
        if (h) out.headingLevel = Number(h[1]);
        else if (String(p.styleBuiltIn) === "Title") out.headingLevel = 1;
        return out;
      });
    });
  }

  /** Find the Word range for a character range inside paragraph N, by searching for its text. */
  private async locate(context: Word.RequestContext, r: RangeRef): Promise<Word.Range> {
    if (r.text.length > 255) throw new Error("The text to find is longer than Word's 255-character search limit.");
    if (r.text.includes("^")) throw new Error("The text contains a caret, which Word search treats as a special code.");
    const paras = context.document.body.paragraphs;
    paras.load("items/text");
    await context.sync();
    const p = paras.items[r.paragraphIndex];
    if (!p) throw new Error(`No paragraph ${r.paragraphIndex + 1}.`);
    if (p.text.slice(r.start, r.end) !== r.text) {
      throw new Error(`The text in paragraph ${r.paragraphIndex + 1} has changed. Scan again.`);
    }
    // Which occurrence of the text inside the paragraph is ours? Word search does not report offsets.
    let nth = 0;
    for (let pos = p.text.indexOf(r.text); pos >= 0 && pos < r.start; pos = p.text.indexOf(r.text, pos + r.text.length)) nth++;
    const hits = p.search(r.text, { matchCase: true });
    hits.load("items");
    await context.sync();
    const hit = hits.items[nth];
    if (!hit) throw new Error(`Word could not find "${r.text}" in paragraph ${r.paragraphIndex + 1}.`);
    return hit;
  }

  async select(range: RangeRef): Promise<void> {
    await Word.run(async (context) => {
      (await this.locate(context, range)).select();
      await context.sync();
    });
  }

  async addComment(range: RangeRef, content: string): Promise<string> {
    return Word.run(async (context) => {
      const c = (await this.locate(context, range)).insertComment(content);
      c.load("id");
      await context.sync();
      return c.id;
    });
  }

  async listComments(): Promise<CommentInfo[]> {
    return Word.run(async (context) => {
      const cs = context.document.body.getComments();
      cs.load("items/id,items/content");
      await context.sync();
      const ranges = cs.items.map((c) => {
        const r = c.getRange();
        r.load("text");
        return r;
      });
      await context.sync();
      return cs.items.map((c, i) => ({ id: c.id, content: c.content, anchorText: ranges[i].text }));
    });
  }

  async deleteComment(id: string): Promise<void> {
    await Word.run(async (context) => {
      const cs = context.document.body.getComments();
      cs.load("items/id");
      await context.sync();
      cs.items.find((c) => c.id === id)?.delete();
      await context.sync();
    });
  }

  /**
   * The ids of comments this add-in created are stored as a JSON string in the document's add-in settings:
   * `context.document.settings` (Word.SettingCollection, WordApi 1.4) with `getItemOrNullObject(key)` and
   * `add(key, value)` (sets or creates). Settings are saved inside the document file, so the list survives
   * closing and reopening. Unverified in real Word: whether Word.Comment.id stays the same across sessions.
   * If it does not, clearAddinComments finds no match and deletes nothing (it fails safe).
   */
  async readOwnCommentIds(): Promise<string[]> {
    return Word.run(async (context) => {
      const s = context.document.settings.getItemOrNullObject(OWN_IDS_KEY);
      s.load("value");
      await context.sync();
      if (s.isNullObject || typeof s.value !== "string") return [];
      try {
        const v: unknown = JSON.parse(s.value);
        return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
      } catch {
        return [];
      }
    });
  }

  async writeOwnCommentIds(ids: string[]): Promise<void> {
    await Word.run(async (context) => {
      context.document.settings.add(OWN_IDS_KEY, JSON.stringify(ids));
      await context.sync();
    });
  }

  async replaceTracked(range: RangeRef, newText: string): Promise<void> {
    await Word.run(async (context) => {
      const doc = context.document;
      doc.load("changeTrackingMode");
      await context.sync();
      const before = doc.changeTrackingMode;
      const target = await this.locate(context, range);
      doc.changeTrackingMode = Word.ChangeTrackingMode.trackAll;
      try {
        target.insertText(newText, "Replace");
        await context.sync();
      } finally {
        doc.changeTrackingMode = before;
        await context.sync();
      }
    });
  }
}
