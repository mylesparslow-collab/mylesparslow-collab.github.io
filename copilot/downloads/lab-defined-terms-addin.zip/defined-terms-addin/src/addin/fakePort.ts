import type { Paragraph } from "../core/types.ts";
import type { CommentInfo, DocumentPort, RangeRef } from "./port.ts";

export interface Revision {
  paragraphIndex: number;
  start: number;
  deleted: string;
  inserted: string;
}

/** In-memory document. Tracked changes are recorded as revisions and applied to the text ("final" view). */
export class FakePort implements DocumentPort {
  paragraphs: Paragraph[];
  comments: Array<CommentInfo & { paragraphIndex: number; start: number; end: number }> = [];
  revisions: Revision[] = [];
  selection: RangeRef | null = null;
  trackingOn = false;
  /** Stands in for the document-stored registry (Word settings in WordPort). */
  ownCommentIds: string[] = [];
  private nextId = 1;

  constructor(paragraphs: Paragraph[]) {
    this.paragraphs = paragraphs.map((p) => ({ ...p }));
  }

  async readParagraphs(): Promise<Paragraph[]> {
    return this.paragraphs.map((p) => ({ ...p }));
  }

  private check(r: RangeRef) {
    const p = this.paragraphs[r.paragraphIndex];
    if (!p) throw new Error(`No paragraph ${r.paragraphIndex}.`);
    const here = p.text.slice(r.start, r.end);
    if (here !== r.text) throw new Error(`The text at paragraph ${r.paragraphIndex + 1} has changed (expected "${r.text}", found "${here}"). Scan again.`);
  }

  async select(range: RangeRef) {
    this.check(range);
    this.selection = { ...range };
  }

  async addComment(range: RangeRef, content: string) {
    this.check(range);
    const id = `c${this.nextId++}`;
    this.comments.push({ id, content, anchorText: range.text, paragraphIndex: range.paragraphIndex, start: range.start, end: range.end });
    return id;
  }

  async listComments(): Promise<CommentInfo[]> {
    return this.comments.map(({ id, content, anchorText }) => ({ id, content, anchorText }));
  }

  async deleteComment(id: string) {
    const n = this.comments.findIndex((c) => c.id === id);
    if (n < 0) throw new Error(`No comment ${id}.`);
    this.comments.splice(n, 1);
  }

  async readOwnCommentIds() {
    return [...this.ownCommentIds];
  }

  async writeOwnCommentIds(ids: string[]) {
    this.ownCommentIds = [...ids];
  }

  async replaceTracked(range: RangeRef, newText: string) {
    this.check(range);
    const p = this.paragraphs[range.paragraphIndex];
    this.revisions.push({ paragraphIndex: range.paragraphIndex, start: range.start, deleted: range.text, inserted: newText });
    p.text = p.text.slice(0, range.start) + newText + p.text.slice(range.end);
  }
}
