# Defined Terms (agent)

Declarative agent `defined-terms` for the Word add-in in the parent lab. It is packaged in the same app package as the add-in, because an add-in-backed agent is declared in the add-in's own unified manifest (`copilotAgents.declarativeAgents`).

| File (in `appPackage/`) | What it is |
|---|---|
| `manifest.json` | Unified manifest 1.24: the add-in (task pane button, runtimes, six `executeDataFunction` actions) and the pointer to the agent |
| `declarativeAgent.json` | Agent v1.9, name "Defined Terms", six conversation starters, instructions from `instructions.txt` |
| `instructions.txt` | Scan first; table by kind; ask before writing; capitalisation is the only edit; never rewrite or opine; the kit's legal safety rules |
| `plugin.json` | API plugin v2.4, `LocalPlugin` runtime (`Microsoft.Office.Addin`, host `document`), six functions, confirmation on the four that change the document |
| `color.png`, `outline.png` | Copied from the kit's order-reader agent |

The function names, the manifest action ids and the `Office.actions.associate` ids must be identical; a test checks this.

Nothing here has been installed in a tenant or run in Copilot. See the lab README.
