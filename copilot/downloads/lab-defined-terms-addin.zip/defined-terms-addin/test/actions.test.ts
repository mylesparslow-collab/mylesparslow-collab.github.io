import { test } from "node:test";
import assert from "node:assert/strict";
import { DefinedTermsActions, COMMENT_PREFIX } from "../src/addin/actions.ts";
import { FakePort } from "../src/addin/fakePort.ts";
import { ACTION_IDS } from "../src/addin/register.ts";
import { loadFixture } from "./helpers.ts";

const num = (r: unknown, k: string) => (r as Record<string, number>)[k];

const setup = (name = "services-agreement") => {
  const port = new FakePort(loadFixture(name));
  return { port, actions: new DefinedTermsActions(port) };
};

test("scanDocument returns findings JSON with counts by kind and 1-based paragraph numbers", async () => {
  const { actions } = setup();
  const r = await actions.scanDocument();
  assert.equal(r.ok, true);
  assert.equal(r.total, 9);
  assert.equal(r.byKind["broken-reference"], 3);
  assert.equal(r.byKind["undefined-term"], 1);
  assert.ok(r.findings.every((f) => f.paragraphNumber === f.paragraphIndex + 1));
  assert.doesNotThrow(() => JSON.stringify(r));
});

test("scanDocument does not change the document", async () => {
  const { actions, port } = setup();
  await actions.scanDocument();
  assert.equal(port.comments.length, 0);
  assert.equal(port.revisions.length, 0);
});

test("goToFinding selects the range; unknown id is a clear error", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const f = scan.findings.find((x) => x.kind === "undefined-term")!;
  const r = await actions.goToFinding({ id: f.id });
  assert.equal(r.ok, true);
  assert.equal(port.selection?.text, "Deliverables");
  const bad = await actions.goToFinding({ id: "NOPE-1-1" });
  assert.equal(bad.ok, false);
  assert.match((bad as { error: string }).error, /scanDocument again/);
  assert.equal((await actions.goToFinding({})).ok, false);
});

test("goToFinding scans by itself when no scan has run", async () => {
  const { actions, port } = setup();
  const id = (await new DefinedTermsActions(port).scanDocument()).findings[0].id;
  const fresh = new DefinedTermsActions(port);
  assert.equal((await fresh.goToFinding({ id })).ok, true);
});

test("addCommentForFinding anchors a prefixed comment on the exact range, once", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const f = scan.findings.find((x) => x.kind === "broken-reference" && x.quote === "3.4")!;
  const r1 = await actions.addCommentForFinding({ id: f.id });
  assert.equal(r1.ok, true);
  assert.equal(port.comments.length, 1);
  const c = port.comments[0];
  assert.equal(c.anchorText, "3.4");
  assert.ok(c.content.startsWith(COMMENT_PREFIX));
  assert.ok(c.content.includes(f.message));
  assert.ok(c.content.includes(`(ref ${f.id})`));
  assert.equal(port.paragraphs[c.paragraphIndex].text.slice(c.start, c.end), "3.4");
  const again = await actions.addCommentForFinding({ id: f.id });
  assert.equal(again.ok, true);
  assert.match((again as { message: string }).message, /already/);
  assert.equal(port.comments.length, 1);
});

test("markAllFindings comments every finding, is idempotent, and honours a kinds filter", async () => {
  const { actions, port } = setup();
  const only = await actions.markAllFindings({ kinds: ["broken-reference"] });
  assert.equal(num(only, 'added'), 3);
  assert.equal(port.comments.length, 3);
  const all = await actions.markAllFindings({});
  assert.equal(num(all, 'added'), 6);
  assert.equal(num(all, 'alreadyPresent'), 3);
  assert.equal(port.comments.length, 9);
  const third = await actions.markAllFindings();
  assert.equal(num(third, 'added'), 0);
  assert.equal(port.comments.length, 9);
});

test("markAllFindings rejects an unknown kind and writes nothing", async () => {
  const { actions, port } = setup();
  const r = await actions.markAllFindings({ kinds: ["made-up" as never] });
  assert.equal(r.ok, false);
  assert.equal(port.comments.length, 0);
});

test("fixCapitalisation makes a tracked change, and only on capitalisation findings", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const cap = scan.findings.find((x) => x.kind === "inconsistent-capitalisation")!;
  const r = await actions.fixCapitalisation({ id: cap.id });
  assert.equal(r.ok, true);
  assert.deepEqual(port.revisions.map((v) => [v.deleted, v.inserted]), [["service fees", "Service Fees"]]);
  assert.ok(port.paragraphs[cap.paragraphIndex].text.includes("pay the Service Fees set out"));
  // The other wording in the paragraph is untouched.
  assert.ok(port.paragraphs[cap.paragraphIndex].text.endsWith("after the Client receives an invoice."));
  const after = await actions.scanDocument();
  assert.equal(after.byKind["inconsistent-capitalisation"], undefined);

  const other = after.findings.find((x) => x.kind === "broken-reference")!;
  const refused = await actions.fixCapitalisation({ id: other.id });
  assert.equal(refused.ok, false);
  assert.match((refused as { error: string }).error, /person to decide/);
  assert.equal(port.revisions.length, 1);
});

test("a stale id after the text moved is refused, not applied to the wrong place", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const cap = scan.findings.find((x) => x.kind === "inconsistent-capitalisation")!;
  port.paragraphs[cap.paragraphIndex].text = "Totally different text now.";
  const r = await actions.fixCapitalisation({ id: cap.id });
  assert.equal(r.ok, false);
  assert.equal(port.revisions.length, 0);
});

test("a range whose text no longer matches is refused by the port itself", async () => {
  const port = new FakePort(loadFixture("lease"));
  await assert.rejects(port.addComment({ paragraphIndex: 4, start: 0, end: 3, text: "zzz" }, "x"), /changed/);
});

test("clearAddinComments removes only comments this add-in wrote", async () => {
  const { actions, port } = setup();
  await actions.markAllFindings({});
  await port.addComment({ paragraphIndex: 1, start: 0, end: 4, text: port.paragraphs[1].text.slice(0, 4) }, "A colleague's own note");
  const before = port.comments.length;
  const r = await actions.clearAddinComments();
  assert.equal(num(r, 'removed'), before - 1);
  assert.deepEqual(port.comments.map((c) => c.content), ["A colleague's own note"]);
  assert.deepEqual(port.ownCommentIds, []);
});

test("a human comment that starts with the add-in prefix survives clearAddinComments", async () => {
  const { actions, port } = setup();
  await actions.markAllFindings({ kinds: ["broken-reference"] });
  const text = port.paragraphs[1].text.slice(0, 4);
  const humanId = await port.addComment({ paragraphIndex: 1, start: 0, end: 4, text }, `${COMMENT_PREFIX}I typed this myself (ref BRK-1-1)`);
  const r = await actions.clearAddinComments();
  assert.equal(num(r, 'removed'), 3);
  assert.deepEqual(port.comments.map((c) => c.id), [humanId]);
});

test("the own-comment registry lives in the port, so a new actions object still clears only its comments", async () => {
  const { actions, port } = setup();
  await actions.markAllFindings({ kinds: ["broken-reference"] });
  await port.addComment({ paragraphIndex: 1, start: 0, end: 4, text: port.paragraphs[1].text.slice(0, 4) }, `${COMMENT_PREFIX}human`);
  const r = await new DefinedTermsActions(port).clearAddinComments();
  assert.equal(num(r, 'removed'), 3);
  assert.equal(port.comments.length, 1);
});

const resolveCap = (port: FakePort, paragraphIndex: number) => {
  port.paragraphs[paragraphIndex].text = port.paragraphs[paragraphIndex].text.replace("service fees", "Service Fees");
};

test("a finding the user has since resolved is refused by comment and fix; nothing is written", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const cap = scan.findings.find((x) => x.kind === "inconsistent-capitalisation")!;
  resolveCap(port, cap.paragraphIndex);
  const c = await actions.addCommentForFinding({ id: cap.id });
  assert.equal(c.ok, false);
  assert.match((c as { error: string }).error, /already resolved/);
  const fx = await actions.fixCapitalisation({ id: cap.id });
  assert.equal(fx.ok, false);
  assert.match((fx as { error: string }).error, /already resolved/);
  assert.equal(port.comments.length, 0);
  assert.equal(port.revisions.length, 0);
});

test("after one finding is resolved, markAllFindings skips it and the others still work", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const cap = scan.findings.find((x) => x.kind === "inconsistent-capitalisation")!;
  const ref = scan.findings.find((x) => x.kind === "broken-reference" && x.quote === "3.4")!;
  resolveCap(port, cap.paragraphIndex);
  assert.equal(num(await actions.markAllFindings({}), 'added'), 8);
  assert.ok(!port.comments.some((c) => c.content.includes(`(ref ${cap.id})`)));
  // an unresolved finding is still actionable by its old id
  assert.equal((await actions.addCommentForFinding({ id: ref.id })).ok, true);
});

test("an old id still works after text moved the finding (matched by kind + quote + paragraph)", async () => {
  const { actions, port } = setup();
  const scan = await actions.scanDocument();
  const ref = scan.findings.find((x) => x.kind === "broken-reference" && x.quote === "3.4")!;
  port.paragraphs[ref.paragraphIndex].text = "Added words. " + port.paragraphs[ref.paragraphIndex].text;
  const r = await actions.addCommentForFinding({ id: ref.id });
  assert.equal(r.ok, true);
  assert.equal(port.comments.length, 1);
  assert.equal(port.comments[0].anchorText, "3.4");
});

test("the six agent actions exist with the registered names", () => {
  const { actions } = setup();
  for (const id of ACTION_IDS) assert.equal(typeof (actions as unknown as Record<string, unknown>)[id], "function", id);
  assert.equal(ACTION_IDS.length, 6);
});

test("clean documents produce no findings through the action layer too", async () => {
  const { actions } = setup("clean-nda");
  const r = await actions.scanDocument();
  assert.equal(r.total, 0);
  assert.equal(num(await actions.markAllFindings({}), 'added'), 0);
});

test("dispatch speaks the agent protocol: JSON string in, JSON string out, bad JSON handled", async () => {
  const { dispatch } = await import("../src/addin/register.ts");
  const { actions } = setup();
  const scan = JSON.parse(await dispatch(actions, "scanDocument"));
  assert.equal(scan.ok, true);
  const id = scan.findings[0].id;
  const go = JSON.parse(await dispatch(actions, "goToFinding", JSON.stringify({ id })));
  assert.equal(go.ok, true);
  const bad = JSON.parse(await dispatch(actions, "goToFinding", "{not json"));
  assert.equal(bad.ok, false);
});
