import { test } from "node:test";
import assert from "node:assert/strict";
import { buildRegistry, cleanLabel } from "../src/core/numbering.ts";
import { parseFixture } from "../src/core/index.ts";

test("cleanLabel", () => {
  assert.equal(cleanLabel("1."), "1");
  assert.equal(cleanLabel("a)"), "(a)");
  assert.equal(cleanLabel("(B)"), "(b)");
  assert.equal(cleanLabel("Section 2.01"), "2.01");
  assert.equal(cleanLabel("4.2"), "4.2");
});

test("(i) after (h) is a letter, (i) after (a) is a roman numeral", () => {
  const ps = parseFixture("[1] x\n[(a)] a\n[(i)] i under a\n[(ii)] ii\n[(b)] b\n[(c)] c\n[(d)] d\n[(e)] e\n[(f)] f\n[(g)] g\n[(h)] h\n[(i)] letter i");
  const reg = buildRegistry(ps);
  assert.ok(reg.sections.has("1(a)(i)"));
  assert.ok(reg.sections.has("1(a)(ii)"));
  assert.ok(reg.sections.has("1(i)"));
  assert.ok(reg.sections.has("1(h)"));
});

test("a deep decimal registers its ancestors", () => {
  const reg = buildRegistry(parseFixture("[4.2.1] x"));
  assert.ok(reg.sections.has("4") && reg.sections.has("4.2") && reg.sections.has("4.2.1"));
});

test("each paragraph knows its own path", () => {
  const reg = buildRegistry(parseFixture("[4] x\n[4.1] y\n[(a)] z\nplain"));
  assert.deepEqual(reg.paths, ["4", "4.1", "4.1(a)", ""]);
});

test("articles and attachments", () => {
  const reg = buildRegistry(parseFixture("# ARTICLE IX - GENERAL\n# Article 4\n# EXHIBIT C-1 - Forms\nSchedule 2.1: Assets\nSchedule 2.2 sets out lists."));
  assert.deepEqual([...reg.articles.keys()], ["9", "4"]);
  assert.deepEqual([...reg.attachments.keys()], ["exhibit:C-1", "schedule:2.1"]);
});
