import { test } from "node:test";
import assert from "node:assert/strict";
import { run } from "./helpers.ts";

/** Ordinary capitalised words must never be reported as undefined terms, however often they repeat. */
const undef = (src: string) => run(src).filter((f) => f.kind === "undefined-term").map((f) => f.quote);

test("months and days", () => {
  assert.deepEqual(undef("[1] Pay in the March payroll and in the March run, on each Friday and each Friday after."), []);
  assert.deepEqual(undef("[1] By the January date and the January cut-off, on the Monday list and the Monday list."), []);
});

test("party names at the start of a sentence, and after a colon or semicolon", () => {
  assert.deepEqual(undef("[1] Larkspur Analytics shall pay. Larkspur Analytics shall pay. Meridian Works agrees: Meridian Works pays; Meridian Works signs."), []);
});

test("party names mid-sentence that are not led by 'the'", () => {
  assert.deepEqual(undef("[1] Payment goes to Larkspur Analytics from Meridian Works, and to Larkspur Analytics again from Meridian Works."), []);
});

test("'Agreement' and friends never need defining", () => {
  assert.deepEqual(undef("[1] Under the Agreement and the Agreement, the Section and the Section, the Exhibit and the Exhibit apply."), []);
});

test("headings are never read for terms", () => {
  assert.deepEqual(undef("# The Purchase Price And The Purchase Price\n[1] x"), []);
  assert.deepEqual(undef("## Payment of the Purchase Price\n## Payment of the Purchase Price\n[1] y"), []);
});

test("places, states, titles, statutes, courts, entity words", () => {
  const text =
    "[1] The State of Delaware, the State of Delaware, the Chief Executive Officer, the Chief Executive Officer, " +
    "the Internal Revenue Code, the Internal Revenue Code, the Supreme Court, the Supreme Court, " +
    "the United States, the United States, the Securities Act, the Securities Act, the Board of Directors, the Board of Directors.";
  assert.deepEqual(undef(text), []);
});

test("a capitalised phrase that CONTAINS a defined term is not 'undefined'", () => {
  assert.deepEqual(undef('[1] "Purchase Price" means money.\n[2] Pay the Adjusted Purchase Price, the Adjusted Purchase Price, and the Purchase Price.'), []);
});

test("a capitalised word that is PART of a longer defined term is not 'undefined'", () => {
  assert.deepEqual(undef('[1] "Change of Control" means a sale.\n[2] On the Change, the Change and the Change of Control.'), []);
});

test("quoted text is never a use", () => {
  assert.deepEqual(undef('[1] The notice must say "the Overdue Amount" or "the Overdue Amount" in capitals.'), []);
});

test("a one-off capitalised word is not reported (threshold of two uses)", () => {
  assert.deepEqual(undef("[1] Deliver the Deliverables on time."), []);
  assert.deepEqual(undef("[1] Deliver the Deliverables on time and keep the Deliverables safe."), ["Deliverables"]);
});

test("the threshold can be changed", () => {
  assert.deepEqual(run("[1] Deliver the Deliverables on time.", { minUndefinedUses: 1 }).map((f) => f.quote), ["Deliverables"]);
});

test("a sentence-initial capitalised word is not enough on its own", () => {
  assert.deepEqual(undef("[1] Deliverables are due. Deliverables are due. Deliverables are due."), []);
});

test("all-capital words and acronyms are ignored", () => {
  assert.deepEqual(undef("[1] The IRS and the IRS, the USD amount and the USD amount, the LLC and the LLC."), []);
});

test("a defined term is not 'undefined', and plural/singular count as the same term", () => {
  assert.deepEqual(undef('[1] The "Party" signs.\n[2] The Parties sign and the Parties agree.'), []);
});

test("sentence-start capitalisation of a defined term is not a capitalisation slip", () => {
  const f = run('[1] "Fee" means money.\n[2] Fee is due. The Fee is due.');
  assert.deepEqual(f.filter((x) => x.kind === "inconsistent-capitalisation"), []);
});

test("all-capital spellings of a defined term (headings, signature blocks) are fine", () => {
  const f = run('[1] "Purchase Price" means money.\n[2] The PURCHASE PRICE is payable; the Purchase Price is final.');
  assert.deepEqual(f.filter((x) => x.kind === "inconsistent-capitalisation"), []);
});

test("common lower-case words are not flagged as a capitalisation slip", () => {
  const f = run('[1] "Term" means five years. "Party" means a signer.\n[2] During the term, each party signs; the parties agree.');
  assert.deepEqual(f.filter((x) => x.kind === "inconsistent-capitalisation"), []);
});

test("a lower-case use inside the term's own definition paragraph is not a slip", () => {
  const f = run('[1] "Services" means the services described in Exhibit A.\n[2] The Services start.');
  assert.deepEqual(f.filter((x) => x.kind === "inconsistent-capitalisation"), []);
});

test("capitalisation slips are caught, with the fix attached", () => {
  const f = run('[1] "Purchase Price" means money.\n[2] The purchase price is due. The Purchase price is due. Two purchase prices apply.').filter((x) => x.kind === "inconsistent-capitalisation");
  assert.deepEqual(f.map((x) => x.quote), ["purchase price", "Purchase price", "purchase prices"]);
  assert.deepEqual(f.map((x) => x.suggestion), ["Purchase Price", "Purchase Price", "Purchase Prices"]);
});

test("single-word term: only 'the/such/each/said + lower-case' is flagged", () => {
  const f = run('[1] "Premises" means the suite.\n[2] The tenant keeps the premises clean. We discuss premises generally.').filter((x) => x.kind === "inconsistent-capitalisation");
  assert.deepEqual(f.map((x) => x.quote), ["premises"]);
});
