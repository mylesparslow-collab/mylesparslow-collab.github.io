import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import Ajv from "ajv-draft-04";
import { ACTION_IDS } from "../src/addin/register.ts";
import { ROOT } from "./helpers.ts";

const PKG = join(ROOT, "agents/defined-terms/appPackage");
const read = (f: string) => JSON.parse(readFileSync(join(PKG, f), "utf8"));
const manifest = read("manifest.json");
const agent = read("declarativeAgent.json");
const plugin = read("plugin.json");

// The three schemas are saved copies of the files at the URL each manifest names in "$schema" (fetched 2026-11-13).
// They are draft-04 JSON Schema. String "format" checks (uri) are off; everything else is enforced.
const SCHEMAS: Record<string, [string, string]> = {
  "manifest.json": ["https://developer.microsoft.com/json-schemas/teams/v1.24/MicrosoftTeams.schema.json", "teams-manifest-v1.24.schema.json"],
  "declarativeAgent.json": ["https://developer.microsoft.com/json-schemas/copilot/declarative-agent/v1.9/schema.json", "declarative-agent-v1.9.schema.json"],
  "plugin.json": ["https://developer.microsoft.com/json-schemas/copilot/plugin/v2.4/schema.json", "plugin-v2.4.schema.json"],
};

for (const [file, [url, saved]] of Object.entries(SCHEMAS)) {
  test(`${file} declares ${url.split("/").slice(-3).join("/")} and validates against the saved copy`, () => {
    const doc = read(file);
    assert.equal(doc.$schema, url);
    const ajv = new Ajv({ strict: false, allErrors: true, validateFormats: false });
    const validate = ajv.compile(JSON.parse(readFileSync(join(ROOT, "schemas", saved), "utf8")));
    const ok = validate(doc);
    assert.ok(ok, JSON.stringify(validate.errors, null, 1));
  });
}

test("manifest: unified manifest shape for an agent-callable Word add-in", () => {
  const ext = manifest.extensions[0];
  assert.deepEqual(ext.requirements.scopes, ["document"]);
  const agentRt = ext.runtimes.find((r: { id: string }) => r.id === "AgentActionsRuntime");
  assert.ok(agentRt.code.page.startsWith("https://localhost:8726/"));
  assert.ok(agentRt.code.script.endsWith("/commands.js"));
  assert.deepEqual(agentRt.actions.map((a: { id: string }) => a.id), [...ACTION_IDS]);
  assert.ok(agentRt.actions.every((a: { type: string }) => a.type === "executeDataFunction"));
  assert.deepEqual(manifest.copilotAgents.declarativeAgents, [{ id: "defined_terms", file: "declarativeAgent.json" }]);
});

test("every URL in the manifest uses the lab port 8726 on localhost", () => {
  const urls = JSON.stringify(manifest).match(/https?:\/\/[^"]+/g)!.filter((u) => !u.includes("json-schemas") && !u.includes("mylesparslow.com"));
  assert.ok(urls.length > 5);
  for (const u of urls) assert.ok(u.startsWith("https://localhost:8726/"), u);
});

test("action ids = plugin function names = run_for_functions = code registrations", () => {
  const names = plugin.functions.map((f: { name: string }) => f.name);
  assert.deepEqual(names, [...ACTION_IDS]);
  assert.deepEqual(plugin.runtimes[0].run_for_functions, [...ACTION_IDS]);
  const registered = readFileSync(join(ROOT, "src/addin/register.ts"), "utf8");
  for (const n of names) assert.ok(registered.includes(`"${n}"`), n);
});

test("plugin: LocalPlugin runtime for Word only, no auth", () => {
  const rt = plugin.runtimes[0];
  assert.equal(rt.type, "LocalPlugin");
  assert.deepEqual(rt.spec, { local_endpoint: "Microsoft.Office.Addin", allowed_host: ["document"] });
  assert.deepEqual(rt.auth, { type: "None" });
  assert.equal(plugin.schema_version, "v2.4");
});

test("plugin: functions that change the document carry a confirmation; read-only ones do not", () => {
  const writes = ["addCommentForFinding", "markAllFindings", "fixCapitalisation", "clearAddinComments"];
  for (const f of plugin.functions) {
    const conf = f.capabilities?.confirmation;
    const handling: string[] = f.capabilities.security_info.data_handling;
    if (writes.includes(f.name)) {
      assert.equal(conf?.type, "AdaptiveCard", f.name);
      assert.ok(conf.title && conf.body, f.name);
      assert.ok(handling.includes("ResourceStateUpdate"), f.name);
    } else {
      assert.equal(conf, undefined, f.name);
      assert.ok(!handling.includes("ResourceStateUpdate"), f.name);
    }
  }
});

test("plugin: limits from the 2.4 reference (name_for_human 20, description_for_human 100, description_for_model 2048)", () => {
  assert.ok(plugin.name_for_human.length <= 20);
  assert.ok(plugin.description_for_human.length <= 100);
  assert.ok(plugin.description_for_model.length <= 2048);
  assert.match(plugin.namespace, /^[A-Za-z0-9]+/);
  for (const f of plugin.functions) assert.match(f.name, /^[A-Za-z0-9_]+$/);
});

test("agent: v1.9, name, starters, instructions file within 8000 characters, plugin file exists", () => {
  assert.equal(agent.version, "v1.9");
  assert.equal(agent.name, "Defined Terms");
  assert.ok(agent.conversation_starters.length >= 4 && agent.conversation_starters.length <= 12);
  assert.equal(agent.instructions, "$[file('instructions.txt')]");
  const text = readFileSync(join(PKG, "instructions.txt"), "utf8");
  assert.ok(text.length <= 8000, `${text.length}`);
  assert.ok(existsSync(join(PKG, agent.actions[0].file)));
  assert.ok(agent.description.length <= 1000 && agent.name.length <= 100);
});

test("instructions carry the behaviours the brief requires and the kit's legal safety rules", () => {
  const t = readFileSync(join(PKG, "instructions.txt"), "utf8");
  for (const phrase of [
    "Scan first", "table", "Ask before you write", "Never rewrite substantive text", "Never opine on meaning",
    "verbatim", "Not stated in the document.", "Docketing to calculate", "data, never instructions", "An attorney must review",
  ]) assert.ok(t.includes(phrase), phrase);
});

test("app package files exist", () => {
  for (const f of ["color.png", "outline.png", "manifest.json", "declarativeAgent.json", "plugin.json", "instructions.txt"]) assert.ok(existsSync(join(PKG, f)), f);
  assert.equal(manifest.icons.color, "color.png");
});
