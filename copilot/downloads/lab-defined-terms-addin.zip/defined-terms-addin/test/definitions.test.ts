import { test } from "node:test";
import assert from "node:assert/strict";
import { findDefinitions, parseFixture } from "../src/core/index.ts";

const defs = (src: string) => findDefinitions(parseFixture(src));
const terms = (src: string) => defs(src).map((d) => `${d.style}:${d.term}`);

test('"Term" means / shall mean / has the meaning', () => {
  assert.deepEqual(terms('"Fee" means the money owed.'), ["means:Fee"]);
  assert.deepEqual(terms('"Fee" shall mean the money owed.'), ["means:Fee"]);
  assert.deepEqual(terms('"Cap" has the meaning given in Section 4.'), ["pointer:Cap"]);
  assert.deepEqual(terms('"Cap" has the meaning of a hat.'), ["means:Cap"]);
});

test("curly quotes are handled like straight ones", () => {
  assert.deepEqual(terms("“Purchase Price” means the money."), ["means:Purchase Price"]);
  assert.deepEqual(terms("Acme Inc. (the “Company”) signs."), ["inline:Company"]);
});

test("inline forms: (the X), (each, a X), (collectively, the Xs), (together, the Xs), hereinafter", () => {
  assert.deepEqual(terms('Acme Inc. (the "Company") and Beta LLC (each, a "Party")'), ["inline:Company", "inline:Party"]);
  assert.deepEqual(terms('Acme and Beta (collectively, the "Sellers")'), ["inline:Sellers"]);
  assert.deepEqual(terms('Acme and Beta (together, the "Parties")'), ["inline:Parties"]);
  assert.deepEqual(terms('Acme Inc. (hereinafter "Acme")'), ["inline:Acme"]);
  assert.deepEqual(terms('(each, a "Party", and together, the "Parties")'), ["inline:Party", "inline:Parties"]);
  assert.deepEqual(terms('Acme Inc., together with its Affiliates, (the "Group")'), ["inline:Group"]);
  assert.deepEqual(terms('(this "Agreement")'), ["inline:Agreement"]);
});

test("a quoted word inside parentheses that is not a defining phrase is not a definition", () => {
  assert.deepEqual(terms('Fees are described later (see "Fees" in Section 3).'), []);
  assert.deepEqual(terms('The label reads (for example "Fragile") on the box.'), []);
  assert.deepEqual(terms('He said "Closing" is late.'), []);
});

test("a quote that does not open a clause is not a definition", () => {
  assert.deepEqual(terms('The word "Fee" means different things to different people.'), []);
});

test("in a Definitions section a paragraph that opens with a quoted term is a definition, whatever the verb", () => {
  const src = '# ARTICLE I - DEFINITIONS\n[1.1] "Knowledge": the actual knowledge of the officer.\n[1.2] "Fee" - the money.\n# ARTICLE II\n[2.1] "Stray": not a definition out here.';
  assert.deepEqual(terms(src), ["listed:Knowledge", "listed:Fee"]);
});

test('"Affiliate" of a Person means ...', () => {
  assert.deepEqual(terms('"Affiliate" of a Person means a controlled company.'), ["means:Affiliate"]);
});

test("definition ranges point at the term without its quotes", () => {
  const ps = parseFixture('Acme (the "Company") signs.');
  const [d] = findDefinitions(ps);
  assert.equal(ps[0].text.slice(d.start, d.end), "Company");
});

test("lowercase quoted words are not terms", () => {
  assert.deepEqual(terms('"cat" means an animal.'), []);
});
