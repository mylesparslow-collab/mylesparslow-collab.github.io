import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { analyze, parseFixture } from "../src/core/index.ts";
import type { Finding, Paragraph } from "../src/core/index.ts";

export const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

export function loadFixture(name: string): Paragraph[] {
  return parseFixture(readFileSync(join(ROOT, "fixtures", `${name}.txt`), "utf8"));
}

/** Analyse a few lines written inline: "[4.2] text" / "# Heading" / plain. */
export function run(src: string, opts?: Parameters<typeof analyze>[1]): Finding[] {
  return analyze(parseFixture(src), opts).findings;
}

export const kinds = (f: Finding[]) => f.map((x) => `${x.kind}:${x.quote}`);
