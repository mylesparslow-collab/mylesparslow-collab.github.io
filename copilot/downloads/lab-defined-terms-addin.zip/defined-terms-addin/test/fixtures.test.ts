import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { analyze } from "../src/core/index.ts";
import { ROOT, loadFixture } from "./helpers.ts";

interface Expected { kind: string; quote: string; inParagraph: string }

const names = ["services-agreement", "lease", "asset-purchase-agreement", "clean-nda", "clean-stress"];

for (const name of names) {
  test(`fixture ${name}: findings equal the planted list, nothing more`, () => {
    const paragraphs = loadFixture(name);
    const spec = JSON.parse(readFileSync(join(ROOT, "fixtures", `${name}.expected.json`), "utf8")) as { expected: Expected[] };
    const want = spec.expected.map((e) => {
      const hits = paragraphs.map((p, i) => (p.text.includes(e.inParagraph) ? i : -1)).filter((i) => i >= 0);
      assert.equal(hits.length, 1, `snippet must identify exactly one paragraph: ${e.inParagraph}`);
      return `${e.kind}|${hits[0]}|${e.quote}`;
    });
    const got = analyze(paragraphs).findings.map((f) => `${f.kind}|${f.paragraphIndex}|${f.quote}`);
    assert.deepEqual([...got].sort(), [...want].sort());
  });
}

test("every finding's range really holds its quote, ids are unique, messages are plain", () => {
  for (const name of names) {
    const paragraphs = loadFixture(name);
    const { findings } = analyze(paragraphs);
    const ids = new Set<string>();
    for (const f of findings) {
      assert.equal(paragraphs[f.paragraphIndex].text.slice(f.start, f.end), f.quote);
      assert.ok(f.quote.length > 0 && f.message.length > 10);
      assert.ok(!ids.has(f.id), `duplicate id ${f.id}`);
      ids.add(f.id);
      assert.match(f.id, /^[A-Z]{3}-\d+-\d+$/);
      assert.ok(["error", "warning", "info"].includes(f.severity));
    }
  }
});

test("analysis is deterministic", () => {
  const p = loadFixture("lease");
  assert.deepEqual(analyze(p).findings, analyze(p).findings);
});
