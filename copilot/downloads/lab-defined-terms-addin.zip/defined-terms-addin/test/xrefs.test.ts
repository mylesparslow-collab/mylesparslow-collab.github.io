import { test } from "node:test";
import assert from "node:assert/strict";
import { run } from "./helpers.ts";

const refs = (src: string) => run(src).filter((f) => f.kind === "broken-reference" || f.kind === "reference-direction").map((f) => `${f.kind}:${f.quote}`);

const DOC = [
  "[1] Intro.",
  "[1.1] First. See Section 2.1(b).",
  "[2] Next.",
  "[2.1] Subject to:",
  "[(a)] one;",
  "[(b)] two; and",
  "[(c)] three.",
  "[2.2] Then:",
  "[(a)] alpha",
  "[(b)] beta",
  "[(i)] roman one",
  "[(ii)] roman two",
].join("\n");

test("resolves sections, lettered and roman sub-paragraphs", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Section 2.1(b), Section 2.2(b)(ii) and Section 1.1."), []);
});

test("flags a missing section and a missing sub-paragraph", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Section 9.1 and Section 2.1(d)."), ["broken-reference:9.1", "broken-reference:2.1(d)"]);
});

test("lists: Sections 2.1, 2.2 and 7", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Sections 2.1, 2.2 and 7."), ["broken-reference:7"]);
});

test("a number after 'and' followed by a unit is a quantity, not a section", () => {
  assert.deepEqual(refs(DOC + "\n[3] Pay within Section 2.1 and 30 days."), []);
});

test("references to other documents are left alone", () => {
  assert.deepEqual(
    refs(DOC + "\n[3] Under Section 409A of the Code, Section 365 of the Bankruptcy Code, Section 4.7 of the Master Agreement and Section 12(b) of the Securities Act."),
    [],
  );
});

test("'of this Agreement' is still checked", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Section 8 of this Agreement."), ["broken-reference:8"]);
});

test("a section number that is only a prefix of a longer token is not read as a section (409A)", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Section 409A."), []);
});

test("above / below pointing the wrong way", () => {
  assert.deepEqual(refs(DOC + "\n[3] See Section 2.1 above and Section 1.1 below."), ["reference-direction:1.1"]);
  assert.deepEqual(refs("[1] See Section 2 above.\n[2] Next."), ["reference-direction:2"]);
  assert.deepEqual(refs("[1] See Section 2 below.\n[2] Next."), []);
});

test("a paragraph inside the section it points to is never 'wrong way'", () => {
  assert.deepEqual(refs("[4] Head.\n[4.1] Within Section 4 below and Section 4 above."), []);
});

test("articles: only checked when the document has Article headings", () => {
  assert.deepEqual(refs("# ARTICLE I\n[1.1] See Article II.\n# ARTICLE III\n[3.1] x"), ["broken-reference:II"]);
  assert.deepEqual(refs("[1.1] See Article II."), []);
  assert.deepEqual(refs("# ARTICLE I\n[1.1] See Article I and Article 1."), []);
});

test("exhibits and schedules: only for a family the document itself lists", () => {
  const listed = "[1.1] See Exhibit A, Exhibit B and Exhibit C.\n# EXHIBIT A - Scope\n# EXHIBIT B - Fees";
  assert.deepEqual(refs(listed), ["broken-reference:C"]);
  // No schedule is listed anywhere, so Schedule references cannot be judged (schedules often sit in a separate letter).
  assert.deepEqual(refs("[1.1] See Schedule 3.4.\n# EXHIBIT A - Scope"), []);
  assert.deepEqual(refs("[1.1] See Schedule 3.4.\nSchedule 3.1 - Title\nSchedule 3.4 - Claims"), []);
  assert.deepEqual(refs("[1.1] See Schedule 3.5.\nSchedule 3.1 - Title\nSchedule 3.4 - Claims"), ["broken-reference:3.5"]);
});

test("a body sentence that begins 'Exhibit A sets out' does not register an exhibit", () => {
  assert.deepEqual(refs("[1.1] Exhibit A sets out the work.\n[1.2] See Exhibit B."), []);
});

test("typed-in numbers (no list numbering behind them) are recognised", () => {
  assert.deepEqual(refs("1.1 Term. Starts now.\n1.2 Fees. See Section 1.1 and Section 1.9."), ["broken-reference:1.9"]);
});

test("no numbering at all: section references cannot be judged and are left alone", () => {
  assert.deepEqual(refs("See Section 4.2 of the plan, see Section 9."), []);
});

test("labels in Word's other dressings: '1.', 'a)', '(A)'", () => {
  assert.deepEqual(refs("[1.] Head.\n[a)] x\n[2.] See Section 1 and Section 1(a) and Section 3."), ["broken-reference:3"]);
});
