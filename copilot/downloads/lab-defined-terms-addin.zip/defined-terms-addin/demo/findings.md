# Defined Terms: demo findings

Real output of the engine on three invented contract excerpts. Fixed rules, no model. An attorney must review every finding.

## Services agreement (services-agreement.txt)

28 paragraphs, 14 definitions found, 9 findings.

| Paragraph | Kind | Severity | Quoted text | Message |
|---|---|---|---|---|
| 7 | Defined but never used | info | `Change Order` | "Change Order" is defined here but the term does not appear anywhere else in the document. |
| 11 | Used but never defined | warning | `Deliverables` | "Deliverables" is capitalised like a defined term and appears 2 times, but the document never defines it. |
| 12 | Used before its definition (info) | info | `Acceptance Criteria` | "Acceptance Criteria" is used here, but it is not defined until paragraph 13. This is informational: it is common to define a term where it first matters. |
| 14 | Defined twice, different wording | error | `Services` | "Services" is defined more than once with different wording. The first definition is in paragraph 5. Check which one is meant to govern. |
| 16 | Inconsistent capitalisation | warning | `service fees` | "Service Fees" is a defined term, but here it is written "service fees". Use the defined capitalisation: "Service Fees". |
| 17 | Reference points to nothing | error | `3.4` | Section 3.4 is referred to here, but nothing in the document is numbered 3.4. |
| 18 | Wrong way: above / below | warning | `5.2` | This says Section 5.2 is above, but Section 5.2 is actually below this paragraph. |
| 20 | Reference points to nothing | error | `VI` | Article VI is referred to here, but the document has no Article VI. |
| 21 | Reference points to nothing | error | `C` | Exhibit C is referred to here, but the document lists no Exhibit C. |

## Office lease (lease.txt)

26 paragraphs, 10 definitions found, 8 findings.

| Paragraph | Kind | Severity | Quoted text | Message |
|---|---|---|---|---|
| 5 | Used but never defined | warning | `Common Areas` | "Common Areas" is capitalised like a defined term and appears 2 times, but the document never defines it. |
| 9 | Defined twice, different wording | error | `Commencement Date` | "Commencement Date" is defined more than once with different wording. The first definition is in paragraph 4. Check which one is meant to govern. |
| 11 | Defined but never used | info | `Holdover Rent` | "Holdover Rent" is defined here but the term does not appear anywhere else in the document. |
| 13 | Used before its definition (info) | info | `Security Deposit` | "Security Deposit" is used here, but it is not defined until paragraph 22. This is informational: it is common to define a term where it first matters. |
| 17 | Wrong way: above / below | warning | `3.3` | This says Section 3.3 is above, but Section 3.3 is actually below this paragraph. |
| 20 | Inconsistent capitalisation | warning | `base rent` | "Base Rent" is a defined term, but here it is written "base rent". Use the defined capitalisation: "Base Rent". |
| 20 | Reference points to nothing | error | `12.3(b)` | Section 12.3(b) is referred to here, but nothing in the document is numbered 12.3(b). |
| 24 | Reference points to nothing | error | `2` | Schedule 2 is referred to here, but the document lists no Schedule 2. |

## Asset purchase agreement (asset-purchase-agreement.txt)

34 paragraphs, 14 definitions found, 12 findings.

| Paragraph | Kind | Severity | Quoted text | Message |
|---|---|---|---|---|
| 9 | Defined but never used | info | `Knowledge` | "Knowledge" is defined here but the term does not appear anywhere else in the document. |
| 10 | Defined but never used | info | `Transition Period` | "Transition Period" is defined here but the term does not appear anywhere else in the document. |
| 13 | Used before its definition (info) | info | `Closing` | "Closing" is used here, but it is not defined until paragraph 15. This is informational: it is common to define a term where it first matters. |
| 14 | Defined twice, different wording | error | `Purchase Price` | "Purchase Price" is defined more than once with different wording. The first definition is in paragraph 8. Check which one is meant to govern. |
| 14 | Used before its definition (info) | info | `Closing Date` | "Closing Date" is used here, but it is not defined until paragraph 15. This is informational: it is common to define a term where it first matters. |
| 16 | Used but never defined | warning | `Excluded Liabilities` | "Excluded Liabilities" is capitalised like a defined term and appears 3 times, but the document never defines it. |
| 16 | Reference points to nothing | error | `6.9` | Section 6.9 is referred to here, but nothing in the document is numbered 6.9. |
| 17 | Inconsistent capitalisation | warning | `purchased assets` | "Purchased Assets" is a defined term, but here it is written "purchased assets". Use the defined capitalisation: "Purchased Assets". |
| 17 | Wrong way: above / below | warning | `7.1` | This says Section 7.1 is above, but Section 7.1 is actually below this paragraph. |
| 19 | Reference points to nothing | error | `3.4` | Schedule 3.4 is referred to here, but the document lists no Schedule 3.4. |
| 21 | Wrong way: above / below | warning | `2.2` | This says Section 2.2 is below, but Section 2.2 is actually above this paragraph. |
| 26 | Reference points to nothing | error | `VIII` | Article VIII is referred to here, but the document has no Article VIII. |
