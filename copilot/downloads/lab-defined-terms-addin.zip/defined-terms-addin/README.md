# Defined Terms: a Word add-in a Copilot agent can call

Defined Terms proofreads a contract's defined terms and cross-references inside the open Word document. **Fixed, tested code finds every problem; the model decides nothing about what is wrong.** The Copilot agent calls the add-in's functions, explains the findings, and, only when you say yes, writes them into the document as Word comments or fixes capitalisation as a tracked change. A small task pane gives the same checks without Copilot.

Everything here uses invented data (the firm is "Thornwood Garza LLP"). Port for the task-pane host: **8726**.

## Run it

```bash
npm install
npm test            # typecheck (tsc) + all tests
npm run demo        # regenerates demo/ from the fixtures
npm run build       # dist/ (bundles, static files, appPackage/, defined-terms.zip)
```

`npm run serve` serves `dist/` on 8726 (plain HTTP; set `CERT_FILE` and `KEY_FILE` for HTTPS, which Word requires). Nothing is installed globally and nothing is left running.

## What it checks (seven kinds, `src/core/`)

| Kind | Severity | Meaning |
|---|---|---|
| `undefined-term` | warning | A capitalised phrase led by "the / such / each / any ..." appears at least twice and is never defined |
| `unused-definition` | info | Defined, but the term (or its plural/singular) never appears outside its own definition paragraph |
| `duplicate-definition` | error | Defined twice with different wording |
| `used-before-definition` | info | Used in an earlier paragraph than the one that defines it (not reported for terms in a Definitions section) |
| `inconsistent-capitalisation` | warning | Defined as "Purchase Price", written "purchase price"; carries the proposed fix |
| `broken-reference` | error | "Section 4.2(b)", "Article IX", "Exhibit C", "Schedule 2.1" that match nothing in the document |
| `reference-direction` | warning | "Section 4.2 above" when 4.2 is below (or the reverse) |

Each finding has an id (`CAP-15-25`), kind, severity, paragraph index, character range, the exact quoted text and a plain-words message.

Definitions recognised: `"Term" means / shall mean / has the meaning ...`, `(the "Term")`, `(each, a "Term")`, `(collectively, the "Terms")`, `(together, ...)`, `(hereinafter "Term")`, several terms in one parenthesis, and, inside a Definitions section, any paragraph that opens with a quoted term. Curly and straight quotes both work (offsets stay aligned).

### How false alarms are kept low

- Only **determiner-led** capitalised phrases (`the Deliverables`) that appear **at least twice** can be "undefined"; phrases at a sentence start are never judged; quoted text and headings are never read.
- A **stop list** (`src/core/stoplist.ts`) skips any phrase containing a month, weekday, US state, place, job title, entity word (Inc, LLC, Bank ...), statute/court/agency word, or an always-present contract word (Agreement, Section, Exhibit, Party ...).
- A phrase that contains a defined term, or sits inside one, is skipped ("the Adjusted Purchase Price", "the Change" next to "Change of Control").
- References followed by "of the ..." (Section 409A of the Code, Section 365 of the Bankruptcy Code) are other documents and ignored; "409A" is not read as "409"; "Section 4.2 and 30 days" is not a reference to Section 30.
- Article, Exhibit and Schedule references are only judged for a family the document itself lists (a document with no schedule list may have a separate disclosure letter). With no numbering at all, section references are not judged.
- Capitalisation: only the same wording in a different case is flagged; ALL CAPS is fine; a lowercase use inside the term's own definition is fine; a single-word term is flagged only after "the / such / each / said", and never for very common words (term, party, law, date ...).

Limits you should know: it needs the document's numbering (Word list numbers, or numbers typed at the start of a paragraph); it does not read bold formatting (a Definitions-section paragraph that opens with a quoted term counts instead); it does not follow definitions in other documents; and "findings" are candidates for an attorney, not conclusions.

## Add-in layer (`src/addin/`)

`DocumentPort` (`port.ts`) is the only door to the document. `WordPort` (Office.js `Word.run`) is the real one; `FakePort` is the in-memory one used by tests and the demo. `actions.ts` holds the six actions with no Office code:

| Action | Changes the document? |
|---|---|
| `scanDocument()` | No. Returns findings JSON |
| `goToFinding({id})` | No. Selects the text |
| `addCommentForFinding({id})` | Adds one Word comment (`[Defined Terms] message (ref ID)`), once |
| `markAllFindings({kinds?})` | Adds comments for all findings, skipping ones already there |
| `fixCapitalisation({id})` | One tracked change; refuses any other kind of finding |
| `clearAddinComments()` | Deletes only comments whose ids this add-in recorded (and that still start `[Defined Terms]`) |

Every write action (`addCommentForFinding`, `markAllFindings`, `fixCapitalisation`) first rescans the document and acts only on findings still present in the fresh scan. An old id is matched to the fresh scan by kind + quoted text + paragraph (ids can shift when text moves). A finding the user has since resolved (for example the term is now defined) returns "already resolved" and nothing is written; a stale id whose text was edited is refused, never applied to the wrong place.

**Which comments `clearAddinComments` deletes.** The ids of the comments the add-in creates are stored in the document: `WordPort` keeps them as a JSON string in the add-in settings (`context.document.settings`, `Word.SettingCollection`, WordApi 1.4: `getItemOrNullObject(key)` and `add(key, value)`; settings are saved inside the document file); `FakePort` keeps them in memory. A comment is deleted only if its id is in that list, so a person's comment is never removed, even one typed with the same `[Defined Terms] ` prefix. I chose ids over an invisible marker because Word may strip or alter invisible characters in comment text. If Word's comment ids turn out not to survive closing and reopening the file (not verified), the clear action finds no match and deletes nothing, so it fails safe; the fallback would then be the prefix plus an appended marker. `register.ts` calls `Office.actions.associate(id, handler)` for each action; the handler receives a JSON string and returns a JSON string. `taskpane.ts` + `static/taskpane.html` is the pane (no framework).

## Packaging (`agents/defined-terms/appPackage/`)

Unified manifest 1.24 (task pane + six `executeDataFunction` actions + `copilotAgents`), `declarativeAgent.json` v1.9 (agent `defined-terms`), `plugin.json` v2.4 with the `LocalPlugin` runtime (`local_endpoint: "Microsoft.Office.Addin"`, `allowed_host: ["document"]`), `confirmation` on the four functions that modify the document, `instructions.txt` (scan first, table by kind, ask before writing, never rewrite substantive text, never opine on meaning, plus the kit's legal safety rules). `npm run build` copies it to `dist/appPackage/` and zips it to `dist/defined-terms.zip`.

## What Microsoft Learn says about add-in-backed agents (checked 2026-11-13)

How the pieces fit, as documented:

1. **Manifest.** The add-in must use the unified manifest for Microsoft 365. In `extensions[].runtimes[]` a runtime with `code.page` (and `code.script` for UI-less) lists `actions[]`; an action with `"type": "executeDataFunction"` is "invoked by a Copilot agent" and its `id` is "passed to the code file". `copilotAgents.declarativeAgents[]` points at the agent file.
2. **Code.** `Office.actions.associate("<id>", async (message) => { ... })`: the first argument must match the manifest action id and the plugin function name exactly; `message` is a JSON string of the parameters; the function returns a string.
3. **Agent and plugin files.** A declarative agent whose `actions[]` points at a plugin manifest; the plugin's `functions[].name` equals the action id; `runtimes[]` has `{"type":"LocalPlugin","spec":{"local_endpoint":"Microsoft.Office.Addin","allowed_host":[...]},"run_for_functions":[...],"auth":{"type":"None"}}`. Valid `allowed_host` values are `document`, `mail`, `presentation`, `workbook`.
4. **Status and limits.** Preview: the schema reference says the overall functionality "remains in preview". An `executeDataFunction` runtime times out after two minutes. Not for content add-ins. The old guide required localhost URLs for testing and sideloading by uploading the zip through Teams.

Sources:

- https://learn.microsoft.com/en-us/office/dev/add-ins/overview/office-add-ins ("Create custom Copilot agents ... (preview)")
- https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/extension-runtimes-actions-item (`executeDataFunction`, id mapping, two-minute timeout)
- https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/?view=m365-app-1.29 (`executeDataFunction` added in manifest 1.24; "remains in preview")
- https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/plugin-manifest-2.4 (`LocalPlugin`, `Microsoft.Office.Addin`, `allowed_host`, `confirmation`, `security_info`)
- Old guide text, read from GitHub history: https://github.com/OfficeDev/office-js-docs-pr/blob/c5e083a769b6012d51b647e1da389fe786c83038/docs/design/agent-and-add-in-overview.md and https://github.com/OfficeDev/office-js-docs-pr/blob/c5e083a769b6012d51b647e1da389fe786c83038/docs/develop/agent-and-add-in.md (the two articles, dated 04/09/2026, with the manifest, agent, plugin and `associate` examples)
- https://learn.microsoft.com/en-us/office/dev/add-ins/excel/excel-skills (the newer, Excel-only "skills" route)

### Where the documentation conflicts or has moved (be aware)

- **The page you named is gone.** `learn.microsoft.com/office/dev/add-ins/design/agent-and-add-in-overview` (and `/develop/agent-and-add-in`) now redirect (HTTP 200 after redirect, confirmed with curl) to the generic "Office Add-ins platform overview". The upstream repo removed both articles on 2026-06-17 (commit 7ab87f3, "removing agent + add-in articles"). The schema reference and the plugin 2.4 page still describe `executeDataFunction` and `LocalPlugin`, but the how-to guide is only available from git history. The Learn quickstart was removed too.
- **A newer route exists and is Excel-only.** The current docs describe "Copilot skills for Excel (preview)": a `SKILL.md` skill plus Office.js scripts packaged as a plugin, needing Excel build 2608+ on Beta or Current Channel (Preview). That is not what this lab builds, and Word is not covered there. Whether the older `executeDataFunction` route still works in Word today is not stated anywhere I could read.
- **Schema version.** The old guide told you to set `manifestVersion` to `devPreview` and use the `vDevPreview` schema; the schema reference says `executeDataFunction` has been in the stable 1.24 schema since October 2025. This lab uses 1.24 (the same as the kit's other agents) and validates against it.
- **Agent version.** The old guide's example used declarative agent v1.6. The kit uses v1.9; the same `actions[]` shape is valid.
- **`auth`.** The plugin 2.4 page's own example writes `"type": "none"` (lower case); its property table and the old guide say `None`. This lab uses `None`, which the published schema accepts.
- **Hosts.** The old guide said only Excel, PowerPoint and Word could be skills ("working to support Outlook") while the 2.4 page lists `mail` as an `allowed_host`.
- A typo on the actions reference page says `Office.action.associate`; the method is `Office.actions.associate`.

## Verified here

| What | Command | Result |
|---|---|---|
| Types | `npx tsc --noEmit` (part of `npm test`) | no errors |
| All tests | `npm test` | 87 tests, 87 pass, 0 fail |
| Engine vs planted problems | tests in `test/fixtures.test.ts` | services agreement 9, lease 8, asset purchase agreement 12 findings, exactly the planted list; both clean texts 0 findings |
| Stop list / false positives | `test/stoplist.test.ts`, `clean-stress` fixture | months, days, states, titles, statutes, headings, party names, `409A`, `Section 365 of the Bankruptcy Code` produce nothing |
| Action layer | `test/actions.test.ts` (FakePort) | scan, go to, comment (once), mark all (idempotent, kinds filter), tracked fix (capitalisation only), stale id refused, resolved finding refused (comment, fix, mark all), moved finding still found, clear (own comments only; a human comment with the same prefix survives), JSON-string dispatch |
| Manifests | `test/manifests.test.ts` | manifest, agent and plugin validate with Ajv (draft-04) against **saved copies of the schemas fetched on 2026-11-13 from the URL each file's `$schema` names** (all three returned HTTP 200; copies in `schemas/`). String `format` checks are off. Plus structural checks: ids match across manifest, plugin and code; confirmation on the four writing functions only; LocalPlugin `document`; 2.4 length limits; instructions under 8000 characters |
| Demo | `npm run demo` | wrote `demo/findings.json`, `findings.md`, `marked-up.html`, `agent-session.json` (7 calls through `dispatch()`) |
| Build | `npm run build` | `dist/taskpane.js` 37.5 kB, `dist/commands.js` 35.7 kB, `dist/appPackage/`, `dist/defined-terms.zip` (6 files) |
| Static host | `PORT=8726 node scripts/serve.mjs`, then curl | taskpane.html, commands.html, both bundles and an icon all 200; stopped afterwards (port closed) |

`demo/marked-up.html` was opened in a browser pane to check it renders. It mimics Word's margin comments and tracked change; it is **not** a screenshot of Word.

## Not verified

- **It has never been sideloaded into Word.** No part of this ran in Word, desktop or web. `WordPort` only type-checks against `@types/office-js`; the real behaviour of `listString` labels, heading styles, `insertComment`, `getComments`, `search`-based locating (it finds the nth occurrence of the text in a paragraph and cannot place a comment on text over 255 characters or containing `^`), and tracked-change replacement is coded from the documentation and untested. In particular, whether Word's paragraph text still includes tracked deletions is unknown.
- **It has never run in Microsoft 365 Copilot.** Nothing was installed in any tenant; the agent, plugin and confirmation cards have not been loaded or seen. The add-in-agent feature is documented as preview and may need a licence, an Insider or preview channel, and an admin to allow it. Whether Copilot passes parameters exactly as documented, honours `confirmation`, or still supports this route in Word is unconfirmed (see the conflicts above).
- **Manifest URLs use `https://localhost:8726`.** Word needs a trusted HTTPS certificate; none was created. The ribbon icons reuse the kit's `outline.png` for all three sizes (16/32/80) without resizing.
- **The schema check is against saved copies** (offline, deterministic), not a live fetch each run.
- **The engine has only been run on the invented fixtures and short test strings.** Real contracts will have numbering schemes, defined-term styles and capitalised words the rules do not anticipate; expect misses and some false alarms and tune the stop list.
- Nothing was tried with a model: no `claude -p` calls were made, because the add-in contains no model.

An attorney must review every finding before anyone relies on it.
