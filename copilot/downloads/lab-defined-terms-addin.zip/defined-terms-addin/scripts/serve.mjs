// Static server for dist/. Word needs HTTPS: set CERT_FILE and KEY_FILE (for example from your own dev certificate).
// Without them it serves plain HTTP, which is enough to smoke-test the files but will not load in Word.
import { createServer as http } from "node:http";
import { createServer as https } from "node:https";
import { readFileSync, existsSync, statSync } from "node:fs";
import { dirname, extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..", "dist");
const port = Number(process.env.PORT ?? 8726);
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".png": "image/png", ".map": "application/json" };

const handler = (req, res) => {
  const url = new URL(req.url, "http://x");
  const file = normalize(join(root, url.pathname === "/" ? "taskpane.html" : url.pathname));
  if (!file.startsWith(root) || !existsSync(file) || !statSync(file).isFile()) {
    res.writeHead(404).end("not found");
    return;
  }
  res.writeHead(200, { "content-type": types[extname(file)] ?? "application/octet-stream" }).end(readFileSync(file));
};

const { CERT_FILE, KEY_FILE } = process.env;
const server = CERT_FILE && KEY_FILE ? https({ cert: readFileSync(CERT_FILE), key: readFileSync(KEY_FILE) }, handler) : http(handler);
server.listen(port, "127.0.0.1", () => console.log(`serving dist/ on ${CERT_FILE ? "https" : "http"}://localhost:${port}`));
