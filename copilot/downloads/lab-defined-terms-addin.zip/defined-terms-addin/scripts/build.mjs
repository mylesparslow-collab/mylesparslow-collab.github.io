// esbuild build: bundles the add-in and copies static files and the agent package into dist/.
import { build } from "esbuild";
import { cpSync, mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dist = join(root, "dist");
rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });

await build({
  entryPoints: { taskpane: join(root, "src/addin/taskpane.ts"), commands: join(root, "src/addin/commands.ts") },
  bundle: true,
  format: "iife",
  target: "es2020",
  outdir: dist,
  sourcemap: true,
  logLevel: "info",
});

cpSync(join(root, "src/addin/static"), dist, { recursive: true });

// The app package (manifest + agent + plugin + icons), with the icon files the manifest's ribbon points at.
const pkg = join(root, "agents/defined-terms/appPackage");
const outPkg = join(dist, "appPackage");
cpSync(pkg, outPkg, { recursive: true });
mkdirSync(join(dist, "assets"), { recursive: true });
for (const size of [16, 32, 80]) cpSync(join(pkg, "outline.png"), join(dist, "assets", `icon-${size}.png`));

if (existsSync(outPkg)) {
  try {
    execFileSync("zip", ["-qr", join(dist, "defined-terms.zip"), "manifest.json", "declarativeAgent.json", "instructions.txt", "plugin.json", "color.png", "outline.png"], { cwd: outPkg });
    console.log("wrote dist/defined-terms.zip");
  } catch {
    console.log("zip not available: dist/appPackage is complete but not zipped");
  }
}
writeFileSync(join(dist, "BUILD.txt"), `built ${new Date().toISOString()}\n`);
void readFileSync;
