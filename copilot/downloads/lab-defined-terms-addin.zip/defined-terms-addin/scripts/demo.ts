// Runs the real engine on the three contract fixtures and writes demo/findings.json, findings.md, marked-up.html,
// plus demo/agent-session.json: the six actions called through the same JSON-string path Copilot would use,
// against the in-memory document (NOT Word, NOT Copilot).
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { analyze, parseFixture } from "../src/core/index.ts";
import type { Finding, Paragraph } from "../src/core/index.ts";
import { DefinedTermsActions } from "../src/addin/actions.ts";
import { FakePort } from "../src/addin/fakePort.ts";
import { dispatch } from "../src/addin/register.ts";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const out = join(root, "demo");
mkdirSync(out, { recursive: true });

const DOCS = [
  { file: "services-agreement", title: "Services agreement" },
  { file: "lease", title: "Office lease" },
  { file: "asset-purchase-agreement", title: "Asset purchase agreement" },
];

const load = (f: string): Paragraph[] => parseFixture(readFileSync(join(root, "fixtures", `${f}.txt`), "utf8"));
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

// 1. findings.json and findings.md
const results = DOCS.map((d) => {
  const paragraphs = load(d.file);
  const { findings, definitions } = analyze(paragraphs);
  return { ...d, paragraphs, findings, definitionCount: definitions.length };
});

writeFileSync(
  join(out, "findings.json"),
  JSON.stringify(
    {
      note: "Real output of src/core on the invented fixtures. Fixed rules; no model was used.",
      documents: results.map((r) => ({
        document: `fixtures/${r.file}.txt`,
        title: r.title,
        paragraphs: r.paragraphs.length,
        definitionsFound: r.definitionCount,
        findings: r.findings.map((f) => ({ ...f, paragraphNumber: f.paragraphIndex + 1 })),
      })),
    },
    null,
    2,
  ) + "\n",
);

const LABEL: Record<string, string> = {
  "undefined-term": "Used but never defined",
  "unused-definition": "Defined but never used",
  "duplicate-definition": "Defined twice, different wording",
  "used-before-definition": "Used before its definition (info)",
  "inconsistent-capitalisation": "Inconsistent capitalisation",
  "broken-reference": "Reference points to nothing",
  "reference-direction": "Wrong way: above / below",
};
let md = "# Defined Terms: demo findings\n\nReal output of the engine on three invented contract excerpts. Fixed rules, no model. An attorney must review every finding.\n";
for (const r of results) {
  md += `\n## ${r.title} (${r.file}.txt)\n\n${r.paragraphs.length} paragraphs, ${r.definitionCount} definitions found, ${r.findings.length} findings.\n\n`;
  md += "| Paragraph | Kind | Severity | Quoted text | Message |\n|---|---|---|---|---|\n";
  for (const f of r.findings) md += `| ${f.paragraphIndex + 1} | ${LABEL[f.kind]} | ${f.severity} | \`${f.quote}\` | ${f.message.replace(/\|/g, "\\|")} |\n`;
}
writeFileSync(join(out, "findings.md"), md);

// 2. marked-up.html: one fixture as Word might show it, findings highlighted, comments in the margin.
function markedUp(title: string, paragraphs: Paragraph[], findings: Finding[]): string {
  const byPara = new Map<number, Finding[]>();
  findings.forEach((f) => byPara.set(f.paragraphIndex, [...(byPara.get(f.paragraphIndex) ?? []), f]));
  let n = 0;
  const rows = paragraphs
    .map((p, i) => {
      const fs = (byPara.get(i) ?? []).sort((a, b) => a.start - b.start);
      let html = "";
      let pos = 0;
      const notes: string[] = [];
      for (const f of fs) {
        n++;
        html += esc(p.text.slice(pos, f.start));
        const tracked = f.suggestion
          ? `<del>${esc(f.quote)}</del><ins>${esc(f.suggestion)}</ins>`
          : esc(f.quote);
        html += `<mark class="${f.severity}" id="m${n}">${tracked}<sup>${n}</sup></mark>`;
        pos = f.end;
        notes.push(
          `<div class="comment ${f.severity}"><b>${n}. [Defined Terms]</b> ${esc(f.message)}${f.suggestion ? " <i>Proposed as a tracked change.</i>" : ""}<span class="id">${esc(f.id)}</span></div>`,
        );
      }
      html += esc(p.text.slice(pos));
      const label = p.label ? `<span class="label">${esc(p.label)}</span> ` : "";
      const tag = p.headingLevel ? `<h${Math.min(p.headingLevel + 1, 4)}>${label}${html}</h${Math.min(p.headingLevel + 1, 4)}>` : `<p>${label}${html}</p>`;
      return `<div class="row"><div class="text">${tag}</div><div class="margin">${notes.join("")}</div></div>`;
    })
    .join("\n");
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Defined Terms: ${esc(title)} marked up</title>
<style>
body{font:15px/1.5 Georgia,serif;margin:0;background:#e9e9e9;color:#1b1b1b}
header{background:#006994;color:#fff;padding:10px 24px;font:600 14px system-ui,sans-serif}
.page{max-width:1100px;margin:16px auto;background:#fff;padding:24px 0;box-shadow:0 1px 4px #0003}
.row{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:20px;padding:0 24px}
.text p,.text h2,.text h3,.text h4{margin:6px 0}.text h2,.text h3,.text h4{font-family:system-ui,sans-serif;font-size:15px;margin-top:14px}
.label{color:#555;margin-right:4px;font-family:system-ui,sans-serif;font-size:13px}
mark{background:#fff2a8;padding:0 1px;border-bottom:2px solid #c77700}
mark.error{background:#ffd9d6;border-color:#b3261e}mark.info{background:#d9ecf3;border-color:#006994}
mark sup{font:700 10px system-ui,sans-serif;margin-left:2px}
del{color:#b3261e}ins{color:#1a7f37;text-decoration:underline;margin-left:3px}
.margin{font:12px/1.35 system-ui,sans-serif}
.comment{border-left:3px solid #c77700;background:#fffbe6;padding:5px 7px;margin:4px 0;box-shadow:0 1px 2px #0002}
.comment.error{border-color:#b3261e;background:#fff1f0}.comment.info{border-color:#006994;background:#eef7fa}
.id{display:block;color:#777;font-size:10px;margin-top:2px}
footer{max-width:1100px;margin:0 auto 24px;font:12px system-ui,sans-serif;color:#555;padding:0 24px}
</style></head><body>
<header>Defined Terms: ${esc(title)}. This page mimics how Word would show the add-in's comments and tracked change. It was rendered from the engine's real findings; it is not a screenshot of Word.</header>
<div class="page">
${rows}
</div>
<footer>${findings.length} findings. Highlight colour: red = error, amber = warning, blue = informational. Strike-through and underline show the one kind of edit the add-in makes (capitalisation, as a tracked change). An attorney must review every finding.</footer>
</body></html>
`;
}
writeFileSync(join(out, "marked-up.html"), markedUp(results[0].title, results[0].paragraphs, results[0].findings));

// 3. agent-session.json: the six actions, through the agent protocol, on the in-memory document.
const port = new FakePort(load("services-agreement"));
const actions = new DefinedTermsActions(port);
const session: Array<{ call: string; arguments: unknown; result: unknown; documentAfter?: unknown }> = [];
async function call(id: Parameters<typeof dispatch>[1], args?: Record<string, unknown>) {
  const result = JSON.parse(await dispatch(actions, id, args ? JSON.stringify(args) : undefined));
  session.push({
    call: id,
    arguments: args ?? {},
    result,
    documentAfter: { comments: port.comments.length, trackedChanges: port.revisions.length, selection: port.selection?.text ?? null },
  });
  return result;
}
const scan = await call("scanDocument");
const find = (kind: string, quote?: string) => scan.findings.find((f: Finding) => f.kind === kind && (!quote || f.quote === quote));
await call("goToFinding", { id: find("undefined-term").id });
await call("addCommentForFinding", { id: find("broken-reference", "3.4").id });
await call("fixCapitalisation", { id: find("broken-reference", "3.4").id }); // refused: not a capitalisation finding
await call("markAllFindings", { kinds: ["broken-reference", "undefined-term"] });
await call("fixCapitalisation", { id: find("inconsistent-capitalisation").id });
await call("clearAddinComments");
writeFileSync(
  join(out, "agent-session.json"),
  JSON.stringify(
    {
      note: "Real run of the six action functions through dispatch(): JSON string in, JSON string out, as Copilot would call them. The document is the in-memory FakePort holding fixtures/services-agreement.txt. This is not Word and not Copilot.",
      session,
      finalDocumentState: { comments: port.comments, trackedChanges: port.revisions },
    },
    null,
    2,
  ) + "\n",
);

console.log(results.map((r) => `${r.file}: ${r.findings.length} findings`).join("\n"));
console.log(`agent-session: ${session.length} calls`);
