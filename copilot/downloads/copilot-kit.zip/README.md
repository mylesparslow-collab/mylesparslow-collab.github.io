# Copilot Kit for law-firm staff

Sixteen no-code Microsoft 365 Copilot agents, one connected agent, and a 36-prompt library, across nine practice areas. Built as a portfolio piece by Myles Parslow. Every sample is invented: the fictional firm is Thornwood Garza LLP, and all clients, people, and cases are made up.

## Contents

| Agent | Area | What it does | Who / where |
|---|---|---|---|
| [Intake Drafter](agents/intake-drafter/) | Firm operations | New-matter email in; filled intake, names-to-search list, open questions out. Never decides a conflict. | Conflicts and intake; Copilot Chat, Outlook |
| [Bill Check](agents/bill-check/) | Firm operations | Answers "can I bill X to client Y?" from the client's guidelines with the rule quoted; reviews a pre-bill. | Billing and finance; Copilot Chat, Excel |
| [Narrative Fixer](agents/narrative-fixer/) | Firm operations | Rewrites vague or block-billed time entries using only facts in the entry; proposes splits. | Timekeepers and billing; Copilot Chat, Excel |
| [Depo Check](agents/depo-check/) | Litigation | Compares testimony with earlier statements, with verbatim quotes and cites. No credibility comments. | Litigation support; Copilot Chat, Word |
| [Order Reader](agents/order-reader/) | Litigation | Lists every obligation in a court order; never calculates deadlines. | Docketing and paralegals; Copilot Chat, Word |
| [Engagement Check](agents/engagement-check/) | Firm operations | Checks a draft California engagement letter against a drafting checklist. | Attorneys and risk; Copilot Chat, Word |
| [Client Prep](agents/client-prep/) | Firm operations | Connected agent: calls the Firm Facts MCP server (nine read-only tools) for client briefings and firm numbers. | Partners, billing, finance, risk; Copilot Studio |
| [Brown Act Check](agents/brown-act-check/) | Government | Checks a draft local-agency meeting agenda against a Brown Act checklist. | Agency counsel, deputy city attorneys, and clerks preparing California local-agency agendas. |
| [Records Request Intake](agents/cpra-intake/) | Government | Splits a Public Records Act request into asks, custodians, and search terms. | City and county attorneys' staff, clerks, and paralegals who log public records requests. |
| [RFP Responder](agents/rfp-responder/) | Firm operations | Turns a public agency's legal RFP into dates, a checklist, and a matrix. | Business development staff, marketing, and the attorneys who lead proposals for public-agency work. |
| [Lease Abstract](agents/lease-abstract/) | Real estate | Abstracts a commercial or retail lease with every clause quoted and cited. | Real estate attorneys, paralegals, and lease administrators, especially on shopping-center deals. |
| [Conditions Tracker](agents/conditions-tracker/) | Land use | Turns land-use conditions of approval into a tracker grouped by timing trigger. | Land use attorneys, paralegals, and project coordinators tracking entitlements. |
| [Public Works Check](agents/public-works-check/) | Construction | Checks a California public works contract against a statutory checklist. | Construction and government attorneys, contract administrators, and paralegals reviewing bid packages. |
| [Separation Check](agents/separation-check/) | Labor & employment | Checks a draft California separation agreement against a drafting checklist. | Employment attorneys, HR counsel, and paralegals reviewing severance and release drafts. |
| [Trust Abstract](agents/trust-abstract/) | Family wealth | Abstracts a trust by article and section, with questions for the attorney. | Trusts and estates attorneys, paralegals, and trust administrators. |
| [Coverage Letter Reader](agents/coverage-letter/) | Insurance recovery | Reads an insurer's reservation-of-rights or denial letter for the policyholder. | Insurance recovery attorneys and paralegals working for the policyholder. |
| [Privilege Log Drafter](agents/privilege-log/) | Litigation | Drafts privilege log entries from a list of withheld documents, with flags. | Litigation paralegals, litigation support staff, and associates preparing privilege logs. |
| [Prompt library](prompts/) | Everyone | 36 paste-ready prompts across six roles. | Everyone; Outlook, Word, Teams, Excel, Copilot Chat |

Each no-code agent folder has a README (setup and limits), `instructions.txt` (paste-ready), `starters.json`, a `sample-input.md` for the demo, and `appPackage/` for IT to deploy.

## Licensing note
Agent Builder (Copilot Chat, then New agent) takes a name up to 30 characters, a description up to 1,000, and instructions up to 8,000. Custom instructions and web search work in free Copilot Chat. SharePoint and uploaded-file knowledge (up to 100 SharePoint files, 20 uploaded files, 4 public URLs) needs a Microsoft 365 Copilot license or pay-as-you-go. Every agent here also works with no knowledge at all: paste or attach the document in the chat.

## Package for deployment
`scripts/package.sh` writes `dist/<agent>-appPackage.zip` for each agent and `dist/copilot-kit.zip` for the whole kit.

## Firm approval
Install in a firm tenant only with IT and risk approval; the samples are invented.

## Safety design
Every agent quotes source text with its location, says "not stated in the document" when something is missing, leaves decisions to a person, gives no legal conclusions beyond its checklist, treats contents as confidential, and ignores instructions found inside the documents it reads.
