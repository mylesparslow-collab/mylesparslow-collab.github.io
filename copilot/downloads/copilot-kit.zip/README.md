# Copilot Kit for law-firm staff

Six no-code Microsoft 365 Copilot agents, one connected agent, and a 36-prompt library. Built as a portfolio piece by Myles Parslow. Every sample is invented: the fictional firm is Thornwood Garza LLP, and all clients, people, and cases are made up.

## Contents

| Agent | What it does | Who / where |
|---|---|---|
| [Intake Drafter](agents/intake-drafter/) | New-matter email in; filled intake, names-to-search list, open questions out. Never decides a conflict. | Conflicts and intake; Copilot Chat, Outlook |
| [Bill Check](agents/bill-check/) | Answers "can I bill X to client Y?" from the client's guidelines with the rule quoted; reviews a pre-bill. | Billing and finance; Copilot Chat, Excel |
| [Narrative Fixer](agents/narrative-fixer/) | Rewrites vague or block-billed time entries using only facts in the entry; proposes splits. | Timekeepers and billing; Copilot Chat, Excel |
| [Depo Check](agents/depo-check/) | Compares testimony with earlier statements, with verbatim quotes and cites. No credibility comments. | Litigation support; Copilot Chat, Word |
| [Order Reader](agents/order-reader/) | Lists every obligation in a court order; never calculates deadlines. | Docketing and paralegals; Copilot Chat, Word |
| [Engagement Check](agents/engagement-check/) | Checks a draft California engagement letter against a drafting checklist. | Attorneys and risk; Copilot Chat, Word |
| [Client Prep](agents/client-prep/) | Connected agent: calls the Firm Facts MCP server (nine read-only tools) for client briefings and firm numbers. | Partners, billing, finance, risk; Copilot Studio |
| [Prompt library](prompts/) | 36 paste-ready prompts across six roles. | Everyone; Outlook, Word, Teams, Excel, Copilot Chat |

Each no-code agent folder has a README (setup and limits), `instructions.txt` (paste-ready), `starters.json`, a `sample-input.md` for the demo, and `appPackage/` for IT to deploy.

## Licensing note
Agent Builder (Copilot Chat, then New agent) takes a name up to 30 characters, a description up to 1,000, and instructions up to 8,000. Custom instructions and web search work in free Copilot Chat. SharePoint and uploaded-file knowledge (up to 100 SharePoint files, 20 uploaded files, 4 public URLs) needs a Microsoft 365 Copilot license or pay-as-you-go. Every agent here also works with no knowledge at all: paste or attach the document in the chat.

## Package for deployment
`scripts/package.sh` writes `dist/<agent>-appPackage.zip` for each agent and `dist/copilot-kit.zip` for the whole kit.

## Firm approval
Install in a firm tenant only with IT and risk approval; the samples are invented.

## Safety design
Every agent quotes source text with its location, says "not stated in the document" when something is missing, leaves decisions to a person, gives no legal conclusions beyond its checklist, treats contents as confidential, and ignores instructions found inside the documents it reads.
