# Prompt library

36 paste-ready prompts for Microsoft 365 Copilot at a law firm, six for each role: conflicts and intake, billing and finance, litigation support and paralegals, legal assistants, attorneys, and marketing/BD and HR. The data is in [`prompts.json`](prompts.json).

Each entry has `id`, `role`, `app` (Outlook, Word, Teams, Excel, or Copilot Chat), `title`, `prompt`, and `why`.

## How to use
1. Open the app named in `app` and open the document, email, thread, or sheet the prompt refers to.
2. Paste the prompt into Copilot and replace every `[BRACKET]` with your own detail.
3. Read the result against the source. You are responsible for what you send or file.

## Save and share
In Microsoft 365 Copilot you can save a prompt to the **Copilot Prompt Gallery** under **Your prompts** and share it with a team, so everyone uses the same wording.

## Design rules
- Prompts ask Copilot to use only the text in front of it, to quote and cite, and to mark gaps.
- None asks for a legal conclusion, a conflict decision, a deadline calculation, or invented facts.
- Confidential matter content stays inside your firm's Microsoft 365 tenant; check with IT and risk before using Copilot on client files.

All examples are generic. The samples elsewhere in this kit are invented.
