# Subpoena Reader

Reads an agency subpoena or CID and drafts a legal-hold notice for counsel to review.

## What it does
Reads a subpoena, civil investigative demand, or agency document request and reports the issuing agency, recipient, and return date as written, definitions and instructions that change scope (quoted), the relevant time period, each numbered request split out with likely custodians and data sources, privilege-log instructions, certification requirements, and the contact for counsel. Lists possible scope questions for counsel as questions only, and drafts a legal-hold notice in brackets for counsel to review. Never computes a date and never advises on objections.

## Who uses it, and where
- **Who:** Government investigations and white-collar attorneys, paralegals, and e-discovery staff.
- **Where:** Copilot Chat; Word (demand open); Outlook (demand attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Subpoena Reader` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a subpoena, civil investigative demand, or agency document request and reports the issuing agency, recipient, and return date as written, definitions and instructions that change scope (quoted), the relevant time period, each numbered request split out with likely custodians and data sources, privilege-log instructions, certification requirements, and the contact for counsel. Lists possible scope questions for counsel as questions only, and drafts a legal-hold notice in brackets for counsel to review. Never computes a date and never advises on objections.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3929 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Read this demand**: Read this subpoena or CID and give me your full report, then a draft legal-hold notice for counsel. Demand: [PASTE OR ATTACH]
- **Requests and custodians**: Split every numbered request in this demand into its own row with likely custodians and data sources. Demand: [PASTE]
- **Scope-changing language**: Quote every definition and instruction in this demand that changes the scope of the requests. Demand: [PASTE]
- **Dates and certifications**: List the return date, the privilege-log timing, and the certification requirement exactly as written. Do not compute any date. Demand: [PASTE]
- **Draft the hold notice**: Draft a legal-hold notice for counsel to review based on this demand, with brackets for anything counsel must approve. Demand: [PASTE]

## What it will NOT do
- Advise on objections; it lists possible scope questions for counsel.
- Calculate any due date; it writes "Docketing to calculate: [trigger + period as written]".
- Describe the investigation in the hold notice beyond what counsel approves.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
