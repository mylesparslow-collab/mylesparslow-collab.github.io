# Sample input: civil investigative demand (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. The Office of the Attorney General of the State of Eastmark and Pinecrest Billing Solutions, LLC do not exist.

---

OFFICE OF THE ATTORNEY GENERAL OF THE STATE OF EASTMARK
CONSUMER PROTECTION DIVISION

CIVIL INVESTIGATIVE DEMAND NO. CID-2026-0192

TO: Pinecrest Billing Solutions, LLC, Attn: Custodian of Records, 88 Quarry Road, Westbrook

You are required to produce the documents and information described below, in accordance with the Instructions and Definitions, to the Office of the Attorney General, Consumer Protection Division. The return date is December 15, 2026, at 10:00 a.m. Production may be made electronically.

This demand is issued in connection with an investigation into the billing and collection practices of health-care billing companies. The Attorney General has not determined that any violation has occurred.

**DEFINITIONS**

1. "You" and "Pinecrest" mean Pinecrest Billing Solutions, LLC, and its parents, subsidiaries, affiliates, predecessors, officers, employees, agents, and anyone acting on its behalf.
2. "Document" means any written, recorded, or electronic material of any kind, including email, text and chat messages, drafts, spreadsheets, and databases, in Your possession, custody, or control.
3. "Relevant Period" means January 1, 2022 through the date of Your response, unless a Request states otherwise.
4. "Provider Client" means any hospital, clinic, or physician group for which You perform billing or collection services.

**INSTRUCTIONS**

A. This demand is continuing. You must supplement Your production if You locate further responsive Documents after Your response.
B. If You withhold any Document on a claim of privilege, You must provide a log within fourteen (14) days after the return date identifying each Document by date, author, recipients, general subject matter, and the privilege claimed.
C. Documents must be produced in the form in which they are kept in the ordinary course of business, or as searchable electronic files with metadata intact.
D. If no Documents respond to a Request, You must say so in writing.
E. A person with knowledge of Your search must sign the attached Certificate of Compliance.

**REQUESTS FOR PRODUCTION**

1. All contracts between You and each Provider Client.
2. All Documents describing Your policies and procedures for sending patient bills and collection notices.
3. All scripts, templates, and form letters used in collection calls or collection letters during the Relevant Period.
4. All Documents concerning patient complaints about billing or collection, including the complaint and Your response.
5. For the period January 1, 2024 through the date of Your response, all Documents sufficient to show the number of accounts placed for collection, by Provider Client, by month.
6. All Documents concerning any compensation or bonus plan for collection staff that is based on amounts collected.
7. All communications with any Provider Client concerning the accuracy of patient balances.
8. All Documents concerning Your document retention policies.
9. All Documents concerning any internal audit or compliance review of Your billing or collection practices.

Questions about this demand may be directed to Assistant Attorney General Philippa Ngozi-Brandt, (555) 010-0142, pngozi@ag.eastmark.example.

Issued: November 9, 2026.
