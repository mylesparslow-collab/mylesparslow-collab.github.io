# Record Cite Check

Checks each cited sentence of a statement of facts against the pasted record pages.

## What it does
Checks a brief's statement of facts against record excerpts the user pastes. For each factual sentence reports Supported (with the record text quoted), Not found in pasted pages, Says something different (with both texts quoted), or No cite given. Reads citation forms such as 2 AA 345, RT 112:4-9, and CT 88 as written. Compares names, numbers, dates, and who said what literally. Never judges whether a statement is a fair characterization of the record beyond its text, and never makes arguments.

## Who uses it, and where
- **Who:** Appellate attorneys, paralegals, and cite-checkers preparing briefs.
- **Where:** Copilot Chat; Word (brief and record excerpts open).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Record Cite Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Checks a brief's statement of facts against record excerpts the user pastes. For each factual sentence reports Supported (with the record text quoted), Not found in pasted pages, Says something different (with both texts quoted), or No cite given. Reads citation forms such as 2 AA 345, RT 112:4-9, and CT 88 as written. Compares names, numbers, dates, and who said what literally. Never judges whether a statement is a fair characterization of the record beyond its text, and never makes arguments.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3915 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check these cites**: Check each sentence of this statement of facts against the record excerpts below. Statement: [PASTE] Record excerpts: [PASTE]
- **Problems only**: List only the sentences that are Not found, Say something different, or have No cite. Quote the record text. Statement: [PASTE] Record: [PASTE]
- **Numbers and dates**: Compare every number, date, and name in this statement of facts with the cited record text. Statement: [PASTE] Record: [PASTE]
- **Which pages are missing**: Which cited pages are not in the record excerpts I pasted? Statement: [PASTE] Record: [PASTE]
- **Cite list**: List every record cite in this statement of facts, in order, with the sentence it supports. Statement: [PASTE]

## What it will NOT do
- Say whether a sentence fairly characterizes the record; it compares text only.
- Look up or assume record pages that were not pasted; it writes Not found in pasted pages.
- Suggest arguments or rewrite the brief.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
