# Sample input: statement of facts and record excerpts (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Halvorsen Fabrication, Inc. and Rosalind Quist do not exist. Three problems are deliberately planted.

---

## Statement of Facts (draft)

1. Halvorsen Fabrication, Inc. hired Rosalind Quist as a plant supervisor on March 4, 2019. (1 CT 12.)
2. Her offer letter stated an annual salary of $78,000. (1 CT 14.)
3. In June 2022, Quist told the plant manager that a guard had been removed from a press brake. (RT 112:4-9.)
4. The plant manager, Desmond Aldous, replied that the guard would be reinstalled "by Friday." (RT 112:10-13.)
5. The guard was not reinstalled until August 15, 2022. (2 AA 345.)
6. On July 11, 2022, Quist emailed the safety coordinator, Imogen Pratt, to repeat her concern. (2 AA 351.)
7. Quist was terminated on September 6, 2022. (1 CT 88.)
8. The termination letter gave "restructuring of the supervisory team" as the reason. (1 CT 88.)
9. Three other supervisors were also terminated that month. (2 AA 360.)
10. Quist had received no written discipline before her termination.

## Record excerpts (pasted pages)

**1 CT 12** (Employee Action Form)
Employee: Rosalind Quist. Position: Plant Supervisor. Hire date: March 4, 2019. Supervisor: Desmond Aldous.

**1 CT 14** (Offer letter dated February 20, 2019)
"We are pleased to offer you the position of Plant Supervisor at an annual salary of $78,000, payable biweekly."

**RT 112** (Reporter's Transcript, direct examination of Rosalind Quist)
4 Q. What did you tell Mr. Aldous in June of 2022?
5 A. I told him the guard on press brake number two had been
6 taken off and that somebody could get hurt.
7 Q. Did you say that to him in person?
8 A. Yes, at the start of the morning shift.
9 Q. Was anyone else present? A. No.
10 Q. What did he say?
11 A. He said it would be put back on by Friday.
12 Q. Did that happen?
13 A. No.

**2 AA 345** (Maintenance work order)
Work order 22-0871. Item: reinstall guard, press brake no. 2. Date completed: August 25, 2022. Completed by: R. Mbeki.

**2 AA 351** (Email, July 11, 2022, from Rosalind Quist to Imogen Pratt)
"Imogen, following up on my conversation with Desmond last month: the guard on press brake 2 is still off. Please let me know when it will go back on."

**1 CT 88** (Letter dated September 6, 2022, from Halvorsen Fabrication, Inc. to Rosalind Quist)
"This letter confirms that your employment is terminated effective today. The reason for this decision is restructuring of the supervisory team."
