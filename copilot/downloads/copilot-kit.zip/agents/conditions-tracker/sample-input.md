# Sample input: city resolution with conditions (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. The City of Larkspur Hills does not exist.

---

CITY OF LARKSPUR HILLS
PLANNING COMMISSION RESOLUTION NO. 2025-14

A RESOLUTION OF THE PLANNING COMMISSION APPROVING CONDITIONAL USE PERMIT 24-006 AND DESIGN REVIEW 24-011 FOR THE HARBOR ROW MIXED-USE PROJECT, 410-450 Harbor Row

Adopted: March 18, 2025

**Section 1. Approval.** The Planning Commission approves a mixed-use project of 96 residential units over 14,000 square feet of ground-floor commercial space, including one restaurant, subject to the conditions in Exhibit A.

**EXHIBIT A: CONDITIONS OF APPROVAL**

1. The project shall be built substantially as shown on the plans stamped "Approved" by the Planning Commission on March 18, 2025.

2. Prior to issuance of a grading permit, the applicant shall submit a final drainage and erosion control plan for review and approval by the City Engineer.

3. Prior to issuance of a grading permit, the applicant shall record a covenant against the property requiring that 10 of the 96 residential units be reserved as affordable to low-income households.

4. Commercial uses shall close by 10:00 p.m. daily. Hours of operation shall not be extended without Planning Commission approval.

5. The maximum building height shall be 55 feet to the top of the roof deck.

6. Prior to issuance of a building permit, the applicant shall provide a minimum of 160 off-street parking spaces, including 8 accessible spaces.

7. Prior to issuance of a certificate of occupancy, all street improvements along Harbor Row, including sidewalks and street trees, shall be completed.

8. Construction activity shall be limited to 7:00 a.m. to 6:00 p.m., Monday through Friday.

9. The restaurant may operate until midnight on Fridays and Saturdays.

10. The project shall comply with all requirements of the Fire Department.

11. Prior to issuance of a building permit, the applicant shall pay all applicable development impact fees.

12. The applicant shall submit annual reports to the City confirming compliance with the affordable housing covenant.

**MITIGATION MONITORING AND REPORTING PROGRAM (EXCERPT)**

MM-N-1 (Noise). Prior to issuance of a grading permit, the contractor shall prepare a construction noise control plan. Responsible party: Contractor. Monitoring: Building Division.

MM-T-1 (Transportation). The applicant shall implement the approved transportation demand management program for the life of the project. Responsible party: Property manager. Monitoring: Public Works Department.
