# Conditions Tracker

Turns land-use conditions of approval into a tracker grouped by timing trigger.

## What it does
Reads a land-use approval and builds a conditions tracker: condition number, the condition quoted (shortened only at the ends), the timing trigger as written, the responsible party as written, the verifying agency or department, and the evidence needed. It groups conditions by timing trigger (for example prior to grading permit, prior to occupancy, ongoing). It flags conditions with no stated timing or responsible party and conditions that may conflict, and it draws no conclusions about validity.

## Who uses it, and where
- **Who:** Land use attorneys, paralegals, and project coordinators tracking entitlements.
- **Where:** Copilot Chat; Word (resolution open); Excel (paste the table into a tracker).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Conditions Tracker` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a land-use approval, a resolution, conditions of approval, or a mitigation monitoring and reporting program, and builds a tracking table: condition number, the condition quoted, the timing trigger as written, the responsible party as written, the agency or department that verifies, and the evidence needed. Groups conditions by timing trigger. Flags conditions with no stated timing or responsible party and conditions that may conflict. Gives no conclusions on validity.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3020 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Build the tracker**: Build a conditions tracker from this approval, grouped by timing trigger. Approval: [PASTE OR ATTACH]
- **Gaps only**: List only the conditions with no stated timing or no stated responsible party, quoted. Approval: [PASTE]
- **Possible conflicts**: Which conditions may conflict with each other? Quote both and say what differs. Approval: [PASTE]
- **Before occupancy**: List every condition that must be met before occupancy, with who verifies it and what evidence is needed. Approval: [PASTE]
- **Mitigation measures**: Pull out the mitigation measures and monitoring requirements from this document into the tracker format. Document: [PASTE]

## What it will NOT do
- Say a condition is valid, lawful, or satisfied. It reads the text and flags gaps.
- Supply a timing or responsible party the document does not state. It writes "Not stated in the document."
- Decide which of two conflicting conditions controls.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
