# Office Action Reader

Reads a USPTO trademark office action: refusals, requirements, cited marks, and what resolves each.

## What it does
Reads a USPTO trademark office action and lists the application serial number, mark, and issue date, then each refusal and requirement quoted with the statutory ground as the office action states it, the cited prior registrations, and what the examiner says would resolve each. Notes the response period in general terms for docketing to calculate and confirm, and never computes the date. Lists information needed from the client, such as specimens, identification of goods amendments, and disclaimers. Does not advise on strategy.

## Who uses it, and where
- **Who:** Trademark attorneys, paralegals, and docketing staff handling USPTO office actions.
- **Where:** Copilot Chat; Word (office action open); Outlook (action attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Office Action Reader` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a USPTO trademark office action and lists the application serial number, mark, and issue date, then each refusal and requirement quoted with the statutory ground as the office action states it, the cited prior registrations, and what the examiner says would resolve each. Notes the response period in general terms for docketing to calculate and confirm, and never computes the date. Lists information needed from the client, such as specimens, identification of goods amendments, and disclaimers. Does not advise on strategy.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3384 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Read this office action**: Read this USPTO office action and list every refusal and requirement, the cited registrations, and what the examiner says would resolve each. Office action: [PASTE OR ATTACH]
- **Cited registrations**: List every prior registration the examiner cites, with the registration number, the mark, the owner, and the goods exactly as stated. Office action: [PASTE]
- **What the examiner says would resolve it**: For each refusal and requirement, quote what the examiner says would resolve it. Office action: [PASTE]
- **Response timing for docketing**: What does this office action say about when a response is due? Quote it, and list the timing for docketing to calculate. Do not compute the date. Office action: [PASTE]
- **What we need from the client**: List the information, documents, and decisions we need from the client to respond, using only what this office action says. Office action: [PASTE]

## What it will NOT do
- Compute the response deadline; docketing calculates and confirms.
- Advise whether to argue, amend, or abandon; it reports what the examiner says.
- Cite any law beyond the grounds the office action itself states.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
