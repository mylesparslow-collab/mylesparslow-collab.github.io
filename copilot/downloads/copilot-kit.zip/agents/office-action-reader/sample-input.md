# Sample input: USPTO trademark office action (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Tidewell Provisions LLC and Calder Street Roasters Inc. do not exist.

---

UNITED STATES PATENT AND TRADEMARK OFFICE (USPTO)
OFFICE ACTION (OFFICIAL LETTER) ABOUT APPLICANT'S TRADEMARK APPLICATION

U.S. APPLICATION SERIAL NO. 98/765,432
MARK: SMOOTHROAST
CORRESPONDENCE ADDRESS: Thornwood Garza LLP (invented)
APPLICANT: Tidewell Provisions LLC
ISSUE DATE: October 6, 2026

**SUMMARY OF ISSUES THAT APPLICANT MUST ADDRESS**
- Trademark Act Section 2(d) Refusal: Likelihood of Confusion
- Trademark Act Section 2(e)(1) Refusal: Merely Descriptive
- Identification of Goods Requirement

**SECTION 2(d) REFUSAL: LIKELIHOOD OF CONFUSION**
Registration of the applied-for mark is refused because of a likelihood of confusion with the mark in U.S. Registration No. 5,512,308. Trademark Act Section 2(d), 15 U.S.C. §1052(d). The registered mark is SMOOTH ROASTERS, registered to Calder Street Roasters Inc. for "coffee beans; ground coffee." The marks are similar in sound, appearance, and meaning, and the goods are identical in part. The examining attorney states: "Applicant may respond to this refusal by submitting evidence and arguments against the refusal, or by deleting or limiting the goods, or by obtaining the consent of the registrant."

**SECTION 2(e)(1) REFUSAL: MERELY DESCRIPTIVE**
Registration is also refused because the applied-for mark merely describes a feature of the applicant's goods. Trademark Act Section 2(e)(1), 15 U.S.C. §1052(e)(1). The examining attorney states that "SMOOTH" describes the taste of the coffee and "ROAST" names the process by which it is made, and that combining the two terms creates no unique commercial impression. The examining attorney states that Applicant may respond by submitting evidence and arguments, or by amending the application to the Supplemental Register if the mark is in use in commerce.

**IDENTIFICATION OF GOODS REQUIREMENT**
The identification "coffee; beverages" is indefinite. The word "beverages" must be clarified. The examining attorney suggests the following amendment: "Coffee; coffee-based beverages." Applicant may adopt this wording or substitute wording that is more specific, but may not broaden the scope of the goods.

**RESPONSE GUIDELINES**
The applicant must respond to this Office action within three months of the issue date. Failure to respond will result in abandonment of the application. The applicant should also submit a specimen if the application is based on use in commerce under Section 1(a); no specimen is currently of record.
