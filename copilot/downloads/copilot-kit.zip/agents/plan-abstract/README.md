# Benefit Plan Abstract

Abstracts a retirement or welfare plan or SPD by section, with questions for benefits counsel.

## What it does
Abstracts a retirement or welfare plan document or summary plan description into a table with the key words quoted and the section cited: plan name, type and number, sponsor, administrator, plan year, eligibility and entry dates, employee and employer contributions and match formulas, vesting schedule, distributions and loans, claims and appeals procedures with time periods as written, and amendment and termination rights. Lists questions for benefits counsel about gaps and inconsistencies, including differences between a plan and its SPD if both are given. Gives no tax advice and no legal conclusions.

## Who uses it, and where
- **Who:** Employee benefits attorneys, paralegals, and plan administrators' counsel.
- **Where:** Copilot Chat; Word (plan document or SPD open); Outlook (document attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Benefit Plan Abstract` (30 characters max). Description: paste the text below (1,000 characters max).

   > Abstracts a retirement or welfare plan document or summary plan description into a table with the key words quoted and the section cited: plan name, type and number, sponsor, administrator, plan year, eligibility and entry dates, employee and employer contributions and match formulas, vesting schedule, distributions and loans, claims and appeals procedures with time periods as written, and amendment and termination rights. Lists questions for benefits counsel about gaps and inconsistencies, including differences between a plan and its SPD if both are given. Gives no tax advice and no legal conclusions.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3040 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Abstract this plan**: Abstract this plan document or SPD into your table with sections and quotes, then list questions for benefits counsel. Document: [PASTE OR ATTACH]
- **Vesting and contributions**: Quote the contribution formulas and the vesting schedule in this document with section numbers, and flag any place the document says two different things. Document: [PASTE]
- **Claims and appeals**: List the claims and appeals procedure in this document with every time period exactly as written. Do not compute dates. Document: [PASTE]
- **Plan versus SPD**: Compare the plan document and the SPD I attached. Quote both versions wherever they differ. Plan: [PASTE] SPD: [PASTE]
- **Gaps only**: List only what this document does not state, and any inconsistency between sections, as questions for benefits counsel. Document: [PASTE]

## What it will NOT do
- Give tax advice or say whether a plan complies with any law.
- Resolve an inconsistency; it quotes both versions and asks benefits counsel.
- Fill a row the document does not address; it writes "Not stated in the document."
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
