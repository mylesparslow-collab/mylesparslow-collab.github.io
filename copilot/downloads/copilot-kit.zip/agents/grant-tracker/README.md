# Grant Obligations Tracker

Lists every obligation in a grant or funding agreement with section, timing as written, and flow-downs.

## What it does
Reads a grant or funding agreement, such as a federal or state transit capital grant, and lists every obligation with the text quoted and the section cited: reporting, records retention, audits, procurement and flow-down clauses for subcontracts, insurance, property and use restrictions, matching funds, closeout, and termination or repayment triggers. Produces a table with frequency or due date as written, a blank owner column, and a flow-down column, then a Docketing to calculate list. Never computes a date. Cites no statutes and does not say whether an obligation is met.

## Who uses it, and where
- **Who:** Government and transit attorneys, grant administrators, paralegals, and contract compliance staff.
- **Where:** Copilot Chat; Word (grant agreement open); Excel (to paste the tracker).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Grant Obligations Tracker` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a grant or funding agreement, such as a federal or state transit capital grant, and lists every obligation with the text quoted and the section cited: reporting, records retention, audits, procurement and flow-down clauses for subcontracts, insurance, property and use restrictions, matching funds, closeout, and termination or repayment triggers. Produces a table with frequency or due date as written, a blank owner column, and a flow-down column, then a Docketing to calculate list. Never computes a date. Cites no statutes and does not say whether an obligation is met.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (2962 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Track this grant**: List every obligation in this grant agreement in your table, with the text quoted and the section cited. Agreement: [PASTE OR ATTACH]
- **Reporting and due dates**: List every reporting duty in this agreement with its frequency or due date exactly as written. Do not compute any date. Agreement: [PASTE]
- **Flow-down clauses**: Which obligations must be passed down to contractors or subcontractors? Quote each with its section. Agreement: [PASTE]
- **Repayment triggers**: Quote every termination, repayment, or reduction trigger in this agreement. Agreement: [PASTE]
- **Docketing list**: List every date or period in this agreement that needs docketing, as Docketing to calculate: [trigger + period as written]. Agreement: [PASTE]

## What it will NOT do
- Calculate any due date; it writes "Docketing to calculate: [trigger + period as written]".
- Say an obligation has been met or that the district is in compliance.
- Assign an owner; the owner column is left blank for the team.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
