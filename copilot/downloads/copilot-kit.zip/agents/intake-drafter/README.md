# Intake Drafter

Turns a new-matter email into a filled intake and a names-to-search list.

## What it does
A partner forwards a new-matter email. Intake Drafter returns a filled new-business intake, a "names to run through conflicts" list (one per line, with role and aliases or former names), and a short list of questions still open for the partner. It never clears, waives, or decides a conflict.

## Who uses it, and where
- **Who:** Conflicts analysts, intake coordinators, and partners' assistants.
- **Where:** Copilot Chat; Outlook (paste or attach the forwarded email); Word (for the intake form).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Intake Drafter` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a new-matter email (or notes) and returns a filled new-business intake, a list of names to run through conflicts with roles and aliases, and the questions still open for the partner. Never clears or decides a conflict.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3721 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: your firm's blank intake form (as an uploaded file) so the output matches your field names. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Draft intake from email**: Draft a new-business intake from the email below. Email: [PASTE EMAIL]
- **Names to run**: List every name I need to run through conflicts from this email, with role and any aliases or former names: [PASTE EMAIL]
- **Open questions**: What does the partner still need to tell me before I can open conflicts on this matter? [PASTE EMAIL]
- **Rule 1.18 note**: Did the sender share confidential information before engagement? Draft a Rule 1.18 prospective-client note from this email. [PASTE EMAIL]
- **Corporate family**: Which corporate family members, parents, and former names are mentioned in this email that should be searched? [PASTE EMAIL]

## What it will NOT do
- Clear, waive, or decide a conflict, or say a name is or is not a conflict.
- Search your conflicts database.
- Fill any field the email does not support; it writes "Not stated" and asks the partner.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
