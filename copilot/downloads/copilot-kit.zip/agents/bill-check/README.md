# Bill Check

Answers 'can I bill this?' from the client's guidelines and checks pre-bills.

## What it does
Two jobs. (1) Answer "can I bill X to client Y?" from the client's outside counsel guidelines (OCG): it quotes the governing rule verbatim with its section number, says what it means in one sentence, and flags whether pre-approval is needed and from whom. (2) Review a pasted pre-bill and list the entries that break a guideline, with the rule quoted, why, and a suggested fix.

## Who uses it, and where
- **Who:** Billing and finance staff, legal assistants, paralegals, and timekeepers.
- **Where:** Copilot Chat; Word (guidelines document open); Excel (pre-bill export pasted); Teams.

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Bill Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Answers 'can I bill X to client Y?' from that client's outside counsel guidelines, quoting the governing rule with its section number, and reviews a pasted pre-bill for entries that break a guideline. Flags when pre-approval is needed. Says so when no rule covers a question.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3641 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: the client's OCG file(s) in SharePoint (one folder per client works well). Without knowledge, attach or paste the OCG in the chat. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Can I bill this?**: Using the outside counsel guidelines I attached, can I bill [TASK] to [CLIENT]?
- **Review a pre-bill**: Review this pre-bill against the guidelines I attached. List every entry that breaks a rule. Pre-bill: [PASTE]
- **Approval needed?**: Does [TASK, e.g. 5 hours of legal research] need pre-approval under these guidelines, and from whom?
- **Rate and staffing rules**: Summarize every staffing, timekeeper-level, and rate rule in these guidelines, quoting each with its section number.
- **Travel and expenses**: What do these guidelines say about travel time and expense reimbursement? Quote each rule.

## What it will NOT do
- Give a final yes beyond what the written rule supports.
- Invent a rule or fill a gap with industry custom; if no rule covers it, it says so and suggests asking the client's billing contact.
- Change time entries or send anything to a client.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
