# Sample input: client OCG excerpt and a pre-bill (invented)

All names and numbers are invented. Thornwood Garza LLP is a fictional firm.

## Part 1: Outside Counsel Guidelines (excerpt)
**Cedar Ridge Mutual Insurance Company: Outside Counsel Billing Guidelines, Rev. 2024**

**1. Billing increments.** Time must be recorded and billed in increments of one-tenth (0.1) of an hour. Minimum charges are not permitted.

**2. Block billing.** Each task must be listed as a separate entry with its own time. Block-billed entries that combine two or more tasks in a single time entry will not be paid.

**3. Clerical and administrative tasks.** Clerical, secretarial, and administrative tasks, including scheduling, filing, copying, scanning, calendar entry, and organizing files, are overhead and are not billable, regardless of who performs them.

**4. Deposition attendance.** No more than two (2) timekeepers from Firm may attend and bill for any deposition without prior written approval of Cedar Ridge's Claims Counsel.

**5. Legal research.** Legal research in excess of three (3) hours on any single issue requires prior written approval from the Claims Counsel assigned to the matter.

**6. Travel.** Non-working travel time is billable at fifty percent (50%) of the timekeeper's approved rate. Local travel within 25 miles of the Firm's office is not billable.

**7. Staffing.** First-year associates and summer associates may not bill time to Cedar Ridge matters without prior written approval. Paralegal time is billable only for substantive legal work and at the approved paralegal rate.

**8. Intra-office conferences.** Conferences between Firm timekeepers are billable only for the timekeeper with the higher billing rate, unless the conference is substantive and approved in advance.

**9. Document review.** Review of documents by more than one timekeeper requires a narrative explaining why each reviewer was necessary.

**10. Preparing the bill.** Time spent preparing, reviewing, or correcting invoices, responding to billing questions, or preparing budgets is not billable.

**11. Vague narratives.** Entries using only "attention to," "work on," "review file," or similar descriptions without identifying the subject will be returned.

## Part 2: Pre-bill (Matter: Cedar Ridge v. Dunmore Roofing, Inc., No. 24CV-004417)

| # | Date | Timekeeper (level) | Hours | Narrative |
|---|------|--------------------|-------|-----------|
| 1 | 02/03 | R. Okonkwo (Partner) | 0.5 | Telephone conference with client regarding deposition schedule |
| 2 | 02/03 | L. Brandt (1st-year Associate) | 3.2 | Draft motion to compel; research standard for sanctions |
| 3 | 02/04 | S. Whitcomb (Paralegal) | 1.0 | Organize deposition exhibits binder; scan and index exhibits |
| 4 | 02/05 | R. Okonkwo (Partner) | 7.5 | Attend deposition of D. Marchetti; draft summary of testimony |
| 5 | 02/05 | A. Delacroix (Associate) | 7.5 | Attend deposition of D. Marchetti |
| 6 | 02/05 | L. Brandt (1st-year Associate) | 7.5 | Attend deposition of D. Marchetti; take notes |
| 7 | 02/06 | A. Delacroix (Associate) | 4.2 | Legal research on comparative fault apportionment under California law; follow-up research on cross-complaint standards |
| 8 | 02/07 | R. Okonkwo (Partner) | 0.25 | Review email from opposing counsel |
| 9 | 02/10 | A. Delacroix (Associate) | 2.0 | Travel to Dunmore Roofing office, Fresno (180 miles), non-working |
| 10 | 02/11 | S. Whitcomb (Paralegal) | 0.8 | Prepare January invoice and respond to client's billing questions |
