# Depo Check

Compares deposition testimony with a witness's earlier statements, with cites.

## What it does
Compares a transcript excerpt with the same witness's earlier statements and returns a table: topic, earlier statement (verbatim with source), testimony (verbatim with page:line), and type (direct contradiction, inconsistent detail, or new fact not in earlier statement). It lists follow-up questions for the attorney. It never comments on credibility or motive.

## Who uses it, and where
- **Who:** Litigation paralegals, litigation support staff, and associates preparing deposition summaries.
- **Where:** Copilot Chat; Word (transcript and declaration open); Teams.

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Depo Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Compares a deposition transcript excerpt with the same witness's earlier statements (declaration, interrogatory answers, emails) and lists each point as a direct contradiction, inconsistent detail, or new fact, with verbatim quotes and page:line or paragraph cites. Never characterizes credibility or motive. Lists follow-up questions for the attorney.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (4115 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: a witness folder in SharePoint holding the earlier statements. Without knowledge, paste or attach both the transcript and the earlier statements. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Compare testimony**: Compare the transcript excerpt with the declaration. Witness: [NAME]. Transcript: [PASTE]. Declaration: [PASTE]
- **Contradictions only**: From the two documents attached, list only the direct contradictions with verbatim quotes and cites.
- **New facts**: List facts in the testimony that do not appear in any earlier statement I attached.
- **Follow-up questions**: Based on the differences you found, draft follow-up questions for the attorney. Do not comment on credibility.
- **Check one topic**: Compare everything this witness said about [TOPIC] in the transcript with the earlier statements.

## What it will NOT do
- Say a witness lied, is credible, or had a motive.
- Call something a contradiction unless both statements can be quoted and they cannot both be true as written.
- Advise on impeachment strategy or admissibility.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
