# Sample input: declaration and deposition excerpt (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. The case is fictional.

Matter: Ellison Park Properties, LLC v. Calloway Mechanical Services, Inc. (invented), Superior Court, Case No. 24CV-009215. Witness: Dominic Ferreira, site supervisor for Calloway.

## Part 1: Declaration of Dominic Ferreira (signed June 12, 2024)

1. I am the site supervisor for Calloway Mechanical Services, Inc. I have personal knowledge of the facts below.
2. Calloway was hired to replace the rooftop air handling units at the Ellison Park office building at 410 Larch Street.
3. The work began on August 7, 2023.
4. I was present at the site every day from August 7 through August 18, 2023.
5. On August 14, 2023, I inspected the second unit and noted no damage to the roof membrane.
6. I did not receive any complaint about water intrusion from the building manager during the project.
7. Three Calloway employees worked on the roof on August 15, 2023: myself, Brandon Teague, and Alicia Moreau.
8. I first learned of water leaks in the building when I received a letter from Ellison Park's counsel in November 2023.
9. After the project, Calloway sent a final invoice for $184,000. Ellison Park has not paid the invoice.
10. Calloway's crane operator for the project was Dale Prentiss, and he was on site for two days.

## Part 2: Deposition of Dominic Ferreira, taken October 22, 2024 (excerpt)

Page 41
01 Q. Mr. Ferreira, when did Calloway start the roof work?
02 A. We mobilized on August 7th, 2023.
03 Q. And were you at the site every day of the project?
04 A. Most days. I was off on the 11th and 14th, I think, for a family matter.
05 Q. Who was supervising on those days?
06 A. Brandon Teague covered for me.
07 Q. Did anyone from Calloway inspect the second unit?
08 A. Yes, I did. That was on the 16th.
09 Q. Did you see any damage to the membrane?
10 A. I noted a small tear near the curb on unit two. I photographed it.

Page 42
01 Q. Did you tell anyone about the tear?
02 A. I mentioned it to the building manager, Gloria Santangelo, that afternoon.
03 Q. Did she ever complain to you about water coming into the building?
04 A. Yes. On August 21st she called me about a leak on the fourth floor.
05 Q. So you learned about leaks in August?
06 A. Yes, that was the first I heard of it.
07 Q. How many Calloway employees worked on the roof on the 15th?
08 A. Three of us, myself, Brandon, and Alicia Moreau.
09 Q. And who ran the crane?
10 A. Dale Prentiss. He was here for two days.
11 Q. Has Ellison Park paid the final invoice?
12 A. No. It was $184,000 and it is still outstanding.
