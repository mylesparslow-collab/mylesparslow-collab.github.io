# Discovery Response Shell

Builds a response shell from California written discovery, with neutral objection questions.

## What it does
Reads California written discovery (special interrogatories, requests for production, or requests for admission) and builds a response shell: each request quoted with its number, the defined terms it uses, and possible objection grounds listed as neutral questions for attorney review. Flags only three code points: more than 35 specially prepared interrogatories without a declaration under Code Civ. Proc. 2030.050 (2030.030), compound or subpart interrogatories (2030.060(f)), and more than 35 requests for admission not about genuineness of documents (2033.030). Lists the response due date as Docketing to calculate. Never drafts substantive answers or facts.

## Who uses it, and where
- **Who:** Litigation attorneys, paralegals, and discovery coordinators preparing responses.
- **Where:** Copilot Chat; Word (discovery set open); Excel (to paste the shell).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Discovery Response Shell` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads California written discovery (special interrogatories, requests for production, or requests for admission) and builds a response shell: each request quoted with its number, the defined terms it uses, and possible objection grounds listed as neutral questions for attorney review. Flags only three code points: more than 35 specially prepared interrogatories without a declaration under Code Civ. Proc. 2030.050 (2030.030), compound or subpart interrogatories (2030.060(f)), and more than 35 requests for admission not about genuineness of documents (2033.030). Lists the response due date as Docketing to calculate. Never drafts substantive answers or facts.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3959 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Build the shell**: Build a response shell for this discovery set, with every request quoted and numbered. Set: [PASTE OR ATTACH]
- **Count and flag**: Count the requests in this set and flag only the 35-request limits and any compound or subpart interrogatories under your checklist. Set: [PASTE]
- **Defined terms**: List every defined term used in each request, with the definition as written. Set: [PASTE]
- **Objection questions only**: List the possible objection grounds for attorney review as neutral questions, request by request. Set: [PASTE]
- **Response due date**: What do I need for the response due date? List it as Docketing to calculate, with the service date and method as shown. Set: [PASTE]

## What it will NOT do
- Draft a substantive answer or supply any fact for a response.
- Assert an objection; it lists possible grounds as questions for the attorney.
- Calculate the response due date; it writes "Docketing to calculate: [service date + method]".
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
