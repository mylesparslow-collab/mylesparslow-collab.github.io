# Sample input: California special interrogatories, Set One (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Delmar Okafor and Sunridge Property Management, Inc. do not exist. Only six interrogatories are written out in full; the rest are shortened for the demonstration.

---

SUPERIOR COURT OF THE STATE OF CALIFORNIA, COUNTY OF EXAMPLE
DELMAR OKAFOR, Plaintiff, v. SUNRIDGE PROPERTY MANAGEMENT, INC., Defendant. Case No. 26CV-04417

PLAINTIFF'S SPECIAL INTERROGATORIES TO DEFENDANT SUNRIDGE PROPERTY MANAGEMENT, INC., SET ONE

PROPOUNDING PARTY: Plaintiff Delmar Okafor
RESPONDING PARTY: Defendant Sunridge Property Management, Inc.
SET NUMBER: One
Date of service: October 2, 2026, by mail.

**DEFINITIONS**
- "YOU" and "YOUR" mean Defendant Sunridge Property Management, Inc. and its employees, agents, and contractors.
- "PROPERTY" means the apartment building at 22 Alder Court, Example City.
- "INCIDENT" means the water leak and resulting damage in Plaintiff's unit on or about June 14, 2026.
- "COMMUNICATION" means any transmission of information by any means.
- "IDENTIFY," with respect to a COMMUNICATION, means to state its date, its author, its recipients, and its substance.
- "PERSON" means any natural person or entity.

**SPECIAL INTERROGATORIES**

**SPECIAL INTERROGATORY NO. 1:** State the full name, address, and job title of each PERSON who was responsible for maintaining the PROPERTY on the date of the INCIDENT.

**SPECIAL INTERROGATORY NO. 2:** State the date on which YOU first received notice of the water leak in the unit leased by PLAINTIFF.

**SPECIAL INTERROGATORY NO. 3:** State the date YOU repaired the leak.

**SPECIAL INTERROGATORY NO. 4:** State the name of the contractor who made the repair.

**SPECIAL INTERROGATORY NO. 5:** State the cost of the repair.

**SPECIAL INTERROGATORY NO. 6:** State the date of the last inspection before the INCIDENT.

**SPECIAL INTERROGATORY NO. 7:** State the name, address, and telephone number of each PERSON who witnessed the INCIDENT and describe what each PERSON saw.

**SPECIAL INTERROGATORY NO. 8:** State the number of units in the PROPERTY.

**SPECIAL INTERROGATORY NO. 9:** State the date YOU acquired management of the PROPERTY.

**SPECIAL INTERROGATORY NO. 10:** State whether YOU carried liability insurance on the INCIDENT date.

**SPECIAL INTERROGATORY NO. 11:** State the name of YOUR insurer on the INCIDENT date.

**SPECIAL INTERROGATORY NO. 12:** State the total number of maintenance requests YOU received for the PROPERTY from January 1, 2024 through the date of the INCIDENT.

**SPECIAL INTERROGATORY NO. 13:** State the number of employees assigned to the PROPERTY.

**SPECIAL INTERROGATORY NO. 14:** State the name of the property manager on the INCIDENT date.

**SPECIAL INTERROGATORY NO. 15:** State the date of YOUR first contact with PLAINTIFF.

**SPECIAL INTERROGATORY NO. 16:** State the monthly rent charged to PLAINTIFF.

**SPECIAL INTERROGATORY NO. 17:** State the date PLAINTIFF'S lease began.

**SPECIAL INTERROGATORY NO. 18:** State whether YOU have a written maintenance policy.

**SPECIAL INTERROGATORY NO. 19:** State the date of YOUR most recent maintenance policy revision.

**SPECIAL INTERROGATORY NO. 20:** State the name of the person who wrote the policy.

**SPECIAL INTERROGATORY NO. 21:** IDENTIFY all COMMUNICATIONS between YOU and PLAINTIFF'S landlord or PLAINTIFF'S renter's insurer concerning the INCIDENT, and state whether YOU contend that either of them was responsible for the INCIDENT.

**SPECIAL INTERROGATORY NO. 22:** State the date YOU received PLAINTIFF'S written repair request.

**SPECIAL INTERROGATORY NO. 23:** State the name of the person who received it.

**SPECIAL INTERROGATORY NO. 24:** State what action YOU took in response to it.

**SPECIAL INTERROGATORY NO. 25:** State the date of that action.

**SPECIAL INTERROGATORY NO. 26:** State whether the leak had occurred before.

**SPECIAL INTERROGATORY NO. 27:** State the date of any earlier leak in the unit.

**SPECIAL INTERROGATORY NO. 28:** State whether YOU notified PLAINTIFF of the repair schedule.

**SPECIAL INTERROGATORY NO. 29:** State the date of that notice.

**SPECIAL INTERROGATORY NO. 30:** State whether any inspection of the PROPERTY's plumbing was performed in the five years before the INCIDENT.

**SPECIAL INTERROGATORY NO. 31:** State the date of the plumbing inspection, if any.

**SPECIAL INTERROGATORY NO. 32:** State the name of the inspector.

**SPECIAL INTERROGATORY NO. 33:** State whether the inspector issued a written report.

**SPECIAL INTERROGATORY NO. 34:** State the date of the report.

**SPECIAL INTERROGATORY NO. 35:** State whether YOU retained the report.

**SPECIAL INTERROGATORY NO. 36:** State where the report is kept.

**SPECIAL INTERROGATORY NO. 37:** State whether YOU contend PLAINTIFF contributed to the INCIDENT.

**SPECIAL INTERROGATORY NO. 38:** State the date YOU first learned of any damage to PLAINTIFF'S property.

Dated: October 2, 2026. Counsel for Plaintiff.
(No declaration for additional discovery is attached to this set.)
