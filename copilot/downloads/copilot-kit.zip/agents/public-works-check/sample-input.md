# Sample input: public works contract excerpt (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. The City of Larkspur Hills does not exist.

---

CITY OF LARKSPUR HILLS
CONSTRUCTION CONTRACT
CIVIC CENTER ROOF REPLACEMENT, PROJECT NO. PW-25-03

This Contract is made on June 2, 2025 between the City of Larkspur Hills ("City") and Granite Peak Roofing Inc. ("Contractor").

**1. Contract Price.** The City shall pay the Contractor $1,480,000 for the Work.

**2. Wages.** The Contractor shall pay all workers not less than the prevailing rates of per diem wages applicable to the Work and shall comply with all applicable labor laws.

**3. Subcontractors.** The Contractor shall list each subcontractor in its bid and shall not substitute a subcontractor without the City's written consent.

**4. Payment.** The City shall pay monthly progress payments within thirty (30) days after approval of the Contractor's application. The City shall retain ten percent (10%) of each progress payment until Final Completion.

**5. Bonds.** Within ten (10) days after award, the Contractor shall furnish a performance bond and a payment bond, each in the amount of one hundred percent (100%) of the Contract Price, from a surety admitted in California.

**6. Time and Liquidated Damages.** The Work shall be completed within one hundred eighty (180) calendar days after the Notice to Proceed. For each day of delay the Contractor shall pay the City liquidated damages of $1,200.

**7. Changes.** The City may order changes in the Work. No change is binding unless made by a written change order signed by the City Manager. The Contractor shall submit any claim for added time or cost within seven (7) days after the event giving rise to it, or the claim is waived.

**8. Claims.** The Contractor shall submit claims in writing to the City promptly. The City will respond within a reasonable time. Disputes shall be resolved in the superior court of the county in which the City is located.

**9. Insurance.** The Contractor shall maintain commercial general liability insurance of not less than $2,000,000 per occurrence and workers' compensation insurance as required by law, naming the City as additional insured.

**10. Indemnity.** The Contractor shall indemnify and hold harmless the City and its officers from all claims arising out of the Work, including claims caused in part by the City's negligence.
