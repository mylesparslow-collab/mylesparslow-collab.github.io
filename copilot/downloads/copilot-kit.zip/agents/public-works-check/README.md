# Public Works Check

Checks a California public works contract against a statutory checklist.

## What it does
Checks a California public works contract or bid package against a checklist and reports Present, Missing, or Unclear with the text quoted: prevailing wage (Lab. Code section 1773.2), Department of Industrial Relations registration (sections 1725.5 and 1771.1), retention (Pub. Cont. Code section 7201, with anything above 5 percent flagged), the payment bond (Civ. Code section 9550), and the claims procedure (Pub. Cont. Code section 9204). It also reports notice and claim deadlines as written, liquidated damages, change orders, insurance, and indemnity. The attorney decides.

## Who uses it, and where
- **Who:** Construction and government attorneys, contract administrators, and paralegals reviewing bid packages.
- **Where:** Copilot Chat; Word (contract or bid package open); Outlook (attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Public Works Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Checks a California public works contract or bid package against a fixed checklist and reports Present, Missing, or Unclear with the text quoted: prevailing wage rates or their availability (Lab. Code 1773.2), contractor and subcontractor DIR registration (Lab. Code 1725.5, 1771.1), retention (Pub. Cont. Code 7201), payment bond (Civ. Code 9550), and the public works claims procedure (Pub. Cont. Code 9204). Also reports notice and claim deadlines as written, liquidated damages, change orders, insurance, and indemnity. Flags retention above 5 percent. Does not decide compliance.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3497 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check this contract**: Check this public works contract against your checklist. Contract: [PASTE OR ATTACH]
- **Retention**: What does this contract say about retention? Quote it and flag anything above the checklist limit. Contract: [PASTE]
- **Claims clause**: Compare this contract's claims clause with each element of the claims procedure on your checklist. Contract: [PASTE]
- **Deadlines as written**: List every notice, claim, and time limit in this contract exactly as written, with the section. Do not compute dates. Contract: [PASTE]
- **Note to the attorney**: Draft a short note to the responsible attorney listing what to look at in this contract. Use only your checklist findings.

## What it will NOT do
- Say a contract is compliant, valid, or enforceable.
- Compute any deadline. It lists notice and claim periods as the contract writes them.
- Rewrite clauses unless the user asks, and then only as a suggestion for the attorney.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
