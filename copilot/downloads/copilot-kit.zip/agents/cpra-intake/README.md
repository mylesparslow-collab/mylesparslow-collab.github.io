# Records Request Intake

Splits a Public Records Act request into asks, custodians, and search terms.

## What it does
Reads a California Public Records Act request and turns it into a working intake. It numbers each distinct ask with the requester's words quoted, suggests likely custodians, search terms, and date ranges, and lists possible exemption categories as questions for counsel (never decisions). It restates the timing rule in Gov. Code section 7922.535 and gives a tenth-calendar-day date only when you supply the receipt date. It drafts a short neutral acknowledgment letter for staff review with no exemption claims.

## Who uses it, and where
- **Who:** City and county attorneys' staff, clerks, and paralegals who log public records requests.
- **Where:** Copilot Chat; Outlook (request email open or forwarded); Word.

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Records Request Intake` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a California Public Records Act request, an email or a letter, and splits it into each distinct request with the text quoted. For each it lists likely record custodians, search terms, and date range, and poses possible exemption categories as questions for counsel to consider. States the response timing rule in the statute and gives a tenth-day date only if the user supplies the receipt date, marked for the clerk to confirm. Drafts a short neutral acknowledgment letter with no exemption claims. Never decides what is disclosed.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3559 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Intake this request**: Read this public records request and split it into each distinct ask. Request: [PASTE EMAIL OR LETTER]
- **With receipt date**: This request was received on [DATE]. Intake it and give the tenth calendar day for the clerk to confirm. Request: [PASTE]
- **Custodians and search terms**: For each ask in this request, list likely custodians, search terms, and date range. Request: [PASTE]
- **Acknowledgment letter**: Draft a short neutral acknowledgment letter for staff review. Make no exemption claims. Request: [PASTE]
- **Questions for counsel**: List the questions counsel should consider on each ask, phrased as questions, never answers. Request: [PASTE]

## What it will NOT do
- Decide that a record is exempt or must be disclosed. Exemption categories appear only as questions for counsel.
- Give a response date unless you supply the receipt date, and then it is labelled for the clerk to confirm.
- Put any exemption claim or legal position in the acknowledgment letter.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
