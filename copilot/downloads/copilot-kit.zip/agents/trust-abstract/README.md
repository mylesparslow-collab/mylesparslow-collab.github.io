# Trust Abstract

Abstracts a trust by article and section, with questions for the attorney.

## What it does
Abstracts a revocable or irrevocable trust instrument into a table, citing the article and section for each item and quoting the key words: name and date, settlors, initial trustees, successor trustees in order, how incapacity is determined, notable trustee powers, distributions (specific gifts, residue, subtrusts, ages and conditions), pour-over, no-contest clause, amendment and revocation, governing law, and signatures and notary as shown. It then lists questions for the attorney about gaps, internal inconsistencies, and missing contingent beneficiaries. It never advises on tax.

## Who uses it, and where
- **Who:** Trusts and estates attorneys, paralegals, and trust administrators.
- **Where:** Copilot Chat; Word (trust open); Outlook (trust attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Trust Abstract` (30 characters max). Description: paste the text below (1,000 characters max).

   > Abstracts a revocable or irrevocable trust instrument: name and date, settlors, initial and successor trustees in order, how incapacity is determined, notable trustee powers, distributions during life and at death (specific gifts, residue, subtrusts, ages and conditions), pour-over, no-contest clause, amendment and revocation, governing law, and signatures and notary as shown. Cites the article and section for each item and quotes key words. Lists questions for the attorney on gaps, inconsistencies, and missing contingent beneficiaries. Never advises on tax.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (2902 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Abstract this trust**: Abstract this trust instrument into your table with articles, sections, and quotes, then list questions for the attorney. Trust: [PASTE OR ATTACH]
- **Successor trustees**: Who serves as trustee, and in what order? Quote each provision with its section. Trust: [PASTE]
- **Distributions**: Summarize every distribution at the settlor's death (gifts, residue, subtrusts, ages and conditions), quoting each with its section. Trust: [PASTE]
- **Gaps and inconsistencies**: List only gaps, inconsistencies, and missing contingent beneficiaries in this trust, quoted. Trust: [PASTE]
- **Incapacity and amendment**: Quote how incapacity is determined and how the trust may be amended or revoked. Trust: [PASTE]

## What it will NOT do
- Give tax advice or say how a distribution will be taxed.
- Say the trust is valid, effective, or properly executed. It reports the signature and notary blocks as shown.
- Fill a gap with an assumption. It lists the gap as a question for the attorney.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
