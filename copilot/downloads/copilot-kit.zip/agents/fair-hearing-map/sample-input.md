# Sample input: medical staff bylaws excerpt and notice letter (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Briarwood Regional Medical Center does not exist. The notice letter is deliberately incomplete for demonstration.

---

BRIARWOOD REGIONAL MEDICAL CENTER
MEDICAL STAFF BYLAWS (EXCERPT), ARTICLE VII: CORRECTIVE ACTION AND FAIR HEARING

**7.1 Corrective Action.** Whenever a practitioner's conduct or clinical performance is, or is reasonably likely to be, detrimental to patient safety or to the delivery of quality care, any officer of the Medical Staff, the chair of a clinical department, or the Medical Executive Committee ("MEC") may request an investigation in writing.

**7.2 Action by the MEC.** The MEC will consider a request for corrective action at its next regular meeting. The MEC may reduce, suspend, or revoke clinical privileges.

**7.3 Notice of Adverse Action.** Within ten (10) days after the MEC votes to recommend an adverse action, the Chief of Staff will give the practitioner written notice by certified mail. The notice will state the action recommended, the reasons for it, and that the practitioner may request a hearing.

**7.4 Request for Hearing.** The practitioner has thirty (30) days after receiving the notice to request a hearing in writing to the Chief of Staff. Failure to request a hearing within that time is a waiver of the right to a hearing and to appellate review.

**7.5 Hearing Panel.** The Chief of Staff will appoint a Hearing Panel of five Medical Staff members who are not in direct economic competition with the practitioner. The Chief of Staff may also appoint a hearing officer, who is an attorney and does not vote.

**7.6 Documents.** The practitioner may inspect and copy the documents on which the MEC relied no later than ten (10) days before the hearing.

**7.7 Hearing.** The hearing will begin within sixty (60) days after the request is received. At the hearing, the practitioner may be represented by an attorney and may present evidence. The MEC may call and examine witnesses.

**7.8 Burden of Proof.** The practitioner has the burden of showing that the recommended action lacks substantial justification.

**7.9 Decision and Appeal.** The Hearing Panel will give a written recommendation within thirty (30) days after the hearing closes. Either side may request appellate review by the Governing Board in writing within fifteen (15) days after receiving the recommendation. The Governing Board's decision is final.

**7.10 Reports.** The Chief of Staff will cause any report required by law to be filed after a final action.

---

NOTICE LETTER

Briarwood Regional Medical Center, Office of the Chief of Staff
October 15, 2026
By certified mail

Dr. Anselm Kowalczyk-Reyes
Department of Surgery

Dear Dr. Kowalczyk-Reyes:

On October 8, 2026, the Medical Executive Committee voted to recommend suspension of your clinical privileges in general surgery for ninety (90) days. The reasons are the four surgical cases listed in the attached Schedule 1, in which the MEC found deviations from the department's standard of care.

You may request a hearing on this recommendation by writing to the Chief of Staff. A Hearing Panel will be appointed under Section 7.5 of the Bylaws. If you have questions, please contact the Medical Staff Office.

Sincerely,
Dr. Imelda Farrow-Nakamura
Chief of Staff
