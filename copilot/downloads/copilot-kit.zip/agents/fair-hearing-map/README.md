# Fair Hearing Map

Maps a hospital's corrective action and fair hearing process as the bylaws write it.

## What it does
Reads hospital medical staff bylaws, and a notice letter if one is given, and maps the corrective action and fair hearing process as the bylaws write it: triggers, who gives notice, notice contents, time to request a hearing as written, hearing panel or officer selection, voir dire, document access, rights at the hearing, burden of proof, appellate review, and reportable events. Cross-references four points of Cal. Bus. & Prof. Code 809 et seq. (809.1(b), 809.2(c), 809.2(d), 809.3) with Present, Missing, or Unclear and the text quoted. Never computes a date and does not decide whether a process is fair or compliant.

## Who uses it, and where
- **Who:** Health care and medical staff attorneys, paralegals, and medical staff office counsel.
- **Where:** Copilot Chat; Word (bylaws or notice letter open); Outlook (documents attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Fair Hearing Map` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads hospital medical staff bylaws, and a notice letter if one is given, and maps the corrective action and fair hearing process as the bylaws write it: triggers, who gives notice, notice contents, time to request a hearing as written, hearing panel or officer selection, voir dire, document access, rights at the hearing, burden of proof, appellate review, and reportable events. Cross-references four points of Cal. Bus. & Prof. Code 809 et seq. (809.1(b), 809.2(c), 809.2(d), 809.3) with Present, Missing, or Unclear and the text quoted. Never computes a date and does not decide whether a process is fair or compliant.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3609 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Map this process**: Map the corrective action and fair hearing process in these bylaws as written, step by step with quotes, then check it against your four Business and Professions Code 809 points. Bylaws: [PASTE OR ATTACH]
- **Check the notice letter**: Check this notice letter against the notice contents the bylaws require and the 809.1(b) hearing-request point. Bylaws: [PASTE] Letter: [PASTE]
- **Hearing rights only**: Quote everything these bylaws say about voir dire, document access, witnesses, and evidence at the hearing. Bylaws: [PASTE]
- **Deadlines as written**: List every time period in these bylaws and in this notice letter exactly as written, with its trigger. Do not compute any date. Documents: [PASTE]
- **Missing or unclear only**: List only the bylaws provisions that are Missing or Unclear against the 809 points, with the text you found. Bylaws: [PASTE]

## What it will NOT do
- Say a hearing process is fair, adequate, or compliant.
- Calculate any date; it writes "Docketing to calculate: [trigger + period as written]".
- Say what law requires beyond its four listed points.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
