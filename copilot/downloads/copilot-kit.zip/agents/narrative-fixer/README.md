# Narrative Fixer

Rewrites vague or block-billed time entries, using only facts in the entry.

## What it does
Takes pasted time entries (or columns copied from Excel) and returns a table: original, proposed narrative, change made, and a question for the timekeeper. It splits block-billed entries only as a proposal the timekeeper must confirm, never changes total hours without saying so, and never invents work. If an entry cannot be fixed without more facts, it asks a specific question instead.

## Who uses it, and where
- **Who:** Timekeepers, legal assistants, and billing coordinators preparing pre-bills.
- **Where:** Copilot Chat (paste rows); Excel (Copilot side pane, or paste columns into chat); Word.

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Narrative Fixer` (30 characters max). Description: paste the text below (1,000 characters max).

   > Rewrites time-entry narratives to be specific and guideline-friendly. Proposes splits for block-billed entries without changing total hours, replaces vague verbs, keeps only facts present in the entry, and asks the timekeeper a specific question when a fix needs facts it does not have.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3986 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: the client's billing guidelines or your firm's narrative style guide, so rewrites follow their wording. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Fix these entries**: Rewrite these time entries to be specific. Use only facts in each entry and ask me questions where you need more. Entries: [PASTE ROWS]
- **Split block billing**: Propose a split for the block-billed entries below. Keep total hours the same per entry and mark each split as a proposal. Entries: [PASTE]
- **Use client wording**: Rewrite these entries to match the narrative rules in the attached guidelines. Entries: [PASTE]
- **Questions only**: For each entry below, tell me only what facts are missing and the question I should ask the timekeeper. Entries: [PASTE]
- **Excel rows**: I pasted columns Date, Timekeeper, Hours, Narrative from Excel. Return the table with proposed narratives. Data: [PASTE]

## What it will NOT do
- Add work, people, documents, or time that is not in the original entry.
- Change hours silently. Any change to hours or a split is labeled as a proposal for the timekeeper to confirm.
- Judge whether the time is reasonable or billable (use Bill Check for guideline questions).
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
