# Sample input: 12 messy time entries (invented)

Invented entries for demonstration. Thornwood Garza LLP is a fictional firm. Matter: Lakemont Freight Partners v. Sable Harbor Logistics, Inc. (invented).

Columns: Date | Timekeeper | Hours | Narrative

| Date | Timekeeper | Hours | Narrative |
|------|-----------|-------|-----------|
| 03/03/2025 | N. Bautista (Assoc) | 2.5 | Work on discovery |
| 03/03/2025 | T. Iyer (Partner) | 1.0 | Review file |
| 03/04/2025 | N. Bautista (Assoc) | 4.0 | Draft responses to RFPs and review client documents and call with client re: production |
| 03/04/2025 | M. Castellanos (Paralegal) | 1.5 | Attention to exhibits |
| 03/05/2025 | T. Iyer (Partner) | 0.7 | Emails |
| 03/05/2025 | N. Bautista (Assoc) | 3.1 | Research; draft section of opposition brief on duty of care, 1.8 on research and 1.3 on drafting |
| 03/06/2025 | M. Castellanos (Paralegal) | 2.0 | Prepare for hearing |
| 03/06/2025 | T. Iyer (Partner) | 0.4 | Telephone conference with J. Okafor (Sable Harbor counsel) regarding extension of time to respond to second set of interrogatories |
| 03/07/2025 | N. Bautista (Assoc) | 5.5 | Follow up on depositions, meeting w/ TI, revise outline, misc. |
| 03/07/2025 | T. Iyer (Partner) | 1.2 | Conference with N. Bautista; review draft meet-and-confer letter; edit |
| 03/10/2025 | M. Castellanos (Paralegal) | 0.6 | Handled filing |
| 03/10/2025 | N. Bautista (Assoc) | 6.0 | Trial prep and strategy |

## Notes from the billing coordinator (for the demo)

The client's guidelines (invented) say each task must be its own entry, that narratives must name the document or subject, and that entries such as "attention to" or "review file" are returned unpaid. The pre-bill goes to the billing partner on Friday. Several of these entries came from timekeepers who were working quickly, so some of the facts needed for a better narrative are simply not in the entry.

Expected behavior in this demo (entries counted top to bottom): entries 3, 9, and 12 are block-billed or vague and cannot be split or sharpened without asking the timekeeper; entries 1, 2, 4, 5, 7, and 11 are vague and need a question; entry 6 already gives the time per task, so a split can use those numbers (1.8 plus 1.3 equals 3.1); entry 8 is already specific and should come back as "No change needed". The agent must not change any hours and must not guess which discovery tasks, which depositions, or which documents are meant.
