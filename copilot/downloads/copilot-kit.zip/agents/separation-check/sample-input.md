# Sample input: draft separation agreement (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Marlowe Ridge Logistics, Inc. does not exist. This draft is deliberately incomplete for demonstration.

---

CONFIDENTIAL SEPARATION AGREEMENT AND GENERAL RELEASE
DRAFT dated May 12, 2025

This Agreement is between Marlowe Ridge Logistics, Inc. ("Company") and Gregory Tanaka ("Employee"), a 52-year-old Operations Manager whose employment ends on May 30, 2025.

**1. Severance.** Provided Employee signs and does not revoke this Agreement, the Company will pay Employee $48,000, less withholdings, in two installments (the "Severance Payment"). Employee agrees that the Severance Payment is good and sufficient consideration for this Agreement.

**2. General Release.** Employee releases the Company and its officers, employees, and agents from all claims, known or unknown, arising on or before the date Employee signs, including claims under the Age Discrimination in Employment Act, Title VII, the California Fair Employment and Housing Act, and any claim for wages, bonuses, or overtime.

**3. Consideration and Revocation.** Employee has fourteen (14) days from receipt of this Agreement to consider it. Employee may revoke within seven (7) days after signing. Employee is advised to consult an attorney before signing.

**4. Non-Disparagement.** Employee shall not make any statement that disparages the Company, its management, or its services to any person, including customers, vendors, and the press.

**5. Confidentiality.** Employee shall keep the terms of this Agreement and the circumstances of Employee's separation strictly confidential and shall not disclose them to anyone except Employee's spouse and tax adviser.

**6. Return of Property.** Employee shall return all Company property, including laptop, badge, and files, on or before the last day of employment.

**7. No Rehire.** Employee agrees not to apply for employment with the Company or its affiliates in the future.

**8. Governing Law.** This Agreement is governed by California law.

**9. Entire Agreement.** This is the entire agreement between the parties.

EMPLOYEE: ______________________  Date: ____________

For the Company: ______________________  Date: ____________
