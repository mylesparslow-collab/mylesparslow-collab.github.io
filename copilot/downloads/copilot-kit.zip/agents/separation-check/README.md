# Separation Check

Checks a draft California separation agreement against a drafting checklist.

## What it does
Checks a draft California separation or severance agreement against a checklist and reports Present, Missing, or Unclear with the clause quoted: the general release and Civil Code section 1542 waiver, the older-worker items under 29 U.S.C. section 626(f) (21 days to consider, 45 for a group exit program, 7 to revoke), the carve-out and attorney-consultation notice required by Gov. Code section 12964.5, Code Civ. Proc. section 1001, and wages under Lab. Code section 206.5. It also checks consideration, return of property, no-rehire, governing law, and signatures.

## Who uses it, and where
- **Who:** Employment attorneys, HR counsel, and paralegals reviewing severance and release drafts.
- **Where:** Copilot Chat; Word (draft agreement open); Outlook (draft attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Separation Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Checks a draft California separation or severance agreement against a fixed checklist and reports Present, Missing, or Unclear with the clause quoted: Civil Code 1542 waiver, the age-claim release items for employees 40 or older (ADEA, 29 U.S.C. 626(f)), the required carve-out and attorney-consultation notice for non-disparagement or confidentiality clauses (Gov. Code 12964.5), the bar on silencing harassment or discrimination facts (Code Civ. Proc. 1001), and wages (Lab. Code 206.5), plus consideration, return of property, no-rehire, governing law, and signature lines. Does not decide validity.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (4085 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check this draft**: Check this draft separation agreement against your checklist. Agreement: [PASTE OR ATTACH]
- **Employee is 40 or older**: The employee is [AGE]. Check the age-claim release items in this draft. Agreement: [PASTE]
- **Non-disparagement and confidentiality**: Check every non-disparagement and confidentiality clause in this draft against the required carve-out and notice. Quote each. Agreement: [PASTE]
- **Missing or unclear only**: List only the checklist items that are Missing or Unclear in this draft, with the clause you found. Agreement: [PASTE]
- **Note to the attorney**: Draft a short note to the responsible attorney listing what to look at in this agreement. Use only your checklist findings.

## What it will NOT do
- Say an agreement or release is valid, enforceable, or compliant.
- Decide whether the employee's age claims are released or whether a group exit program applies; it asks.
- Draft replacement clauses unless the user asks, and then only as a suggestion for the attorney.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
