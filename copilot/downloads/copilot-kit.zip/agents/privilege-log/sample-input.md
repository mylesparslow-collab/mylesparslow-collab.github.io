# Sample input: withheld-document list (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. The client is Redfern Tidal Energy, Inc.

Attorneys: Priya Nandakumar, Esq. (Thornwood Garza LLP); Marcus Pell, Esq. (Redfern general counsel). Everyone else is Redfern staff unless noted.

| # | Date | From | To | CC | Subject / file name | Attorney note |
|---|---|---|---|---|---|---|
| 1 | 2025-01-06 | Marcus Pell | Hana Lindqvist | | Review of tidal turbine supply contract | attorney-client |
| 2 | 2025-01-08 | Hana Lindqvist | Marcus Pell | | RE: Review of tidal turbine supply contract | attorney-client |
| 3 | 2025-01-13 | Priya Nandakumar | Marcus Pell | Hana Lindqvist | Memo re: dispute with Pelham Docks Authority | attorney-client; work product |
| 4 | 2025-01-15 | Hana Lindqvist | Owen Barlow | | Pelham dockside inspection notes | attorney-client |
| 5 | 2025-01-21 | Marcus Pell | Priya Nandakumar | | Questions on lease termination notice | attorney-client |
| 6 | 2025-01-22 | Priya Nandakumar | Marcus Pell | Corinne Haverford-Ng; Tessa Brandt (Brandt Strategic Communications) | Draft statement for press, edits | attorney-client |
| 7 | 2025-01-27 | Marcus Pell | Hana Lindqvist | | Counsel's advice that our position on the notice is weak | attorney-client |
| 8 | 2025-02-03 | Hana Lindqvist | Marcus Pell | | Spreadsheet of berth fees 2022-2024 prepared for counsel | work product |
| 9 | 2025-02-05 | Marcus Pell | Priya Nandakumar | | Berth fee questions | attorney-client |
| 10 | 2025-02-10 | Priya Nandakumar | Marcus Pell | | Outline of deposition topics | work product |
| 11 | 2025-02-12 | Hana Lindqvist | Marcus Pell | | Meeting follow-up | attorney-client |
| 12 | 2025-02-14 | Marcus Pell | Hana Lindqvist | Owen Barlow | Insurance notice question | attorney-client |
