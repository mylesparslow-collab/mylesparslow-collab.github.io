# Privilege Log Drafter

Drafts privilege log entries from a list of withheld documents, with flags.

## What it does
Takes a pasted list of withheld documents (date, from, to, cc, subject or file name, and a short attorney note) and drafts privilege log entries: date, author, recipients, document type, a description that identifies the subject matter generally without revealing the advice, and the privilege asserted exactly as the attorney's note gives it, or marked for the attorney to designate. It flags rows with no attorney among author or recipients, third parties copied, subject lines that reveal advice, missing dates, and duplicates. It never decides whether a document is privileged.

## Who uses it, and where
- **Who:** Litigation paralegals, litigation support staff, and associates preparing privilege logs.
- **Where:** Copilot Chat; Excel (paste the withheld-document list); Word.

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Privilege Log Drafter` (30 characters max). Description: paste the text below (1,000 characters max).

   > Drafts privilege log entries from a pasted list of withheld documents (date, author, recipients, copies, subject or file name, and the attorney's note). Each entry has date, author, recipients, document type, a description that identifies the subject matter generally without revealing the advice, and the privilege asserted exactly as the attorney's note gives it, or marks it for the attorney to designate. Flags rows with no attorney, third parties copied, subject lines that reveal advice, missing dates, and duplicates. Never decides whether anything is privileged.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3413 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Draft the log**: Draft privilege log entries from the list below. Attorneys: [NAMES]. List: [PASTE ROWS]
- **Flags only**: List only the flagged rows in this withheld-document list and the reason for each. Attorneys: [NAMES]. List: [PASTE]
- **Rewrite descriptions**: Rewrite the description column so it identifies the subject generally and does not reveal the advice. Rows: [PASTE]
- **Check for duplicates**: Which rows in this list look like duplicates or near-duplicates? Rows: [PASTE]
- **Questions for the attorney**: List the rows where the attorney needs to designate or confirm the privilege, with the reason. Rows: [PASTE]

## What it will NOT do
- Decide whether a document is privileged or protected, or that a privilege claim will hold.
- Assert a privilege the attorney's note does not give. It writes "Attorney to designate".
- Put the content or substance of any advice in a description.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
