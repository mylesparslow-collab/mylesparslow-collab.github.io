# Phase I Reader

Lists exactly what a Phase I report itself labels as RECs, CRECs, HRECs, data gaps, and recommendations.

## What it does
Reads a Phase I Environmental Site Assessment and lists, with page cites and quotes, exactly what the report itself labels as recognized environmental conditions, controlled RECs, historical RECs, de minimis conditions, data gaps (and whether the report calls any significant), business environmental risks, and recommendations. Also lists the site, user, report and site visit dates, the environmental professional, and the standard the report says it follows. Never classifies a finding itself, and notes that counsel confirms the report's age and viability for the transaction.

## Who uses it, and where
- **Who:** Environmental and real estate attorneys, paralegals, and deal teams reviewing diligence reports.
- **Where:** Copilot Chat; Word (report open); Outlook (report attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Phase I Reader` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a Phase I Environmental Site Assessment and lists, with page cites and quotes, exactly what the report itself labels as recognized environmental conditions, controlled RECs, historical RECs, de minimis conditions, data gaps (and whether the report calls any significant), business environmental risks, and recommendations. Also lists the site, user, report and site visit dates, the environmental professional, and the standard the report says it follows. Never classifies a finding itself, and notes that counsel confirms the report's age and viability for the transaction.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3353 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Read this Phase I**: Read this Phase I report and list what it labels as RECs, CRECs, HRECs, de minimis conditions, data gaps, and business environmental risks, with page cites and quotes. Report: [PASTE OR ATTACH]
- **Findings in the report's words**: Quote the report's findings and conclusions sections exactly, with page numbers. Do not add labels of your own. Report: [PASTE]
- **Data gaps**: List every data gap the report identifies and quote whether the report calls each one significant. Report: [PASTE]
- **Recommendations**: Quote every recommendation in this report with its page number. Report: [PASTE]
- **Report details**: List the site, the user, the environmental professional, the site visit date, the report date, and the standard the report says it follows. Report: [PASTE]

## What it will NOT do
- Classify a condition itself; it reports only the labels the report uses.
- Say a report is current, viable, or sufficient for a transaction; counsel confirms.
- Assess contamination, risk, or liability.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
