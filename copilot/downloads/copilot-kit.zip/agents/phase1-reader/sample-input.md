# Sample input: Phase I Environmental Site Assessment (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Ridgeline Environmental Consulting, Inc., Brindle Capital Partners LLC, and the Calloway Street property do not exist. Page numbers are as shown in the report.

---

[Page i]
PHASE I ENVIRONMENTAL SITE ASSESSMENT
1140 Calloway Street, Harlan Springs
Prepared for: Brindle Capital Partners LLC (the "User")
Prepared by: Ridgeline Environmental Consulting, Inc.
Environmental Professional: Marguerite Ostrander, P.G.
Site reconnaissance: July 28, 2026
Report date: August 21, 2026

[Page 1] 1.0 INTRODUCTION
1.1 Purpose. Ridgeline performed this Phase I Environmental Site Assessment of the approximately 0.8-acre property at 1140 Calloway Street (the "Site") for the User in connection with a proposed acquisition.
1.2 Standard. This assessment was prepared in general conformance with ASTM E1527-21, Standard Practice for Environmental Site Assessments: Phase I Environmental Site Assessment Process.

[Page 6] 3.0 SITE HISTORY
From approximately 1958 to 1994 the Site was occupied by Calloway Dry Cleaners, which used tetrachloroethylene (PCE) in on-site cleaning machines. Since 1996 the Site has been a one-story retail building with four tenant spaces. In 2003 a 1,000-gallon heating oil underground storage tank (UST) at the rear of the building was removed.

[Page 11] 5.0 INTERVIEWS AND RECORDS REVIEW
5.1 The current owner's representative, Tobias Wrenfield, was interviewed on July 28, 2026. He stated he was not aware of any spills at the Site.
5.2 A state environmental agency file for the Site shows that in 2014 the agency issued a closure letter for a groundwater PCE plume associated with the former dry cleaner. The closure letter is conditioned on a recorded restriction that prohibits the use of groundwater at the Site.
5.3 The agency file shows that the 2003 UST was removed and that the agency issued a no-further-action letter without conditions.

[Page 14] 6.0 FINDINGS
6.1 Recognized Environmental Condition. The Phase I identified one recognized environmental condition (REC): the presence of PCE in soil gas beneath the former dry cleaner space, as reported in a 2009 soil gas survey, which was not addressed by the 2014 closure letter. The report did not find that this condition has been investigated since 2009.
6.2 Controlled Recognized Environmental Condition. The groundwater PCE plume is identified as a controlled recognized environmental condition (CREC) because the 2014 closure letter relies on the recorded restriction prohibiting groundwater use.
6.3 Historical Recognized Environmental Condition. The 2003 removal of the heating oil UST is identified as a historical recognized environmental condition (HREC) because the agency issued no-further-action without conditions.
6.4 De minimis conditions. None identified.

[Page 16] 7.0 DATA GAPS
Fire insurance maps for the period 1958 to 1970 were not available, so the use of the rear of the building in those years could not be confirmed. The environmental professional does not consider this data gap significant because the Site's use as a dry cleaner is documented in other sources.
The environmental professional was unable to interview any former owner of the dry cleaner. The environmental professional considers this data gap significant because the dry cleaner operated for 36 years.

[Page 17] 8.0 RECOMMENDATIONS
Ridgeline recommends a limited Phase II subsurface investigation, including soil gas sampling beneath the former dry cleaner space, before closing. Ridgeline further recommends that the User review the recorded groundwater restriction with counsel.

[Page 18] 9.0 CONCLUSIONS
This assessment has revealed the evidence of one REC, one CREC, and one HREC in connection with the Site. No other environmental issues were noted by Ridgeline. In our opinion, the soil gas condition may pose a vapor intrusion risk to future occupants.
