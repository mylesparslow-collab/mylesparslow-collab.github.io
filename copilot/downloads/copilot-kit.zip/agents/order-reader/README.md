# Order Reader

Lists every obligation in a court order, with who, when as written, and where.

## What it does
Reads a court order, minute order, or notice and lists every obligation with what must be done, who must do it, the date or trigger exactly as written, and the paragraph or page. Dates stated in the order are listed as stated. Anything that must be counted from a rule or event is marked "Docketing to calculate" and is never computed by the agent. It ends with the hearings and appearances and items for docketing to confirm.

## Who uses it, and where
- **Who:** Docketing staff, litigation paralegals, legal assistants, and attorneys.
- **Where:** Copilot Chat; Word (order open); Outlook (order attached to an email).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Order Reader` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a court order, minute order, or notice and lists every obligation: what, who must do it, the date or trigger as written, and the paragraph or page. Dates stated in the order are listed as stated. Dates that must be counted from a rule or event are marked for docketing to calculate and are never computed by the agent.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3657 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: none needed. Attach or paste each order in the chat. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **List obligations**: List every obligation in this order with who, what, date or trigger, and paragraph. Order: [PASTE OR ATTACH]
- **Hearings only**: List all hearings, conferences, and appearances in this order with date, time, department, and who must appear.
- **What does docketing check?**: What items in this order need docketing to calculate or confirm? Do not compute any dates.
- **Email summary for team**: Draft a short internal email summarizing this order's obligations for the litigation team. Use only the order's text.
- **Who must do what**: Group the obligations in this order by responsible party (plaintiff, defendant, both, court).

## What it will NOT do
- Calculate, count, or compute any deadline. Docketing staff do that from the rule and trigger.
- Say what a rule requires beyond what the order itself says.
- Replace the calendar. A person enters and confirms all dates.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
