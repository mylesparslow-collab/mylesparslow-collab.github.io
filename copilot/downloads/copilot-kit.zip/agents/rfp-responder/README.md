# RFP Responder

Turns a public agency's legal RFP into dates, a checklist, and a matrix.

## What it does
Reads a public agency's request for proposals for legal services and prepares the working documents: key dates as stated, a submission checklist (format, page limits, copies, portal, signatures, forms), a compliance matrix, the evaluation criteria with weights, insurance and contract terms to send to the firm's risk office or general counsel, and questions to submit to the agency. It quotes the RFP with section numbers. It never writes claims about the firm's experience; the answer, owner, and status columns stay blank for your team.

## Who uses it, and where
- **Who:** Business development staff, marketing, and the attorneys who lead proposals for public-agency work.
- **Where:** Copilot Chat; Word (RFP open); Outlook (RFP attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `RFP Responder` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads a public agency's request for proposals for legal services and builds the working documents: a key dates table as stated, a submission requirements checklist, a compliance matrix with a blank answer column, evaluation criteria with weights, insurance and contract terms quoted for the firm's risk or general counsel, and questions to submit to the agency. Quotes the RFP with section numbers. Never drafts claims about the firm's experience or qualifications.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3183 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Read this RFP**: Read this RFP and give me the key dates, submission checklist, compliance matrix, evaluation criteria, contract terms, and questions. RFP: [PASTE OR ATTACH]
- **Compliance matrix only**: Build only the compliance matrix from this RFP. Leave the answer, owner, and status columns blank. RFP: [PASTE]
- **Terms for risk**: Quote every insurance, indemnity, conflict-of-interest, rate, and billing term in this RFP for our risk office. RFP: [PASTE]
- **Questions to submit**: List the ambiguities and inconsistencies in this RFP as questions to submit to the agency before the question deadline. RFP: [PASTE]
- **Dates table**: Give me a table of every date and deadline in this RFP, as stated, with the section. Do not compute any dates. RFP: [PASTE]

## What it will NOT do
- Write or suggest claims about the firm's experience, clients, results, or qualifications.
- Compute dates. It lists dates and deadlines exactly as the RFP states them.
- Decide whether the firm should bid or accept any contract term. Terms go to risk or the general counsel.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
