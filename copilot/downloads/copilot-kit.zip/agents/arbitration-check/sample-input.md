# Sample input: skilled nursing facility admission packet (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Larkspur Meadows Skilled Nursing Center does not exist. This packet is deliberately problematic for demonstration.

---

LARKSPUR MEADOWS SKILLED NURSING CENTER
RESIDENT ADMISSION AGREEMENT
Date of admission: September 3, 2026

This Admission Agreement is between Larkspur Meadows Operating Company, LLC, which operates Larkspur Meadows Skilled Nursing Center (the "Facility"), and Dorothea Imrie (the "Resident"). Paulina Imrie-Vance, the Resident's daughter, signs as the Resident's "Responsible Party."

**1. Services.** The Facility will provide room, board, nursing care, and the other services described in the attached Schedule of Services.

**2. Payment.** The Resident or the Responsible Party will pay the daily rate in Schedule A on the first business day of each month. The Responsible Party signs to confirm that she has reviewed Schedule A.

**3. Personal Property.** The Facility is not responsible for loss of personal property that is not listed on the inventory form completed at admission.

**9. Visitors.** Visitors are welcome between 8:00 a.m. and 8:00 p.m. and at other times by arrangement with the Administrator.

**11. Complaints.** The Resident and the Responsible Party agree to bring any complaint about care first to the Administrator in writing and to give the Facility thirty (30) days to respond before contacting any outside agency or government office.

**12. Discharge.** The Facility may transfer or discharge the Resident only as described in the Resident Rights notice attached as Schedule C.

**14. Binding Arbitration.**
14.1 Any dispute between the Resident and the Facility, including any claim of negligence or malpractice, will be resolved by binding arbitration and not by a lawsuit or a jury trial. This Section 14 must be signed prior to admission.
14.2 The arbitrator will be selected by the Facility from the panel of the Pacific Resolution Forum, and the arbitration will follow that organization's rules.
14.3 The arbitration will take place at the Facility's offices in Larkspur County.
14.4 The Resident will pay one-half of the filing fee and one-half of the arbitrator's fees. Each party pays its own attorney's fees.
14.5 The Resident may rescind this Section 14 by written notice to the Administrator within fourteen (14) days after signing.

**15. Entire Agreement.** This Agreement, with its Schedules, is the entire agreement between the parties.

SIGNATURES

RESIDENT: ______________________  Date: ____________
Dorothea Imrie

RESPONSIBLE PARTY: ______________________  Date: ____________
Paulina Imrie-Vance, signing as Responsible Party and as agent under a Durable Power of Attorney dated June 2, 2024. The Responsible Party states that she has full authority to bind the Resident to every Section of this Agreement, including Section 14.

FACILITY: ______________________  Date: ____________
By: Calvin Oyelaran, Administrator

ACKNOWLEDGMENT: The Resident and Responsible Party each acknowledge that Section 14 is part of this Agreement and that they have received a copy.
