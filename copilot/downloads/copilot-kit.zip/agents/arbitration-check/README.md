# Admission Arbitration Check

Checks a nursing facility admission packet's arbitration terms against 42 CFR 483.70(m).

## What it does
Reviews a skilled nursing facility admission packet and reports Present, Missing, or Unclear with the text quoted against a fixed checklist drawn from 42 CFR 483.70(m): whether signing is required as a condition of admission or care and whether the right not to sign is stated, the 30-calendar-day right to rescind, and any term that prohibits or discourages communicating with officials. Also lists whether the arbitration terms are separate from the admission agreement, who signs and in what capacity as stated, the arbitrator selection and venue terms as written, and the cost terms as written. Does not decide validity or enforceability.

## Who uses it, and where
- **Who:** Senior housing and health care attorneys, paralegals, and facility counsel reviewing admission packets.
- **Where:** Copilot Chat; Word (admission packet open); Outlook (packet attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Admission Arbitration Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reviews a skilled nursing facility admission packet and reports Present, Missing, or Unclear with the text quoted against a fixed checklist drawn from 42 CFR 483.70(m): whether signing is required as a condition of admission or care and whether the right not to sign is stated, the 30-calendar-day right to rescind, and any term that prohibits or discourages communicating with officials. Also lists whether the arbitration terms are separate from the admission agreement, who signs and in what capacity as stated, the arbitrator selection and venue terms as written, and the cost terms as written. Does not decide validity or enforceability.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (4085 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check this packet**: Check this skilled nursing facility admission packet against your arbitration checklist. Packet: [PASTE OR ATTACH]
- **Condition of admission**: Quote every sentence in this packet that says the arbitration agreement is required, a condition, or must be signed, and every sentence that tells the signer they may decline. Packet: [PASTE]
- **Rescission period**: What rescission period does the arbitration agreement in this packet state? Quote it and compare it with 30 calendar days as written. Do not compute dates. Packet: [PASTE]
- **Who signed, and as what**: List every signature block in this packet with the capacity and any authority language exactly as stated. Packet: [PASTE]
- **Missing or unclear only**: List only the checklist items that are Missing or Unclear in this packet, with the text you found. Packet: [PASTE]

## What it will NOT do
- Say an arbitration agreement is valid, enforceable, voluntary, or compliant.
- Decide whether a signer had authority to sign for the resident; it lists what the document states.
- Say whether an arbitrator or venue is neutral; it quotes the terms and asks the attorney.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
