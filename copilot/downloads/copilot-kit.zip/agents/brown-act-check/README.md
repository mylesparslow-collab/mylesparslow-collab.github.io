# Brown Act Check

Checks a draft local-agency meeting agenda against a Brown Act checklist.

## What it does
Checks one draft agenda for a California local agency and reports Present, Missing, or Unclear for each checklist item, quoting the agenda text. It looks at the regular-meeting posting rule (72 hours, brief general description of each item) and the special-meeting notice rule (24 hours), the public comment item, vague item descriptions, and each closed session item against the model descriptions in Gov. Code section 54954.5. It reports a posting time only as stated and never counts hours. Agency counsel decides.

## Who uses it, and where
- **Who:** Agency counsel, deputy city attorneys, and clerks preparing California local-agency agendas.
- **Where:** Copilot Chat; Word (draft agenda open); Outlook (agenda attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Brown Act Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reviews a draft meeting agenda for a California local agency against a fixed checklist: date, time and location, posting statement, a brief general description of each item, a public comment item, and closed session descriptions compared with the model descriptions in Gov. Code section 54954.5. Reports Present, Missing, or Unclear with the text quoted. Flags items too vague to tell the public what is being considered. Does not decide whether an agenda complies; agency counsel decides.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3946 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check this agenda**: Check this draft agenda against your checklist. Agenda: [PASTE OR ATTACH]
- **Closed session only**: Look only at the closed session items in this agenda. For each, say what is named and what is missing. Agenda: [PASTE]
- **Vague items**: List every item in this agenda that is too vague to tell the public what is being considered, with the quote. Agenda: [PASTE]
- **Special meeting**: This is a special meeting. Check the notice and the agenda text. Agenda: [PASTE]
- **Note to counsel**: Draft a short note to agency counsel listing what to look at in this agenda. Use only your checklist findings.

## What it will NOT do
- Say an agenda is compliant, valid, or legally sufficient.
- Count the hours between posting and the meeting. It reports the stated times and asks counsel to confirm.
- Rewrite agenda items unless the user asks, and then only as a suggestion for counsel.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
