# Lease Abstract

Abstracts a commercial or retail lease with every clause quoted and cited.

## What it does
Reads a commercial or retail lease and produces an abstract table with the section cited and the key words quoted in each row, covering parties, premises, term, rent, percentage rent, operating expenses and caps, deposit, use and exclusives, radius restriction, co-tenancy, options, assignment, insurance, repairs, default and cure, SNDA and estoppel, and guaranty. It then lists every date and notice window exactly as written, marking what docketing must calculate, and flags unusual or one-sided terms for the attorney. It does not advise.

## Who uses it, and where
- **Who:** Real estate attorneys, paralegals, and lease administrators, especially on shopping-center deals.
- **Where:** Copilot Chat; Word (lease open); Outlook (lease attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Lease Abstract` (30 characters max). Description: paste the text below (1,000 characters max).

   > Abstracts a commercial or retail lease into a table: parties, premises, term and commencement, rent and escalations, percentage rent, CAM and operating expense caps, security deposit, use and exclusives, radius restriction, co-tenancy, options with notice windows, assignment and subletting, insurance, repairs, default and cure periods, SNDA and estoppel, guaranty. Each row cites the section and quotes the key words. Lists every date or notice window as written, never calculated, and flags unusual or one-sided terms for the attorney.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (2951 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Abstract this lease**: Abstract this lease into your table with sections and quotes, then list critical dates and unusual terms. Lease: [PASTE OR ATTACH]
- **Critical dates only**: List every date and notice window in this lease exactly as written. Do not compute any date. Lease: [PASTE]
- **Co-tenancy and radius**: Quote the co-tenancy, exclusive, use, and radius clauses in this lease with section numbers. Lease: [PASTE]
- **Options and notices**: List every renewal, expansion, and termination option in this lease with its notice window as written. Lease: [PASTE]
- **One-sided terms**: List terms in this lease that look unusual or one-sided, quoted, for the attorney to review. Flag only. Lease: [PASTE]

## What it will NOT do
- Calculate any date from a trigger. It writes "Docketing to calculate: [trigger]".
- Say whether a term is market, fair, or enforceable. It flags unusual terms for the attorney.
- Fill a row the lease does not address. It writes "Not stated in the document."
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
