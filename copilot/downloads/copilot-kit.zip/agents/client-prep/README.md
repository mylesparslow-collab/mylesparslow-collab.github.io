# Client Prep (connected agent)

Briefs partners, billing, finance, HR, and risk staff on clients and firm numbers by calling the **Firm Facts** MCP server. Unlike the six no-code agents in this kit, Client Prep needs a live data source, so it is built in Copilot Studio (or with the Agents Toolkit) and is documented here rather than packaged.

All data is invented: the fictional firm Thornwood Garza LLP, as of October 17, 2026.

## What it does
- Meeting prep for a client: talking points first, then urgent items (overdue money, deadlines, ethical walls, pending conflicts).
- Billing guideline questions: finds the rule that applies and quotes it.
- Firm-numbers questions: realization (where money is lost), cross-sell leads, receivables aging, workload, trust accounts, and risk findings.
- Says plainly when a tool returns nothing. It does not fill gaps from general knowledge.

## Who uses it, and where
Partners and business development, billing and collections, finance, HR, accounting, and risk. Used in Copilot Studio's test panel, and in Teams or Microsoft 365 Copilot once published.

## The MCP server
- **Demo host:** https://firm-facts-alpha.vercel.app
- **Endpoint:** `/api/mcp` (Streamable HTTP, stateless)
- **Auth:** API key sent in the `x-api-key` header. The key is not stored in this kit; the swagger file has no key value. Ask Myles for the demo key, or set your own.
- **Nine read-only tools:** `client_prep`, `find_client`, `billing_rules`, `firm_money`, `cross_sell`, `aging`, `people_workload`, `trust_check`, `risk_findings`. None can write or change data.

## Files here
- [`agent-instructions.md`](agent-instructions.md): name, description, and the instructions to paste into the agent.
- [`firm-facts-mcp.swagger.json`](firm-facts-mcp.swagger.json): OpenAPI file for the connector. Replace the `host` with your own Vercel host if you deploy your own copy. If you add a key to your working copy, never commit it; use `<API_KEY>` as the placeholder.

## Two install routes
1. **Copilot Studio (MCP tool from the Swagger).** Create an agent, paste the name, description, and instructions from `agent-instructions.md`, then add the Firm Facts MCP tool using the swagger file (or the MCP onboarding wizard) and create the connection with the API key. Microsoft labels MCP support in Copilot Studio as preview, so menu names and behavior may change. Confirm all nine tools appear in the tool list, then test in the test panel.
2. **Microsoft 365 Agents Toolkit 6.12 or later (MCP plugin for a declarative agent).** In VS Code, create a declarative agent, add an MCP plugin that points at the endpoint, and keep the same instructions. This route produces a package IT can deploy like the other agents in this kit.

## What it will NOT do
- Write to or change any firm data (all tools are read-only).
- Answer from anything but the tool results.
- Replace a partner's or billing attorney's judgment on a client decision.

## Approval note
Install in a firm tenant only with IT and risk approval; the samples are invented. Do not point this agent at real client data without a security review of the MCP server.
