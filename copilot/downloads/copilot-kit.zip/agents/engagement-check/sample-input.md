# Sample input: draft engagement letter (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. This letter is deliberately incomplete for demonstration.

---

THORNWOOD GARZA LLP
500 Harbor Street, Suite 2100, Fictional City, California

April 15, 2025

Ms. Corinne Haverford-Ng
Chief Executive Officer
Redfern Tidal Energy, Inc.
1200 Seawall Road
Fictional City, California

Re: Engagement of Thornwood Garza LLP: Commercial Lease Dispute with Pelham Docks Authority

Dear Ms. Haverford-Ng:

Thank you for selecting Thornwood Garza LLP ("the Firm") to represent Redfern Tidal Energy, Inc. ("Redfern"). This letter explains the terms of our engagement.

1. Scope of Services. The Firm will represent Redfern in negotiating and, if necessary, litigating a dispute with Pelham Docks Authority over the terms of the lease for Pier 4. The engagement does not include tax advice, regulatory permitting, or any appeal. If you want us to handle any of those, we will need a separate written agreement.

2. Responsibilities. The Firm will keep you informed of significant developments and will respond promptly to your questions. Redfern agrees to provide accurate and complete information, to make decisions promptly, and to pay our invoices on time.

3. Fees. Our fees will be based on the time spent by our lawyers and staff at their hourly rates. Current rates are: partners, $780 per hour; associates, $520 per hour; paralegals, $260 per hour. Time is recorded in tenth-of-an-hour increments. The Firm may adjust its rates once a year, on thirty days' written notice.

4. Costs. Redfern will reimburse the Firm for costs such as filing fees, court reporter charges, and expert fees. Costs over $2,500 will be sent to Redfern for direct payment.

5. Retainer. Redfern will pay an advance deposit of $25,000, which the Firm will hold in its client trust account and apply to the final invoice. Any unused portion will be refunded.

6. Billing. Invoices are sent monthly and are due within thirty days.

7. Professional Liability Insurance. The Firm maintains errors and omissions insurance applicable to the services to be rendered under this agreement.

8. Conflict Waiver. Redfern understands that the Firm represents other clients in the energy industry, and Redfern agrees that the Firm may continue to do so. Redfern waives any conflicts of interest that may arise now or in the future.

9. Entire Agreement. This letter is the entire agreement between Redfern and the Firm about this engagement and may be changed only in writing signed by both.

If these terms are acceptable, please sign below and return a copy to us.

Sincerely,

THORNWOOD GARZA LLP

By: ______________________
Joaquin Delacruz-Weiss, Partner

ACCEPTED AND AGREED:

Redfern Tidal Energy, Inc.

By: ______________________
Name: Corinne Haverford-Ng
Title: Chief Executive Officer
Date: ______________
