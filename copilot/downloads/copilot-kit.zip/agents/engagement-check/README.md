# Engagement Check

Checks a draft California engagement letter against a drafting checklist.

## What it does
Checks a draft California engagement letter against a fixed checklist and reports Present, Missing, or Unclear for each item, quoting the clause found. Items include Cal. Bus. & Prof. Code section 6148, section 6147 for contingency matters, Rule 1.5, Rule 1.4.2, Rule 1.7 consent language, scope and limitations, termination, file retention, and signature blocks. It is a drafting checklist, not legal advice; the responsible attorney decides.

## Who uses it, and where
- **Who:** Attorneys, legal assistants, and risk or conflicts staff reviewing engagement letters.
- **Where:** Copilot Chat; Word (draft letter open); Outlook (letter attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Engagement Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Checks a draft California engagement letter against a fixed drafting checklist (Bus. & Prof. Code section 6148, section 6147 if contingency, Rule 1.5, Rule 1.4.2, Rule 1.7 consent, scope, termination, file retention, signatures) and reports Present, Missing, or Unclear with the clause quoted. A drafting checklist, not legal advice; the responsible attorney decides.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (4655 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Optional knowledge: your firm's engagement letter template, so the agent can note differences. Not required. Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Run the checklist**: Check this draft engagement letter against your checklist. Letter: [PASTE OR ATTACH]
- **Missing items only**: List only the checklist items that are Missing or Unclear in this letter, with the clause you found for each.
- **Conflict waiver check**: Does the conflict waiver in this letter describe the relevant circumstances and reasonably foreseeable consequences? Quote the text. Checklist only, no legal advice.
- **Contingency letter**: This is a contingency fee matter. Check the letter against the section 6147 items as well. Letter: [PASTE]
- **Note for the attorney**: Draft a short note to the responsible attorney listing what to look at in this letter. Use only your checklist findings.

## What it will NOT do
- Give legal advice or say a letter is legally sufficient, enforceable, or compliant.
- Draft replacement clauses unless the user asks, and then only as a suggestion for the attorney.
- Decide whether a section 6148 exception applies. It flags that exceptions exist and a person decides.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
