# Privacy Contract Check

Checks a vendor data processing agreement against CCPA service-provider contract terms.

## What it does
Checks a vendor data processing agreement or service-provider addendum against a fixed checklist of California Consumer Privacy Act service-provider contract terms (Cal. Civ. Code 1798.100(d) and 11 CCR 7051(a)) and reports Present, Missing, or Unclear with the clause quoted. Also checks security measures, breach notice timing as written, subprocessors, deletion or return at the end, audit rights, and cross-border transfers. Marks other required contract terms in 11 CCR 7051(a) for counsel to review. Does not decide whether the agreement complies with the law.

## Who uses it, and where
- **Who:** Privacy and data attorneys, paralegals, and procurement counsel reviewing vendor addenda.
- **Where:** Copilot Chat; Word (addendum open); Outlook (addendum attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Privacy Contract Check` (30 characters max). Description: paste the text below (1,000 characters max).

   > Checks a vendor data processing agreement or service-provider addendum against a fixed checklist of California Consumer Privacy Act service-provider contract terms (Cal. Civ. Code 1798.100(d) and 11 CCR 7051(a)) and reports Present, Missing, or Unclear with the clause quoted. Also checks security measures, breach notice timing as written, subprocessors, deletion or return at the end, audit rights, and cross-border transfers. Marks other required contract terms in 11 CCR 7051(a) for counsel to review. Does not decide whether the agreement complies with the law.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (4004 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Check this DPA**: Check this data processing addendum against your CCPA service-provider checklist. Addendum: [PASTE OR ATTACH]
- **The CCPA terms only**: Check only the CCPA service-provider terms in this addendum. Quote each clause or write None found. Addendum: [PASTE]
- **No-sell and no-share**: Does this addendum prohibit the vendor from selling or sharing personal information? Quote the clause or say None found. Addendum: [PASTE]
- **Breach and deletion terms**: Quote every breach notice, subprocessor, deletion or return, audit, and cross-border term in this addendum as written. Addendum: [PASTE]
- **Missing or unclear only**: List only the checklist items that are Missing or Unclear in this addendum, with the clause you found. Addendum: [PASTE]

## What it will NOT do
- Say an agreement is compliant, adequate, or safe to sign.
- Review the vendor's security practices; it reads only the contract text.
- Check the other 11 CCR 7051(a) items in detail; it marks them for counsel.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
