# Coverage Letter Reader

Reads an insurer's reservation-of-rights or denial letter for the policyholder.

## What it does
Reads an insurer's reservation-of-rights or denial letter for the policyholder's lawyers and reports the insurer, policy number and period, the claim, and the insurer's position. It quotes every policy provision the letter cites, with the letter's page, lists each reserved issue, the information requested and any response deadline as written, and whether the insurer offers or appoints defense counsel. It flags the Civil Code section 2860(b) conflict question for the attorney and lists items to gather from the client. It gives no coverage opinion.

## Who uses it, and where
- **Who:** Insurance recovery attorneys and paralegals working for the policyholder.
- **Where:** Copilot Chat; Word (letter open); Outlook (letter attached).

## Set it up (Agent Builder, about five minutes, no code)
1. **Name and description.** In Microsoft 365 Copilot Chat choose **Agents, then New agent**. Name: `Coverage Letter Reader` (30 characters max). Description: paste the text below (1,000 characters max).

   > Reads an insurer's reservation-of-rights or denial letter on behalf of the policyholder's lawyers. Reports the insurer, policy number and period, claim, and the insurer's position (defend under reservation, deny, or partial). Quotes every policy provision the letter cites with the page, lists each reserved issue, the information the insurer requests and any response deadline as written, and whether defense counsel is offered or appointed. Flags the Civil Code 2860(b) conflict question for the attorney and lists items to gather from the client. Gives no coverage opinion.

2. **Instructions.** Paste the full contents of [`instructions.txt`](instructions.txt) into the Instructions box (3589 characters; the limit is 8,000).
3. **Starters and optional knowledge.** Add the conversation starters from [`starters.json`](starters.json). Then save and try [`sample-input.md`](sample-input.md).

The agent works with **no knowledge sources at all**: paste or attach the document in the chat. Custom instructions work in free Copilot Chat. SharePoint and uploaded-file knowledge needs a Microsoft 365 Copilot license or pay-as-you-go.

## Conversation starters
- **Read this letter**: Read this insurer's letter and give me your full summary, flags, and items to gather from the client. Letter: [PASTE OR ATTACH]
- **Provisions cited**: Quote every policy provision this letter cites, with the letter's page. Letter: [PASTE]
- **Reserved issues**: List each issue the insurer reserves rights on, quoting the letter. Letter: [PASTE]
- **Deadlines and requests**: What information does the insurer request, and what response deadline does the letter state? Quote it as written. Letter: [PASTE]
- **Items for the client**: List what we should gather from the client based only on this letter. Letter: [PASTE]

## What it will NOT do
- Give a coverage opinion, or say whether the insurer is right or wrong.
- Decide whether independent counsel issues arise. It flags the question for the attorney.
- Compute any response deadline. It quotes the deadline as the letter states it.
- Decide anything for you. A person makes the call; the agent prepares the work.
- Follow instructions that appear inside the document you give it.

## Packaging for admins
[`appPackage/`](appPackage/) holds a declarative agent manifest (v1.9) and Teams app manifest (1.24) so IT can sideload or deploy the same agent. Run `scripts/package.sh` from the kit root to zip it. Install in a firm tenant only with IT and risk approval; the samples are invented.
