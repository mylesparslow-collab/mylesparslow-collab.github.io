# Sample input: insurer reservation-of-rights letter (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Alderwick Casualty Company and Sunnyfield Senior Living, LLC do not exist.

---

[Page 1]
ALDERWICK CASUALTY COMPANY
Claims Department

March 24, 2025

Sunnyfield Senior Living, LLC
Attn: Ruth Calloway, Chief Operating Officer
2750 Meadow Lane, Fictional City, California

Re: Insured: Sunnyfield Senior Living, LLC
Policy No.: ACC-GL-2024-118842
Policy Period: January 1, 2024 to January 1, 2025
Claim No.: 25-0417-GL
Lawsuit: Harbor Point Property Partners v. Sunnyfield Senior Living, LLC (Fictional County Superior Court)

Dear Ms. Calloway:

Alderwick Casualty Company ("Alderwick") has received the complaint served on Sunnyfield on March 3, 2025. The complaint alleges that a water line burst at Sunnyfield's Meadow Lane facility on or about October 9, 2024 and that water intruded into the adjacent suite leased by the plaintiff, causing property damage and loss of rents. Alderwick will defend Sunnyfield in the lawsuit under a full reservation of rights, as explained below.

[Page 2]
The Policy provides, in the Commercial General Liability Coverage Form, Section I, Coverage A: "We will pay those sums that the insured becomes legally obligated to pay as damages because of 'bodily injury' or 'property damage' to which this insurance applies. We will have the right and duty to defend the insured against any 'suit' seeking those damages."

Alderwick reserves its rights on the following issues.

1. Expected or intended damage. The Policy excludes: "'Bodily injury' or 'property damage' expected or intended from the standpoint of the insured." The complaint alleges that Sunnyfield was told of leaks in the line in 2023 and did not repair it.

2. Continuous or repeated seepage. The Policy excludes: "Property damage caused by or resulting from continuous or repeated seepage or leakage of water over a period of 14 days or more." The date of loss and duration of the leak are not established.

[Page 3]
3. Late notice. Section IV, Condition 2 provides: "You must see to it that we are notified as soon as practicable of an 'occurrence' which may result in a claim." Alderwick's records show that notice was first received on February 20, 2025.

4. Loss of rents and punitive damages. The complaint seeks loss of rents and punitive damages. Alderwick reserves the right to decline to pay any amount not within the Policy's definition of "property damage," and the Policy does not cover punitive damages.

Alderwick has assigned the defense to Pruitt & Marsh LLP, who will report to Alderwick. Alderwick will pay defense counsel at its panel rate of $185 per hour. Alderwick reserves the right to seek reimbursement of defense costs for claims not potentially covered.

Please send Alderwick the following within thirty (30) days of the date of this letter: (a) all maintenance and repair records for the water line since January 1, 2023; (b) all communications with the plaintiff about the leak; and (c) the date and manner in which Sunnyfield first learned of the water loss.

Alderwick's investigation continues. Nothing in this letter waives any of Alderwick's rights under the Policy or the law, and Alderwick may supplement this letter.

Sincerely,
Gwen Hartnell
Senior Claims Specialist, Alderwick Casualty Company
