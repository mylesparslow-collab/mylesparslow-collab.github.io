## Part 1: Demand details

| Item | Text as written | Location |
|---|---|---|
| Issuing agency | "OFFICE OF THE ATTORNEY GENERAL OF THE STATE OF EASTMARK / CONSUMER PROTECTION DIVISION" | Caption, top of document |
| Recipient | "TO: Pinecrest Billing Solutions, LLC, Attn: Custodian of Records, 88 Quarry Road, Westbrook" | "TO:" line, below the CID number |
| Document type and number | "CIVIL INVESTIGATIVE DEMAND NO. CID-2026-0192" | Caption |
| Return date | "The return date is December 15, 2026, at 10:00 a.m." | Opening paragraph |
| Place of production | "to the Office of the Attorney General, Consumer Protection Division" | Opening paragraph |
| Method of production | "Production may be made electronically." | Opening paragraph |
| Physical production address | Not stated in the document. | |
| Contact for counsel | "Questions about this demand may be directed to Assistant Attorney General Philippa Ngozi-Brandt, (555) 010-0142, pngozi@ag.eastmark.example." | Closing paragraph, before "Issued" |
| Date issued | "Issued: November 9, 2026." | Final line |

**Referenced but not provided:** "the attached Certificate of Compliance" (Instruction E). The Instructions and Definitions are included in the text.

## Part 2: Scope-changing language

| No. | Text as written | Effect as written |
|---|---|---|
| Def. 1 ("You") | "'You' and 'Pinecrest' mean Pinecrest Billing Solutions, LLC, and its parents, subsidiaries, affiliates, predecessors, officers, employees, agents, and anyone acting on its behalf." | Extends "You" beyond the named LLC |
| Def. 2 ("Document") | "'Document' means any written, recorded, or electronic material of any kind, including email, text and chat messages, drafts, spreadsheets, and databases, in Your possession, custody, or control." | Broad media definition; includes databases; limited by "possession, custody, or control" |
| Def. 3 ("Relevant Period") | "'Relevant Period' means January 1, 2022 through the date of Your response, unless a Request states otherwise." | Default period; yields to a Request that states its own |
| Def. 4 ("Provider Client") | "'Provider Client' means any hospital, clinic, or physician group for which You perform billing or collection services." | Used in Requests 1, 5, and 7 |
| Instr. A | "This demand is continuing. You must supplement Your production if You locate further responsive Documents after Your response." | Continuing obligation |
| Instr. B | "If You withhold any Document on a claim of privilege, You must provide a log within fourteen (14) days after the return date…" | Log timing tied to return date |
| Instr. C | "Documents must be produced in the form in which they are kept in the ordinary course of business, or as searchable electronic files with metadata intact." | Form of production (two alternatives) |
| Instr. D | "If no Documents respond to a Request, You must say so in writing." | Written statement required for empty responses |
| Instr. E | "A person with knowledge of Your search must sign the attached Certificate of Compliance." | Signed certificate required |

## Part 3: Relevant time period

- **Default (Def. 3):** "January 1, 2022 through the date of Your response, unless a Request states otherwise."
- **Request-specific:**
  - Request 3: "during the Relevant Period" (uses the default).
  - Request 5: "For the period January 1, 2024 through the date of Your response…"
- Requests 1, 2, 4, 6, 7, 8, and 9 state no period (Def. 3 applies by default).

## Part 4: Request table

Custodians and sources below are suggestions from the words of each request. **Suggested for counsel to confirm.**

| Request # | Request (quoted) | Period | Likely custodians | Likely data sources |
|---|---|---|---|---|
| 1 | "All contracts between You and each Provider Client." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: contracts or legal staff; account management | Suggested for counsel to confirm: contract repository; shared drives; CRM |
| 2 | "All Documents describing Your policies and procedures for sending patient bills and collection notices." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: policy owners; billing operations | Suggested for counsel to confirm: policy library or intranet; shared drives |
| 3 | "All scripts, templates, and form letters used in collection calls or collection letters during the Relevant Period." | Relevant Period (Request text and Def. 3) | Suggested for counsel to confirm: collection staff; template administrators | Suggested for counsel to confirm: call-center or dialer scripts; letter template system; print-vendor files |
| 4 | "All Documents concerning patient complaints about billing or collection, including the complaint and Your response." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: customer service; complaint handling; collection staff | Suggested for counsel to confirm: complaint or ticketing system; email |
| 5 | "For the period January 1, 2024 through the date of Your response, all Documents sufficient to show the number of accounts placed for collection, by Provider Client, by month." | January 1, 2024 through date of response (Request text) | Suggested for counsel to confirm: billing or reporting staff; data or analytics staff | Suggested for counsel to confirm: billing database; account placement records; reports |
| 6 | "All Documents concerning any compensation or bonus plan for collection staff that is based on amounts collected." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: HR; compensation; collection management | Suggested for counsel to confirm: HR or compensation systems; plan documents |
| 7 | "All communications with any Provider Client concerning the accuracy of patient balances." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: account managers; billing staff | Suggested for counsel to confirm: email; chat; text messages; CRM; client portal |
| 8 | "All Documents concerning Your document retention policies." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: legal or records management; IT | Suggested for counsel to confirm: policy repository; IT retention or auto-delete settings |
| 9 | "All Documents concerning any internal audit or compliance review of Your billing or collection practices." | Relevant Period (Def. 3; none stated in Request) | Suggested for counsel to confirm: compliance; internal audit | Suggested for counsel to confirm: audit workpapers; compliance tracker; shared drives |

## Part 5: Privilege log and certification

- **Instr. B (privilege log):** "If You withhold any Document on a claim of privilege, You must provide a log within fourteen (14) days after the return date identifying each Document by date, author, recipients, general subject matter, and the privilege claimed."
  - Timing: "Docketing to calculate: return date (December 15, 2026, at 10:00 a.m., per opening paragraph) + fourteen (14) days after the return date."
- **Instr. E (certificate):** "A person with knowledge of Your search must sign the attached Certificate of Compliance."
  - Certificate form and content: Not stated in the document (attachment not provided).
- **Instr. D (no responsive documents):** "If no Documents respond to a Request, You must say so in writing."

## Part 6: Possible scope questions for counsel

**Who and what is covered**
1. Does "You" in Def. 1 reach the listed parents, subsidiaries, affiliates, predecessors, and "anyone acting on its behalf"? Which entities and agents are meant?
2. Does "Document" in Def. 2 ("in Your possession, custody, or control") reach material held by Provider Clients, vendors, or former employees?
3. Does "Provider Client" in Def. 4 include former clients and clients for which the services ended before January 1, 2022?

**Time period**
4. Def. 3 runs "through the date of Your response." Is the response date fixed by this demand or by agreement? Docketing to calculate the cut-off once a date is set.
5. Is the period in Request 5 (January 1, 2024 through the date of response) different from the Def. 3 period, and does Request 3 ("during the Relevant Period") limit templates to versions in use during that period?
6. Requests 1, 2, 4, 6, 7, 8, and 9 state no period. Should the Def. 3 default apply to each?

**Breadth and form**
7. Request 4 covers "all Documents concerning patient complaints about billing or collection." Does it reach every complaint, or only those that involve collection?
8. Request 5 asks for "all Documents sufficient to show" account placements. Does this call for a summary, a report generated from a database (Def. 2 includes "databases"), or source records?
9. Request 7 covers "all communications" with each Provider Client about "the accuracy of patient balances." What communication channels are in scope, including text and chat?
10. Request 9 covers "any internal audit or compliance review." Is the scope limited to reviews of billing or collection practices?
11. Instr. C offers two forms of production. Which applies to databases, email, and chat?
12. Instr. A makes the demand continuing. For how long, and in what form, does supplementation continue?

**Burden and volume**
13. The number of Provider Clients, custodians, and systems is not stated. What is the expected volume for Requests 1, 4, and 7?
14. The demand does not state how patient-identifying information is to be handled. Is any such term stated elsewhere?
15. Instr. E requires a signed certificate, but the attachment is not provided. Who will sign, and what does it say?

## Part 7: Draft legal-hold notice

DRAFT FOR COUNSEL REVIEW. Do not send.

To: [RECIPIENTS]
From: [COUNSEL]
Date: [DATE]
Subject: [COUNSEL TO APPROVE]

Please preserve, and do not delete, alter, or discard, documents in the categories listed below, in any form and wherever kept, including email, chat, text messages, and shared drives.

[COUNSEL TO APPROVE DESCRIPTION OF MATTER]

Categories:
1. Contracts between the company and each Provider Client.
2. Documents describing policies and procedures for sending patient bills and collection notices.
3. Scripts, templates, and form letters used in collection calls or collection letters.
4. Documents concerning patient complaints about billing or collection, including the complaint and the response.
5. Documents sufficient to show the number of accounts placed for collection, by Provider Client, by month.
6. Documents concerning any compensation or bonus plan for collection staff based on amounts collected.
7. Communications with any Provider Client concerning the accuracy of patient balances.
8. Documents concerning document retention policies.
9. Documents concerning any internal audit or compliance review of billing or collection practices.

Period to preserve: [PERIOD TO PRESERVE, COUNSEL TO CONFIRM]
Custodians: [CUSTODIANS]
Systems: [SYSTEMS]
Auto-delete: [SUSPEND AUTO-DELETE FOR THESE SYSTEMS, COUNSEL TO CONFIRM]
Questions: [CONTACT NAME, PHONE, EMAIL]

This is a checklist read of the text provided. The responsible attorney decides.
