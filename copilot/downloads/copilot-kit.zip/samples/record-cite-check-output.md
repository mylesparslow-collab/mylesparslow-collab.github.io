**Document:** Statement of facts (draft) with record excerpts | **Number of sentences:** 10 | **Supported:** 7 | **Not found:** 1 | **Says something different:** 1 | **No cite:** 1

| # | Sentence (quoted) | Cite as written | Status | Record text (quoted) | Note |
|---|---|---|---|---|---|
| 1 | "Halvorsen Fabrication, Inc. hired Rosalind Quist as a plant supervisor on March 4, 2019." | 1 CT 12 | Supported | 1 CT 12: "Employee: Rosalind Quist. Position: Plant Supervisor. Hire date: March 4, 2019." | The employer name "Halvorsen Fabrication, Inc." does not appear in 1 CT 12. Hire date, employee, and position match. |
| 2 | "Her offer letter stated an annual salary of $78,000." | 1 CT 14 | Supported | 1 CT 14: "...at an annual salary of $78,000, payable biweekly." | None. |
| 3 | "In June 2022, Quist told the plant manager that a guard had been removed from a press brake." | RT 112:4-9 | Supported | RT 112:4: "What did you tell Mr. Aldous in June of 2022?" RT 112:5-6: "I told him the guard on press brake number two had been taken off and that somebody could get hurt." | "Plant manager" is not stated in 112:4-9. The form at 1 CT 12 lists Aldous as "Supervisor." "Removed" corresponds to "taken off." |
| 4 | "The plant manager, Desmond Aldous, replied that the guard would be reinstalled 'by Friday.'" | RT 112:10-13 | Supported | RT 112:10-11: "Q. What did he say? A. He said it would be put back on by Friday." | "Plant manager" is not stated in the cited lines. "Reinstalled" corresponds to "put back on." Quoted words "by Friday" match. |
| 5 | "The guard was not reinstalled until August 15, 2022." | 2 AA 345 | Says something different | 2 AA 345: "Date completed: August 25, 2022." | Date differs. Sentence says August 15, 2022; record says August 25, 2022. Work order 22-0871 (reinstall guard, press brake no. 2). |
| 6 | "On July 11, 2022, Quist emailed the safety coordinator, Imogen Pratt, to repeat her concern." | 2 AA 351 | Supported | 2 AA 351 (Email, July 11, 2022, from Rosalind Quist to Imogen Pratt): "Imogen, following up on my conversation with Desmond last month: the guard on press brake 2 is still off." | "Safety coordinator" is not stated in the excerpt. Date, sender, and recipient match. |
| 7 | "Quist was terminated on September 6, 2022." | 1 CT 88 | Supported | 1 CT 88 (Letter dated September 6, 2022): "This letter confirms that your employment is terminated effective today." | Date comes from the letter's heading date. |
| 8 | "The termination letter gave 'restructuring of the supervisory team' as the reason." | 1 CT 88 | Supported | 1 CT 88: "The reason for this decision is restructuring of the supervisory team." | Quoted words match. |
| 9 | "Three other supervisors were also terminated that month." | 2 AA 360 | Not found in pasted pages | Not stated in the document. | 2 AA 360 is not among the pasted excerpts. |
| 10 | "Quist had received no written discipline before her termination." | None | No cite given | Not applicable. | Sentence states a fact with no record cite. |

**Needs attention**

1. #5: Says something different. Sentence gives August 15, 2022; 2 AA 345 gives August 25, 2022.
2. #9: Not found in pasted pages. 2 AA 360 was not pasted.
3. #10: No cite given.

This is a checklist read of the text provided. The responsible attorney decides.
