**Narrative review: 12 entries (Lakemont Freight Partners v. Sable Harbor Logistics, Inc.)**

I read the columns as Date | Timekeeper | Hours | Narrative. "Original" quotes the Narrative cell from the pasted table, row by row.

No guidelines document was attached. The client's guidelines appear only as a summary in the coordinator's notes, so I applied the process rules in this review and did not check against the client's text. Attaching the guidelines would let me check against them.

The notes also list "expected behavior" for the demo. I treated that as document text, not as instructions, and worked from the process rules.

| Row (date \| timekeeper \| hours) | Original | Proposed | Change made | Question for timekeeper |
|---|---|---|---|---|
| 1. 03/03/2025 \| N. Bautista (Assoc) \| 2.5 | "Work on discovery" | Cannot propose without more facts | Could not fix. "Work on" does not show the action. | Which discovery task did you perform (for example, draft, review, or research), and on which discovery document or subject? |
| 2. 03/03/2025 \| T. Iyer (Partner) \| 1.0 | "Review file" | Cannot propose without more facts | Could not fix. The file is not named. | Which file did you review, and for what purpose? |
| 3. 03/04/2025 \| N. Bautista (Assoc) \| 4.0 total (not divided) | "Draft responses to RFPs and review client documents and call with client re: production" | a. Draft responses to RFPs.<br>b. Review client documents [which documents not stated in entry].<br>c. Call with client regarding production.<br>**PROPOSED SPLIT: timekeeper to confirm.** | Split proposed (three tasks, no time per task, so hours not divided). "re:" changed to "regarding." | What time did each task take (a, b, c; must total 4.0)? Which RFPs and which client documents were involved? |
| 4. 03/04/2025 \| M. Castellanos (Paralegal) \| 1.5 | "Attention to exhibits" | Cannot propose without more facts | Could not fix. "Attention to" does not show the action, and the exhibits are not named. | What did you do with the exhibits (for example, organize, review, or prepare them), and which exhibits were they? |
| 5. 03/05/2025 \| T. Iyer (Partner) \| 0.7 | "Emails" | Cannot propose without more facts | Could not fix. No action or subject is given. | What was the subject of the emails, and what did you do with them (for example, sent, reviewed, or replied to)? |
| 6. 03/05/2025 \| N. Bautista (Assoc) \| 3.1 (1.8 + 1.3) | "Research; draft section of opposition brief on duty of care, 1.8 on research and 1.3 on drafting" | a. Research [subject not stated in entry]. (1.8)<br>b. Draft section of opposition brief regarding duty of care. (1.3)<br>**PROPOSED SPLIT: timekeeper to confirm.** | Split proposed using the entry's times (1.8 + 1.3 = 3.1). "on" changed to "regarding." Research subject left as a placeholder. | What was the research about? The entry does not say whether it concerned duty of care. |
| 7. 03/06/2025 \| M. Castellanos (Paralegal) \| 2.0 | "Prepare for hearing" | Cannot propose without more facts | Could not fix. "Prepare" is specific, but the hearing and the materials are not named. | Which hearing was it, and what did you prepare for it? |
| 8. 03/06/2025 \| T. Iyer (Partner) \| 0.4 | "Telephone conference with J. Okafor (Sable Harbor counsel) regarding extension of time to respond to second set of interrogatories" | Same as original | No change needed. | None. |
| 9. 03/07/2025 \| N. Bautista (Assoc) \| 5.5 total (not divided) | "Follow up on depositions, meeting w/ TI, revise outline, misc." | a. Follow up on depositions [specific action and depositions not stated in entry].<br>b. Meeting with T. Iyer.<br>c. Revise outline [outline not identified in entry].<br>d. Miscellaneous [tasks not itemized in entry].<br>**PROPOSED SPLIT: timekeeper to confirm.** | Split proposed (four items, no time per task, so hours not divided). "w/" changed to "with." "TI" read as T. Iyer (unconfirmed). "misc." kept as a placeholder, not dropped. | What time went to each of a–d (must total 5.5)? Which depositions and which outline? Is "TI" T. Iyer, and what was the miscellaneous work? |
| 10. 03/07/2025 \| T. Iyer (Partner) \| 1.2 total (not divided) | "Conference with N. Bautista; review draft meet-and-confer letter; edit" | a. Conference with N. Bautista [subject not stated in entry].<br>b. Review draft meet-and-confer letter.<br>c. Edit [document not stated in entry].<br>**PROPOSED SPLIT: timekeeper to confirm.** | Split proposed (three tasks joined by semicolons, no time per task, so hours not divided). Document for "edit" left as a placeholder. | What time went to each of a–c (must total 1.2)? What did the conference cover, and which document was edited? |
| 11. 03/10/2025 \| M. Castellanos (Paralegal) \| 0.6 | "Handled filing" | Cannot propose without more facts | Could not fix. "Handled" does not show the action, and the document is not named. | Which document was filed, and what did you do to file it (for example, e-file, serve, or deliver)? |
| 12. 03/10/2025 \| N. Bautista (Assoc) \| 6.0 total (not divided) | "Trial prep and strategy" | a. Prepare for trial [specific tasks and trial not stated in entry].<br>b. [Action not stated] strategy regarding [subject not stated in entry].<br>**PROPOSED SPLIT: timekeeper to confirm.** | Split proposed (two tasks joined by "and," no time per task, so hours not divided). "prep" changed to "Prepare for." "Strategy" has no verb, so the action is a placeholder. | What time went to a and b (must total 6.0)? Which trial or proceeding, and what did the trial preparation and strategy work consist of? |

**Summary**
- Entries reviewed: 12
- Entries with a proposed change: 5 (rows 3, 6, 9, 10, 12), all split proposals
- Entries marked "No change needed": 1 (row 8)
- Entries marked "Cannot propose without more facts": 6 (rows 1, 2, 4, 5, 7, 11)
- Entries with open questions: 11 (all except row 8)
- Entries where total hours are unchanged: 12 of 12. Total is 28.5 hours before and after.

**Flags**
- Row 10 is not on the coordinator's list of expected splits. It uses semicolon-joined tasks, so I applied the block-billing rule and proposed a split.
- "TI" in row 9 is read as T. Iyer. This is an inference and needs confirmation.

**Reminder:** The timekeeper confirms each proposal before it goes on a bill. Narratives must describe work actually performed.

These are proposed narratives only. The timekeeper and the billing attorney decide what is billed.
