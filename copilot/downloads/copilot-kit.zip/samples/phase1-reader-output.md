## Part 1: Report details

| Item | Report text (quoted) | Page |
|---|---|---|
| Site | "1140 Calloway Street, Harlan Springs" | Cover (p. i) |
| User | "Brindle Capital Partners LLC (the "User")" | Cover (p. i) |
| Environmental professional | "Marguerite Ostrander, P.G." | Cover (p. i) |
| Date of site visit | "Site reconnaissance: July 28, 2026" | Cover (p. i) |
| Report date | "Report date: August 21, 2026" | Cover (p. i) |
| Standard the report says it follows | "in general conformance with ASTM E1527-21, Standard Practice for Environmental Site Assessments: Phase I Environmental Site Assessment Process." | p. 1, §1.2 |

- EPA recognizes ASTM E1527-21 for All Appropriate Inquiries.
- Counsel confirms the report's age and viability for the transaction.

## Part 2: Findings as the report labels them

| Category (as the report labels it) | What the report says (quoted) | Page |
|---|---|---|
| Recognized environmental conditions (RECs) | "The Phase I identified one recognized environmental condition (REC): the presence of PCE in soil gas beneath the former dry cleaner space, as reported in a 2009 soil gas survey, which was not addressed by the 2014 closure letter. The report did not find that this condition has been investigated since 2009." | p. 14, §6.1 |
| Controlled RECs (CRECs) | "The groundwater PCE plume is identified as a controlled recognized environmental condition (CREC) because the 2014 closure letter relies on the recorded restriction prohibiting groundwater use." | p. 14, §6.2 |
| Historical RECs (HRECs) | "The 2003 removal of the heating oil UST is identified as a historical recognized environmental condition (HREC) because the agency issued no-further-action without conditions." | p. 14, §6.3 |
| De minimis conditions | "None identified." | p. 14, §6.4 |
| Data gaps | **Gap 1:** "Fire insurance maps for the period 1958 to 1970 were not available, so the use of the rear of the building in those years could not be confirmed." Significance: "The environmental professional does not consider this data gap significant because the Site's use as a dry cleaner is documented in other sources." | p. 16, §7.0 |
| | **Gap 2:** "The environmental professional was unable to interview any former owner of the dry cleaner." Significance: "The environmental professional considers this data gap significant because the dry cleaner operated for 36 years." | p. 16, §7.0 |
| Business environmental risks | Not stated in the document. | — |
| Recommendations | "Ridgeline recommends a limited Phase II subsurface investigation, including soil gas sampling beneath the former dry cleaner space, before closing." | p. 17, §8.0 |
| | "Ridgeline further recommends that the User review the recorded groundwater restriction with counsel." | p. 17, §8.0 |

## Part 3: Described but not labeled

| Description (quoted) | Page | Note |
|---|---|---|
| "From approximately 1958 to 1994 the Site was occupied by Calloway Dry Cleaners, which used tetrachloroethylene (PCE) in on-site cleaning machines." | p. 6, §3.0 | The report does not label this. |
| "He stated he was not aware of any spills at the Site." (Owner's representative, Tobias Wrenfield) | p. 11, §5.1 | The report does not label this. |
| "In our opinion, the soil gas condition may pose a vapor intrusion risk to future occupants." | p. 18, §9 | The report does not label this. |

## For the attorney

- **Standard:** The report cites ASTM E1527-21 (p. 1, §1.2).
- **Summary vs. body, counts:** §9 says "one REC, one CREC, and one HREC" (p. 18). §6.1 to §6.3 (p. 14) match those counts.
- **Summary vs. body, vapor intrusion:** The vapor intrusion statement appears only in §9 (p. 18). §6.1 (p. 14) does not mention vapor intrusion.
- **Summary vs. body, other issues:** §9 says "No other environmental issues were noted by Ridgeline" (p. 18). §7 (p. 16) lists two data gaps and §8 (p. 17) lists recommendations. The report does not say how it classifies these.
- **Data gaps:** The environmental professional's significance statements differ. Gap 1 is "not significant" and Gap 2 is "significant," in the report's words (p. 16, §7.0).
- **Business environmental risks:** Not stated in the document.
- **Former owner:** The report says the environmental professional could not interview any former owner of the dry cleaner (p. 16, §7.0).
- **Recommended Phase II:** The report recommends a limited Phase II "before closing" (p. 17, §8.0).

This is a checklist read of the text provided. The responsible attorney decides.
