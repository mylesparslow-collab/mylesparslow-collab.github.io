# RFP Working Aid: Valle Verde Transit District RFP 25-07

**1. Agency and RFP**

- **Agency:** VALLE VERDE TRANSIT DISTRICT
- **RFP:** "REQUEST FOR PROPOSALS NO. 25-07", "GENERAL COUNSEL AND LITIGATION LEGAL SERVICES"
- **Scope (Section 1):** "to serve as General Counsel and to provide litigation legal services for a term of three (3) years, with two (2) one-year options to extend, at the District's sole discretion."
- **Addenda:** None mentioned in the document.

**2. Key dates**

| Event | Date and time as written | Section |
|---|---|---|
| RFP released | "April 7, 2025" | Section 2 |
| Written questions due | "April 21, 2025, 5:00 p.m." | Section 2 |
| Proposals due | "May 5, 2025, 3:00 p.m." | Section 2 |
| Proposals due (second statement) | "by 4:00 p.m. on the date in Section 2" | Section 5. **Conflict: ask the agency.** |
| Interviews of finalists | "week of May 19, 2025" | Section 2 |
| Board award | "June 9, 2025" | Section 2 |
| Term start | Not stated in the document | Section 1 |

**3. Submission requirements**

- [ ] **Copies:** "one (1) original and six (6) bound copies to the Clerk of the Board, 1180 Alder Court, Valle Verde, California" (Section 3)
- [ ] **Electronic:** "one electronic PDF through the District's procurement portal" (Section 3). Portal address and upload instructions: Not stated in the document.
- [ ] **Page limit:** "may not exceed twenty-five (25) pages, excluding resumes and required forms, in 11-point type" (Section 3). Whether the cover letter counts toward the limit: Not stated in the document.
- [ ] **Timeliness:** "Late proposals will not be accepted." (Section 3)
- [ ] **Signature:** "Cover letter signed by a partner authorized to bind the firm." (Section 4(a))
- [ ] **Required forms:** "Completed Attachment A (Certification of No Conflict)" and "Attachment B (Form 700 disclosure for each attorney who will serve as General Counsel or attend Board meetings)" (Section 4(e)). The attachments themselves are not in the document.
- [ ] **Narrative and team:** "Description of the firm's experience with California public transit agencies" (4(b)); "Proposed team with resumes" (4(c))
- [ ] **Fees:** "Fee proposal, including hourly rates by classification and an annual not-to-exceed estimate." (Section 4(d))
- [ ] **References:** "Three references from public agencies." (Section 4(f))

**4. Compliance matrix**

| Req # | Requirement (quoted) | Section | Where we answer it | Owner | Status |
|---|---|---|---|---|---|
| R1 | "one (1) original and six (6) bound copies to the Clerk of the Board" | Section 3 | | | |
| R2 | "one electronic PDF through the District's procurement portal" | Section 3 | | | |
| R3 | "may not exceed twenty-five (25) pages, excluding resumes and required forms, in 11-point type" | Section 3 | | | |
| R4 | "Late proposals will not be accepted." | Section 3 | | | |
| R5 | "Cover letter signed by a partner authorized to bind the firm." | Section 4(a) | | | |
| R6 | "Description of the firm's experience with California public transit agencies." | Section 4(b) | | | |
| R7 | "Proposed team with resumes." | Section 4(c) | | | |
| R8 | "Fee proposal, including hourly rates by classification and an annual not-to-exceed estimate." | Section 4(d) | | | |
| R9 | "Completed Attachment A (Certification of No Conflict)" | Section 4(e) | | | |
| R10 | "Attachment B (Form 700 disclosure for each attorney who will serve as General Counsel or attend Board meetings)" | Section 4(e) | | | |
| R11 | "Three references from public agencies." | Section 4(f) | | | |
| R12 | "Proposals are due by 4:00 p.m. on the date in Section 2." | Section 5 | | | |
| R13 | "Direct all questions in writing to Procurement Officer Mia Castellanos at procurement@valleverdetransit.example." | Section 7 | | | |

**5. Evaluation criteria**

"Proposals will be scored out of 100 points":

| Criterion | Points as stated |
|---|---|
| Experience with public transit agencies | 30 |
| Qualifications of the proposed team | 25 |
| Approach and responsiveness | 20 |
| Fee proposal | 15 |
| References | 10 |

Interviews: "Interviews, if held, are included in the scoring." (Section 5). Points for interviews: Not stated in the document.

**6. For risk or general counsel (quoted, not evaluated)**

| Item | Quoted text | Section |
|---|---|---|
| Term and options | "for a term of three (3) years, with two (2) one-year options to extend, at the District's sole discretion." | Section 1 |
| Governing agreement | "The selected firm will sign the District's Professional Services Agreement, which provides:" The agreement itself is not attached. | Section 6 |
| Rate cap | "hourly rates may not exceed $385 per hour for partners and $265 per hour for associates for the initial term" | Section 6(a) |
| Professional liability insurance | "the firm shall carry professional liability insurance of not less than $5,000,000 per claim" | Section 6(b) |
| General liability insurance | "general liability insurance of not less than $2,000,000 per occurrence" | Section 6(b) |
| Indemnity | "the firm shall indemnify and hold harmless the District from all claims arising from the firm's services, including claims arising from the District's own negligence" | Section 6(c) |
| Billing guidelines | "the firm shall follow the District's Legal Billing Guidelines, which prohibit billing for clerical work and for more than one attorney at a meeting without prior approval" | Section 6(d) |
| Termination for convenience | "the District may terminate for convenience on ten (10) days' written notice" | Section 6(e) |
| Conflict certification | "Completed Attachment A (Certification of No Conflict)" | Section 4(e) |
| Form 700 disclosure | "Attachment B (Form 700 disclosure for each attorney who will serve as General Counsel or attend Board meetings)" | Section 4(e) |
| Insurance certificates or endorsements | Not stated in the document | Section 6 |
| Rates in option years | Not stated in the document. Section 6(a) applies only "for the initial term." | Section 6(a) |

**7. Questions to submit to the agency**

1. **Conflict on the proposal deadline.** Section 2 states "Proposals due: May 5, 2025, 3:00 p.m." Section 5 states "Proposals are due by 4:00 p.m. on the date in Section 2." Which time governs?
2. **Attachments A and B.** Section 4(e) requires "Completed Attachment A (Certification of No Conflict)" and "Attachment B (Form 700 disclosure...)". Neither form is in the document. Please provide copies.
3. **Portal.** Section 3 refers to "the District's procurement portal." No address or upload instructions are given. Please provide them.
4. **Page limit scope.** Section 3 excludes "resumes and required forms" from the 25-page limit. Does the cover letter, the references, or the fee proposal count toward the limit? Not stated in the document.
5. **Interview scoring.** Section 5 says "Interviews, if held, are included in the scoring," but no points are assigned. How many points, and in which criteria?
6. **Professional Services Agreement.** Section 6 refers to "the District's Professional Services Agreement." Please provide a copy for review before submission.
7. **Billing guidelines.** Section 6(d) refers to "the District's Legal Billing Guidelines" and "prior approval." Please provide the guidelines and state how prior approval is requested.
8. **Option-year rates.** Section 6(a) states the rate cap "for the initial term." What rate cap applies during the two one-year options? Not stated in the document.
9. **Term start.** Section 1 states a three-year term but no start date. Please confirm the start date.
10. **Fee estimate.** Section 4(d) requires "an annual not-to-exceed estimate." What assumptions or workload should the estimate reflect? Not stated in the document.
11. **Insurance evidence.** Section 6(b) states minimum limits. Must certificates or endorsements be submitted with the proposal? Not stated in the document.

---

This is a working aid from the RFP text. The proposal team and the firm's risk office or general counsel decide.
