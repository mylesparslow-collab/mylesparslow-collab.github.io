**Lease Abstract: Brightwater Commons / Mesa Linen Co. (Suite 140)**

**Scope:** This is an excerpt, as labeled in the document header. It includes Sections 1.1 through 16.1 and the preamble. It does not include the signature page, any separate guaranty instrument, exhibits, amendments, or any other sections.

**1. Abstract table**

| Term | What the lease says | Section |
|---|---|---|
| Parties: Landlord | "Brightwater Commons LLC, a California limited liability company ("Landlord")" | Preamble |
| Parties: Tenant | "Mesa Linen Co., a California corporation ("Tenant")" | Preamble |
| Parties: Guarantor | "Ines Valdivia, Tenant's principal, shall personally guarantee all of Tenant's obligations under this Lease." | 16.1 |
| Premises and center | "Suite 140, containing approximately 3,200 rentable square feet, in the Brightwater Commons shopping center, Fictional City, California" | 1.1 |
| Term and commencement | "five (5) years from the Commencement Date." Commencement is "the earlier of (a) one hundred twenty (120) days after Landlord delivers the Premises to Tenant, or (b) the date Tenant opens for business." | 2.1 |
| Base rent and escalations | "$4.25 per square foot per month for lease year one, increasing three percent (3%) on each anniversary of the Commencement Date." | 3.1 |
| Percentage rent and breakpoint | "six percent (6%) of Gross Sales above the natural breakpoint." Breakpoint amount: Not stated in the document. | 3.4 |
| CAM and operating expenses, and any cap | "pro rata share of Common Area Maintenance and operating expenses." "Controllable expenses shall not increase more than five percent (5%) per year on a cumulative basis." Taxes, insurance, and utilities are "not subject to the cap." Base year and pro rata share percentage: Not stated in the document. | 4.1 |
| Security deposit | "$27,200 on signing." "Landlord may commingle the deposit with its own funds." | 5.1 |
| Permitted use | "only for the retail sale of home linens and related accessories." | 6.1 |
| Exclusives: Tenant's | Not stated in the document. | N/A |
| Exclusives: Landlord's | "Landlord shall not lease space in the Center to another tenant whose primary use is the sale of home linens, so long as Tenant is not in default." | 6.2 |
| Radius restriction | "Tenant shall not, during the term, directly or indirectly own or operate a store selling home linens within five (5) miles of the Center." | 6.3 |
| Co-tenancy: condition | "If Hartwell Market (the "Anchor") ceases operating in its premises, or if less than seventy percent (70%) of the leasable area of the Center is open for business." | 7.1 |
| Co-tenancy: remedy | "Tenant shall pay Alternative Rent equal to fifty percent (50%) of Base Rent. If the failure continues for twelve (12) consecutive months, Tenant may terminate on thirty (30) days' notice." | 7.1 |
| Renewal options | "two (2) options to renew for five (5) years each by written notice given not less than nine (9) months nor more than twelve (12) months before the expiration of the then-current term." Option rent: "ninety-five percent (95%) of fair market rent as determined by Landlord." | 8.1 |
| Expansion option | Not stated in the document. | N/A |
| Termination option (other than 7.1) | Not stated in the document. | N/A |
| Assignment and subletting | "shall not assign or sublet without Landlord's prior written consent, which Landlord may withhold in its sole discretion." | 9.1 |
| Insurance | "commercial general liability insurance of $2,000,000 per occurrence naming Landlord as additional insured." Other coverages: Not stated in the document. | 10.1 |
| Repairs and maintenance | "Tenant shall maintain the interior and, at Tenant's cost, the HVAC and roof membrane serving the Premises." Landlord's repair obligations: Not stated in the document. | 11.1 |
| Default: tenant | "rent is not paid within five (5) days after written notice" or "fails to perform another obligation within thirty (30) days after written notice." | 12.1 |
| Default: landlord | "Landlord's default occurs only if Landlord fails to cure within ninety (90) days after Tenant's written notice." | 12.1 |
| SNDA and estoppel | "Tenant shall sign Landlord's subordination and non-disturbance form within fifteen (15) days after request, and an estoppel certificate within ten (10) days after request." Landlord's SNDA obligation: Not stated in the document. | 14.1 |
| Guaranty | "personally guarantee all of Tenant's obligations under this Lease." Cap or duration: Not stated in the document. | 16.1 |
| Holdover | "rent is two hundred percent (200%) of the last monthly rent." | 15.1 |
| Relocation | "Landlord may relocate Tenant to comparable space in the Center on sixty (60) days' notice at Landlord's cost." | 13.1 |
| Recapture | "Landlord may recapture the Premises on any request for consent." | 9.1 |

**2. Critical dates**

Docketing to calculate every date below that depends on a trigger. Only the preamble date is stated outright.

| Item | Text as written | Section | Docketing |
|---|---|---|---|
| Lease date | "Dated as of February 3, 2025." | Preamble | Stated |
| Commencement Date | "the earlier of (a) one hundred twenty (120) days after Landlord delivers the Premises to Tenant, or (b) the date Tenant opens for business." | 2.1 | Docketing to calculate: Landlord's delivery of Premises (delivery date not stated) and Tenant's opening date (not stated) |
| Term | "five (5) years from the Commencement Date." | 2.1 | Docketing to calculate: Commencement Date |
| Rent escalations | "increasing three percent (3%) on each anniversary of the Commencement Date." | 3.1 | Docketing to calculate: each anniversary of the Commencement Date |
| Signing deposit | "$27,200 on signing." | 5.1 | Docketing to calculate: signing date (not stated) |
| Percentage rent payment | "payable within thirty (30) days after the end of each calendar quarter." | 3.4 | Docketing to calculate: end of each calendar quarter |
| Co-tenancy failure period | "If the failure continues for twelve (12) consecutive months" | 7.1 | Docketing to calculate: start date of the failure (trigger not stated) |
| Co-tenancy termination notice | "Tenant may terminate on thirty (30) days' notice." | 7.1 | Stated period: thirty (30) days' notice |
| Renewal notice window | "not less than nine (9) months nor more than twelve (12) months before the expiration of the then-current term." | 8.1 | Docketing to calculate: expiration of then-current term |
| Tenant monetary cure | "five (5) days after written notice" | 12.1 | Docketing to calculate: date of written notice |
| Tenant non-monetary cure | "thirty (30) days after written notice" | 12.1 | Docketing to calculate: date of written notice |
| Landlord cure | "ninety (90) days after Tenant's written notice" | 12.1 | Docketing to calculate: date of Tenant's written notice |
| Relocation notice | "sixty (60) days' notice" | 13.1 | Stated period: sixty (60) days' notice |
| SNDA form | "within fifteen (15) days after request" | 14.1 | Docketing to calculate: date of request |
| Estoppel certificate | "within ten (10) days after request" | 14.1 | Docketing to calculate: date of request |

**3. Unusual or one-sided terms for the attorney**

- **4.1:** "Controllable expenses shall not increase more than five percent (5%) per year on a cumulative basis." Stands out because "cumulative" and "controllable" are not defined in the excerpt, and taxes, insurance, and utilities are outside the cap.
- **5.1:** "Landlord may commingle the deposit with its own funds." Stands out because the excerpt does not state any return or interest terms for the deposit.
- **6.2:** "so long as Tenant is not in default." Stands out because the landlord's exclusive covenant is conditioned on tenant default, and no remedy for a breach by Landlord is stated.
- **7.1:** "Tenant shall pay Alternative Rent equal to fifty percent (50%) of Base Rent." Stands out because the trigger "open for business" is undefined, and no notice requirement is stated before the reduced rent applies.
- **8.1:** "as determined by Landlord." Stands out because Landlord alone sets the fair market rent for option terms, and no determination process is stated.
- **9.1:** "which Landlord may withhold in its sole discretion" and "Landlord may recapture the Premises on any request for consent." Stands out because consent is at sole discretion, and a request alone triggers recapture.
- **11.1:** "at Tenant's cost, the HVAC and roof membrane." Stands out because the Tenant bears the roof membrane and HVAC, and no Landlord repair obligation appears in the excerpt.
- **12.1:** "Landlord's default occurs only if Landlord fails to cure within ninety (90) days after Tenant's written notice." Stands out because the Landlord's cure period (90 days) is three times the Tenant's non-monetary cure period (30 days), and the Landlord-default wording is restrictive.
- **13.1:** "Landlord may relocate Tenant to comparable space in the Center on sixty (60) days' notice." Stands out because the relocation right is unilateral, and "comparable" is undefined.
- **14.1:** "failure is a default without further notice." Stands out because it conflicts with the written-notice requirement in 12.1 (see Section 4 below).
- **15.1:** "two hundred percent (200%) of the last monthly rent." Stands out because the holdover rate is double the last monthly rent, with no stated notice or grace period.
- **16.1:** "personally guarantee all of Tenant's obligations under this Lease." Stands out because no cap, duration, or release is stated.
- **3.4:** Percentage rent of "six percent (6%) of Gross Sales above the natural breakpoint" has no stated cap, and the breakpoint amount is not stated.

**4. Missing or unclear**

- **Not stated in the document:** Breakpoint amount (3.4); definition of "Gross Sales" (3.4); base year and pro rata share percentage (4.1); Tenant's exclusive (N/A); expansion option (N/A); termination options other than 7.1 (N/A); Landlord's repair obligations (11.1); Landlord's SNDA obligation (14.1); security deposit return conditions (5.1); guaranty cap and duration (16.1); delivery date and opening date (2.1); signing date (5.1); other insurance coverages (10.1).
- **Undefined terms:** "controllable expenses" (4.1); "Center is open for business" (7.1); "comparable space" (13.1); "natural breakpoint" (3.4); "lease year one" (3.1); "Alternative Rent" is defined only inline in 7.1.
- **Conflicts within the excerpt:**
  - **12.1 vs. 14.1:** Section 12.1 requires written notice before a default occurs, but Section 14.1 says a failure to sign the SNDA or estoppel "is a default without further notice."
  - **4.1:** "per year on a cumulative basis" is internally unclear as to how the cap accumulates.
- **Other gaps:** Post-term application of the radius restriction (6.3) is not stated, and no definition of "directly or indirectly" appears. Recapture procedure after a consent request (9.1) is not stated.

This abstract covers only the text provided. The responsible attorney reviews the lease and docketing confirms every date.
