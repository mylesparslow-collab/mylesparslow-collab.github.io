**Scope:** The document is labeled an excerpt. It contains Articles 1–10 and a signature block. Not provided: Schedule C, the Settlors' pour-over wills, any amendments, and the notary acknowledgment.

## 1. Abstract

| Item | What the instrument says | Article / Section |
|---|---|---|
| Trust name and date | "THE ELLISON-VOSS FAMILY TRUST" / "Declaration of Trust dated September 14, 2019" | Title block |
| Type | "this revocable trust" | Article 1 |
| Settlors | "Margaret Ellison and Thomas Voss (the "Settlors")" | Article 1 |
| Initial trustees | "The initial trustees are the Settlors." | Article 1 |
| Successor trustees, in order | "Daniel Voss shall serve as successor trustee." If he "fails or ceases to act," "the successor trustee shall be the person named in Schedule C." Schedule C is not attached. Trigger: "On the death, incapacity, or resignation of both Settlors." | Article 4 |
| How incapacity is determined | "two licensed physicians certify in writing that the person is unable to manage financial affairs." | Article 3 |
| Trustee powers worth noting | "(a) sell, lease, or encumber real property without court order, (b) continue to operate any family business, and (c) make loans to beneficiaries on such terms as the trustee decides." | Article 5 |
| Distributions during life | Not stated in the document. | Not stated in the document. |
| Specific gifts at death | (a) "the Settlors' home at 88 Quarry Lane, Fictional City, to Daniel Voss, if he survives." (b) "$50,000 to the Larkspur Animal Shelter." Trigger: "Distributions on the Death of the Surviving Settlor." | Article 6(a), 6(b) |
| Residue | "equal shares for the Settlors' children, Daniel Voss and Nora Ellison-Voss." | Article 6(c) |
| Subtrusts, ages, conditions | "A child's share shall be held in a separate trust until the child reaches age thirty (30)." Trustee may distribute "income and principal ... for health, education, maintenance, and support," and "shall distribute one-half of the remaining principal at age twenty-five (25) and the balance at age thirty (30)." | Article 7 |
| Pour-over | "Any property not transferred to the trustee at a Settlor's death is intended to pass to this trust under the Settlors' pour-over wills." | Article 8 |
| No-contest clause (full) | "If any beneficiary contests this trust or any of its provisions, or any gift made under it, in any court, that beneficiary's interest shall be forfeited and distributed as if the beneficiary had predeceased the Settlors." | Article 9 |
| Amendment and revocation | "While both Settlors are living, either Settlor may revoke this trust as to community property only with the written consent of the other. Either Settlor may amend this trust as to that Settlor's separate property by a signed writing delivered to the trustee." | Article 2 |
| Governing law | "California law governs this trust." | Article 10 |
| Signatures, witnesses, notary | "Signed September 14, 2019: ______________ Margaret Ellison (Settlor and Trustee); ______________ Thomas Voss (Settlor and Trustee)." The signature lines are blank in the text provided, so I cannot tell from this copy whether it was signed. Witnesses: Not stated in the document. Notary: "[Notary acknowledgment not included in this excerpt.]" | Signature block after Article 10 |

## 2. Questions for the attorney

1. **Schedule C missing.** Article 4 says "the person named in Schedule C." Schedule C is not attached. Please obtain it.
2. **No second-level successor.** Article 4: "If Daniel Voss fails or ceases to act, the successor trustee shall be the person named in Schedule C." The instrument does not say who serves if the Schedule C person also fails. Not stated in the document.
3. **One-Settlor events.** Article 4 triggers on "the death, incapacity, or resignation of both Settlors." Who serves if only one Settlor dies, becomes incapacitated, or resigns? Not stated in the document.
4. **Co-trustees.** Article 1 says "The initial trustees are the Settlors." It does not say whether they act jointly or either may act alone. Not stated in the document.
5. **Revocability.** Article 1 says "this revocable trust," but Article 2 says a Settlor "may revoke this trust as to community property only with the written consent of the other." Please confirm the intended scope of revocation.
6. **Amendment gaps.** Article 2 allows amendment only "as to that Settlor's separate property." It does not say how community property may be amended. It also does not address changes after one Settlor's death, because it opens with "While both Settlors are living."
7. **Home has no alternate taker.** Article 6(a): "to Daniel Voss, if he survives." If Daniel does not survive, the instrument does not name a taker for 88 Quarry Lane. Not stated in the document.
8. **Charity gift.** Article 6(b): "$50,000 to the Larkspur Animal Shelter." No address or identifier is given, and no alternate applies if the shelter does not exist at the time of distribution. Not stated in the document.
9. **Child does not survive.** Article 6(c) divides the residue "equally" between Daniel Voss and Nora Ellison-Voss. It does not say what happens if one child does not survive the Settlors. Please also confirm these are the only children.
10. **Age 25 versus age 30 conflict.** Article 7 says: "A child's share shall be held in a separate trust until the child reaches age thirty (30)." It also says: "shall distribute one-half of the remaining principal at age twenty-five (25)." Which controls the age-25 distribution?
11. **"Remaining principal" is undefined.** Article 7: "one-half of the remaining principal." Remaining after what? Not stated in the document.
12. **Child dies before a subtrust distribution.** Article 7 does not say where a child's share goes if that child dies before age 25 or 30. Not stated in the document.
13. **Ages not provided.** The instrument does not state the ages or birth dates of Daniel Voss or Nora Ellison-Voss. Article 7 cannot be applied without them. Please confirm from the file.
14. **Charges against the residue.** Article 6(a) (home) and 6(b) ($50,000) come before Article 6(c): "The remaining trust estate (the "Residue")." It is not stated whether the home and the gift are charged before the equal division.
15. **Simultaneous death.** Article 6 is triggered by "the Death of the Surviving Settlor." Not stated in the document: what happens if both Settlors die at the same time.
16. **No-contest scope.** Article 9 covers a contest of "this trust or any of its provisions, or any gift made under it." Please confirm whether it reaches a contest of the pour-over wills in Article 8. It also says the forfeited interest is "distributed as if the beneficiary had predeceased the Settlors." Article 6 does not say where a forfeited child's share then goes. Not stated in the document.
17. **Pour-over wills not provided.** Article 8 refers to "the Settlors' pour-over wills." The wills and any named executor are not in the excerpt. Please obtain them.
18. **Is the home in the trust?** Article 6(a) refers to "the Settlors' home at 88 Quarry Lane, Fictional City." The instrument does not say whether the property is titled in the trust. Not stated in the document.
19. **Undefined trustee terms.** Article 5(b) refers to "any family business" without identifying one. Article 5(c) allows loans "on such terms as the trustee decides," with no standard. Not stated in the document.
20. **Signature and notary blocks.** The signature lines in the text are blank. The copy does not show signatures, witnesses, or a notary acknowledgment. Please obtain the executed original and the notary acknowledgment.
21. **Lifetime distributions and amendments.** No lifetime distribution provision and no amendments are included in the excerpt. Please confirm whether the full instrument contains either.

This abstract covers only the text provided. The responsible attorney reviews the instrument.
