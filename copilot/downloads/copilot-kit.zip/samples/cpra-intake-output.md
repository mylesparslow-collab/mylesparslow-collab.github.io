# Records Request Intake

**Header**
- **Requester:** Dana Okafor-Reyes, Larkspur Courier. Contact as written: dokafor@larkspurcourier.example; (555) 010-0177
- **Agency addressed:** City Clerk, City of Larkspur Hills (cityclerk@larkspurhills.example)
- **Date received:** Ask the clerk. The document shows "Sent: Tuesday, March 4, 2025, 4:52 p.m." That is a sent date, not a receipt date.
- **Delivery format requested:** "Electronic copies by email are fine." (Body, opening paragraph)

---

## 1. Requests

**1(a). Emails**
- **Request:** "All emails ... from January 1, 2024 to the date of this request between Councilmember Priya Anand and anyone at Bayfront Partners LLC concerning the Harbor Row project." (Body, item 1)
- **Likely custodians or departments:** Councilmember Priya Anand; "anyone at Bayfront Partners LLC" is not a custodian. Confirm with the clerk whether the Councilmember's city email account and the clerk's records are the relevant sources.
- **Search terms:** "Priya Anand," "Councilmember Anand," "Anand," "Bayfront Partners LLC," "Bayfront," "Harbor Row"
- **Date range:** "from January 1, 2024 to the date of this request." The end date depends on what "the date of this request" means (see Clarity).
- **Possible exemption categories for counsel to consider:**
  - Are any of these emails attorney-client communications?
  - Do any emails reflect deliberative process on the Harbor Row project?
  - Do any emails contain business information supplied by Bayfront Partners LLC that may be confidential?
  - Does the Harbor Row project involve pending or anticipated litigation?
- **Clarity:**
  - "concerning the Harbor Row project": "concerning" is broad. Question for requester: Do you want only messages with Bayfront Partners LLC personnel that mention Harbor Row, or also messages among other people about Harbor Row?
  - "to the date of this request": The document gives a sent date (March 4, 2025) but no receipt date. Question for requester: Which date do you mean as the end of the range?

**1(b). Text messages**
- **Request:** "All ... text messages from January 1, 2024 to the date of this request between Councilmember Priya Anand and anyone at Bayfront Partners LLC concerning the Harbor Row project." (Body, item 1)
- **Likely custodians or departments:** Councilmember Priya Anand. Confirm with the clerk which devices or accounts hold text messages, and whether any are personal devices.
- **Search terms:** Same as 1(a). Add "text," "SMS," and "messages."
- **Date range:** "from January 1, 2024 to the date of this request." See Clarity.
- **Possible exemption categories for counsel to consider:**
  - Are any text messages on personal devices or accounts, and does that affect the search?
  - Are any messages attorney-client communications?
  - Do any messages reflect deliberative process?
  - Do any messages contain business information supplied by Bayfront Partners LLC that may be confidential?
- **Clarity:** Same questions as 1(a). Also: Does the requester want text messages from personal devices, city-issued devices, or both?

**2(a). Contract**
- **Request:** "The contract with Brightline Paving Inc. for the 2024 street resurfacing program, with all amendments and change orders." (Body, item 2)
- **Likely custodians or departments:** Not stated in the document. Confirm with the clerk, since the request names no department.
- **Search terms:** "Brightline Paving Inc.," "Brightline Paving," "2024 street resurfacing program," "contract"
- **Date range:** Not stated in the document.
- **Possible exemption categories for counsel to consider:**
  - Does the contract contain pricing or bid information that Brightline Paving Inc. may claim as confidential?
- **Clarity:** "The contract" could mean only the executed agreement or also the bid and related procurement documents. Question for requester: Do you want only the executed contract, or also bid or proposal documents?

**2(b). Amendments and change orders**
- **Request:** "... with all amendments and change orders." (Body, item 2)
- **Likely custodians or departments:** Not stated in the document. Confirm with the clerk.
- **Search terms:** "amendment," "amendments," "change order," "change orders," plus the search terms in 2(a)
- **Date range:** Not stated in the document.
- **Possible exemption categories for counsel to consider:**
  - Do any amendments or change orders contain pricing information that Brightline Paving Inc. may claim as confidential?
- **Clarity:** "all amendments and change orders" is specific enough on its face. No question needed unless counsel wants to confirm the scope.

**3. Police Department records**
- **Request:** "All records relating to the Larkspur Hills Police Department." (Body, item 3)
- **Likely custodians or departments:** "Larkspur Hills Police Department." Confirm with the clerk and the department.
- **Search terms:** "Larkspur Hills Police Department," "police," "Police Department," "LHPD" (variant not in the request; confirm with the clerk)
- **Date range:** Not stated in the document.
- **Possible exemption categories for counsel to consider:**
  - Does this ask reach investigative or law-enforcement records?
  - Does this ask reach personnel records?
  - Does this ask reach records of pending or open matters?
  - Are any records attorney-client communications?
- **Clarity:** This ask is overbroad. Quoted words: "All records" and "relating to." Question for requester: Which records about the Larkspur Hills Police Department do you seek? Please identify a subject, time period, or type of record.

**4. City Manager's calendar**
- **Request:** "The City Manager's calendar entries for February 2025." (Body, item 4)
- **Likely custodians or departments:** "City Manager." Confirm with the clerk and the City Manager's office.
- **Search terms:** "City Manager," "calendar," "calendar entries," "February 2025"
- **Date range:** "for February 2025" (as written).
- **Possible exemption categories for counsel to consider:**
  - Do any calendar entries reflect attorney-client communications or deliberative matters?
  - Do any calendar entries contain personal information about non-officials?
  - Do any calendar entries reflect personal rather than city business?
- **Clarity:** "calendar" could mean a city calendar, a personal calendar, or meeting invitations. Question for requester: Do you want entries from the City Manager's city calendar only, or from other calendars as well?

**5(a). Settlement agreement**
- **Request:** "The settlement agreement ... in the claim brought by a former Public Works employee against the City last year." (Body, item 5)
- **Likely custodians or departments:** "Public Works" is named as the employee's former department. Confirm with the clerk and counsel's office. The document does not name a custodian.
- **Search terms:** "settlement agreement," "settlement," "claim," "former Public Works employee," "Public Works"
- **Date range:** "last year" (as written). Not stated in the document.
- **Possible exemption categories for counsel to consider:**
  - Does the claim or settlement involve personnel records?
  - Is the claim, or any related matter, pending litigation?
  - Are any settlement terms subject to confidentiality or privacy protections counsel must review?
- **Clarity:** The claim is not identified by name, claim number, or filing date. "last year" is a relative phrase. Question for requester: Can you identify the claim by claimant name, claim number, or filing date?

**5(b). Payment records**
- **Request:** "... and any records of payment, in the claim brought by a former Public Works employee against the City last year." (Body, item 5)
- **Likely custodians or departments:** Not stated in the document. Confirm with the clerk and the finance or payroll office.
- **Search terms:** "payment," "records of payment," "check," "warrant," "voucher," plus the search terms in 5(a)
- **Date range:** "last year" (as written). Not stated in the document.
- **Possible exemption categories for counsel to consider:**
  - Do any payment records reveal personnel or payroll information about the former employee?
  - Are any payment records attorney-client communications?
- **Clarity:** "any records of payment" is broad. Quoted words: "any records." Question for requester: Which payment records do you seek, such as payment vouchers, checks, or ledger entries?

---

## 2. Timing

Gov. Code §7922.535(a): the agency must determine within 10 days whether it has disclosable records; under §7922.535(b) it may extend by written notice in unusual circumstances, by no more than 14 days. Counsel confirms the dates and any later amendments.

No receipt date is stated in the document, so no date is given here. The requester wrote: "I would appreciate a response as soon as possible, and I am on deadline, so please treat this as urgent." (Closing paragraph)

---

## 3. Draft acknowledgment letter (for staff review)

[City of Larkspur Hills letterhead]

[Date]

Dana Okafor-Reyes
Larkspur Courier
dokafor@larkspurcourier.example

Dear Ms. Okafor-Reyes:

Thank you for your Public Records Act request to the City Clerk, which the City received on [date confirmed by the clerk]. Staff are reviewing your request and will respond as the law requires.

If you have questions, please contact [name, title, phone, email].

Sincerely,

[Name]
[Title]
City of Larkspur Hills

---

This intake is a working aid. Counsel and the clerk decide the response.
