## Order identification

Note: The pasted text appears complete (paragraphs 1–10, "IT IS SO ORDERED," and the date and signature block).

- **Court:** "SUPERIOR COURT OF THE STATE OF CALIFORNIA FOR THE COUNTY OF MERIDIAN"
- **Case name:** "HARTWELL & SONS FABRICATION, INC., a California corporation, Plaintiff, v. NORTHSTAR LOGISTICS GROUP, LLC, a Nevada limited liability company, and DOES 1 through 25, Defendants."
- **Case number:** "Case No. 24CV-031187"
- **Title:** "ORDER AFTER CASE MANAGEMENT CONFERENCE"
- **Date of order:** "Dated: April 8, 2025"
- **Judge and department:** "Hon. Eleanor V. Marchetti-Sloane" (Judge of the Superior Court); "Department 12"

## Obligations

| # | What must be done | Who must do it | Date or trigger as written (verbatim) | Where |
|---|---|---|---|---|
| 1 | Attend the Mandatory Settlement Conference in person | "Lead trial counsel" | "A Mandatory Settlement Conference is set for January 16, 2026, at 1:30 p.m. in Department 12." | ¶2 |
| 2 | Attend the Mandatory Settlement Conference in person | "a representative of each party with full settlement authority" | "A Mandatory Settlement Conference is set for January 16, 2026, at 1:30 p.m. in Department 12." | ¶2 |
| 3 | Lodge a Settlement Conference Statement with the Court | "Each party" | Docketing to calculate: "no later than five (5) court days before the Mandatory Settlement Conference, in accordance with local rules." Specific rule not named in the order (refers only to "local rules"). | ¶2 |
| 4 | File and serve trial documents, including motions in limine, witness lists, exhibit lists, and proposed jury instructions | "Counsel" | "no later than the Trial Readiness Conference set for January 30, 2026, at 8:30 a.m. in Department 12" | ¶3 |
| 5 | Prepare trial documents as required by the Local Rules | "Counsel" | Not stated in the document. (Phrase reads: "as required by the Local Rules.") | ¶3 |
| 6 | Complete all discovery | Not stated in the order | Docketing to calculate: "all discovery shall be completed 30 days before the date initially set for trial" + Code of Civil Procedure section 2024.020 | ¶4 |
| 7 | Have motions concerning discovery heard | Not stated in the order | Docketing to calculate: "Motions concerning discovery shall be heard no later than 15 days before the date initially set for trial." No rule or statute named. | ¶4 |
| 8 | Exchange expert witness information | "The parties" | "on the date set by the Court below" (statute cited: Code of Civil Procedure section 2034.230) | ¶5 |
| 9 | Initial expert disclosure | Not stated in the order | "November 3, 2025" (sentence: "Initial expert disclosure is due on November 3, 2025.") | ¶5 |
| 10 | Rebuttal expert disclosure | Not stated in the order | Docketing to calculate: "Rebuttal expert disclosure is due as provided by statute." Statute not named in the order. | ¶5 |
| 11 | File, notice, and hear any motion for summary judgment or summary adjudication | Not stated in the order ("Any motion") | Docketing to calculate: "shall be filed, noticed, and heard in accordance with Code of Civil Procedure section 437c" | ¶6 |
| 12 | Have any motion for summary judgment or summary adjudication heard | Not stated in the order | Docketing to calculate: "shall be heard no later than 30 days before trial." No rule or statute named. | ¶6 |
| 13 | Participate in private mediation | "The parties" | Not stated in the document. (Sentence: "The parties are ordered to participate in private mediation.") | ¶7 |
| 14 | Select a mediator | "Plaintiff" | Docketing to calculate: "within 21 days of this order." No rule or statute named. | ¶7 |
| 15 | Notify Defendant of the selected mediator | "Plaintiff" | Docketing to calculate: "within 21 days of this order." No rule or statute named. | ¶7 |
| 16 | Complete mediation | Not stated in the order | "October 15, 2025" (sentence: "Mediation shall be completed by October 15, 2025.") | ¶7 |
| 17 | File a status report regarding the identity of Doe defendants, or a request to dismiss the Doe defendants | "Plaintiff" | "at the Further Case Management Conference" | ¶8 |
| 18 | File an updated Case Management Statement | "Parties" | Docketing to calculate: "as required by California Rules of Court, rule 3.725." No trigger date stated. | ¶9 |
| 19 | Give notice of this order to all parties who did not appear at the conference | "Plaintiff" | Not stated in the document. (Phrase reads: "all parties who did not appear at the conference.") | ¶10 |

**Court actions stated in the order**

- Sets jury trial: "Jury trial is set for February 9, 2026, at 9:00 a.m. in Department 12." (¶1)
- Sets Mandatory Settlement Conference: "A Mandatory Settlement Conference is set for January 16, 2026, at 1:30 p.m. in Department 12." (¶2)
- Sets Trial Readiness Conference: "the Trial Readiness Conference set for January 30, 2026, at 8:30 a.m. in Department 12" (¶3)
- Sets the expert exchange date: "on the date set by the Court below" (¶5)
- Sets Further Case Management Conference: "A Further Case Management Conference is set for August 12, 2025, at 8:30 a.m. in Department 12." (¶9)

## Hearings and appearances

| Event | Date | Time | Department or location | Who must appear | Remote or in person (if stated) | Where |
|---|---|---|---|---|---|---|
| Case Management Conference (held) | "held on April 8, 2025" | Not stated | Not stated | "counsel for Plaintiff, Ruth Anderssen-Cole, and counsel for Defendant Northstar Logistics Group, LLC, Marcus Delgado-Pryor, appeared" | Not stated | Preamble |
| Jury trial (estimated length: "seven (7) court days") | February 9, 2026 | 9:00 a.m. | Department 12 | Not stated | Not stated | ¶1 |
| Mandatory Settlement Conference | January 16, 2026 | 1:30 p.m. | Department 12 | "Lead trial counsel and a representative of each party with full settlement authority" | "must attend in person" | ¶2 |
| Trial Readiness Conference | January 30, 2026 | 8:30 a.m. | Department 12 | Not stated | Not stated | ¶3 |
| Further Case Management Conference | August 12, 2025 | 8:30 a.m. | Department 12 | Not stated | Not stated | ¶9 |

## Items for docketing to confirm

1. **Settlement Conference Statement (¶2):** "no later than five (5) court days before the Mandatory Settlement Conference, in accordance with local rules." Docketing to calculate. The specific local rule is not named.
2. **Trial documents (¶3):** "as required by the Local Rules." The Local Rules are not identified, and no rule is named.
3. **Discovery cut-off and discovery motions (¶4):** "all discovery shall be completed 30 days before the date initially set for trial" and "Motions concerning discovery shall be heard no later than 15 days before the date initially set for trial." Both are Docketing to calculate. The order does not say who must complete discovery or who must bring the motions. Also, ¶1 states "Jury trial is set for February 9, 2026," but the order does not say whether that is the date "initially set for trial."
4. **Expert exchange date (¶5):** "on the date set by the Court below" and "Initial expert disclosure is due on November 3, 2025." The first passage refers to a date "below." Confirm whether "November 3, 2025" is that date. The subject of "Initial expert disclosure is due" is not stated, while the preceding sentence reads "The parties shall exchange expert witness information."
5. **Rebuttal expert disclosure (¶5):** "Rebuttal expert disclosure is due as provided by statute." The statute is not named.
6. **Summary judgment and summary adjudication (¶6):** "shall be filed, noticed, and heard in accordance with Code of Civil Procedure section 437c" and "shall be heard no later than 30 days before trial." Both are Docketing to calculate. The order does not say who must file, and "trial" is not defined. Paragraph 4 uses "the date initially set for trial," and paragraph 1 states "Jury trial is set for February 9, 2026." Confirm which trial date applies.
7. **Mediator selection and notice (¶7):** "within 21 days of this order." Docketing to calculate. The order's date line reads "Dated: April 8, 2025." Confirm the trigger.
8. **Mediation (¶7):** "The parties are ordered to participate in private mediation" gives no date for participation. "Mediation shall be completed by October 15, 2025" gives a completion date. The order does not say who must complete mediation.
9. **Doe defendants (¶8):** "a status report regarding the identity of Doe defendants, or a request to dismiss the Doe defendants, at the Further Case Management Conference." The "or" makes this one of two alternatives. The Further Case Management Conference is set in ¶9 for "August 12, 2025, at 8:30 a.m. in Department 12."
10. **Updated Case Management Statement (¶9):** "as required by California Rules of Court, rule 3.725." Docketing to calculate. No trigger date is stated.
11. **Notice to non-appearing parties (¶10):** "all parties who did not appear at the conference." The preamble identifies only counsel for Plaintiff and counsel for Defendant Northstar Logistics Group, LLC as appearing. The order does not identify any other party, including DOES 1 through 25, or confirm who did not appear.
12. **Past-date check against the order's date (April 8, 2025):** No stated calendar date falls before April 8, 2025.
13. **For information, relative to today (November 11, 2026):** Every stated calendar date (August 12, 2025; October 15, 2025; November 3, 2025; January 16, 2026; January 30, 2026; February 9, 2026) falls before today's date. Confirm whether these events have already occurred or whether a later order governs.
14. **Document source:** The pasted text begins with a header reading "Sample input: case management order (invented)" and "All names and facts are invented." I treated the text as the order as pasted. Confirm it is the actual signed order before calendaring.

Docketing staff and the responsible attorney confirm all dates before they are calendared.
