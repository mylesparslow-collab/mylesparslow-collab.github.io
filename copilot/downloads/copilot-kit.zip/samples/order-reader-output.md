## Order identification

- **Court:** "SUPERIOR COURT OF THE STATE OF CALIFORNIA FOR THE COUNTY OF MERIDIAN (fictional county)"
- **Case name:** "HARTWELL & SONS FABRICATION, INC., a California corporation, Plaintiff, v. NORTHSTAR LOGISTICS GROUP, LLC, a Nevada limited liability company, and DOES 1 through 25, Defendants."
- **Case number:** "Case No. 24CV-031187"
- **Title of document:** "ORDER AFTER CASE MANAGEMENT CONFERENCE"
- **Date of order:** "Dated: April 8, 2025"
- **Judge / department:** "Hon. Eleanor V. Marchetti-Sloane" / "Department 12"

The document appears complete: it has numbered paragraphs 1–10, "IT IS SO ORDERED," and a signature block. The pasted text opens with a preface stating that the input is invented sample material. That preface is not part of the order and was not treated as an obligation.

## Obligations

In the "Where" column, ¶ means paragraph of the order.

| # | What must be done | Who must do it | Date or trigger as written (verbatim) | Where |
|---|---|---|---|---|
| 1 | Attend the Mandatory Settlement Conference in person | "Lead trial counsel and a representative of each party with full settlement authority" | "set for January 16, 2026, at 1:30 p.m. in Department 12" | ¶2 |
| 2 | Lodge a Settlement Conference Statement with the Court | "Each party" | Docketing to calculate: "no later than five (5) court days before the Mandatory Settlement Conference, in accordance with local rules." Rule not named in the order. | ¶2 |
| 3 | File and serve trial documents, including motions in limine, witness lists, exhibit lists, and proposed jury instructions | "Counsel" | "no later than the Trial Readiness Conference set for January 30, 2026, at 8:30 a.m. in Department 12" | ¶3 |
| 4 | Make the trial documents in row 3 in the form and timing required by the Local Rules | "Counsel" | Docketing to calculate: "as required by the Local Rules." Rule not named in the order. | ¶3 |
| 5 | Complete all discovery | "Not stated in the order" | Docketing to calculate: "all discovery shall be completed 30 days before the date initially set for trial," pursuant to Code of Civil Procedure section 2024.020 | ¶4 |
| 6 | Have motions concerning discovery heard | "Not stated in the order" | Docketing to calculate: "Motions concerning discovery shall be heard no later than 15 days before the date initially set for trial." No rule cited in this sentence. | ¶4 |
| 7 | Exchange expert witness information under Code of Civil Procedure section 2034.230 | "The parties" (per "The parties shall exchange expert witness information") | "on the date set by the Court below" (see row 8) | ¶5 |
| 8 | Initial expert disclosure | "Not stated in the order" | "Initial expert disclosure is due on November 3, 2025." | ¶5 |
| 9 | Rebuttal expert disclosure | "Not stated in the order" | Docketing to calculate: "Rebuttal expert disclosure is due as provided by statute." Statute not named in the order. | ¶5 |
| 10 | File, notice, and hear any motion for summary judgment or summary adjudication | "Not stated in the order" | Docketing to calculate: "shall be filed, noticed, and heard in accordance with Code of Civil Procedure section 437c" | ¶6 |
| 11 | Hear any motion for summary judgment or summary adjudication | "Not stated in the order" | Docketing to calculate: "shall be heard no later than 30 days before trial." No rule cited in this clause. | ¶6 |
| 12 | Participate in private mediation | "The parties" ("The parties are ordered to participate in private mediation") | "Not stated in the document." | ¶7 |
| 13 | Select a mediator and notify Defendant | "Plaintiff" | Docketing to calculate: "within 21 days of this order." Rule not named in the order. | ¶7 |
| 14 | Complete mediation | "Not stated in the order" (see row 12) | "Mediation shall be completed by October 15, 2025." | ¶7 |
| 15 | File a status report regarding the identity of Doe defendants, or a request to dismiss the Doe defendants | "Plaintiff" | "at the Further Case Management Conference" (see ¶9 for the date) | ¶8 |
| 16 | File an updated Case Management Statement | "Parties" | Docketing to calculate: "as required by California Rules of Court, rule 3.725" | ¶9 |
| 17 | Give notice of this order to all parties who did not appear at the conference | "Plaintiff" | "Not stated in the document." | ¶10 |

**Court actions stated in the order**

- Jury trial is set for February 9, 2026, at 9:00 a.m. in Department 12. The estimated length of trial is seven (7) court days. (¶1)
- Mandatory Settlement Conference is set for January 16, 2026, at 1:30 p.m. in Department 12. (¶2)
- Trial Readiness Conference is set for January 30, 2026, at 8:30 a.m. in Department 12. (¶3)
- Further Case Management Conference is set for August 12, 2025, at 8:30 a.m. in Department 12. (¶9)

## Hearings and appearances

| Event | Date | Time | Department or location | Who must appear | Remote or in person (if stated) | Where |
|---|---|---|---|---|---|---|
| Further Case Management Conference | August 12, 2025 | 8:30 a.m. | Department 12 | Not stated | Not stated | ¶9 |
| Mandatory Settlement Conference | January 16, 2026 | 1:30 p.m. | Department 12 | "Lead trial counsel and a representative of each party with full settlement authority" | "in person" | ¶2 |
| Trial Readiness Conference | January 30, 2026 | 8:30 a.m. | Department 12 | Not stated | Not stated | ¶3 |
| Jury trial | February 9, 2026 | 9:00 a.m. | Department 12 | Not stated | Not stated | ¶1 |

## Items for docketing to confirm

1. **Docketing to calculate (rule or statute not named):** Row 2, "no later than five (5) court days before the Mandatory Settlement Conference, in accordance with local rules."
2. **Docketing to calculate (rule not named):** Rows 4, 9, and 13 ("as required by the Local Rules"; "as provided by statute"; "within 21 days of this order").
3. **Docketing to calculate (statute cited):** Row 5, "30 days before the date initially set for trial," pursuant to Code of Civil Procedure section 2024.020.
4. **Docketing to calculate (no rule cited in the sentence):** Row 6, "no later than 15 days before the date initially set for trial." Confirm whether the "Pursuant to Code of Civil Procedure section 2024.020" in ¶4 applies to this sentence.
5. **Docketing to calculate (statute cited):** Rows 10 and 11, "in accordance with Code of Civil Procedure section 437c" and "no later than 30 days before trial." No rule is cited in the second clause.
6. **Docketing to calculate (rule cited):** Row 16, "as required by California Rules of Court, rule 3.725." The order does not state when the updated statement is due relative to the August 12, 2025 conference.
7. **Who is responsible (not stated):** Row 5 ("all discovery shall be completed"), row 6 (discovery motions "shall be heard"), rows 8 and 9 (expert disclosures), row 10 and 11 (dispositive motions), and row 14 (mediation completion). The order does not name a party for these.
8. **Ambiguity, trial date reference:** ¶1 states "Jury trial is set for February 9, 2026." ¶4 refers to "the date initially set for trial," and ¶6 refers to "trial." The order does not state whether February 9, 2026 is the initially set trial date or whether it has been changed.
9. **Ambiguity, expert disclosure date:** ¶5 states "on the date set by the Court below," and then "Initial expert disclosure is due on November 3, 2025." Confirm whether November 3, 2025 is the date referred to.
10. **Ambiguity, "Defendant":** ¶7 states "notify Defendant." The caption lists "NORTHSTAR LOGISTICS GROUP, LLC ... and DOES 1 through 25, Defendants." Confirm which defendant or defendants are meant.
11. **Ambiguity, trigger date:** ¶7 states "within 21 days of this order." The order is dated "April 8, 2025." The order does not state whether this runs from the order date, entry, or service.
12. **Ambiguity, "Counsel":** ¶3 states "Counsel shall file and serve trial documents." The order does not say which counsel.
13. **Ambiguity, parties who did not appear:** ¶10 states "all parties who did not appear at the conference." ¶(preamble) states "Counsel for Plaintiff, Ruth Anderssen-Cole, and counsel for Defendant Northstar Logistics Group, LLC, Marcus Delgado-Pryor, appeared." The order does not list any other appearances.
14. **Ambiguity, Doe status report:** ¶8 states "at the Further Case Management Conference." This refers to the conference set in ¶9 for August 12, 2025, at 8:30 a.m. ¶8 also gives two alternatives ("a status report ... or a request to dismiss"). Confirm that the either/or reading is intended.
15. **Past dates:** None of the dates in the order appears to fall before the order's own date of April 8, 2025.

Docketing staff and the responsible attorney confirm all dates before they are calendared.
