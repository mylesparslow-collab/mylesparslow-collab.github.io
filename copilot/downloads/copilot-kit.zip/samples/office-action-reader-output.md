**Application serial number:** "98/765,432" | **Mark:** "SMOOTHROAST" | **Applicant:** "Tidewell Provisions LLC" | **Issue date:** "October 6, 2026" | **Examining attorney:** Not stated in the document.

| # | Refusal or requirement | Ground as the office action states it (quoted) | What the office action says | Cited registrations | What the examiner says would resolve it (quoted) |
|---|---|---|---|---|---|
| 1 | Section 2(d) refusal: likelihood of confusion (Section 2(d) Refusal, para. 1) | "Registration of the applied-for mark is refused because of a likelihood of confusion with the mark in U.S. Registration No. 5,512,308. Trademark Act Section 2(d), 15 U.S.C. §1052(d)." | "The marks are similar in sound, appearance, and meaning, and the goods are identical in part." | U.S. Reg. No. 5,512,308 | "Applicant may respond to this refusal by submitting evidence and arguments against the refusal, or by deleting or limiting the goods, or by obtaining the consent of the registrant." (Section 2(d) Refusal, para. 1) |
| 2 | Section 2(e)(1) refusal: merely descriptive (Section 2(e)(1) Refusal, para. 1) | "Registration is also refused because the applied-for mark merely describes a feature of the applicant's goods. Trademark Act Section 2(e)(1), 15 U.S.C. §1052(e)(1)." | "The examining attorney states that 'SMOOTH' describes the taste of the coffee and 'ROAST' names the process by which it is made, and that combining the two terms creates no unique commercial impression." | Not stated in the document. | "Applicant may respond by submitting evidence and arguments, or by amending the application to the Supplemental Register if the mark is in use in commerce." (Section 2(e)(1) Refusal, para. 2) |
| 3 | Identification of goods requirement (Identification of Goods Requirement, para. 1) | "The identification 'coffee; beverages' is indefinite. The word 'beverages' must be clarified." | Suggested amendment: "Coffee; coffee-based beverages." | Not applicable. | "Applicant may adopt this wording or substitute wording that is more specific, but may not broaden the scope of the goods." (Identification of Goods Requirement, para. 2) |
| 4 | Specimen (advisory; Response Guidelines, para. 2) | "The applicant should also submit a specimen if the application is based on use in commerce under Section 1(a); no specimen is currently of record." | "No specimen is currently of record." | Not applicable. | "The applicant should also submit a specimen if the application is based on use in commerce under Section 1(a)." (Response Guidelines, para. 2) |

**Cited prior registrations**

| Registration number | Mark | Owner | Goods or services (as stated) |
|---|---|---|---|
| 5,512,308 | "SMOOTH ROASTERS" | "Calder Street Roasters Inc." | "coffee beans; ground coffee." |

**Timing**

- Response Guidelines, para. 1: "The applicant must respond to this Office action within three months of the issue date. Failure to respond will result in abandonment of the application."
- USPTO: the response is due three months from the issue date of the office action; one three-month extension is available for a fee (Madrid section 66(a) applications differ). Docketing calculates and confirms.
- The action does not state whether the application is a Madrid application.

**Information needed from the client**

- **Identification of goods:** Clarify the word "beverages" in "coffee; beverages." The action suggests "Coffee; coffee-based beverages." or wording that is more specific. It may not broaden the goods.
- **Specimen:** Submit a specimen if the application is based on use in commerce under Section 1(a). The action says none is currently of record.
- **Section 2(d) refusal:** The action lists these options: evidence and arguments against the refusal, deleting or limiting the goods, or obtaining the registrant's consent.
- **Section 2(e)(1) refusal:** The action lists these options: evidence and arguments, or amending to the Supplemental Register if the mark is in use in commerce.

**Questions for the attorney**

- The filing basis is not stated in the document. The specimen item and the Supplemental Register option both refer to use in commerce under Section 1(a).
- The examining attorney's name is not stated in the document.
- The document gives no status information for Reg. No. 5,512,308 beyond the mark, owner, and goods. Not stated in the document.
- The text has no examiner signature block and lists no attachments. Please confirm the text provided is the complete action.

This is a checklist read of the text provided. The responsible attorney decides.
