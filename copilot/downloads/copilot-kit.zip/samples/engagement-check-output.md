**Thornwood Garza LLP engagement letter** | Dated April 15, 2025 | Parties: Thornwood Garza LLP ("the Firm") and Redfern Tidal Energy, Inc. ("Redfern"), addressed to Ms. Corinne Haverford-Ng, CEO | Not contingency: fees are hourly (¶3)

| # | Item | Status | Clause quoted (verbatim, with paragraph) | Note |
|---|---|---|---|---|
| **A. Bus. & Prof. Code § 6148** | | | | |
| 1 | Basis of compensation (rate, flat fee, or other basis) | Present | ¶3 (Fees): "Our fees will be based on the time spent by our lawyers and staff at their hourly rates. Current rates are: partners, $780 per hour; associates, $520 per hour; paralegals, $260 per hour." | |
| 2 | Nature of legal services | Present | ¶1 (Scope of Services): "The Firm will represent Redfern in negotiating and, if necessary, litigating a dispute with Pelham Docks Authority over the terms of the lease for Pier 4." | |
| 3 | Respective responsibilities of attorney and client | Present | ¶2 (Responsibilities): "The Firm will keep you informed of significant developments and will respond promptly to your questions. Redfern agrees to provide accurate and complete information, to make decisions promptly, and to pay our invoices on time." | |
| 4 | Statement about changes to rates or basis | Present | ¶3 (Fees): "The Firm may adjust its rates once a year, on thirty days' written notice." | |
| **B. Bus. & Prof. Code § 6147** | | | | |
| 5 | Contingency rate | Not applicable (not a contingency matter) | | |
| 6 | Disbursements and costs and their effect on the client's recovery | Not applicable (not a contingency matter) | | |
| 7 | Related-matter compensation outside the contingency agreement | Not applicable (not a contingency matter) | | |
| 8 | Statement that fee is not set by law and is negotiable | Not applicable (not a contingency matter) | | |
| 9 | Signed duplicate copy provided to client | Not applicable (not a contingency matter) | | |
| **C. Rule 1.5 fee terms** | | | | |
| 10 | Fee terms stated clearly: billing intervals, retainer, cost billing, refund of unearned amounts | Unclear | ¶4 (Costs): "Costs over $2,500 will be sent to Redfern for direct payment." ¶5 (Retainer): "Any unused portion will be refunded." ¶6 (Billing): "Invoices are sent monthly and are due within thirty days." | ¶4 does not say whether the $2,500 threshold applies per cost item or to total costs. |
| **D. Rule 1.4.2** | | | | |
| 11 | Insurance disclosure | Present: the letter states the firm has insurance | ¶7 (Professional Liability Insurance): "The Firm maintains errors and omissions insurance applicable to the services to be rendered under this agreement." | Disclosure is needed only if the firm lacks insurance. |
| **E. Rule 1.7** | | | | |
| 12 | Conflict waiver shows informed written consent | Unclear | ¶8 (Conflict Waiver): "Redfern understands that the Firm represents other clients in the energy industry, and Redfern agrees that the Firm may continue to do so. Redfern waives any conflicts of interest that may arise now or in the future." | Sub-line (a), circumstances described: only that the Firm "represents other clients in the energy industry." Sub-line (b), reasonably foreseeable adverse consequences: Not stated in the document. The paragraph also does not say the consent must be written, and it waives conflicts "that may arise now or in the future" without describing them. |
| **F. General terms** | | | | |
| 13 | Scope and limitations | Present | ¶1 (Scope of Services): "The engagement does not include tax advice, regulatory permitting, or any appeal. If you want us to handle any of those, we will need a separate written agreement." | |
| 14 | Termination or withdrawal by either side | Missing | Not stated in the document. | ¶9 covers changing the agreement, not ending it. |
| 15 | File retention and return | Missing | Not stated in the document. | |
| 16 | Signature blocks with date lines | Unclear | Firm: "By: ______________________ Joaquin Delacruz-Weiss, Partner" (no date line). Client: "Date: ______________" | The firm's block has no date line; the client's does. |
| 17 | Identity of client (entity or individual, and any non-clients) | Unclear | "Thank you for selecting Thornwood Garza LLP ("the Firm") to represent Redfern Tidal Energy, Inc. ("Redfern")." | The client entity is clear. The letter does not say whether any individual, such as the addressee, is or is not a client. |

**Note on § 6148:** Section 6148 has exceptions (for example, certain recurring services or corporate clients). Whether any applies is for the attorney to decide.

**For the attorney**
1. Item 10: Clarify whether the $2,500 cost threshold in ¶4 applies per cost item or to total costs.
2. Item 12: The conflict waiver in ¶8 describes the circumstance only generally, does not describe foreseeable adverse consequences, does not say consent must be in writing, and covers conflicts "that may arise now or in the future."
3. Item 14: Termination or withdrawal is not addressed.
4. Item 15: File retention and return are not addressed.
5. Item 16: The firm signature block has no date line.
6. Item 17: The letter does not say whether any non-client is covered.

This is a drafting checklist, not legal advice. The responsible attorney decides what the letter should say.
