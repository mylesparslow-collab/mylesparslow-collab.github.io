## Draft log

| No. | Date | Author | Recipients (to and cc) | Document type | Description | Privilege asserted |
|---|---|---|---|---|---|---|
| 1 | 2025-01-06 | Marcus Pell | Hana Lindqvist | Not stated | Communication regarding review of tidal turbine supply contract. | attorney-client |
| 2 | 2025-01-08 | Hana Lindqvist | Marcus Pell | Email (inferred from "RE:") | Reply regarding review of tidal turbine supply contract. | attorney-client |
| 3 | 2025-01-13 | Priya Nandakumar | To: Marcus Pell; cc: Hana Lindqvist | Memorandum | Memorandum regarding dispute with Pelham Docks Authority. | attorney-client; work product |
| 4 | 2025-01-15 | Hana Lindqvist | Owen Barlow | Notes | Notes regarding Pelham dockside inspection. | attorney-client |
| 5 | 2025-01-21 | Marcus Pell | Priya Nandakumar | Not stated | Communication regarding lease termination notice. | attorney-client |
| 6 | 2025-01-22 | Priya Nandakumar | To: Marcus Pell; cc: Corinne Haverford-Ng; Tessa Brandt (Brandt Strategic Communications) | Draft | Draft press statement, with edits. | attorney-client |
| 7 | 2025-01-27 | Marcus Pell | Hana Lindqvist | Not stated | Communication regarding a notice. | attorney-client |
| 8 | 2025-02-03 | Hana Lindqvist | Marcus Pell | Spreadsheet | Spreadsheet of berth fees, 2022–2024, prepared for counsel. | work product |
| 9 | 2025-02-05 | Marcus Pell | Priya Nandakumar | Not stated | Communication regarding berth fee questions. | attorney-client |
| 10 | 2025-02-10 | Priya Nandakumar | Marcus Pell | Outline | Outline of deposition topics. | work product |
| 11 | 2025-02-12 | Hana Lindqvist | Marcus Pell | Not stated | Follow-up communication regarding a meeting. | attorney-client |
| 12 | 2025-02-14 | Marcus Pell | To: Hana Lindqvist; cc: Owen Barlow | Not stated | Communication regarding insurance notice question. | attorney-client |

## Flags

| No. | Flag | Why |
|---|---|---|
| 4 | No attorney among author or recipients | Author Hana Lindqvist and recipient Owen Barlow are both listed as Redfern staff. No attorney appears on the row. |
| 4 | Attorney note conflicting | Note reads "attorney-client," but no attorney is listed among author or recipients on this row. |
| 6 | Third party copied | cc includes "Tessa Brandt (Brandt Strategic Communications)." The list identifies her firm as outside the client, but her role is not stated in the document. |
| 7 | Subject line reveals advice or evaluation | Subject line, Row 7: "Counsel's advice that our position on the notice is weak." The description is generic and does not repeat this text. |

No rows are missing a date, have a missing attorney note, or match the possible-duplicate test (no two rows share the same date, author, and recipients).

## For the attorney

- **Row 4:** No attorney on the row, but the note asserts attorney-client. Confirm the designation or change it.
- **Row 6:** Third party (Tessa Brandt) copied. Her role is not stated in the list. Decide whether the attorney-client designation stands.
- **Row 7:** The subject line states the content of advice. The log uses a generic description and omits the subject text. Confirm the description and designation.
- **Row 2:** Document type "Email" is inferred from the "RE:" prefix. Confirm.
- **Rows 1, 5, 7, 9, 11, 12:** Document type is "Not stated" because the subject lines do not name a type. Confirm or supply.

This is a draft from the list provided. The responsible attorney decides every privilege designation.
