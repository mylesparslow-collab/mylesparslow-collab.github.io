**Header**
Employer: Marlowe Ridge Logistics, Inc. | Employee: Gregory Tanaka | Employee age (as stated): 52 ("a 52-year-old Operations Manager," preamble) | Date of draft: May 12, 2025 | Document type: Confidential Separation Agreement and General Release (draft)

| Item | Status | Quote | Section | Note |
|---|---|---|---|---|
| 1. General release | Present | "Employee releases the Company and its officers, employees, and agents from all claims, known or unknown, arising on or before the date Employee signs" | §2 | Covers ADEA, Title VII, FEHA, and "any claim for wages, bonuses, or overtime." |
| 1. Civil Code §1542 waiver | Missing | None found. | — | No reference to §1542 or a waiver of it. |
| 2. Age claims released (ADEA) | Present | "including claims under the Age Discrimination in Employment Act" | §2 | Item 2 applies on the stated age of 52. |
| 2. Understandable terms | Unclear | None found. | Whole document | Readability is for the attorney to judge. |
| 2. Refers to ADEA rights | Present | "the Age Discrimination in Employment Act" | §2 | Named as a released claim. |
| 2. Advised in writing to consult attorney | Present | "Employee is advised to consult an attorney before signing." | §3 | |
| 2. Time to consider (21 days) | Missing | None found. | §3 | Document states "fourteen (14) days from receipt of this Agreement to consider it." This is shorter than the 21-day figure. |
| 2. Group program (45 days, disclosures) | Missing | None found. | — | No group exit program is mentioned. None assumed. |
| 2. Revocation (7 days) | Present | "Employee may revoke within seven (7) days after signing." | §3 | Matches the 7-day figure as written. |
| 3. Non-disparagement clause | Present | "Employee shall not make any statement that disparages the Company, its management, or its services to any person, including customers, vendors, and the press." | §4 | Quoted for review. |
| 3. Gov. Code §12964.5 carve-out (§4) | Missing | None found. | §4 | Required carve-out text not located. |
| 3. Attorney notice, 5 business days (§4) | Unclear | "Employee is advised to consult an attorney before signing." | §3 | §3 gives 14 days to consider. The document does not tie this to §4. |
| 3. Confidentiality clause | Present | "Employee shall keep the terms of this Agreement and the circumstances of Employee's separation strictly confidential and shall not disclose them to anyone except Employee's spouse and tax adviser." | §5 | Quoted for review. |
| 3. Gov. Code §12964.5 carve-out (§5) | Missing | None found. | §5 | Required carve-out text not located. |
| 3. Attorney notice, 5 business days (§5) | Unclear | "Employee is advised to consult an attorney before signing." | §3 | Same as §4 row. The document does not tie this to §5. |
| 4. CCP §1001 (factual info on harassment/discrimination) | Unclear | "keep the terms of this Agreement and the circumstances of Employee's separation strictly confidential" | §5 | Could reach factual information about harassment or discrimination claims. No carve-out. Flagged for attorney. |
| 4. CCP §1001 identity shielding on request | Missing | None found. | — | No claimant-identity provision. |
| 5. Lab. Code §206.5 (wage release, payment shown) | Missing | None found. | §2 | Release reaches "any claim for wages, bonuses, or overtime." No statement that wages due were paid. |
| 6. Consideration | Present | "Employee agrees that the Severance Payment is good and sufficient consideration for this Agreement." | §1 | $48,000, less withholdings, in "two installments." Installment amounts and dates: Not stated in the document. |
| 6. Return of company property | Present | "Employee shall return all Company property, including laptop, badge, and files, on or before the last day of employment." | §6 | |
| 6. No-rehire clause | Present | "Employee agrees not to apply for employment with the Company or its affiliates in the future." | §7 | No time limit stated. |
| 6. Governing law | Present | "This Agreement is governed by California law." | §8 | |
| 6. Signature and date lines | Present | "EMPLOYEE: ______________________ Date: ____________" / "For the Company: ______________________ Date: ____________" | Signature block | Company signatory name and title: Not stated in the document. Unsigned draft. |

**For the attorney**
- ADEA period: §3 states 14 days to consider. The checklist figure is 21. No group program is mentioned, so the 45-day figure is not applied.
- Civil Code §1542: no waiver found. §2 uses "known or unknown" without citing §1542.
- Gov. Code §12964.5: neither §4 nor §5 contains the carve-out text. The attorney-consultation advice and 14-day period in §3 are not tied to either clause. Attorney to determine.
- CCP §1001: §5 covers "the circumstances of Employee's separation" with no carve-out for factual information about harassment or discrimination. No identity-shielding provision. Marked Unclear.
- Lab. Code §206.5: §2 releases "any claim for wages, bonuses, or overtime." No statement that wages were paid.
- Not stated in the document: Company signatory name and title, installment amounts and dates, and any time limit on the no-rehire clause.
- Item 2 readability is left Unclear for your judgment.

Statutes change. Confirm the current text of each statute before relying on this checklist.

This is a checklist read of the text provided. The responsible attorney decides.
