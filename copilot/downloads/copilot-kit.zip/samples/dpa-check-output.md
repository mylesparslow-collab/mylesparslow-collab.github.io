**Customer:** Ashgrove Retail Group, Inc. | **Vendor:** Brightloom Analytics, Inc. | **Document:** Data Processing Addendum to the Master Subscription Agreement | **Date:** Addendum date not stated in the document. It references the Master Subscription Agreement dated April 1, 2026.

**Roles (business / service provider):** Not stated in the document. The document uses "Customer" and "Vendor."

| Item | Status | Quote | Section | Note |
|---|---|---|---|---|
| 1. Limited and specified purposes | Present | "Vendor will process Personal Information only for the limited and specified purpose of providing the customer analytics dashboards described in Order Form No. 1 (the "Services")." | §2 | Purpose is tied to the Services in Order Form No. 1, which was not provided. |
| 2. Comply with CCPA; same level of protection | Present | "Vendor will comply with all laws that apply to its processing of Personal Information, including the CCPA, and will provide the same level of privacy protection as the CCPA requires of Customer." | §3 | None. |
| 3. Business's rights to ensure consistent use | Present | "Customer may, on thirty (30) days' written notice and no more than once per year, take reasonable and appropriate steps, including a documented review of Vendor's records, to confirm that Vendor uses Personal Information consistently with Customer's obligations." | §4 | Limited to once per year on 30 days' written notice, as written. |
| 4. Notice if unable to comply | Missing | None found. | None found. | No Vendor duty to notify Customer if it can no longer meet its obligations was found. |
| 5. Stop and remediate unauthorized use | Unclear | "If Customer reasonably believes Vendor has used Personal Information in a way that is not permitted by this Addendum, the parties will confer promptly about next steps." | §5 | Clause provides for conferring only. No express right to stop or remediate was found. |
| 6. No selling or sharing | Missing | None found. | None found. | §2 says "Vendor will not use Personal Information for any other purpose." No express prohibition on selling or sharing was found. |
| 8. Security measures | Present | "Vendor will maintain reasonable administrative, technical, and physical safeguards appropriate to the nature of the Personal Information." | §6 | None. |
| 9. Breach or incident notice timing | Present | "Vendor will notify Customer of a confirmed security incident affecting Personal Information without undue delay and in any event within seventy-two (72) hours after Vendor confirms the incident." | §7 | Period: seventy-two (72) hours. Starts when "Vendor confirms the incident." Notice applies to a "confirmed" incident. |
| 10. Subprocessors: permission, notice, flow-down | Present | "Vendor may engage subprocessors to deliver the Services. Vendor will give Customer fifteen (15) days' notice of a new subprocessor and will bind each subprocessor to written terms no less protective than this Addendum." | §8 | Permission and notice present. Flow-down present. No Customer objection right found. |
| 11. Deletion or return at end | Present | "Within ninety (90) days after the Agreement ends, Vendor will delete or return Personal Information at Customer's election, except as retention is required by law." | §9 | Period as written: ninety (90) days after the Agreement ends. |
| 12. Audit rights | Present | "Customer may audit Vendor's compliance with this Addendum once per year on thirty (30) days' notice during business hours." | §10 | Once per year, 30 days' notice, business hours, as written. |
| 13. Cross-border transfers or location of processing | Present | "Vendor may process Personal Information in any country in which Vendor or its subprocessors maintain facilities." | §11 | No specific countries or location restriction stated. |

**For the attorney**
- Item 4 (notice if Vendor can no longer comply): none found in the document.
- Item 6 (no selling or sharing): no express prohibition found. §2 restricts use to other purposes only.
- Item 5 (stop and remediate): §5 provides only that "the parties will confer promptly." Marked Unclear per the checklist.
- Audit and review rights (§4 and §10) are each limited to once per year on 30 days' written notice. §4 also refers to a "documented review of Vendor's records." §10 refers to an "audit."
- §11 permits processing in any country where Vendor or its subprocessors maintain facilities. No country list was found.
- §8 has no Customer objection or approval right for new subprocessors. Only 15 days' notice is stated.
- §9 deletion/return is at Customer's election, within 90 days after the Agreement ends. No certification of deletion was found.
- Business and service-provider roles are not stated in the document. Order Form No. 1 is referenced in §2 but was not provided.
- Checklist item 7 (other §7051(a) terms) was not assessed, per the checklist.

This is a checklist read of the text provided. The responsible attorney decides.
