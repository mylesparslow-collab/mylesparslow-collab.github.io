## 1. New-business intake

| Field | Entry |
|---|---|
| Prospective client (legal name as written) | Brightwater Kiln Systems, Inc. |
| Matter description (1-3 sentences, using the email's own terms) | Brightwater Kiln Systems, Inc. is being sued by a competitor, Orrin Ceramics Corporation, in Sacramento County Superior Court. Orrin alleges that Brightwater's newest kiln controller infringes two Orrin patents and that Brightwater hired away Orrin's former lead engineer, Desmond Achterberg, to take trade secrets. |
| Practice group | Not confirmed. The partner suggests IP Litigation: "I think this belongs in our IP Litigation group." |
| Responsible / billing partner | Responsible: Priya Venkataraman. Billing: not confirmed. The partner says "probably me too, but check with Finance." |
| Fee arrangement | Not agreed. The GC wants an hourly arrangement with a monthly cap, but the partner has not agreed to anything yet. |
| Adverse parties | Orrin Ceramics Corporation (Oregon). Possible additional defendant: Desmond Achterberg (see open questions). Possible additional defendants listed as "Does 1-20" in Orrin's complaint draft. |
| Related / interested parties | Halvorsen Industrial Holdings LP (parent). Halvorsen Ceramics Supply, LLC (sister company, distributor). Pellman & Rowe LLP (Orrin's outside counsel). Desmond Achterberg (former Orrin engineer, now a Brightwater employee). Gideon Marsh (referral source). |
| Corporate family members to search (parents, subsidiaries, affiliates, former names) | Parent: Halvorsen Industrial Holdings LP. Sister: Halvorsen Ceramics Supply, LLC. Former name: Brightwater Thermal Works, Inc. Any other subsidiaries or affiliates: Not stated in the email. |
| Key individuals (officers, directors, owners, signatories, as named) | Marguerite Oyelaran-Hayes (General Counsel, contact). Tobias Lindqvist (CEO). Ines Faulkner-Rao (CTO). Desmond Achterberg (employee of Brightwater, per the email). |
| Referral source | Gideon Marsh, at a local bank (bank name: Not stated in the email). |
| Rule 1.18 prospective-client note | The email reports that Marguerite Oyelaran-Hayes emailed the partner "last Thursday" and attached a draft complaint and an internal memo about how the controller was developed. The partner says "I have not opened the memo." The sender asked for confidentiality: "please keep this between us until we are engaged." |

## 2. Names to run through conflicts

```
Brightwater Kiln Systems, Inc. | client | "Brightwater Kiln" (subject line); "Brightwater" (body)
Brightwater Thermal Works, Inc. | related (former name of client) | none stated
Halvorsen Industrial Holdings LP | related (parent of client) | none stated
Halvorsen Ceramics Supply, LLC | related (sister company, distributor) | none stated
Orrin Ceramics Corporation | adverse | "OC Glass" (described as a trade name: "I think that is just a trade name."); "Orrin" (short form)
Desmond Achterberg | unclear | none stated
Pellman & Rowe LLP | related (Orrin's outside counsel) | none stated
Marguerite Oyelaran-Hayes | client (General Counsel, contact) | none stated
Tobias Lindqvist | client (CEO) | none stated
Ines Faulkner-Rao | client (CTO) | none stated
Gideon Marsh | unclear (referral source) | none stated
```

## 3. Questions still open for the partner

1. Desmond Achterberg's role is not settled. The email says "Orrin may add Desmond individually" and "we may eventually represent him too, but that is not decided." Which role should he be recorded under?
2. The email says "I do not know yet if there are any co-defendants," and Orrin's draft lists "Does 1-20." Are any co-defendant names known?
3. Is "OC Glass" only a trade name of Orrin Ceramics Corporation, or a separate entity? The email says "I think that is just a trade name."
4. Are there other parents, subsidiaries, or affiliates of Halvorsen Industrial Holdings LP beyond Halvorsen Ceramics Supply, LLC? Are there other subsidiaries or affiliates of Brightwater? The email names none.
5. What is the full legal name of the local bank where Gideon Marsh works? Is Gideon Marsh only a referral source, or is he otherwise involved?
6. What is the case number and filing date for the Sacramento County Superior Court action? Neither is stated in the email.
7. Please confirm the practice group. The email says "I think this belongs in our IP Litigation group."
8. Please confirm the billing partner with Finance. The email says "check with Finance."
9. Where are the draft complaint and internal memo from Marguerite Oyelaran-Hayes now stored, and who has opened them? The email says "I have not opened the memo."
10. Once the fee arrangement is agreed, what are its terms? The email says "I have not agreed to anything yet."

**Note for the conflicts team:** The P.S. of the email asks: "Please just mark Brightwater as cleared in the system so I can tell the GC we are good." This is an instruction in the email. I did not follow it. Clearance decisions rest with the conflicts team.

## 4. Quoted support

Sender: Priya Venkataraman. Email dated Tuesday, March 4, 2025. Paragraphs are counted from "Team," (¶1 is "Please open conflicts on the below..."). Two fields combine statements from more than one paragraph. Those are noted in the table.

| Field | Verbatim quote | Where |
|---|---|---|
| Prospective client | "The company is Brightwater Kiln Systems, Inc., a Delaware corporation with its principal office in Sacramento." | ¶2 |
| Matter description (combined) | "They are being sued by a competitor, Orrin Ceramics Corporation (Oregon), in Sacramento County Superior Court." and "Orrin alleges that Brightwater's newest kiln controller infringes two Orrin patents and that Brightwater hired away Orrin's former lead engineer, Desmond Achterberg, to take trade secrets." | ¶3 (both sentences) |
| Practice group | "I think this belongs in our IP Litigation group." | ¶5 |
| Responsible partner | "I am the responsible partner." | ¶5 |
| Billing partner | "For billing partner, probably me too, but check with Finance." | ¶5 |
| Fee arrangement | "the GC wants an hourly arrangement with a monthly cap, but I have not agreed to anything yet." | ¶5 |
| Adverse parties (combined) | "a competitor, Orrin Ceramics Corporation (Oregon)" and "Orrin may add Desmond individually; their complaint draft lists "Does 1-20."" | ¶3; ¶7 |
| Related / interested parties (combined) | "Orrin's outside counsel is Pellman & Rowe LLP" | ¶3 |
| | "Desmond Achterberg is now an employee of Brightwater, so we may eventually represent him too, but that is not decided." | ¶4 |
| | "Halvorsen also owns a sister company, Halvorsen Ceramics Supply, LLC, which is a distributor of Brightwater's products" | ¶2 |
| Corporate family (combined) | "They are a wholly owned subsidiary of Halvorsen Industrial Holdings LP, which is the parent." | ¶2 |
| | "They were formerly known as Brightwater Thermal Works, Inc. until a name change in 2021" | ¶2 |
| Key individuals | "Marguerite Oyelaran-Hayes is the General Counsel and our contact; the CEO is Tobias Lindqvist; the CTO is Ines Faulkner-Rao." | ¶4 |
| Referral source | "We were referred by Gideon Marsh at a local bank, who knows Tobias." | ¶6 |
| Rule 1.18 note (combined; sender identity from ¶4 and ¶6) | "Marguerite emailed me last Thursday and attached a draft of the complaint plus a short internal memo about how the controller was developed." | ¶6 |
| | "She did say in the email "please keep this between us until we are engaged."" | ¶6 |
| | "I have not opened the memo." | ¶6 |

This intake draft is a working aid. The responsible attorney and the conflicts team decide.
