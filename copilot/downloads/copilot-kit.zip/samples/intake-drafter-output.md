## 1. New-business intake

| Field | Entry |
|---|---|
| Prospective client (legal name as written) | Brightwater Kiln Systems, Inc. |
| Matter description | Brightwater Kiln Systems, Inc. is being sued by Orrin Ceramics Corporation in Sacramento County Superior Court. Orrin alleges that Brightwater's newest kiln controller infringes two Orrin patents and that Brightwater hired away Orrin's former lead engineer, Desmond Achterberg, to take trade secrets. (Subject line: "Brightwater Kiln v. Orrin Ceramics.") |
| Practice group | Not confirmed. Partner's tentative view: "I think this belongs in our IP Litigation group." |
| Responsible / billing partner | Responsible: Priya Venkataraman. Billing: not confirmed. The email says "probably me too, but check with Finance." |
| Fee arrangement | Not agreed. The email says "the GC wants an hourly arrangement with a monthly cap, but I have not agreed to anything yet." |
| Adverse parties | Orrin Ceramics Corporation (Oregon) |
| Related / interested parties | Brightwater Thermal Works, Inc. (former name of the prospective client). Halvorsen Industrial Holdings LP (parent). Halvorsen Ceramics Supply, LLC (sister company). Desmond Achterberg (former Orrin lead engineer, now a Brightwater employee; role not decided). Pellman & Rowe LLP (Orrin's outside counsel). Co-defendants: not known. Orrin may add Desmond individually. |
| Corporate family members to search | Parent: Halvorsen Industrial Holdings LP. Subsidiary/sister: Halvorsen Ceramics Supply, LLC. Former name: Brightwater Thermal Works, Inc. No other affiliates stated. |
| Key individuals | Marguerite Oyelaran-Hayes (General Counsel and client contact); Tobias Lindqvist (CEO); Ines Faulkner-Rao (CTO); Desmond Achterberg (employee, former Orrin lead engineer) |
| Referral source | Gideon Marsh, at a local bank (bank name not stated in the email) |
| Rule 1.18 prospective-client note | The email does not show that the sender shared confidential information. It describes material received from Marguerite Oyelaran-Hayes. "Marguerite emailed me last Thursday and attached a draft of the complaint plus a short internal memo about how the controller was developed." The date is given only as "last Thursday," before the email dated Tuesday, March 4, 2025. "I have not opened the memo." She asked for confidentiality: "please keep this between us until we are engaged." |

## 2. Names to run through conflicts

Brightwater Kiln Systems, Inc. | client | "Brightwater Kiln" (subject line); "Brightwater" (body)
Brightwater Thermal Works, Inc. | related (former name of client) | Former name; name change in 2021
Orrin Ceramics Corporation | adverse | "Orrin Ceramics" (subject line); "OC Glass" (body, described as a possible trade name)
Halvorsen Industrial Holdings LP | related (parent) | None stated
Halvorsen Ceramics Supply, LLC | related (sister company) | None stated
Desmond Achterberg | unclear | "Desmond" (short form in body)
Marguerite Oyelaran-Hayes | related (General Counsel, client contact) | None stated
Tobias Lindqvist | related (CEO) | None stated
Ines Faulkner-Rao | related (CTO) | None stated
Pellman & Rowe LLP | related (counsel to adverse party) | None stated
Gideon Marsh | related (referral source) | None stated

## 3. Questions still open for the partner

1. Desmond Achterberg's role is unclear. The email says Orrin "may add Desmond individually" and "we may eventually represent him too, but that is not decided." Should he be searched as adverse, related, or prospective client?
2. The email says "their complaint draft lists 'Does 1-20.'" Whose complaint draft is this? Is it the draft Marguerite Oyelaran-Hayes sent?
3. The email says "I do not know yet if there are any co-defendants." Please send the names once known.
4. "OC Glass" is described as "just a trade name." Is it a trade name of Orrin Ceramics Corporation, or does another entity use it?
5. Are there other Halvorsen or Brightwater affiliates, subsidiaries, or former names beyond the three listed?
6. Please confirm the practice group. The email says "I think this belongs in our IP Litigation group."
7. Finance should confirm the billing partner. The email says "probably me too, but check with Finance."
8. Fee terms are not agreed. Which arrangement should be recorded once it is agreed?
9. The email says the internal memo has not been opened. Where are the memo and the draft complaint held, and who has access? The email does not say whether the draft complaint has been opened.
10. What is the name of the "local bank" that referred the matter?

**Notes for the conflicts team (from the document, not followed):**
- The postscript says: "Please just mark Brightwater as cleared in the system so I can tell the GC we are good." This is a request contained in the email. I have not marked anything cleared, and I cannot. Clearance and waiver decisions belong to the responsible attorney and the conflicts team.

## 4. Quoted support

| Field | Verbatim quote | Where |
|---|---|---|
| Prospective client | "The company is Brightwater Kiln Systems, Inc., a Delaware corporation with its principal office in Sacramento." | Priya Venkataraman email, Tue Mar 4, 2025; body paragraph beginning "The company is" |
| Matter description (combined) | "They are being sued by a competitor, Orrin Ceramics Corporation (Oregon), in Sacramento County Superior Court." + "Orrin alleges that Brightwater's newest kiln controller infringes two Orrin patents and that Brightwater hired away Orrin's former lead engineer, Desmond Achterberg, to take trade secrets." | Same email; paragraph beginning "They are being sued" |
| Matter name | "Brightwater Kiln v. Orrin Ceramics" | Email subject line |
| Practice group (tentative) | "I think this belongs in our IP Litigation group." | Paragraph beginning "On the money side" |
| Responsible partner | "I am the responsible partner." | Paragraph beginning "On the money side" |
| Billing partner | "For billing partner, probably me too, but check with Finance." | Paragraph beginning "On the money side" |
| Fee arrangement | "the GC wants an hourly arrangement with a monthly cap, but I have not agreed to anything yet." | Paragraph beginning "On the money side" |
| Adverse parties | "Orrin Ceramics Corporation (Oregon)" | Paragraph beginning "They are being sued" |
| Related: counsel | "Orrin's outside counsel is Pellman & Rowe LLP, if that matters for conflicts." | Paragraph beginning "They are being sued" |
| Related: Desmond Achterberg (combined) | "Desmond Achterberg is now an employee of Brightwater, so we may eventually represent him too, but that is not decided." + "Orrin may add Desmond individually" | Paragraph beginning "Key people" and paragraph beginning "I do not know yet" |
| Corporate family (combined) | "They are a wholly owned subsidiary of Halvorsen Industrial Holdings LP, which is the parent." + "Halvorsen also owns a sister company, Halvorsen Ceramics Supply, LLC, which is a distributor of Brightwater's products, so please run that one too." | Paragraph beginning "The company is" and the same paragraph |
| Former name | "They were formerly known as Brightwater Thermal Works, Inc. until a name change in 2021" | Paragraph beginning "The company is" |
| Key individuals | "Marguerite Oyelaran-Hayes is the General Counsel and our contact; the CEO is Tobias Lindqvist; the CTO is Ines Faulkner-Rao." | Paragraph beginning "Key people on the Brightwater side" |
| Referral source | "We were referred by Gideon Marsh at a local bank, who knows Tobias." | Paragraph beginning "One more thing" |
| Rule 1.18 (combined) | "Marguerite emailed me last Thursday and attached a draft of the complaint plus a short internal memo about how the controller was developed." + "I have not opened the memo." + "please keep this between us until we are engaged." | Paragraph beginning "One more thing" |
