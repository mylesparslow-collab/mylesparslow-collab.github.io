## Witness and sources

**Witness:** Dominic Ferreira, site supervisor for Calloway Mechanical Services, Inc. Both sources name him, so the earlier statement and the testimony are from the same person.

**Sources:**
- **Earlier statement:** Declaration of Dominic Ferreira, signed June 12, 2024, paragraphs 1–10.
- **Testimony:** Deposition of Dominic Ferreira, taken October 22, 2024, excerpt only, pages 41–42, lines 01–12.

**Not provided:** The full deposition transcript (only pages 41–42 were pasted), and any other earlier statements such as emails or interrogatory answers. The input document is labeled as invented sample material.

## Comparison table

| # | Topic | Earlier statement (verbatim, source, cite) | Testimony (verbatim, page:line) | Type |
|---|---|---|---|---|
| 1 | Days on site, Aug. 7–18, 2023 | Declaration ¶4: "I was present at the site every day from August 7 through August 18, 2023." | 41:03 Q: "And were you at the site every day of the project?" 41:04 A: "Most days. I was off on the 11th and 14th, I think, for a family matter." | Direct contradiction. The "I think" qualifier is in the testimony, not the declaration. |
| 2 | Who supervised on the days he was off | Not stated in the document. | 41:05 Q: "Who was supervising on those days?" 41:06 A: "Brandon Teague covered for me." | New fact not in earlier statement |
| 3 | Date of second-unit inspection | Declaration ¶5: "On August 14, 2023, I inspected the second unit and noted no damage to the roof membrane." | 41:07 Q: "Did anyone from Calloway inspect the second unit?" 41:08 A: "Yes, I did. That was on the 16th." | Direct contradiction (August 14 vs. "the 16th") |
| 4 | Condition of roof membrane at inspection | Declaration ¶5: "...noted no damage to the roof membrane." | 41:10 A: "I noted a small tear near the curb on unit two. I photographed it." | Direct contradiction |
| 5 | Photograph of the tear | Not stated in the document. | 41:10 A: "I photographed it." | New fact not in earlier statement |
| 6 | Reporting the tear to the building manager | Declaration ¶6 refers to "the building manager" without naming her. No report of the tear is stated. | 42:01 Q: "Did you tell anyone about the tear?" 42:02 A: "I mentioned it to the building manager, Gloria Santangelo, that afternoon." | New fact not in earlier statement (name and same-day report) |
| 7 | Complaints from the building manager about water | Declaration ¶6: "I did not receive any complaint about water intrusion from the building manager during the project." | 42:03 Q: "Did she ever complain to you about water coming into the building?" 42:04 A: "Yes. On August 21st she called me about a leak on the fourth floor." | Direct contradiction. The witness answered "Yes" to a question on the same subject as ¶6. The wording differs ("water intrusion" / "complaint" vs. "water coming into the building" / "called me about a leak"). |
| 8 | When he first learned of leaks | Declaration ¶8: "I first learned of water leaks in the building when I received a letter from Ellison Park's counsel in November 2023." | 42:05 Q: "So you learned about leaks in August?" 42:06 A: "Yes, that was the first I heard of it." | Direct contradiction (November 2023 vs. August) |

## Compared and consistent (not a difference)

| Topic | Earlier statement (quote + cite) | Testimony (quote + cite) | Why they can both be true as written |
|---|---|---|---|
| Start of work | Declaration ¶3: "The work began on August 7, 2023." | 41:02 A: "We mobilized on August 7th, 2023." | Both give August 7, 2023 as the start date; the verbs differ but the date matches. |
| Who was on the roof Aug. 15 | Declaration ¶7: "Three Calloway employees worked on the roof on August 15, 2023: myself, Brandon Teague, and Alicia Moreau." | 42:07 Q: "How many Calloway employees worked on the roof on the 15th?" 42:08 A: "Three of us, myself, Brandon, and Alicia Moreau." | Same count and same three names for the same date. |
| Crane operator and days on site | Declaration ¶10: "Calloway's crane operator for the project was Dale Prentiss, and he was on site for two days." | 42:09 Q: "And who ran the crane?" 42:10 A: "Dale Prentiss. He was here for two days." | Same operator and same two-day presence. |
| Final invoice and nonpayment | Declaration ¶9: "After the project, Calloway sent a final invoice for $184,000. Ellison Park has not paid the invoice." | 42:11 Q: "Has Ellison Park paid the final invoice?" 42:12 A: "No. It was $184,000 and it is still outstanding." | Same amount ($184,000) and same status (unpaid). |
| Whether he inspected the second unit | Declaration ¶5: "I inspected the second unit..." | 41:08 A: "Yes, I did." | Both say the witness personally inspected the second unit. The date and findings differ (Rows 3–4). |

## Not addressed

- Declaration ¶1: his role as site supervisor and his statement of personal knowledge.
- Declaration ¶2: that Calloway was hired to replace the rooftop air handling units at 410 Larch Street.
- The excerpt covers pages 41–42 only. Other topics may appear elsewhere in the full transcript.

## Follow-up questions for the attorney

1. Row 1: Are there site logs, daily reports, or timesheets for August 7–18, 2023 that show who was on site each day?
2. Row 2: Does any document identify who supervised on August 11 and 14, 2023?
3. Row 3: Does any document, such as an inspection log, photo metadata, or correspondence, record the date of the second-unit inspection? Does the file show whether the witness was on site on August 14, given his testimony at 41:04?
4. Row 4: Do any records describe the condition of the membrane at unit two in August 2023?
5. Row 5: Are the photographs referenced at 41:10 in the file? What dates do they carry, if any?
6. Row 6: Does any document record a report about the tear to Gloria Santangelo on or after August 15, 2023?
7. Row 7: Does the file contain any communication from Gloria Santangelo, or any other building-manager communication about water or leaks, dated before November 2023? Does it include the August 21, 2023 call referenced at 42:04?
8. Row 8: Does the file contain the November 2023 letter from Ellison Park's counsel referenced in Declaration ¶8, and any earlier written notice of leaks?
9. Declaration generally: Does the file show who drafted the June 12, 2024 declaration, and whether the witness reviewed each paragraph before signing?

This is a comparison of text only. The attorney decides what, if anything, it means.
