## Witness and sources

**Witness:** Dominic Ferreira, site supervisor for Calloway Mechanical Services, Inc. (Declaration ¶1). The deposition and the declaration name the same witness.

**Source 1:** Declaration of Dominic Ferreira, signed June 12, 2024. Numbered paragraphs 1–10 were all provided.

**Source 2:** Deposition of Dominic Ferreira, taken October 22, 2024. This is an excerpt of pages 41–42 (lines 01–12 on each page). Testimony outside those pages was not provided.

**Not provided:** No other earlier statements, such as emails, interrogatory answers, or the full transcript.

## Comparison table

| Topic | Earlier statement (verbatim, source, ¶ or page:line) | Testimony (verbatim, page:line) | Type |
|---|---|---|---|
| Days on site | Declaration ¶4: "I was present at the site every day from August 7 through August 18, 2023." | 41:03–04 Q: "And were you at the site every day of the project?" A: "Most days. I was off on the 11th and 14th, I think, for a family matter." | Direct contradiction. The testimony is hedged ("I think"), but the declaration is not, and the two passages cannot both be true as written. |
| Date of second-unit inspection | Declaration ¶5: "On August 14, 2023, I inspected the second unit and noted no damage to the roof membrane." | 41:07–08 Q: "Did anyone from Calloway inspect the second unit?" A: "Yes, I did. That was on the 16th." | Direct contradiction (August 14, 2023 versus "the 16th"). |
| Membrane condition found at inspection | Declaration ¶5: "...noted no damage to the roof membrane." | 41:09–10 Q: "Did you see any damage to the membrane?" A: "I noted a small tear near the curb on unit two." | Direct contradiction. |
| Photograph of membrane | Not stated in the document. | 41:10: "I photographed it." | New fact not in earlier statement |
| Reporting the tear | Not stated in the document. | 42:01–02 Q: "Did you tell anyone about the tear?" A: "I mentioned it to the building manager, Gloria Santangelo, that afternoon." | New fact not in earlier statement |
| Building manager complaints about water | Declaration ¶6: "I did not receive any complaint about water intrusion from the building manager during the project." | 42:03–04 Q: "Did she ever complain to you about water coming into the building?" A: "Yes. On August 21st she called me about a leak on the fourth floor." | Direct contradiction. The declaration does not name the building manager. The testimony names Gloria Santangelo as building manager at 42:02. |
| Location of leak | Not stated in the document. | 42:04: "...a leak on the fourth floor." | New fact not in earlier statement |
| When the witness first learned of leaks | Declaration ¶8: "I first learned of water leaks in the building when I received a letter from Ellison Park's counsel in November 2023." | 42:05–06 Q: "So you learned about leaks in August?" A: "Yes, that was the first I heard of it." | Direct contradiction (first learned upon a letter in November 2023 versus first heard in August, as the answer adopts counsel's "in August"). |
| Who supervised on the 11th and 14th | Not stated in the document. (Declaration ¶4 states the witness was present every day.) | 41:05–06 Q: "Who was supervising on those days?" A: "Brandon Teague covered for me." | New fact not in earlier statement |

## Compared and consistent (not a difference)

| Topic | Earlier statement (quote + cite) | Testimony (quote + cite) | Why they can both be true as written |
|---|---|---|---|
| Start of work | Declaration ¶3: "The work began on August 7, 2023." | 41:02: "We mobilized on August 7th, 2023." | Both give August 7, 2023 as the start day; "mobilized" and "began" describe that same start. |
| Employees on the roof on the 15th | Declaration ¶7: "Three Calloway employees worked on the roof on August 15, 2023: myself, Brandon Teague, and Alicia Moreau." | 42:07–08: "Three of us, myself, Brandon, and Alicia Moreau." | Same number and same three names. The testimony says "the 15th" without a month, and the declaration's August 15, 2023 is the same day. |
| Crane operator | Declaration ¶10: "Calloway's crane operator for the project was Dale Prentiss, and he was on site for two days." | 42:09–10: "Dale Prentiss. He was here for two days." | Same person and same two-day duration. |
| Final invoice | Declaration ¶9: "After the project, Calloway sent a final invoice for $184,000. Ellison Park has not paid the invoice." | 42:11–12: "No. It was $184,000 and it is still outstanding." | Same amount, and both say the invoice has not been paid. |

## Not addressed

- Declaration ¶1: the witness's title and his statement of personal knowledge (the testimony excerpt does not address these directly).
- Declaration ¶2: the scope of work and the building address, 410 Larch Street.
- Declaration ¶8: the receipt of a letter from Ellison Park's counsel in November 2023 (the testimony addresses only when the witness first learned of leaks, at 42:05–06).
- Any testimony beyond pages 41–42 of the excerpt.

## Follow-up questions for the attorney

1. Row 1: Are there sign-in logs, timesheets, or daily reports showing which days Mr. Ferreira was on site, including the 11th and 14th?
2. Row 2: The declaration states "On August 14, 2023," and the testimony states "That was on the 16th." Do any records show the date of the second-unit inspection?
3. Row 3: Does the file include any record of the condition of the membrane on unit two at the time of inspection?
4. Row 4: Does the file include the photograph referred to at 41:10, and does it show a date?
5. Row 5: Do any records show the conversation with Gloria Santangelo that the witness places "that afternoon" at 42:02?
6. Row 6: The declaration does not name the building manager. Do the records confirm that the building manager during the project was Gloria Santangelo, as stated at 42:02? The document does not state when the project ended, so would the project end date help confirm whether the August 21st call (42:04) falls "during the project" in declaration ¶6?
7. Row 7: Do any records show the fourth-floor leak call referred to at 42:04?
8. Row 8: Is the November 2023 letter from Ellison Park's counsel referred to in declaration ¶8 in the file, and does it show when it was received?
9. Row 9: Do any records identify who supervised Calloway work on the days the witness was off, as described at 41:05–06?

This is a comparison of text only. The attorney decides what, if anything, it means.
