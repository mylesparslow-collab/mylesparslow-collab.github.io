**Header**

| Field | Entry |
|---|---|
| Case | Delmar Okafor v. Sunridge Property Management, Inc., Superior Court of the State of California, County of Example, Case No. 26CV-04417 |
| Type of discovery | Special Interrogatories, Set One |
| Propounding party | Plaintiff Delmar Okafor |
| Responding party | Defendant Sunridge Property Management, Inc. |
| Set number | One |
| Date and method of service (as stated) | "Date of service: October 2, 2026, by mail." |
| Number of requests | 38 (Special Interrogatory Nos. 1–38) |

**Response due date:** Docketing to calculate: October 2, 2026, by mail.

**Definitions**

- **YOU / YOUR:** "\"YOU\" and \"YOUR\" mean Defendant Sunridge Property Management, Inc. and its employees, agents, and contractors."
- **PROPERTY:** "\"PROPERTY\" means the apartment building at 22 Alder Court, Example City."
- **INCIDENT:** "\"INCIDENT\" means the water leak and resulting damage in Plaintiff's unit on or about June 14, 2026."
- **COMMUNICATION:** "\"COMMUNICATION\" means any transmission of information by any means."
- **IDENTIFY:** "\"IDENTIFY,\" with respect to a COMMUNICATION, means to state its date, its author, its recipients, and its substance."
- **PERSON:** "\"PERSON\" means any natural person or entity."

**Shell table**

| No. | Request (quoted) | Defined terms used | Flags | Possible objection grounds for attorney review | Response |
|---|---|---|---|---|---|
| 1 | SI No. 1: "State the full name, address, and job title of each PERSON who was responsible for maintaining the PROPERTY on the date of the INCIDENT." | PERSON, PROPERTY, INCIDENT | None | Is "responsible for maintaining" defined in the set? | [ATTORNEY TO DRAFT] |
| 2 | SI No. 2: "State the date on which YOU first received notice of the water leak in the unit leased by PLAINTIFF." | YOU | None | Is "notice" defined? Is "water leak" the INCIDENT, or a different leak? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 3 | SI No. 3: "State the date YOU repaired the leak." | YOU | None | Does "the leak" refer to the INCIDENT leak or another leak? | [ATTORNEY TO DRAFT] |
| 4 | SI No. 4: "State the name of the contractor who made the repair." | None | None | Does "the repair" refer to the repair in No. 3? Is "contractor" defined? | [ATTORNEY TO DRAFT] |
| 5 | SI No. 5: "State the cost of the repair." | None | None | Does "the repair" refer to the repair in Nos. 3 and 4? | [ATTORNEY TO DRAFT] |
| 6 | SI No. 6: "State the date of the last inspection before the INCIDENT." | INCIDENT | None | Is "inspection" defined? Does it cover any inspection of the PROPERTY or only plumbing (compare No. 30)? | [ATTORNEY TO DRAFT] |
| 7 | SI No. 7: "State the name, address, and telephone number of each PERSON who witnessed the INCIDENT and describe what each PERSON saw." | PERSON, INCIDENT | §2030.060(f): For attorney review. Quoted: "and describe what each PERSON saw" | Is "witnessed" defined? | [ATTORNEY TO DRAFT] |
| 8 | SI No. 8: "State the number of units in the PROPERTY." | PROPERTY | None | None noted. | [ATTORNEY TO DRAFT] |
| 9 | SI No. 9: "State the date YOU acquired management of the PROPERTY." | YOU, PROPERTY | None | None noted. | [ATTORNEY TO DRAFT] |
| 10 | SI No. 10: "State whether YOU carried liability insurance on the INCIDENT date." | YOU, INCIDENT | None | None noted. | [ATTORNEY TO DRAFT] |
| 11 | SI No. 11: "State the name of YOUR insurer on the INCIDENT date." | YOUR, INCIDENT | None | Does "insurer" refer to the insurance in No. 10? | [ATTORNEY TO DRAFT] |
| 12 | SI No. 12: "State the total number of maintenance requests YOU received for the PROPERTY from January 1, 2024 through the date of the INCIDENT." | YOU, PROPERTY, INCIDENT | None | Is "maintenance requests" defined? Is the time period limited (it is stated as January 1, 2024 through the INCIDENT date)? | [ATTORNEY TO DRAFT] |
| 13 | SI No. 13: "State the number of employees assigned to the PROPERTY." | PROPERTY | None | Is "assigned to" defined? | [ATTORNEY TO DRAFT] |
| 14 | SI No. 14: "State the name of the property manager on the INCIDENT date." | INCIDENT | None | None noted. | [ATTORNEY TO DRAFT] |
| 15 | SI No. 15: "State the date of YOUR first contact with PLAINTIFF." | YOUR | None | Is "contact" defined? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 16 | SI No. 16: "State the monthly rent charged to PLAINTIFF." | None | None | None noted. | [ATTORNEY TO DRAFT] |
| 17 | SI No. 17: "State the date PLAINTIFF'S lease began." | None | None | Is "lease" defined? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 18 | SI No. 18: "State whether YOU have a written maintenance policy." | YOU | None | Is "maintenance policy" defined? | [ATTORNEY TO DRAFT] |
| 19 | SI No. 19: "State the date of YOUR most recent maintenance policy revision." | YOUR | None | Is "maintenance policy" defined? Does "most recent" refer to a date before or after the INCIDENT? | [ATTORNEY TO DRAFT] |
| 20 | SI No. 20: "State the name of the person who wrote the policy." | None | None | Does "the policy" refer to the policy in Nos. 18 and 19? | [ATTORNEY TO DRAFT] |
| 21 | SI No. 21: "IDENTIFY all COMMUNICATIONS between YOU and PLAINTIFF'S landlord or PLAINTIFF'S renter's insurer concerning the INCIDENT, and state whether YOU contend that either of them was responsible for the INCIDENT." | IDENTIFY, COMMUNICATION, YOU, INCIDENT | §2030.060(f): For attorney review. Quoted: "and state whether YOU contend that either of them was responsible for the INCIDENT"; "PLAINTIFF'S landlord or PLAINTIFF'S renter's insurer" | Is "COMMUNICATION" used broadly? (Defined as "any transmission of information by any means.") Is the time period limited? Could this request call for privileged information? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 22 | SI No. 22: "State the date YOU received PLAINTIFF'S written repair request." | YOU | None | Is "written repair request" defined? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 23 | SI No. 23: "State the name of the person who received it." | None | None | Does "it" refer to the request in No. 22? | [ATTORNEY TO DRAFT] |
| 24 | SI No. 24: "State what action YOU took in response to it." | YOU | None | Does "it" refer to the request in No. 22? | [ATTORNEY TO DRAFT] |
| 25 | SI No. 25: "State the date of that action." | None | None | Does "that action" refer to No. 24? | [ATTORNEY TO DRAFT] |
| 26 | SI No. 26: "State whether the leak had occurred before." | None | None | Does "the leak" refer to the INCIDENT? Is the time period limited? | [ATTORNEY TO DRAFT] |
| 27 | SI No. 27: "State the date of any earlier leak in the unit." | None | None | Is "earlier leak" defined? Is "the unit" defined? Is the time period limited? | [ATTORNEY TO DRAFT] |
| 28 | SI No. 28: "State whether YOU notified PLAINTIFF of the repair schedule." | YOU | None | Is "repair schedule" defined? Is "PLAINTIFF" defined? | [ATTORNEY TO DRAFT] |
| 29 | SI No. 29: "State the date of that notice." | None | None | Does "that notice" refer to No. 28? | [ATTORNEY TO DRAFT] |
| 30 | SI No. 30: "State whether any inspection of the PROPERTY's plumbing was performed in the five years before the INCIDENT." | PROPERTY, INCIDENT | None | Is "inspection" defined? | [ATTORNEY TO DRAFT] |
| 31 | SI No. 31: "State the date of the plumbing inspection, if any." | None | None | Does "the plumbing inspection" refer to No. 30? | [ATTORNEY TO DRAFT] |
| 32 | SI No. 32: "State the name of the inspector." | None | None | Does "the inspector" refer to the inspection in Nos. 30 and 31? | [ATTORNEY TO DRAFT] |
| 33 | SI No. 33: "State whether the inspector issued a written report." | None | None | Does "the inspector" refer to No. 32? Is "written report" defined? | [ATTORNEY TO DRAFT] |
| 34 | SI No. 34: "State the date of the report." | None | None | Does "the report" refer to No. 33? | [ATTORNEY TO DRAFT] |
| 35 | SI No. 35: "State whether YOU retained the report." | YOU | None | Does "the report" refer to No. 33? Is "retained" defined? | [ATTORNEY TO DRAFT] |
| 36 | SI No. 36: "State where the report is kept." | None | None | Does "the report" refer to No. 33? | [ATTORNEY TO DRAFT] |
| 37 | SI No. 37: "State whether YOU contend PLAINTIFF contributed to the INCIDENT." | YOU, INCIDENT | None | Is "contributed" defined? Could this request call for a legal contention rather than facts? | [ATTORNEY TO DRAFT] |
| 38 | SI No. 38: "State the date YOU first learned of any damage to PLAINTIFF'S property." | YOU | None | Is "PLAINTIFF'S property" defined? Does it include the unit? Is "damage" tied to the INCIDENT? | [ATTORNEY TO DRAFT] |

**For the attorney**

- **Count:** 38 special interrogatories (Nos. 1–38), which is more than 35 (CCP §2030.030). No declaration found in the pasted text. The pasted text includes the line "(No declaration for additional discovery is attached to this set.)" after the signature block.
- **Compound flags (§2030.060(f)):** Nos. 7 and 21, both marked For attorney review.
- **Undefined capitalized term:** "PLAINTIFF" (and "PLAINTIFF'S") appears in several requests but is not in the Definitions list.
- **Lowercase terms without a definition:** "water leak," "repair," "maintenance policy," "landlord," "renter's insurer," and "written repair request" are not defined in the set.
- **Back-references:** Nos. 23–25, 29, 31–36 refer to "it," "that action," "that notice," "the inspector," "the report," and "the plumbing inspection" by back-reference. Confirm the referents.
- **Service:** Date and method as stated: October 2, 2026, by mail. Docketing to calculate the due date.
- **Statutes:** The attorney confirms the current text of the cited CCP sections before relying on this checklist.

This is a checklist read of the text provided. The responsible attorney decides.
