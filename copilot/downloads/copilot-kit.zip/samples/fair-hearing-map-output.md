**Briarwood Regional Medical Center | Medical Staff Bylaws Article VII excerpt (§§7.1–7.10) and notice letter | Dr. Anselm Kowalczyk-Reyes | October 15, 2026**

## Part 1: Process timeline as written

1. **Trigger for investigation.** Actor: any officer of the Medical Staff, the chair of a clinical department, or the MEC. Period: none stated. Quote: "is, or is reasonably likely to be, detrimental to patient safety or to the delivery of quality care" and "may request an investigation in writing." §7.1

2. **MEC considers request.** Actor: MEC. Period: "at its next regular meeting." Quote: "The MEC will consider a request for corrective action at its next regular meeting." Options: "may reduce, suspend, or revoke clinical privileges." §7.2

3. **MEC votes to recommend adverse action.** Actor: MEC. Period: none stated for the vote. The letter gives the vote date as October 8, 2026 (Letter, ¶1). This is the trigger for Step 4.

4. **Notice of adverse action.** Actor: Chief of Staff. Period: "Within ten (10) days after the MEC votes to recommend an adverse action." Docketing to calculate: "Within ten (10) days after the MEC votes to recommend an adverse action." Method: "by certified mail." Required contents: "The notice will state the action recommended, the reasons for it, and that the practitioner may request a hearing." §7.3

5. **Request for hearing.** Actor: practitioner, in writing to the Chief of Staff. Period: "thirty (30) days after receiving the notice." Docketing to calculate: "thirty (30) days after receiving the notice." Waiver: "Failure to request a hearing within that time is a waiver of the right to a hearing and to appellate review." §7.4

6. **Hearing Panel and hearing officer.** Actor: Chief of Staff. Panel: "five Medical Staff members who are not in direct economic competition with the practitioner." Hearing officer: "may also appoint a hearing officer, who is an attorney and does not vote." Practitioner input on selection: Not stated in the document. Voir dire: Not stated in the document. §7.5

7. **Access to documents.** Actor: practitioner. Period: "no later than ten (10) days before the hearing." Docketing to calculate: "no later than ten (10) days before the hearing." The hearing date is not stated in the document. Quote: "may inspect and copy the documents on which the MEC relied." §7.6

8. **Hearing begins.** Actor: Not stated in the document. Period: "within sixty (60) days after the request is received." Docketing to calculate: "within sixty (60) days after the request is received." §7.7

9. **Rights at hearing.**
   - Practitioner: "may be represented by an attorney and may present evidence." §7.7
   - MEC: "The MEC may call and examine witnesses." §7.7
   - Practitioner's right to call, examine, or cross-examine witnesses, and to rebut: Not stated in the document.

10. **Burden of proof.** Practitioner: "has the burden of showing that the recommended action lacks substantial justification." §7.8

11. **Hearing Panel written recommendation.** Actor: Hearing Panel. Period: "within thirty (30) days after the hearing closes." Docketing to calculate: "within thirty (30) days after the hearing closes." §7.9

12. **Request for appellate review.** Actor: "Either side." Period: "within fifteen (15) days after receiving the recommendation." Docketing to calculate: "within fifteen (15) days after receiving the recommendation." Request goes to the Governing Board "in writing." §7.9

13. **Governing Board decision.** Actor: Governing Board. Period: Not stated in the document. Quote: "The Governing Board's decision is final." §7.9

14. **Reports.** Actor: Chief of Staff. Timing: "after a final action." Quote: "will cause any report required by law to be filed after a final action." Scope of "report required by law": Not stated in the document. §7.10

## Part 2: §809 cross-reference table

| Bylaws provision | §809 point | Status | Quote | Section |
|---|---|---|---|---|
| Notice contents (bylaws) | §809.1(b): time limit to request hearing | Missing | "The notice will state the action recommended, the reasons for it, and that the practitioner may request a hearing." | §7.3 |
| Notice letter | §809.1(b): time limit to request hearing | Missing | "You may request a hearing on this recommendation by writing to the Chief of Staff." No time limit appears in the letter. | Letter, ¶2 |
| Panel and hearing officer | §809.2(c): voir dire of panel and hearing officer | Missing | Not stated in the document. | §7.5 (selection only) |
| Documents: right to inspect and copy | §809.2(d): right to inspect and copy | Present | "may inspect and copy the documents on which the MEC relied" | §7.6 |
| Documents: timing | §809.2(d): access at least 30 days before hearing | Missing (period is shorter than 30 days) | "no later than ten (10) days before the hearing" | §7.6 |
| Notice letter: documents | §809.2(d) | Unclear | "The reasons are the four surgical cases listed in the attached Schedule 1." Schedule 1 is not in the text provided. | Letter, ¶1 |
| Practitioner: evidence | §809.3: present and rebut evidence | Present (present evidence); Missing (rebut) | "may present evidence." Rebuttal: Not stated in the document. | §7.7 |
| Practitioner: witnesses | §809.3: call, examine, cross-examine | Missing | Not stated in the document. | §7.7 |
| MEC: witnesses | §809.3: call and examine | Present | "The MEC may call and examine witnesses." | §7.7 |
| MEC: cross-examination and evidence | §809.3: cross-examine, present and rebut | Missing | Not stated in the document. | §7.7 |

Note: The 30-day request period is at §7.4. It is not part of the §7.3 notice-contents sentence. The table reports the §7.3 provision only.

## Questions for the attorney

- Date the practitioner received the letter: Not stated in the document. §7.4 runs from receipt. Docketing needs this date.
- The letter gives the MEC vote as October 8, 2026, and §7.3 runs from the vote. Confirm the vote date. The document shows no mailing or postmark date.
- Schedule 1 is referenced in the letter but is not in the text provided. Obtain it.
- Hearing date and request-receipt date are not in the document. §§7.6 and 7.7 depend on them. Docketing to calculate once known.
- Is this excerpt complete and current? Confirm the bylaws version and effective date. Definitions (including "Governing Board") and any hearing procedure rules are not in the text.
- Voir dire, hearing officer's role, practitioner's cross-examination, and rebuttal are not stated. Check whether any other provision or rule addresses them.
- §7.10 refers to "any report required by law," and the document does not define the scope. The reportable-event rules come from outside this text.
- Confirm the current text of Cal. Bus. & Prof. Code §809 before relying on this checklist. Statutes change.

This is a checklist read of the text provided. The responsible attorney decides.
