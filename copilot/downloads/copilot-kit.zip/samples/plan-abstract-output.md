# Plan Abstract: Alder Ridge Components, Inc. 401(k) Savings Plan

**Plan name:** Alder Ridge Components, Inc. 401(k) Savings Plan | **Plan type:** "defined contribution 401(k) plan" (Section 1) | **Plan number:** "Plan Number 002" (cover) | **Sponsor:** "Alder Ridge Components, Inc." (Section 1) | **Administrator:** "Alder Ridge Benefits Committee, 410 Harrow Lane, Westbrook" (Section 1) | **Plan year:** "January 1 through December 31" (cover) | **Document(s) and date(s):** Summary plan description, excerpt only; "Effective date of this restatement: January 1, 2025" (cover). No plan document was provided.

| Item | Abstract (key words quoted) | Section | Note |
|---|---|---|---|
| Eligibility and entry dates | Eligibility: "first day of the month after you complete sixty (60) days of service and reach age 18." Entry: "first day of the calendar quarter that follows the date you meet these requirements." | Section 2 | Two different timing rules (monthly eligibility, quarterly entry). "Service" is not defined in the excerpt. |
| Employee contributions | "defer from 1% to 50% of your eligible pay on a pre-tax basis, or on a Roth basis." Auto-enrollment: "Newly eligible employees are automatically enrolled at 4% unless they elect otherwise." | Section 3 | No escalation terms stated. "Eligible pay" is not defined in the excerpt. |
| Employer contributions and match formulas | Match: "matches 100% of the first 3% of eligible pay that you defer and 50% of the next 2% of eligible pay that you defer." Profit sharing: "may also make a discretionary profit-sharing contribution each year," "allocated in proportion to eligible pay." | Section 4 | No maximum match amount stated. Not stated whether the match applies to Roth deferrals. |
| Vesting schedule | Own deferrals: "always fully vested." Company contributions: "less than 1 year of service, 0%; 1 year, 25%; 2 years, 50%; 3 years, 75%; 4 or more years, 100%." | Section 5 (see also Section 7) | **Conflicts with Section 7.** See Question 1. |
| Distributions | "receive your vested account after you leave the Company, reach age 59 1/2, or become disabled." | Section 6 | Form of payment and timing of distribution: Not stated in the document. |
| Loans | "may borrow from your vested account." "A loan may not exceed the lesser of $50,000 or 50% of your vested account." "must be repaid through payroll deduction over no more than five years." | Section 6 | Interest rate, application process, and default terms: Not stated in the document. |
| Claims procedure and time periods | "you will receive written notice within ninety (90) days after the Plan Administrator receives your claim." | Section 8 | Trigger: "the Plan Administrator receives your claim." Docketing to calculate: Plan Administrator receives your claim + ninety (90) days. Extension rules: Not stated in the document. |
| Appeals procedure and time periods | Appeal: "may appeal a denial in writing within sixty (60) days after you receive the denial notice." Decision: "The Benefits Committee will decide the appeal within sixty (60) days after it receives your appeal." | Section 8 | Trigger 1: "you receive the denial notice." Docketing to calculate: you receive the denial notice + sixty (60) days. Trigger 2: "it receives your appeal." Docketing to calculate: Benefits Committee receives your appeal + sixty (60) days. Extension rules: Not stated in the document. |
| Amendment rights | "The Company may amend the Plan at any time." | Section 9 | No limits or procedure stated. |
| Termination rights | "The Company may terminate the Plan at any time by action of its Board of Directors. If the Plan is terminated, your account becomes fully vested." | Section 9 | Scope of "your account" is not clarified. Termination procedure: Not stated in the document. |
| Plan year | "Plan Year: January 1 through December 31." | Cover | None. |

## Questions for Benefits Counsel

1. **Vesting conflict (most important).** Section 5 states "1 year, 25%; 2 years, 50%; 3 years, 75%; 4 or more years, 100%." Section 7 states "you are 100% vested in Company contributions only after three (3) years of service; before that, you have no vested interest in Company contributions." These passages conflict on the 100% point (3 years vs. 4 years) and on any vesting before year 3 (Section 5 gives 25% at 1 year and Section 7 gives none). Which controls?

2. **Plan document not provided.** Only an SPD excerpt was pasted. The document-versus-SPD comparison cannot be made. Should the plan document be provided? The excerpt is also labeled "(EXCERPT)," so the rest of the SPD may address items marked "Not stated in the document."

3. **Eligibility versus entry timing.** Section 2 states eligibility on "the first day of the month after you complete sixty (60) days of service" and entry on "the first day of the calendar quarter that follows the date you meet these requirements." Are these meant to operate together, and which controls for the date of entry?

4. **Undefined terms.** "Service" (60 days, and the vesting years) and "eligible pay" (match and profit sharing) are used but not defined in the excerpt. Are definitions in another section or in the plan document?

5. **Plan Administrator versus Benefits Committee.** Section 1 names the "Alder Ridge Benefits Committee" as the Plan Administrator. Section 8 uses both "Plan Administrator" and "Benefits Committee." Are these the same party?

6. **Forfeitures.** Section 7 states "you forfeit the unvested part of the Company contributions," but the excerpt does not say how forfeitures are used. Not stated in the document.

7. **Match on Roth deferrals.** Section 3 permits Roth deferrals, and Section 4 refers to amounts "that you defer." Not stated in the document whether the match applies to both pre-tax and Roth deferrals.

8. **Auto-enrollment.** Section 3 states a 4% default for "Newly eligible employees." Not stated in the document: any escalation, timing of the election window, or whether the default applies to all eligible employees.

9. **Missing items in the excerpt.** The following are not stated in the document: form and timing of distributions; loan interest, application, and default terms; claims extension rules; appeal content requirements; the Plan Administrator's decision notice content; amendment procedure and limits; termination procedure; and whether "your account becomes fully vested" on termination applies to all of the account or only to Company contributions.

This is a checklist read of the text provided. The responsible attorney decides.
