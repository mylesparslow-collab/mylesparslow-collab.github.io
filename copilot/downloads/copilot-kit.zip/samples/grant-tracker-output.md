**Grantor:** State Office of Clean Mobility (the "State")
**Recipient:** Valle Verde Transit District (the "District")
**Agreement number:** ZEB-2026-0417
**Effective date:** "July 1, 2026"
**Project:** "the purchase of twelve (12) battery-electric transit buses and related charging equipment" (Section 1)
**Amount:** "up to $6,400,000" (Section 1)

| # | Obligation (quoted) | Section | Frequency or due date as written | Owner | Flow down? |
|---|---|---|---|---|---|
| **Reporting** | | | | | |
| 1 | "shall submit a written progress report to the State" | 2 | "within thirty (30) days after the end of each calendar quarter until the Project is complete" | | Not stated in the document. |
| 2 | "Each report shall state expenditures to date and the status of bus delivery." | 2 | Each report (timing as in row 1) | | Not stated in the document. |
| 3 | "shall submit a final report within ninety (90) days after the last bus is accepted" | 3 | "within ninety (90) days after the last bus is accepted" | | Not stated in the document. |
| **Records retention** | | | | | |
| 4 | "shall keep all records related to the Project for three (3) years after the State makes final payment" | 4 | "for three (3) years after the State makes final payment" | | Not stated in the document. |
| 5 | "shall make them available to the State on request." | 4 | "on request" | | Not stated in the document. |
| **Audits** | | | | | |
| 6 | "The State may audit the District's Project records at any time." (State right; this sentence states no District duty) | 5 | "at any time" | | Not stated in the document. |
| 7 | "shall provide a single audit report if it meets the audit threshold stated in Exhibit B" | 5 | Not stated in the document. | | Not stated in the document. |
| 8 | "shall provide any audit report to the State within thirty (30) days after the District receives it." | 5 | "within thirty (30) days after the District receives it" | | Not stated in the document. |
| **Procurement and flow-down** | | | | | |
| 9 | "shall procure buses and equipment by competitive solicitation." | 6 | Not stated in the document. | | Not stated in the document. |
| 10 | "shall include in every contract and subcontract over $100,000 the clauses in Exhibit C" | 6 | "in every contract and subcontract over $100,000" | | Yes: "include in every contract and subcontract over $100,000 the clauses in Exhibit C" |
| 11 | "which require the contractor to (a) permit State access to its records" | 6 | Not stated in the document. | | Yes: "include in every contract and subcontract over $100,000 the clauses in Exhibit C" |
| 12 | "(b) comply with the State's nondiscrimination requirements" | 6 | Not stated in the document. | | Yes: "include in every contract and subcontract over $100,000 the clauses in Exhibit C" |
| 13 | "(c) include these clauses in each of its own subcontracts." | 6 | Not stated in the document. | | Yes: "include these clauses in each of its own subcontracts" |
| **Insurance** | | | | | |
| 14 | "shall maintain … commercial general liability insurance of not less than $2,000,000 per occurrence" | 7 | Not stated in the document. | | Not stated in the document. |
| 15 | "shall require each contractor to maintain, commercial general liability insurance of not less than $2,000,000 per occurrence" | 7 | Not stated in the document. | | Not stated. Related words: "shall require each contractor to maintain" |
| 16 | "naming the State as an additional insured." | 7 | Not stated in the document. | | Not stated in the document. |
| **Property and use restrictions** | | | | | |
| 17 | "Each bus purchased with grant funds shall be used for public transit service for its useful life of twelve (12) years." | 8 | "for its useful life of twelve (12) years" (start of period not stated) | | Not stated in the document. |
| 18 | "shall not sell, lease, or encumber a grant-funded bus during that period without the State's prior written consent." | 8 | "during that period" (see row 17) | | Not stated in the document. |
| 19 | "Charging equipment purchased with grant funds shall be installed at District facilities" | 9 | Not stated in the document. | | Not stated in the document. |
| 20 | "shall not be relocated without the State's written approval." | 9 | Not stated in the document. | | Not stated in the document. |
| **Matching funds** | | | | | |
| 21 | "shall provide matching funds of not less than twenty percent (20%) of total Project cost from non-State sources." | 1 | Not stated in the document. | | Not stated in the document. |
| **Closeout** | | | | | |
| 22 | "shall submit closeout documents, as listed in Exhibit D" | 10 | "within one hundred twenty (120) days after the final report is accepted by the State" | | Not stated in the document. |
| **Termination and repayment** | | | | | |
| 23 | Termination trigger: "if the District fails to meet a milestone in Exhibit A" (State right: "may terminate this Agreement on thirty (30) days' written notice") | 11 | Not stated in the document. | | Not stated in the document. |
| 24 | "the District shall repay the State the unamortized share of the grant funds attributable to that bus" | 11 | Trigger: "If a grant-funded bus is removed from transit service before the end of its useful life." Due date not stated in the document. | | Not stated in the document. |
| 25 | "the State may reduce the grant by a proportionate amount" (trigger: "If the District fails to provide the matching funds in Section 1") | 11 | Not stated in the document. | | Not stated in the document. |
| **Other obligations** | | | | | |
| 26 | "The District shall display the State's logo on each grant-funded bus in the form shown in Exhibit E." | 12 | Not stated in the document. | | Not stated in the document. |

**Docketing to calculate:**
- Docketing to calculate: within thirty (30) days after the end of each calendar quarter until the Project is complete (Section 2)
- Docketing to calculate: within ninety (90) days after the last bus is accepted (Section 3)
- Docketing to calculate: for three (3) years after the State makes final payment (Section 4)
- Docketing to calculate: within thirty (30) days after the District receives it (Section 5)
- Docketing to calculate: within one hundred twenty (120) days after the final report is accepted by the State (Section 10)

**Documents referred to but not provided**
- Exhibit A: project milestones (Section 11)
- Exhibit B: audit threshold (Section 5)
- Exhibit C: procurement and flow-down clauses (Section 6)
- Exhibit D: closeout documents (Section 10)
- Exhibit E: State logo form (Section 12)
- The State's nondiscrimination requirements (Section 6(b))

**Questions for the attorney**
- Exhibit C is not provided. Rows 10–13 rely on Section 6's description of its clauses.
- Section 8 sets a useful life of twelve (12) years but does not say when it starts. Rows 17–18 have no start date.
- Section 2 runs reporting "until the Project is complete." The document does not define completion.
- Section 3 keys the final report to when "the last bus is accepted." The document does not describe an acceptance process.
- Section 7 says the District "shall require each contractor to maintain" insurance. The document does not say this must be placed in contracts (row 15).
- Section 5's first sentence is a State right to audit. Confirm whether it should be tracked as a District obligation (row 6).
- Section 1 sets 20% matching funds but gives no timing or measurement date. Section 11 gives no repayment due date.

This is a checklist read of the text provided. The responsible attorney decides.
