## 1. Header

| Field | Detail (page) |
|---|---|
| Insurer | Alderwick Casualty Company, Claims Department (page 1) |
| Policy number and period | Policy No. ACC-GL-2024-118842; Policy Period: January 1, 2024 to January 1, 2025 (page 1) |
| Policyholder | Sunnyfield Senior Living, LLC (page 1) |
| Claim or lawsuit | Claim No. 25-0417-GL; Lawsuit: Harbor Point Property Partners v. Sunnyfield Senior Living, LLC (Fictional County Superior Court) (page 1) |
| Date of letter | March 24, 2025 (page 1) |
| Insurer's position | Defend under reservation. "Alderwick will defend Sunnyfield in the lawsuit under a full reservation of rights, as explained below." (page 1, para. 2) |

## 2. Policy provisions cited

| Provision (quoted exactly as the letter quotes it) | Letter page | How the letter uses it |
|---|---|---|
| "We will pay those sums that the insured becomes legally obligated to pay as damages because of 'bodily injury' or 'property damage' to which this insurance applies. We will have the right and duty to defend the insured against any 'suit' seeking those damages." (Commercial General Liability Coverage Form, Section I, Coverage A) | Page 2 | "The Policy provides, in the Commercial General Liability Coverage Form, Section I, Coverage A:" |
| "'Bodily injury' or 'property damage' expected or intended from the standpoint of the insured." | Page 2 | "The Policy excludes:" (Reserved Issue 1) |
| "Property damage caused by or resulting from continuous or repeated seepage or leakage of water over a period of 14 days or more." | Page 2 | "The Policy excludes:" (Reserved Issue 2) |
| "You must see to it that we are notified as soon as practicable of an 'occurrence' which may result in a claim." (Section IV, Condition 2) | Page 3 | "Section IV, Condition 2 provides:" (Reserved Issue 3) |
| Policy's definition of "property damage" | Page 3 | Referenced: "Alderwick reserves the right to decline to pay any amount not within the Policy's definition of 'property damage.'" The definition itself is not quoted. Text of the definition: Not stated in the document. |

Notes:
- The letter says "the Policy does not cover punitive damages" (page 3) but cites no policy provision for that statement.
- The letter reserves "the right to seek reimbursement of defense costs for claims not potentially covered" (page 3) but cites no policy provision for it.

## 3. Reserved issues

1. **Expected or intended damage** (page 2): "The Policy excludes: 'Bodily injury' or 'property damage' expected or intended from the standpoint of the insured." The letter adds: "The complaint alleges that Sunnyfield was told of leaks in the line in 2023 and did not repair it."
2. **Continuous or repeated seepage** (page 2): "The Policy excludes: 'Property damage caused by or resulting from continuous or repeated seepage or leakage of water over a period of 14 days or more.'" The letter adds: "The date of loss and duration of the leak are not established."
3. **Late notice** (page 3): "Section IV, Condition 2 provides: 'You must see to it that we are notified as soon as practicable of an "occurrence" which may result in a claim.'" The letter adds: "Alderwick's records show that notice was first received on February 20, 2025."
4. **Loss of rents and punitive damages** (page 3): "The complaint seeks loss of rents and punitive damages. Alderwick reserves the right to decline to pay any amount not within the Policy's definition of 'property damage,' and the Policy does not cover punitive damages."
5. **Reimbursement of defense costs** (page 3): "Alderwick reserves the right to seek reimbursement of defense costs for claims not potentially covered."
6. **General reservation** (page 3): "Nothing in this letter waives any of Alderwick's rights under the Policy or the law, and Alderwick may supplement this letter."

## 4. Information requested and deadlines

- **Deadline (page 3):** "Please send Alderwick the following within thirty (30) days of the date of this letter:"
  - Docketing to calculate: thirty (30) days of the date of this letter (letter dated March 24, 2025, page 1).
- **Request (a), page 3:** "all maintenance and repair records for the water line since January 1, 2023"
- **Request (b), page 3:** "all communications with the plaintiff about the leak"
- **Request (c), page 3:** "the date and manner in which Sunnyfield first learned of the water loss"

## 5. Defense counsel

- **Offered or appointed:** The letter says: "Alderwick has assigned the defense to Pruitt & Marsh LLP, who will report to Alderwick." (page 3)
- **Terms stated:**
  - Rate: "Alderwick will pay defense counsel at its panel rate of $185 per hour." (page 3)
  - Reporting: "who will report to Alderwick" (page 3). Reporting frequency or format: Not stated in the document.
  - Consent to counsel or settlement: Not stated in the document.

## 6. Flag for the attorney

Civil Code §2860(b): a conflict of interest may exist when the insurer reserves rights on an issue whose outcome counsel it retains could control. The attorney decides whether independent counsel issues arise.

Reserved issues the attorney may want to compare against that sentence:
1. "Expected or intended damage."
2. "Continuous or repeated seepage."
3. "Late notice."
4. "Loss of rents and punitive damages."
5. "reimbursement of defense costs"

Statutes change. The attorney confirms the current text before relying on this checklist.

## 7. Items to gather from the client

- The full Policy No. ACC-GL-2024-118842, including the Commercial General Liability Coverage Form, Section I, Coverage A, Section IV, Condition 2, and the definition of "property damage" (the letter refers to the definition but does not quote it).
- The complaint in Harbor Point Property Partners v. Sunnyfield Senior Living, LLC, and proof of the March 3, 2025 service date the letter states.
- Maintenance and repair records for the water line since January 1, 2023 (request (a)).
- All communications with the plaintiff about the leak (request (b)).
- Documents showing the date and manner in which Sunnyfield first learned of the water loss (request (c)).
- Records on the allegation that "Sunnyfield was told of leaks in the line in 2023 and did not repair it."
- Records of the leak on or about October 9, 2024, including its date and duration, given that the letter says "The date of loss and duration of the leak are not established."
- Records of every notice Sunnyfield gave Alderwick or any broker before February 20, 2025, the date the letter says notice was first received.
- The plaintiff's lease for the "adjacent suite leased by the plaintiff," relevant to the complaint's "loss of rents" claim.
- Correspondence from Pruitt & Marsh LLP about the assignment of the defense.
- Records of defense costs, relevant to the reserved reimbursement right.
- Any supplemental Alderwick letters, given that "Alderwick may supplement this letter."

This is a reading of the letter only. The responsible attorney decides all coverage questions.
