**Agency:** City of Larkspur Hills | **Project:** Civic Center Roof Replacement, Project No. PW-25-03 | **Contract price (as stated):** $1,480,000 (§1) | **Document type:** Construction contract, excerpt (per the document title). No call for bids, general conditions, or wage determination appears in the text provided.

| Item | Status | Quote | Section | Note |
|---|---|---|---|---|
| 1. Prevailing wage rates stated or on file | Missing | None found. | Not stated in the document. | §2 says "The Contractor shall pay all workers not less than the prevailing rates of per diem wages applicable to the Work." It does not state the rates or say where they are on file. |
| 2. DIR registration to bid, be listed, or perform | Missing | None found. | Not stated in the document. | §3 requires listing subcontractors in the bid. No DIR registration language appears. |
| 3. Retention (≤5%) | Present, flagged | "The City shall retain ten percent (10%) of each progress payment until Final Completion." | §4 | 10% is above the 5% limit in Pub. Cont. Code §7201. Retention is stated only for progress payments. Whether an exception applies is not determined here. |
| 4. Payment bond (contracts over $25,000) | Present | "a performance bond and a payment bond, each in the amount of one hundred percent (100%) of the Contract Price" and "Within ten (10) days after award" | §5 | Contract price is stated ($1,480,000). Checklist standard is delivery before work starts. The excerpt does not say when work starts. |
| 5a. Claim by registered or certified mail | Missing | None found. | §8 | §8 says "The Contractor shall submit claims in writing to the City promptly." No mail method is stated. |
| 5b. Agency response within 45 days | Unclear | "The City will respond within a reasonable time." | §8 | General standard. No response period is stated. |
| 5c. Meet and confer | Missing | None found. | Not stated in the document. | |
| 5d. Undisputed amounts paid | Missing | None found. | Not stated in the document. | |
| 5. Claims clause overall | Unclear | "Disputes shall be resolved in the superior court of the county in which the City is located." | §8 | General clause. Forum is stated. Only the response standard is addressed, and only generally. |
| 6a. Notice and claim deadline | Present | "within seven (7) days after the event giving rise to it, or the claim is waived." | §7 | Reported as written. |
| 6b. Liquidated damages | Present | "For each day of delay the Contractor shall pay the City liquidated damages of $1,200." | §6 | Completion period as written: "within one hundred eighty (180) calendar days after the Notice to Proceed." |
| 6c. Change order process | Present | "No change is binding unless made by a written change order signed by the City Manager." | §7 | |
| 6d. Insurance | Present | "commercial general liability insurance of not less than $2,000,000 per occurrence" and "naming the City as additional insured" | §9 | The additional-insured phrase follows both coverages as written. |
| 6e. Indemnity | Present | "including claims caused in part by the City's negligence" | §10 | Scope as written. |

**For the attorney**

- **§4 retention:** 10% stated against the 5% limit in Pub. Cont. Code §7201. Flagged only; no exception determined.
- **§8 claims:** No mail-delivery, meet-and-confer, or undisputed-payment language appears in this excerpt. The response standard is "a reasonable time," not a stated period. Check the full contract and any general conditions for these terms.
- **§7 claim waiver:** Seven-day period with waiver language, as written. Compare with any other notice terms in the full contract.
- **§2 prevailing wage:** Rates are not stated, and the excerpt does not say they are on file. Check the call for bids and any attachments, which were not provided.
- **§10 indemnity:** Covers claims "caused in part by the City's negligence." Flagged for review.
- **Excerpt scope:** Items marked "Not stated in the document" may appear in parts not provided. Confirm before relying on any "Missing" status.
- **§5 bond timing:** The excerpt gives "Within ten (10) days after award." It does not say when work starts. Confirm against the checklist standard.

This is a checklist read of the text provided. The responsible attorney decides.
