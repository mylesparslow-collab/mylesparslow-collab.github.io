# Conditions Tracker: Harbor Row Mixed-Use Project

## 1. Header

| Field | As written |
|---|---|
| Approving body | "PLANNING COMMISSION" of the "CITY OF LARKSPUR HILLS" (Resolution No. 2025-14, header) |
| Project name | "HARBOR ROW MIXED-USE PROJECT, 410-450 Harbor Row" (header) |
| Approval date | "Adopted: March 18, 2025" (header) |
| Entitlements granted | "APPROVING CONDITIONAL USE PERMIT 24-006 AND DESIGN REVIEW 24-011" (header). Section 1: "approves a mixed-use project of 96 residential units over 14,000 square feet of ground-floor commercial space, including one restaurant, subject to the conditions in Exhibit A." |
| Sources | Resolution Exhibit A (Conditions 1-12); MMRP excerpt (MM-N-1, MM-T-1). Total conditions: 14. |

## 2. Tracker Tables

### Prior to issuance of a grading permit (3)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| Exh. A, #2 | "Prior to issuance of a grading permit, the applicant shall submit a final drainage and erosion control plan for review and approval by the City Engineer." | "Prior to issuance of a grading permit" | "the applicant" | "City Engineer" (named as reviewer and approver) | Final drainage and erosion control plan, reviewed and approved by City Engineer |
| Exh. A, #3 | "Prior to issuance of a grading permit, the applicant shall record a covenant against the property requiring that 10 of the 96 residential units be reserved as affordable to low-income households." | "Prior to issuance of a grading permit" | "the applicant" | Not stated in the document. | Recorded covenant against the property |
| MMRP MM-N-1 | "Prior to issuance of a grading permit, the contractor shall prepare a construction noise control plan. Responsible party: Contractor. Monitoring: Building Division." | "Prior to issuance of a grading permit" | "the contractor" (text); "Contractor" (responsible party field) | "Building Division" (Monitoring field) | Construction noise control plan |

### Prior to issuance of a building permit (2)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| Exh. A, #6 | "Prior to issuance of a building permit, the applicant shall provide a minimum of 160 off-street parking spaces, including 8 accessible spaces." | "Prior to issuance of a building permit" | "the applicant" | Not stated in the document. | Not stated in the document. |
| Exh. A, #11 | "Prior to issuance of a building permit, the applicant shall pay all applicable development impact fees." | "Prior to issuance of a building permit" | "the applicant" | Not stated in the document. | Payment of development impact fees |

### Prior to issuance of a certificate of occupancy (1)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| Exh. A, #7 | "Prior to issuance of a certificate of occupancy, all street improvements along Harbor Row, including sidewalks and street trees, shall be completed." | "Prior to issuance of a certificate of occupancy" | Not stated in the document. | Not stated in the document. | Not stated in the document. |

### For the life of the project (1)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| MMRP MM-T-1 | "The applicant shall implement the approved transportation demand management program for the life of the project. Responsible party: Property manager. Monitoring: Public Works Department." | "for the life of the project" | "The applicant" (text); "Property manager" (responsible party field) | "Public Works Department" (Monitoring field) | Implementation of the approved transportation demand management program (no form of evidence stated) |

### Annual (1)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| Exh. A, #12 | "The applicant shall submit annual reports to the City confirming compliance with the affordable housing covenant." | "annual" | "The applicant" | "the City" (recipient; no department stated) | Annual reports confirming compliance with the affordable housing covenant |

### No timing stated (6)

| Condition # | Condition (quoted) | Timing trigger as written | Responsible party as written | Verifying agency or department | Evidence needed |
|---|---|---|---|---|---|
| Exh. A, #1 | "The project shall be built substantially as shown on the plans stamped "Approved" by the Planning Commission on March 18, 2025." | Not stated in the document. | Not stated in the document. | Not stated in the document. | Plans stamped "Approved" (March 18, 2025), as referenced in the condition |
| Exh. A, #4 | "Commercial uses shall close by 10:00 p.m. daily. Hours of operation shall not be extended without Planning Commission approval." | Not stated in the document. ("daily" appears in the condition text.) | Not stated in the document. | Not stated in the document. Approval referenced: "Planning Commission" | Not stated in the document. |
| Exh. A, #5 | "The maximum building height shall be 55 feet to the top of the roof deck." | Not stated in the document. | Not stated in the document. | Not stated in the document. | Not stated in the document. |
| Exh. A, #8 | "Construction activity shall be limited to 7:00 a.m. to 6:00 p.m., Monday through Friday." | Not stated in the document. | Not stated in the document. | Not stated in the document. | Not stated in the document. |
| Exh. A, #9 | "The restaurant may operate until midnight on Fridays and Saturdays." | Not stated in the document. | Not stated in the document. (Subject: "The restaurant") | Not stated in the document. | Not stated in the document. |
| Exh. A, #10 | "The project shall comply with all requirements of the Fire Department." | Not stated in the document. | Not stated in the document. | Not stated in the document. ("Fire Department" is named as the source of requirements; verifier not stated.) | Not stated in the document. |

## 3. Flags

**No timing stated (6):** Exh. A #1, #4, #5, #8, #9, #10.

**No responsible party stated (6):** Exh. A #1, #4, #5, #8, #9, #10.

**Possible conflicts (2 pairs):**
- **Exh. A #4 vs. #9 (restaurant closing time on Fri/Sat):** "Commercial uses shall close by 10:00 p.m. daily." vs. "The restaurant may operate until midnight on Fridays and Saturdays." Differs on closing time for Fridays and Saturdays (10:00 p.m. vs. midnight).
- **MMRP MM-T-1 (responsible party within the same entry):** "The applicant shall implement..." vs. "Responsible party: Property manager." Differs on who performs the program.

**Unclear (open-ended language, 7):**
- Exh. A #1: "substantially as shown on the plans" (no tolerance stated).
- Exh. A #7: "all street improvements along Harbor Row, including sidewalks and street trees" (scope and completion standard beyond the examples not stated).
- Exh. A #10: "all requirements of the Fire Department" (requirements not identified).
- Exh. A #11: "all applicable development impact fees" ("applicable" not defined).
- Exh. A #12: "annual reports" (no due date or reporting period stated).
- MMRP MM-N-1: "construction noise control plan" (required content not stated).
- MMRP MM-T-1: "the approved transportation demand management program" (the approving document or action is not identified).

## 4. Counts

| Item | Count |
|---|---|
| Conditions found | 14 (Exhibit A: 12; MMRP: 2) |
| Prior to issuance of a grading permit | 3 |
| Prior to issuance of a building permit | 2 |
| Prior to issuance of a certificate of occupancy | 1 |
| For the life of the project | 1 |
| Annual | 1 |
| No timing stated | 6 |
| No responsible party stated | 6 |
| Possible conflicts (conditions involved) | 3 (Exh. A #4, #9; MMRP MM-T-1) |
| Unclear | 7 |

This tracker reflects only the text provided. The responsible attorney decides how each condition is handled.
