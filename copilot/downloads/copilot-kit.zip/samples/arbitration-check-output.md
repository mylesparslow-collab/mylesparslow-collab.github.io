**Header**

- **Facility:** Larkspur Meadows Skilled Nursing Center, operated by Larkspur Meadows Operating Company, LLC
- **Resident:** Dorothea Imrie
- **Signer(s) and capacity as stated:** Dorothea Imrie (Resident; no capacity stated). Paulina Imrie-Vance ("Responsible Party," and "agent under a Durable Power of Attorney dated June 2, 2024"). Calvin Oyelaran ("Administrator," for the Facility).
- **Date(s):** Date of admission: September 3, 2026. Signature and date lines are blank in the text provided.
- **Documents reviewed:** Resident Admission Agreement (Sections 1, 2, 3, 9, 11, 12, 14, 15; signature page; Acknowledgment).
  - **Referenced but not provided:** Schedule of Services; Schedule A (daily rate); inventory form; Schedule C (Resident Rights notice); Durable Power of Attorney dated June 2, 2024; Pacific Resolution Forum rules.
  - **Separate arbitration agreement:** none in the packet.

**Checklist table**

| Item | Status | Quote | Section or page | Note |
|---|---|---|---|---|
| 1(a) Condition of admission: required / condition / must sign | Present | "This Section 14 must be signed prior to admission." | §14.1 | Only language of this kind found. |
| 1(b) Right not to sign | Missing | None found. | — | The Acknowledgment says only that the parties "have received a copy." |
| 2 Rescission period | Present | "The Resident may rescind this Section 14 by written notice to the Administrator within fourteen (14) days after signing." | §14.5 | Stated period is shorter than 30 calendar days. Right is stated for the Resident only. |
| 3 Communication with officials | Unclear (for attorney) | "...give the Facility thirty (30) days to respond before contacting any outside agency or government office." | §11 (Complaints), outside Section 14 | Complaint-first and notice-first clause. Schedule C (referenced in §12) is not provided. No confidentiality or non-disparagement clause found in the text provided. |
| 4 Separate or combined | Present (combined) | "14. Binding Arbitration." | §14, within the Resident Admission Agreement | No separate arbitration agreement in the packet. |
| 5 Signer: Resident | Present | "RESIDENT: ______________________ Date: ____________ Dorothea Imrie" | Signature page | Capacity: none stated. Authority language: none stated. |
| 5 Signer: Responsible Party | Present | "Paulina Imrie-Vance, signing as Responsible Party and as agent under a Durable Power of Attorney dated June 2, 2024. The Responsible Party states that she has full authority to bind the Resident to every Section of this Agreement, including Section 14." | Signature page; preamble | Preamble: "Paulina Imrie-Vance, the Resident's daughter, signs as the Resident's 'Responsible Party.'" "Responsible Party" is not defined in the text. Not stated: the DPOA text, its scope, and whether it covers arbitration or health-care decisions. |
| 5 Signer: Facility | Present | "By: Calvin Oyelaran, Administrator" | Signature page | Capacity as stated: Administrator. Authority language: not stated. |
| 5 Acknowledgment | Present | "The Resident and Responsible Party each acknowledge that Section 14 is part of this Agreement and that they have received a copy." | Acknowledgment, after signatures | No separate signature block for the Acknowledgment. |
| 6 Arbitrator selection | Present | "The arbitrator will be selected by the Facility from the panel of the Pacific Resolution Forum, and the arbitration will follow that organization's rules." | §14.2 | Selection by the Facility. Panel list and selection process beyond this sentence: not stated. |
| 6 Administrator or rules | Present | "...the arbitration will follow that organization's rules." | §14.2 | Rules not provided. |
| 6 Venue | Present | "The arbitration will take place at the Facility's offices in Larkspur County." | §14.3 | Street address: not stated. |
| 7 Filing fee | Present | "The Resident will pay one-half of the filing fee..." | §14.4 | |
| 7 Arbitrator fees | Present | "...and one-half of the arbitrator's fees." | §14.4 | |
| 7 Other costs | Missing | None found. | §14.4 | Only attorney's fees addressed: "Each party pays its own attorney's fees." |

**Questions for the attorney**

- Section 11 requires the Resident and Responsible Party to bring complaints to the Administrator in writing and allow 30 days "before contacting any outside agency or government office." Confirm its reach against §483.70(m)(5). Schedule C was not provided.
- No right-not-to-sign language was found. Confirm that no other page, insert, or notice in the full packet addresses it.
- Rescission in §14.5 is 14 days, against the 30-day checklist reference. §14.5 is stated for the Resident only. Confirm whether the Responsible Party has any rescission right.
- Responsible Party authority: the DPOA dated June 2, 2024 was not provided. Its scope is not stated in the packet. Confirm the DPOA and the signature-block statement of "full authority."
- Arbitrator: §14.2 says the Facility selects from the Pacific Resolution Forum panel. The panel list and the Forum's rules were not provided.
- Venue: the Facility's offices in Larkspur County. No street address is stated.
- Costs: the Forum's rules may govern costs beyond those in §14.4. They were not provided.
- §14.1 covers "any claim of negligence or malpractice." This is outside the checklist and noted for attorney review without assessment.
- Referenced documents not provided: Schedule of Services, Schedule A, inventory form, Schedule C, the DPOA, and the Forum rules.
- Signature and date lines appear blank in the text provided. Confirm whether signed pages exist.
- Confirm the current text of 42 CFR §483.70(m) before relying on this checklist.

This is a checklist read of the text provided. The responsible attorney decides.
