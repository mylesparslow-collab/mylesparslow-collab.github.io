#!/usr/bin/env bash
# Zips each agent's appPackage and the whole kit into dist/. Run from anywhere.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
rm -rf dist && mkdir -p dist
for d in agents/*/appPackage; do
  [ -d "$d" ] || continue
  slug="$(basename "$(dirname "$d")")"
  (cd "$d" && zip -q -r -X "$ROOT/dist/${slug}-appPackage.zip" manifest.json declarativeAgent.json instructions.txt color.png outline.png)
  echo "dist/${slug}-appPackage.zip"
done
zip -q -r -X dist/copilot-kit.zip . -x "dist/*" -x "*.DS_Store"
echo "dist/copilot-kit.zip"
