#!/usr/bin/env python3
"""Run the checks.

  --saved                      score samples/<slug>-output.md for every baseline case (no model calls)
  --live --cached-only         re-score outputs already in cache/; never calls the model
  --live --agents a,b          call the model for each selected case, then score
         --max-calls N         hard cap on real model calls in this invocation (cache hits are free)
         --kinds injection,missing   which case kinds to run (default: all kinds)
         --provider claude-cli | azure-openai (stub)

Outputs are cached in cache/ by hash of (model + instructions + input), so re-runs are free.
Results: results/<timestamp>/results.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import lib
import providers

CACHE = lib.LAB / "cache"
LOCK = threading.Lock()


def cache_key(model: str, instr: str, doc: str) -> str:
    return hashlib.sha256(f"{model}\0{instr}\0{doc}".encode()).hexdigest()[:24]


def sha(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:12]


def score(case: dict, output: str, source: str, **extra) -> dict:
    return {"id": case["id"], "slug": case["slug"], "kind": case["kind"], "source": source,
            "description": case.get("description", ""), "output_sha": sha(output), "output": output,
            "checks": lib.run_checks(case, output), **extra}


def do_saved(cases):
    rows = []
    for c in cases:
        out = lib.saved_output(c)
        if out is None:
            rows.append({"id": c["id"], "slug": c["slug"], "kind": c["kind"], "source": "none",
                         "description": c.get("description", ""), "output": "",
                         "checks": {n: {"status": "na", "message": c["not_applicable"].get(n, "no output"), "evidence": [], "stats": {}}
                               for n in lib.CHECK_NAMES}})
            continue
        rows.append(score(c, out, "saved"))
    return rows, 0


def do_live(cases, provider, max_calls, concurrency, cached_only=False):
    CACHE.mkdir(exist_ok=True)
    state = {"calls": 0}
    plan = []
    for c in cases:
        instr = lib.instructions(c["slug"])
        key = cache_key(provider.model, instr, c["document"])
        plan.append((c, instr, key, CACHE / f"{key}.md"))

    def work(item):
        c, instr, key, path = item
        if path.exists():
            return score(c, path.read_text(), "cache", cache_key=key)
        with LOCK:
            if cached_only or state["calls"] >= max_calls:
                return {"id": c["id"], "slug": c["slug"], "kind": c["kind"], "source": "skipped",
                        "description": c.get("description", ""), "output": "",
                        "error": "not run: not cached and --cached-only" if cached_only else f"not run: --max-calls {max_calls} reached",
                        "checks": {n: {"status": "na", "message": "not run (call cap)", "evidence": [], "stats": {}} for n in lib.CHECK_NAMES}}
            state["calls"] += 1
        t0 = time.time()
        try:
            out = provider.generate(instr, c["document"])
        except Exception as e:  # keep going; record the failure
            return {"id": c["id"], "slug": c["slug"], "kind": c["kind"], "source": "error",
                    "description": c.get("description", ""), "output": "", "error": str(e),
                    "checks": {n: {"status": "na", "message": "model call failed", "evidence": [], "stats": {}} for n in lib.CHECK_NAMES}}
        path.write_text(out)
        with LOCK, open(CACHE / "calls.jsonl", "a") as f:
            f.write(json.dumps({"at": datetime.now(timezone.utc).isoformat(), "case": c["id"],
                                "model": provider.model, "key": key, "seconds": round(time.time() - t0, 1)}) + "\n")
        return score(c, out, "live", cache_key=key, seconds=round(time.time() - t0, 1))

    with ThreadPoolExecutor(max_workers=concurrency) as ex:
        rows = list(ex.map(work, plan))
    return rows, state["calls"]


def summarise(rows):
    tally = {"pass": 0, "fail": 0, "warn": 0, "na": 0}
    for r in rows:
        for res in r["checks"].values():
            tally[res["status"]] += 1
    return tally


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--saved", action="store_true")
    g.add_argument("--live", action="store_true")
    ap.add_argument("--agents", help="comma-separated slugs (default: all)")
    ap.add_argument("--kinds", help="comma-separated case kinds (default: baseline for --saved, all for --live)")
    ap.add_argument("--max-calls", type=int, default=0, help="hard cap on real model calls (required > 0 for --live)")
    ap.add_argument("--provider", default="claude-cli", choices=list(providers.PROVIDERS))
    ap.add_argument("--model", default="haiku")
    ap.add_argument("--concurrency", type=int, default=2)
    ap.add_argument("--out", help="results directory (default results/<timestamp>)")
    ap.add_argument("--cached-only", action="store_true", help="with --live: re-score cached outputs, never call the model")
    ap.add_argument("--strict", action="store_true", help="exit 1 if any check fails (warn does not fail)")
    a = ap.parse_args(argv)

    agents = a.agents.split(",") if a.agents else None
    kinds = a.kinds.split(",") if a.kinds else (["baseline"] if a.saved else None)
    cases = lib.load_cases(agents, kinds)
    if not cases:
        sys.exit("no cases matched")
    provider = None
    if a.saved:
        rows, calls = do_saved(cases)
    else:
        if a.max_calls <= 0 and not a.cached_only:
            sys.exit("--live needs --max-calls N (N > 0), or --cached-only")
        provider = providers.get(a.provider, model=a.model)
        rows, calls = do_live(cases, provider, a.max_calls, min(a.concurrency, 2), a.cached_only)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = lib.LAB / "results" / stamp if not a.out else lib.LAB / a.out
    out_dir.mkdir(parents=True, exist_ok=True)
    doc = {"run_id": stamp, "mode": "saved" if a.saved else "live",
           "provider": provider.name if provider else "saved-outputs", "model": provider.model if provider else "haiku (earlier run, see samples/)",
           "calls_made": calls, "max_calls": a.max_calls, "summary": summarise(rows), "cases": rows}
    (out_dir / "results.json").write_text(json.dumps(doc, indent=1))
    t = doc["summary"]
    print(f"{doc['mode']}: {len(rows)} cases, {calls} model calls -> {out_dir.relative_to(lib.LAB)}/results.json")
    print(f"checks: {t['pass']} pass, {t['fail']} fail, {t['warn']} warn, {t['na']} n/a")
    for r in rows:
        bad = [f"{n}={x['status']}" for n, x in r["checks"].items() if x["status"] in ("fail", "warn")]
        if bad or r["source"] in ("error", "skipped"):
            print(f"  {r['id']:<34} {r['source']:<8} {', '.join(bad) or r.get('error', '')}")
    if a.strict and t["fail"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
