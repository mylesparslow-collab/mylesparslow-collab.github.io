from checks.missing_marker import check

FIELDS = [{"label": "fee arrangement", "forbidden": ["monthly cap"]}]


def test_marker_on_same_row_passes():
    out = "| Fee arrangement | Not stated in the document. |\n| Practice group | IP |"
    assert check("", out, fields=FIELDS).status == "pass"


def test_marker_on_next_line_after_heading_passes():
    out = "**Fee arrangement:**\nNot stated in the document.\n"
    assert check("", out, fields=FIELDS).status == "pass"


def test_value_supplied_fails():
    out = "| Fee arrangement | Hourly with a monthly cap |"
    r = check("", out, fields=FIELDS)
    assert r.status == "fail"
    kinds = {e["kind"] for e in r.evidence}
    assert kinds == {"marker-missing", "value-supplied"}


def test_field_never_mentioned_fails():
    r = check("", "| Practice group | IP |", fields=FIELDS)
    assert r.status == "fail" and r.evidence[0]["kind"] == "field-omitted"


def test_custom_marker_and_all_lines():
    f = [{"label": "date range", "all": True}]
    out = "- **Date range:** Not stated in the email.\n- **Date range:** Not stated in the email."
    assert check("", out, fields=f, markers=["Not stated in the email."]).status == "pass"
    out2 = out + "\n- **Date range:** February 2025"
    assert check("", out2, fields=f, markers=["Not stated in the email."]).status == "fail"


def test_regex_forbidden_and_na():
    f = [{"label": "age", "forbidden": [r"re:\b52\b"]}]
    assert check("", "Employee age: Not stated in the document. (52 mentioned)", fields=f).status == "fail"
    assert check("", "anything").status == "na"


def test_regression_group_heading_row_takes_its_marker_from_the_next_row():
    out = "| | **Insurance** | | |\n| — | None found. | — | Not stated in the document. |"
    assert check("", out, fields=[{"label": "insurance"}]).status == "pass"
    out2 = "| | **Insurance** | | |\n| 7 | \"$2,000,000 per occurrence\" | §7 | |"
    assert check("", out2, fields=[{"label": "insurance"}]).status == "fail"


def test_regression_all_mode_only_counts_lines_that_start_with_the_label():
    f = [{"label": "date range", "all": True}]
    out = ("- **Date range:** Not stated in the document.\n"
           "- **Clarity:** broad. What date range do you seek?\n"
           "- **Date range:** Not stated in the document.")
    assert check("", out, fields=f).status == "pass"


def test_except_excuses_lines_whose_value_is_in_the_document():
    f = [{"label": "date range", "all": True, "except": ["last year"]}]
    out = "- **Date range:** Not stated in the document.\n- **Date range:** \"last year\" (relative)."
    assert check("", out, fields=f).status == "pass"
    assert check("", out, fields=[{"label": "date range", "all": True}]).status == "fail"
