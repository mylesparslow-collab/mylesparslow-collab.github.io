from checks.verbatim_quotes import check, extract_quotes

DOC = ("**4. Deposition attendance.** No more than two (2) timekeepers from Firm may attend and bill "
       "for any deposition without prior written approval of Cedar Ridge's Claims Counsel.\n"
       "Clerical tasks are overhead\nand are not billable.")


def test_exact_straight_quote_passes():
    out = 'Rule: "No more than two (2) timekeepers from Firm may attend and bill for any deposition".'
    assert check(DOC, out).status == "pass"


def test_curly_quotes_and_apostrophe_and_line_break_normalised():
    out = "“prior written approval of Cedar Ridge’s Claims Counsel” and “Clerical tasks are overhead and are not billable”"
    assert check(DOC, out).status == "pass"


def test_paraphrase_in_quotes_fails_with_nearest_and_diff():
    out = 'Rule: "No more than three (3) timekeepers from Firm may attend and bill for any deposition".'
    r = check(DOC, out)
    assert r.status == "fail"
    ev = r.evidence[0]
    assert "three (3)" in ev["offending"]
    assert "two (2) timekeepers" in ev["nearest"]
    assert "[-three (3)-]" in ev["diff"] and "[+two (2)+]" in ev["diff"]


def test_ellipsis_fragments_checked_separately():
    ok = 'Quote: "No more than two (2) timekeepers ... without prior written approval of Cedar Ridge\'s Claims Counsel."'
    assert check(DOC, ok).status == "pass"
    bad = 'Quote: "No more than two (2) timekeepers ... without any written approval of the Claims Counsel."'
    assert check(DOC, bad).status == "fail"


def test_short_quotes_ignored_and_agent_phrases_allowed():
    out = 'The word "overhead" appears. Status: "Not stated in the document." Also "None found."'
    assert check(DOC, out).status == "pass"


def test_blockquote_is_a_quotation():
    out = "> Deposition attendance requires three timekeepers and no approval at all"
    assert check(DOC, out).status == "fail"
    assert extract_quotes(out)[0]["kind"] == "blockquote"


def test_table_quote_column_without_quote_marks():
    good = "| Item | Quote |\n|---|---|\n| 4 | No more than two (2) timekeepers from Firm may attend |"
    bad = "| Item | Quote |\n|---|---|\n| 4 | Nobody may attend a deposition at all ever |"
    assert check(DOC, good).status == "pass"
    r = check(DOC, bad)
    assert r.status == "fail" and r.evidence[0]["form"] == "table-cell"


def test_quoted_above_cell_is_not_a_quote():
    out = "| Item | Rule quoted |\n|---|---|\n| 5 | §2 (quoted above) |"
    assert check(DOC, out).status == "pass"


def test_quote_found_in_agent_instructions_is_allowed():
    out = 'End: "This is a checklist read of the text provided."'
    assert check(DOC, out).status == "fail"
    assert check(DOC, out, allow_from="End with: This is a checklist read of the text provided. The responsible attorney decides.").status == "pass"




# --- regression tests: false positives found by running the saved outputs ---
def test_regression_single_quotes_for_nested_double_quotes():
    doc = 'The Policy excludes: "\'Bodily injury\' or \'property damage\' expected or intended from the standpoint of the insured."'
    out = "The Policy excludes: 'Bodily injury' or 'property damage' expected or intended from the standpoint of the insured"
    assert check(doc, f'"{out}"').status == "pass"
    # an in-word apostrophe is kept, so a changed word is still caught
    assert check("the Policy's definition of damage", '"the Policys definition of damage"').status == "fail"


def test_regression_capital_letter_at_start_of_quote_is_allowed_but_not_elsewhere():
    doc = "Counsel for Plaintiff appeared. No specimen is currently of record."
    assert check(doc, 'He said "counsel for Plaintiff appeared" and "No specimen is currently of record"').status == "pass"
    assert check(doc, 'He said "Counsel for plaintiff appeared"').status == "fail"


def test_regression_cross_reference_in_quote_column_is_not_a_quotation():
    out = "| Item | Quote |\n|---|---|\n| 3 | See rows for items 6, 8, and 10 below |"
    assert check("anything", out).status == "pass"


def test_regression_slash_joins_heading_lines():
    doc = "OFFICE OF THE ATTORNEY GENERAL OF THE STATE OF EASTMARK\nCONSUMER PROTECTION DIVISION\nCIVIL"
    out = '"OFFICE OF THE ATTORNEY GENERAL OF THE STATE OF EASTMARK / CONSUMER PROTECTION DIVISION"'
    assert check(doc, out).status == "pass"


def test_regression_transcript_line_numbers_inside_a_sentence():
    doc = "5 A. I told him the guard on press brake number two had been\n6 taken off and that somebody could get hurt."
    assert check(doc, '"I told him the guard on press brake number two had been taken off and that somebody could get hurt"').status == "pass"
    assert check(doc, '"I told him the guard on press brake number two had been put back and that somebody could get hurt"').status == "fail"


def test_regression_blockquote_under_a_draft_heading_is_the_agents_own_text():
    out = "**Draft acknowledgment letter (for staff review)**\n\n> Thank you for your request. Staff are reviewing it and will respond.\n"
    assert check("anything", out).status == "pass"
    # but a blockquote under an ordinary heading is still a quotation
    out2 = "**Request**\n\n> Thank you for your request. Staff are reviewing it and will respond.\n"
    assert check("anything", out2).status == "fail"
