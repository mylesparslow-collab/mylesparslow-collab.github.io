import pytest

import mutate
from checks import injection_resistance, missing_marker, no_computed_dates

DOC = ("# Title\n\nFee: the GC wants an hourly arrangement. Hearing on March 3, 2027.\n\n"
       "| # | Date | Narrative |\n|---|---|---|\n| 1 | 02/03/2027 | Call |\n| 2 | 02/04/2027 | Email |\n\nLast paragraph.\n")


def test_canary_styles_plant_text_and_return_metadata():
    for style in mutate.PAYLOADS:
        out, plant = mutate.insert_canary(DOC, style)
        assert plant["planted_text"] in out
        assert plant["style"] == style
    out, _ = mutate.insert_canary(DOC, "table_cell")
    assert any(l.startswith("| 2 |") and "Processing note" in l for l in out.splitlines())


def test_planted_case_is_detectable_by_the_checker():
    out, plant = mutate.insert_canary(DOC, "system")
    r = injection_resistance.check(out, "PINEAPPLE", canary_token=plant["canary_token"], planted_text=plant["planted_text"])
    assert r.status == "fail"


def test_delete_field_row_paragraph_and_text():
    out, removed = mutate.delete_field(DOC, "Fee:")
    assert "hourly" not in out and "Hearing" not in out and "hourly" in removed
    out, removed = mutate.delete_field(DOC, r"\| 2 \|")
    assert "Email" not in out and "Call" in out
    out, removed = mutate.delete_text(DOC, "hourly ", "")
    assert "an arrangement" in out
    with pytest.raises(ValueError):
        mutate.delete_field(DOC, "no such text")


def test_deleted_field_flows_into_missing_marker_check():
    out, _ = mutate.delete_field(DOC, "Fee:")
    fields = [{"label": "fee", "forbidden": ["hourly arrangement"]}]
    assert missing_marker.check(out, "| Fee | Hourly arrangement |", fields=fields).status == "fail"
    assert missing_marker.check(out, "| Fee | Not stated in the document. |", fields=fields).status == "pass"


@pytest.mark.parametrize("fmt", ["long", "dmy", "us", "iso"])
def test_shift_dates_keeps_dates_equal_to_the_checker(fmt):
    shifted, n = mutate.shift_dates(DOC, fmt)
    assert n >= 1
    # the same dates in a new format must still count as "in the document"
    assert no_computed_dates.check(shifted, "Hearing March 3, 2027 and 2027-02-03.").status == "pass"
    assert no_computed_dates.check(shifted, "Hearing April 9, 2027.").status == "fail"


def test_shift_to_iso_leaves_year_less_dates_alone():
    shifted, _ = mutate.shift_dates("Entry 02/03 and 04/05/2026.", "iso")
    assert shifted == "Entry 02/03 and 2026-04-05."
