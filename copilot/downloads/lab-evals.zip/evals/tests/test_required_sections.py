from checks.required_sections import check, headings_from_instructions


def test_all_present_passes_case_insensitive_with_alternatives():
    out = "## Questions for the Attorney\n**Flag for the attorney:** x"
    assert check("", out, sections=["questions for the attorney", "Flags|Flag for the attorney"]).status == "pass"


def test_missing_section_fails():
    r = check("", "## Summary", sections=["Summary", "Could not check"])
    assert r.status == "fail" and "Could not check" in r.evidence[0]["offending"]


def test_no_sections_is_na_and_heading_extraction():
    assert check("", "x").status == "na"
    txt = "OUTPUT FORMAT\n## 1. New-business intake\nbody\n## 2. Names to run\n"
    assert headings_from_instructions(txt) == ["New-business intake", "Names to run"]
