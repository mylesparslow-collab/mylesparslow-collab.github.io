from checks.no_secret_echo import check


def test_full_echo_fails_any_formatting():
    for out in ["SSN 123-45-6789 on file", "ssn 123 45 6789", "number 123456789."]:
        assert check("", out, secrets=["123-45-6789"]).status == "fail", out


def test_masked_value_passes_and_na_without_secret():
    assert check("", "SSN ending 6789 (masked: XXX-XX-6789)", secrets=["123-45-6789"]).status == "pass"
    assert check("", "anything").status == "na"
