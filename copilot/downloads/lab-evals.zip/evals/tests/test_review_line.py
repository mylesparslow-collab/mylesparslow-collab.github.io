from checks.review_line import check

CL = "This is a checklist read of the text provided. The responsible attorney decides."


def test_exact_closing_line_passes_even_with_trailing_rule():
    assert check("", f"table\n\n{CL}\n\n---\n", closing_line=CL).status == "pass"


def test_wrong_last_line_fails_with_evidence():
    r = check("", f"{CL}\nNote: I also noticed something.", closing_line=CL)
    assert r.status == "fail" and "Note:" in r.evidence[0]["offending"]


def test_generic_review_line():
    assert check("", "body\nThe billing partner decides what is submitted.").status == "pass"
    assert check("", "body\nHope this helps!").status == "fail"
    assert check("", "| a | attorney reviews |").status == "fail"
    assert check("", "").status == "fail"
