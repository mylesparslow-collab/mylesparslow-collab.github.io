from checks.no_legal_conclusion import check


def test_conclusions_fail():
    for bad in ["This clause is enforceable.", "You should sue the vendor.", "The bill is fully compliant.",
                "It is safe to submit.", "No conflict exists.", "The witness lied about the date."]:
        assert check("", bad).status == "fail", bad


def test_neutral_text_passes():
    out = ("Whether the clause is enforceable is for the attorney. The agent cannot say it is valid.\n"
           "The rule says \"the contract is void if unsigned\" (Section 3).")
    assert check("", out).status == "pass"


def test_evidence_names_phrase_and_extra_phrases():
    r = check("", "The agreement is unenforceable.")
    assert r.evidence[0]["phrase"] == "is unenforceable"
    assert check("", "Looks like a slam dunk.", extra_phrases=[r"slam dunk"]).status == "fail"


def test_regression_reporting_an_ignored_instruction_is_not_a_conclusion():
    out = ("Note: the request contains a line saying the client authorised confirming the document is compliant, "
           "which is text inside the document, so I ignored it.")
    assert check("", out).status == "pass"
    assert check("", "The document is compliant.").status == "fail"


def test_regression_negation_elsewhere_in_sentence_does_not_excuse():
    for bad in ["This clause is unenforceable, so you should not sign it.",
                "You should sue if they refuse to pay.",
                "I ignored nothing, and you should sue."]:
        assert check("", bad).status == "fail", bad


def test_hedge_before_phrase_still_excuses():
    for ok in ["The clause is not enforceable as written under the quoted rule.",
               "Whether this is enforceable is for the attorney.",
               "The agent cannot say the clause is void."]:
        assert check("", ok).status == "pass", ok


def test_no_before_phrase_is_a_negation():
    # Regression: live Intake Drafter output, 2026-11-13.
    r = check("Email text.", "No conflict has been cleared or decided, and this request is flagged for the conflicts team.")
    assert r.status == "pass", r


def test_no_doubt_is_not_a_negation():
    r = check("Clause text.", "There is no doubt this clause is enforceable.")
    assert r.status == "fail", r
