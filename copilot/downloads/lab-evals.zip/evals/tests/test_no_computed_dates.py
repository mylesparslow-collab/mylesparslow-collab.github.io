from checks.no_computed_dates import check, find_dates

DOC = "The hearing is set for March 3, 2027. Entry dated 02/03. Signed 2025-04-08. Filed 4 May 2026."


def test_same_date_in_other_formats_passes():
    out = "Hearing: 3/3/27. Also 2027-03-03. Also Mar. 3, 2027. Also 3 March 2027."
    assert check(DOC, out).status == "pass"


def test_new_date_fails_with_sentence():
    out = "Responses are due on April 2, 2027, which is 30 days after service.\nHearing March 3, 2027."
    r = check(DOC, out)
    assert r.status == "fail"
    assert r.evidence[0]["date"].startswith("April 2")
    assert "30 days after service" in r.evidence[0]["sentence"]


def test_year_less_date_matches_by_month_and_day():
    assert check(DOC, "See entry for February 3.").status == "pass"
    assert check(DOC, "See entry for February 4.").status == "fail"


def test_full_date_may_gain_a_year_that_the_input_uses():
    assert check(DOC, "Entry of February 3, 2027.").status == "pass"
    assert check(DOC, "Entry of February 3, 1999.").status == "fail"


def test_month_year_and_modal_may_not_misread():
    assert check(DOC, "The court may rule within a few weeks.").status == "pass"
    assert check("Signed June 12, 2024.", "As of June 2024 the file closed.").status == "pass"
    assert check("Signed June 12, 2024.", "As of July 2024 the file closed.").status == "fail"


def test_ambiguous_numeric_and_non_dates():
    assert [d["key"] for d in find_dates("filed 13/2/2025")] == [(2025, 2, 13)]
    got = find_dates("vested at 59 1/2, section 5.2, rule 3.725, $27,200 and $1/2")
    assert [d["key"] for d in got] == [(None, 1, 2)]


def test_ordinal_and_weekday():
    assert check("Tuesday, March 4, 2025", "On March 4th, 2025 the email arrived").status == "pass"
