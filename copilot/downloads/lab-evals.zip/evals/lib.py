"""Paths, case loading and check running shared by run.py, report.py, mutate.py."""
from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

import checks as checks_pkg

LAB = Path(__file__).resolve().parent
KIT = LAB.parents[1]                       # copilot-kit/
CASES = LAB / "cases"
CHECK_NAMES = list(checks_pkg.REGISTRY)


def agent_slugs() -> list[str]:
    return [a["slug"] for a in json.loads((KIT / "kit.json").read_text())["agents"]]


def agent_names() -> dict[str, str]:
    return {a["slug"]: a["name"] for a in json.loads((KIT / "kit.json").read_text())["agents"]}


def instructions_path(slug: str) -> Path:
    p = KIT / "agents" / slug / "instructions.txt"
    return p if p.exists() else KIT / "agents" / slug / "agent-instructions.md"


def instructions(slug: str) -> str:
    return instructions_path(slug).read_text()


def closing_line(instr: str) -> str | None:
    m = re.search(r'(?:End(?: Mode B)? with|Closing line, exactly):\s*"([^"]+)"', instr)
    return m.group(1) if m else None


def resolve(path: str, base: Path) -> Path:
    for root in (base, KIT, LAB):
        if (root / path).exists():
            return (root / path).resolve()
    raise FileNotFoundError(path)


def load_case(path: Path) -> dict:
    case = yaml.safe_load(path.read_text())
    case["_path"] = str(path)
    case["id"] = f"{case['slug']}/{path.stem}"
    case.setdefault("kind", path.stem)
    case["document"] = resolve(case["input"], path.parent).read_text() if case.get("input") else None
    return case


def all_case_paths() -> list[Path]:
    return sorted(CASES.glob("*/*.yaml"))


def load_cases(agents: list[str] | None = None, kinds: list[str] | None = None) -> list[dict]:
    out = []
    for p in all_case_paths():
        c = load_case(p)
        if agents and c["slug"] not in agents:
            continue
        if kinds and c["kind"] not in kinds:
            continue
        out.append(c)
    return out


def saved_output(case: dict) -> str | None:
    rel = case.get("saved_output")
    return (KIT / rel).read_text() if rel and (KIT / rel).exists() else None


def run_checks(case: dict, output: str) -> dict[str, dict]:
    """Run every check the case applies. Returns {check: Result-dict}. Checks the case
    lists under `not_applicable` come back as na with the reason."""
    instr = instructions(case["slug"])
    doc = case["document"] or ""
    results = {}
    for name in CHECK_NAMES:
        if name in case.get("not_applicable", {}):
            results[name] = {"status": "na", "message": case["not_applicable"][name], "evidence": [], "stats": {}}
            continue
        if name not in case.get("checks", {}):
            results[name] = {"status": "na", "message": "not used by this case", "evidence": [], "stats": {}}
            continue
        params = dict(case["checks"][name] or {})
        if name == "verbatim_quotes":
            params.setdefault("allow_from", instr)
        results[name] = checks_pkg.REGISTRY[name](doc, output, **params).to_dict()
    return results


def case_label(case: dict) -> str:
    return case["id"]


def dump_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=100))
