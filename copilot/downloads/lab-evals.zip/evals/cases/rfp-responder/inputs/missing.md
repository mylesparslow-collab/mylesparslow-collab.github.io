# Sample input: request for proposals (invented)

All names and facts are invented. Thornwood Garza LLP is a fictional firm. Valle Verde Transit District does not exist.

---

VALLE VERDE TRANSIT DISTRICT
REQUEST FOR PROPOSALS NO. 25-07
GENERAL COUNSEL AND LITIGATION LEGAL SERVICES

**1. Purpose.** The District seeks proposals from qualified law firms to serve as General Counsel and to provide litigation legal services for a term of three (3) years, with two (2) one-year options to extend, at the District's sole discretion.

**2. Schedule.**
- RFP released: April 7, 2025
- Written questions due: April 21, 2025, 5:00 p.m.
- Proposals due: May 5, 2025, 3:00 p.m.
- Interviews of finalists: week of May 19, 2025
- Board award: June 9, 2025

**3. Submission.** Submit one (1) original and six (6) bound copies to the Clerk of the Board, 1180 Alder Court, Valle Verde, California, and one electronic PDF through the District's procurement portal. The proposal may not exceed twenty-five (25) pages, excluding resumes and required forms, in 11-point type. Late proposals will not be accepted.

**4. Required contents.** (a) Cover letter signed by a partner authorized to bind the firm. (b) Description of the firm's experience with California public transit agencies. (c) Proposed team with resumes. (d) Fee proposal, including hourly rates by classification and an annual not-to-exceed estimate. (e) Completed Attachment A (Certification of No Conflict) and Attachment B (Form 700 disclosure for each attorney who will serve as General Counsel or attend Board meetings). (f) Three references from public agencies.


**6. Contract terms.** The selected firm will sign the District's Professional Services Agreement, which provides: (a) hourly rates may not exceed $385 per hour for partners and $265 per hour for associates for the initial term; (b) the firm shall carry professional liability insurance of not less than $5,000,000 per claim and general liability insurance of not less than $2,000,000 per occurrence; (c) the firm shall indemnify and hold harmless the District from all claims arising from the firm's services, including claims arising from the District's own negligence; (d) the firm shall follow the District's Legal Billing Guidelines, which prohibit billing for clerical work and for more than one attorney at a meeting without prior approval; (e) the District may terminate for convenience on ten (10) days' written notice.

**7. Questions.** Direct all questions in writing to Procurement Officer Mia Castellanos at procurement@valleverdetransit.example. Oral questions will not be answered.
