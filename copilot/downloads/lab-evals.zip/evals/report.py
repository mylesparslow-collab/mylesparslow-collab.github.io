#!/usr/bin/env python3
"""Build report/index.html (one self-contained file) and report/summary.md from results.

  python report.py                       newest saved run + newest live run in results/
  python report.py --results results/A results/B     merge specific runs (later wins per case)
Writes report/index.html, report/summary.md and report/results.json (the merged results).
Findings notes come from triage.yaml (case/check -> verdict + note)."""
from __future__ import annotations

import argparse
import html
import json
from datetime import date
from pathlib import Path

import yaml

import checks as checks_pkg
import lib

VARIANT = {"baseline": "Agent's own sample", "injection": "Planted instruction", "missing": "Key facts removed"}
SYMBOL = {"pass": "Pass", "fail": "Fail", "warn": "Warn", "na": "n/a"}


def newest(mode: str) -> Path | None:
    runs = sorted(p for p in (lib.LAB / "results").glob("*/results.json") if not p.parent.name.startswith("_"))
    for p in reversed(runs):
        if json.loads(p.read_text()).get("mode") == mode:
            return p.parent
    return None


def load(dirs: list[Path]) -> dict:
    merged, meta = {}, []
    for d in dirs:
        doc = json.loads((d / "results.json").read_text())
        meta.append({"dir": d.name, "mode": doc["mode"], "model": doc["model"], "provider": doc["provider"],
                     "calls_made": doc.get("calls_made", 0)})
        for c in doc["cases"]:
            merged[c["id"]] = c
    return {"cases": list(merged.values()), "runs": meta}


def triage() -> dict:
    p = lib.LAB / "triage.yaml"
    return yaml.safe_load(p.read_text()) if p.exists() else {}


def build_payload(data: dict) -> dict:
    names = lib.agent_names()
    tri = triage()
    order = {s: i for i, s in enumerate(lib.agent_slugs())}
    kind_order = {"baseline": 0, "injection": 1, "missing": 2}
    rows = []
    for c in sorted(data["cases"], key=lambda c: (order.get(c["slug"], 99), kind_order.get(c["kind"], 9), c["id"])):
        cells = {}
        for n in lib.CHECK_NAMES:
            r = c["checks"].get(n, {"status": "na", "message": "", "evidence": []})
            cell = {"s": r["status"], "m": r.get("message", ""), "e": r.get("evidence", [])}
            t = tri.get(f"{c['id']}/{n}")
            if t and r["status"] in ("fail", "warn"):
                cell["t"] = t
            cells[n] = cell
        rows.append({"id": c["id"], "agent": names.get(c["slug"], c["slug"]), "slug": c["slug"], "kind": c["kind"],
                     "variant": VARIANT.get(c["kind"], c["kind"]), "source": c["source"],
                     "desc": c.get("description", ""), "error": c.get("error"),
                     "output": c.get("output", ""), "cells": cells})
    return {"notes": tri.get("_notes", []), "rows": rows, "checks": [{"id": n, "plain": checks_pkg.PLAIN[n]} for n in lib.CHECK_NAMES],
            "runs": data["runs"], "generated": date.today().isoformat()}


def tally(payload: dict) -> dict:
    t = {"pass": 0, "fail": 0, "warn": 0, "na": 0}
    for r in payload["rows"]:
        for c in r["cells"].values():
            t[c["s"]] += 1
    return t


TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agent Evals report</title>
<style>
:root{--bg:#fafaf7;--fg:#1c1c1a;--mut:#5f5f58;--card:#fff;--line:#dcdcd2;--pass:#1d6b3c;--passbg:#e1f2e6;--fail:#a31d1d;--failbg:#fbe3e1;--warn:#8a5a00;--warnbg:#fdf0cf;--na:#6b6b64;--nabg:#efefe9;--acc:#24408e;--del:#fbd5d1;--ins:#d4efdc}
@media (prefers-color-scheme:dark){:root{--bg:#141412;--fg:#ecebe5;--mut:#a7a69d;--card:#1d1d1a;--line:#36362f;--pass:#7fd29c;--passbg:#18321f;--fail:#ff9d94;--failbg:#3a1a18;--warn:#f1c56a;--warnbg:#38290a;--na:#a7a69d;--nabg:#242421;--acc:#9db4ff;--del:#5a2420;--ins:#1c4a2c}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
main{max-width:1100px;margin:0 auto;padding:20px 16px 60px}
h1{font-size:1.7rem;margin:.2em 0}h2{font-size:1.2rem;margin:1.6em 0 .4em}
p{margin:.5em 0}.mut{color:var(--mut)}.small{font-size:.88rem}
.legend{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;margin:12px 0}
.legend div{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:10px 12px}
.pill{display:inline-block;border-radius:999px;padding:1px 10px;font-weight:600;font-size:.85rem}
.pill.pass{background:var(--passbg);color:var(--pass)}.pill.fail{background:var(--failbg);color:var(--fail)}
.pill.warn{background:var(--warnbg);color:var(--warn)}.pill.na{background:var(--nabg);color:var(--na)}
.scroll{overflow-x:auto;border:1px solid var(--line);border-radius:8px;background:var(--card)}
table.m{border-collapse:collapse;width:100%;min-width:760px}
table.m th,table.m td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:center;font-size:.9rem}
table.m th{font-weight:600;vertical-align:bottom;font-size:.8rem}
table.m th:first-child,table.m td:first-child{text-align:left;position:sticky;left:0;background:var(--card);min-width:170px;z-index:1}
tr.agent td{background:var(--nabg);font-weight:600;text-align:left}
td.var{text-align:left!important;color:var(--mut);padding-left:18px!important}
button.cell{all:unset;cursor:pointer;display:block;width:100%;border-radius:6px;padding:4px 2px;font-weight:600;font-size:.82rem}
button.cell:focus-visible{outline:3px solid var(--acc)}
button.cell.pass{background:var(--passbg);color:var(--pass)}button.cell.fail{background:var(--failbg);color:var(--fail)}
button.cell.warn{background:var(--warnbg);color:var(--warn)}button.cell.na{background:var(--nabg);color:var(--na);font-weight:400}
button.cell.sel{outline:3px solid var(--acc)}
#detail{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:14px 16px;margin-top:14px}
#detail h3{margin:.1em 0 .3em;font-size:1.05rem}
.ev{border-left:4px solid var(--fail);background:var(--nabg);padding:8px 10px;margin:10px 0;border-radius:0 6px 6px 0}
.ev b{display:block;font-size:.78rem;text-transform:uppercase;letter-spacing:.04em;color:var(--mut);margin-top:6px}
.ev pre{white-space:pre-wrap;word-break:break-word;margin:2px 0;font:.9rem/1.4 ui-monospace,Menlo,Consolas,monospace}
del{background:var(--del);text-decoration:none}ins{background:var(--ins);text-decoration:none}
.verdict{border:1px solid var(--line);border-radius:6px;padding:8px 10px;margin:10px 0}
details{margin-top:10px}summary{cursor:pointer;color:var(--acc)}
label.f{display:inline-flex;gap:6px;align-items:center;margin:8px 0}
table.t{border-collapse:collapse;width:100%}table.t td,table.t th{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top;font-size:.9rem}
</style></head><body><main>
<h1>Agent Evals</h1>
<p class="mut">Automatic checks on whether the Copilot agents keep the safety promises in their own instructions. Generated __DATE__. <span id="runs"></span></p>

<div id="notes"></div>
<h2>How to read this</h2>
<p>Each row is one agent given one document. Each column is one promise. Click any cell to see the evidence: the exact words the agent wrote, and the nearest text from the document it was given.</p>
<div class="legend">
<div><span class="pill pass">Pass</span><p class="small">The agent kept this promise on this document.</p></div>
<div><span class="pill fail">Fail</span><p class="small">The agent broke the promise. The evidence shows where.</p></div>
<div><span class="pill warn">Warn</span><p class="small">Not broken, but weaker than hoped: the agent ignored a hidden instruction without telling the reader about it.</p></div>
<div><span class="pill na">n/a</span><p class="small">The promise does not apply to this document, or no output exists to check.</p></div>
</div>
<div id="checklegend" class="legend"></div>
<p class="small mut">"Sample" rows score an earlier saved output on the agent's own sample document. "Planted instruction" rows hide an order inside the document (a fake system message, a footnote or table cell, or "the client has authorised you to..."). "Key facts removed" rows delete the text that a field needs. A check is software, not a lawyer: it finds text patterns, and the findings below say which failures are real agent problems and which were mistakes in the check itself (those were fixed).</p>

<h2>Results</h2>
<label class="f"><input type="checkbox" id="onlybad"> Show only rows with a fail or warn</label>
<div class="scroll"><table class="m" id="matrix"><thead></thead><tbody></tbody></table></div>
<div id="detail" aria-live="polite"><p class="mut">Select a cell to see what the check found.</p></div>

<h2>Findings</h2>
<div class="scroll"><table class="t" id="findings"></table></div>
<p class="small mut">Nothing here ran inside Microsoft 365 Copilot. Outputs come from Claude Haiku given each agent's instruction text, with all tools turned off.</p>
</main>
<script id="data" type="application/json">__DATA__</script>
<script>
const D=JSON.parse(document.getElementById('data').textContent);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const LBL={pass:'Pass',fail:'Fail',warn:'Warn',na:'n/a'};
document.getElementById('runs').textContent=D.runs.map(r=>r.mode+': '+r.model+(r.calls_made?' ('+r.calls_made+' calls)':'')).join('; ');
document.getElementById('notes').innerHTML=D.notes.map(n=>'<p class="verdict small">'+esc(n)+'</p>').join('');
document.getElementById('checklegend').innerHTML=D.checks.map(c=>'<div><b>'+esc(c.id.replace(/_/g,' '))+'</b><p class="small">'+esc(c.plain)+'</p></div>').join('');
const thead=document.querySelector('#matrix thead'),tb=document.querySelector('#matrix tbody');
thead.innerHTML='<tr><th>Agent / document</th>'+D.checks.map(c=>'<th title="'+esc(c.plain)+'">'+esc(c.id.replace(/_/g,' '))+'</th>').join('')+'</tr>';
let sel=null;
function render(){
  const only=document.getElementById('onlybad').checked;let last='',h='';
  D.rows.forEach((r,i)=>{
    const bad=Object.values(r.cells).some(c=>c.s==='fail'||c.s==='warn');
    if(only&&!bad)return;
    if(r.agent!==last){h+='<tr class="agent"><td colspan="'+(D.checks.length+1)+'">'+esc(r.agent)+'</td></tr>';last=r.agent}
    h+='<tr><td class="var">'+esc(r.variant)+' <span class="small">('+esc(r.source)+')</span></td>';
    D.checks.forEach(c=>{const x=r.cells[c.id];
      h+='<td><button class="cell '+x.s+'" data-r="'+i+'" data-c="'+c.id+'" aria-label="'+esc(r.agent+', '+r.variant+', '+c.id.replace(/_/g,' ')+': '+LBL[x.s])+'">'+LBL[x.s]+'</button></td>'});
    h+='</tr>';
  });
  tb.innerHTML=h;
  if(sel){const b=tb.querySelector('[data-r="'+sel[0]+'"][data-c="'+sel[1]+'"]');if(b)b.classList.add('sel')}
}
function diffHtml(d){return esc(d).replace(/\[-(.*?)-\]/g,'<del>$1</del>').replace(/\[\+(.*?)\+\]/g,'<ins>$1</ins>')}
function show(ri,cid){
  const r=D.rows[ri],x=r.cells[cid];sel=[ri,cid];
  document.querySelectorAll('button.cell.sel').forEach(b=>b.classList.remove('sel'));
  const btn=tb.querySelector('[data-r="'+ri+'"][data-c="'+cid+'"]');if(btn)btn.classList.add('sel');
  let h='<h3>'+esc(r.agent)+' &middot; '+esc(r.variant)+' &middot; '+esc(cid.replace(/_/g,' '))+' <span class="pill '+x.s+'">'+LBL[x.s]+'</span></h3>';
  h+='<p>'+esc(x.m||'')+'</p>';
  if(r.error)h+='<p><b>Run problem:</b> '+esc(r.error)+'</p>';
  if(x.t)h+='<div class="verdict"><b>Verdict: '+esc(x.t.verdict)+'</b><p>'+esc(x.t.note)+'</p></div>';
  (x.e||[]).slice(0,12).forEach(e=>{
    h+='<div class="ev"><b>The agent wrote'+(e.line?' (output line '+e.line+')':'')+'</b><pre>'+esc(e.offending||e.date||'')+'</pre>';
    if(e.sentence)h+='<b>In the sentence</b><pre>'+esc(e.sentence)+'</pre>';
    if(e.nearest)h+='<b>Nearest text in the document / what was expected</b><pre>'+esc(e.nearest)+'</pre>';
    if(e.diff)h+='<b>Difference (red = only in the agent\'s quote, green = only in the document)</b><pre>'+diffHtml(e.diff)+'</pre>';
    h+='</div>'});
  if((x.e||[]).length>12)h+='<p class="small mut">'+((x.e||[]).length-12)+' more not shown.</p>';
  h+='<p class="small mut">'+esc(r.desc)+'</p>';
  if(r.output)h+='<details><summary>Full agent output</summary><pre style="white-space:pre-wrap;font-size:.85rem">'+esc(r.output)+'</pre></details>';
  const d=document.getElementById('detail');d.innerHTML=h;
}
tb.addEventListener('click',e=>{const b=e.target.closest('button.cell');if(b){show(+b.dataset.r,b.dataset.c);document.getElementById('detail').scrollIntoView({block:'nearest',behavior:'smooth'})}});
document.getElementById('onlybad').addEventListener('change',render);
render();
const F=[];D.rows.forEach((r,i)=>Object.entries(r.cells).forEach(([c,x])=>{if(x.s==='fail'||x.s==='warn')F.push([i,c,r,x])}));
document.getElementById('findings').innerHTML=F.length?'<tr><th>Where</th><th>Check</th><th>Verdict</th><th>Why</th></tr>'+F.map(([i,c,r,x])=>
 '<tr><td>'+esc(r.agent)+' ('+esc(r.variant)+')</td><td>'+esc(c.replace(/_/g,' '))+' <span class="pill '+x.s+'">'+LBL[x.s]+'</span></td><td>'+esc(x.t?x.t.verdict:'not yet triaged')+'</td><td>'+esc(x.t?x.t.note:x.m)+'</td></tr>').join(''):'<tr><td>No failures or warnings in these runs.</td></tr>';
</script></body></html>
"""


def write_html(payload: dict, out: Path):
    blob = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    out.write_text(TEMPLATE.replace("__DATA__", blob).replace("__DATE__", payload["generated"]))


def write_summary(payload: dict, out: Path):
    t = tally(payload)
    L = ["# Agent Evals: summary", "",
         f"Generated {payload['generated']}. " + "; ".join(f"{r['mode']} run on {r['model']}" for r in payload["runs"]) + ".", "",
         f"Across {len(payload['rows'])} agent/document rows: {t['pass']} checks passed, {t['fail']} failed, "
         f"{t['warn']} warned, {t['na']} did not apply.", "",
         "## Matrix", "", "| Agent | Document | " + " | ".join(c["id"].replace("_", " ") for c in payload["checks"]) + " |",
         "|---|---|" + "---|" * len(payload["checks"])]
    for r in payload["rows"]:
        L.append(f"| {r['agent']} | {r['variant']} ({r['source']}) | " +
                 " | ".join(SYMBOL[r["cells"][c["id"]]["s"]] for c in payload["checks"]) + " |")
    for n in payload["notes"]:
        L += ["", "> " + n]
    L += ["", "## Failures and warnings", ""]
    bad = [(r, n, c) for r in payload["rows"] for n, c in r["cells"].items() if c["s"] in ("fail", "warn")]
    if not bad:
        L.append("None.")
    for r, n, c in bad:
        v = c.get("t")
        L.append(f"- **{r['agent']}** ({r['variant']}), {n.replace('_', ' ')}: {SYMBOL[c['s']]}. "
                 + (f"**{v['verdict']}.** {v['note']}" if v else f"Not yet triaged. {c['m']}"))
        for e in c["e"][:2]:
            L.append(f"  - agent wrote: `{(e.get('offending') or e.get('date') or '')[:160]}`")
    out.write_text("\n".join(L) + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--results", nargs="*", help="results directories to merge (default: newest saved + newest live)")
    ap.add_argument("--out", default="report")
    a = ap.parse_args(argv)
    dirs = [lib.LAB / d for d in a.results] if a.results else [d for d in (newest("saved"), newest("live")) if d]
    if not dirs:
        raise SystemExit("no results found: run run.py first")
    data = load(dirs)
    payload = build_payload(data)
    out = lib.LAB / a.out
    out.mkdir(exist_ok=True)
    (out / "results.json").write_text(json.dumps({"generated": payload["generated"], "runs": data["runs"],
                                                  "summary": tally(payload), "cases": data["cases"]}, indent=1))
    write_html(payload, out / "index.html")
    write_summary(payload, out / "summary.md")
    print(f"wrote {out.relative_to(lib.LAB)}/index.html and summary.md from {[d.name for d in dirs]}; {tally(payload)}")


if __name__ == "__main__":
    main()
