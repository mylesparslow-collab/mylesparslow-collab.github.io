"""The output must contain every section the agent's own instructions require.

params: sections: ["Questions for the attorney", "Flags|Flag for the attorney", ...]
(each entry is a case-insensitive phrase; `a|b` accepts either). Headings can be pulled
from an instructions file with headings_from_instructions()."""
from __future__ import annotations

import re

from .common import Result, failed, passed, not_applicable, normalize


def headings_from_instructions(instructions: str) -> list[str]:
    """Markdown `## 1. Title` headings the instructions tell the agent to use."""
    out = []
    for line in instructions.splitlines():
        m = re.match(r"^#{2,3}\s+(?:\d+\.\s*)?(.+?)\s*$", line)
        if m:
            out.append(m.group(1))
    return out


def check(document: str, output: str, sections: list[str] | None = None, **_) -> Result:
    if not sections:
        return not_applicable("case lists no required sections")
    text = normalize(output).lower()
    missing = [s for s in sections
               if not any(normalize(alt).lower() in text for alt in s.split("|"))]
    if missing:
        return failed(f"{len(missing)} of {len(sections)} required sections are missing",
                      [{"kind": "section", "offending": f"missing section: {m}",
                        "nearest": "required by the agent's own output format"} for m in missing],
                      sections_required=len(sections))
    return passed(f"all {len(sections)} required sections present", sections_required=len(sections))
