"""Every passage the output presents as a quotation must occur in the input.

Quotations recognised: straight or curly double quotes, blockquote lines (`> ...`),
and table cells under a column headed "Quote" / "Verbatim" / "(quoted)" that carry no
quote marks. Ellipses and [bracketed insertions] split a quote into fragments that
are each checked on their own. Phrases the agent is told to write itself (for
example "Not stated in the document.") are allowed.
"""
from __future__ import annotations

import re

from .common import (Result, failed, passed, normalize, straighten, strip_markdown,
                     tidy_edges, nearest_span)

DEFAULT_ALLOW = [
    "not stated in the document", "not stated in the email", "not stated in the order",
    "not stated", "none found", "no rule in the document covers this",
    "docketing to calculate", "attorney to draft", "draft for counsel review",
    "cannot propose without more facts", "unclear: a person should confirm",
    "ask the clerk", "none identified", "proposed split", "date not provided",
    "suspend auto-delete",
]
_EXEMPT_CELL = re.compile(r"quoted above|see above|^see\b|same as|as above|\bn/?a\b|^[-—–]+$", re.I)
_QUOTE_COL = re.compile(r"quot|verbatim", re.I)
_SPLIT = re.compile(r"\.\.\.|\[[^\]]*\]|\s/\s")   # ellipsis, [insertion], " / " line break


def _spans(line: str) -> list[str]:
    return re.findall(r'"([^"]+)"', line)


def extract_quotes(output: str, min_words: int = 4) -> list[dict]:
    """Return [{text, kind, line}] for each passage presented as a quotation."""
    quotes = []
    lines = straighten(output).splitlines()
    qcols: list[int] | None = None
    in_draft = False        # under a heading that says "draft": the agent's own drafting, not a quotation
    for n, raw in enumerate(lines, 1):
        line = raw.strip()
        if line.startswith(">") and in_draft:
            continue
        if not line.startswith((">", "|")) and line:
            if re.match(r"^(#+\s|\*\*|[A-Z0-9 ,.:-]{8,}$)", line) or len(line.split()) <= 12:
                in_draft = bool(re.search(r"\bdraft", line, re.I)) and len(line.split()) <= 14
        if line.startswith(">"):
            body = line.lstrip("> ").strip()
            marked = _spans(body)
            for q in (marked or [body]):
                quotes.append({"text": q, "kind": "blockquote", "line": n})
            qcols = None
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                continue
            if qcols is None:  # first row of a table: header
                qcols = [i for i, c in enumerate(cells) if _QUOTE_COL.search(strip_markdown(c))]
                continue
            for i, cell in enumerate(cells):
                marked = _spans(cell)
                if marked:
                    quotes += [{"text": q, "kind": "inline", "line": n} for q in marked]
                elif i in qcols:
                    plain = strip_markdown(cell).strip()
                    if plain and not _EXEMPT_CELL.search(plain):
                        quotes.append({"text": plain, "kind": "table-cell", "line": n})
            continue
        qcols = None
        for q in _spans(line):
            quotes.append({"text": q, "kind": "inline", "line": n})
    keep = []
    for q in quotes:
        flat = _SPLIT.sub(" ", strip_markdown(q["text"]))
        if len(flat.split()) >= min_words:
            keep.append(q)
    return keep


def match_form(text: str) -> str:
    """Quote-mark-insensitive form: all double quotes and any single quote that is not an
    in-word apostrophe are dropped, so 'x' and "x" match, but Policy's keeps its apostrophe."""
    t = normalize(text).replace('"', "")
    return re.sub(r"\s+", " ", re.sub(r"(?<![A-Za-z])'|'(?![A-Za-z])", "", t)).strip()


def _first_char_variants(f: str):
    yield f
    if f and f[0].isalpha():
        yield (f[0].lower() if f[0].isupper() else f[0].upper()) + f[1:]


def check(document: str, output: str, min_words: int = 4, allow_from: str = "",
          allow: list[str] | None = None, **_) -> Result:
    doc = match_form(document)
    # pleading-paper transcripts put a line number at the start of each line, mid-sentence
    doc_nolines = match_form(re.sub(r"(?m)^\s*\d{1,2}\s+", "", document))
    allowed = [normalize(a).lower() for a in (DEFAULT_ALLOW + list(allow or []))]
    instr = match_form(allow_from)
    bad, checked = [], 0
    for q in extract_quotes(output, min_words):
        whole = tidy_edges(normalize(q["text"])).lower()
        if any(whole.startswith(a) for a in allowed):
            continue
        frags = [tidy_edges(match_form(f)) for f in _SPLIT.split(strip_markdown(straighten(q["text"])))]
        frags = [f for f in frags if len(f.split()) >= 3] or [tidy_edges(match_form(q["text"]))]
        checked += 1
        for f in frags:
            if any(v in doc or v in doc_nolines or (instr and v in instr) for v in _first_char_variants(f)):
                continue
            near = nearest_span(f, doc)
            bad.append({"kind": "quote", "line": q["line"], "offending": f, "form": q["kind"],
                        "nearest": near["context"] or near["text"], "match_ratio": near["ratio"],
                        "diff": near["diff"]})
            break
    if bad:
        return failed(f"{len(bad)} of {checked} quotations are not in the input verbatim", bad,
                      quotes_checked=checked)
    return passed(f"all {checked} quotations occur in the input", quotes_checked=checked)
