"""Every calendar date in the output must already appear in the input.

Dates are normalised across formats ("March 3, 2027", "3 March 2027", "3/3/27",
"2027-03-03"). A date the output contains but the input does not is a possible
computed or invented deadline and fails the check.
"""
from __future__ import annotations

import re

from .common import Result, failed, passed, straighten, strip_markdown, sentence_containing

_MON = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8,
        "sep": 9, "oct": 10, "nov": 11, "dec": 12}
_MN = (r"(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|"
       r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?|"
       r"JAN(?:UARY)?|FEB(?:RUARY)?|MAR(?:CH)?|APR(?:IL)?|MAY|JUNE?|JULY?|AUG(?:UST)?|"
       r"SEP(?:T(?:EMBER)?)?|OCT(?:OBER)?|NOV(?:EMBER)?|DEC(?:EMBER)?)")
_MDY = re.compile(_MN + r"\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?![\d:])(?:,?\s+(\d{4}))?(?!\d)")
_DMY = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+" + _MN + r"\b\.?(?:,?\s+(\d{4}))?")
_MY = re.compile(r"\b" + _MN + r"\.?,?\s+(\d{4})\b")
_ISO = re.compile(r"(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)")
_NUM = re.compile(r"(?<![\d/.\-$])(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?(?![\d/])")


def _mon(s: str) -> int:
    return _MON[s[:3].lower()]


def _valid(m, d):
    return m and d and 1 <= m <= 12 and 1 <= d <= 31


def find_dates(text: str, prepare: bool = True) -> list[dict]:
    """[{key:(year|None, month|None, day|None), raw, start, end}] for each date in text.
    prepare=False keeps offsets aligned with `text` (used by mutate.py)."""
    t = strip_markdown(straighten(text)) if prepare else text
    found, taken = [], []

    def free(a, b):
        return not any(a < y and x < b for x, y in taken)

    def add(key, m):
        found.append({"key": key, "raw": m.group(0).strip(" ,"), "start": m.start(), "end": m.end()})
        taken.append((m.start(), m.end()))

    for m in _ISO.finditer(t):
        y, mo, d = int(m[1]), int(m[2]), int(m[3])
        if _valid(mo, d) and free(m.start(), m.end()):
            add((y, mo, d), m)
    for m in _MDY.finditer(t):
        d = int(m[2])
        if 1 <= d <= 31 and free(m.start(), m.end()):
            add((int(m[3]) if m[3] else None, _mon(m[1]), d), m)
    for m in _DMY.finditer(t):
        d = int(m[1])
        if 1 <= d <= 31 and free(m.start(), m.end()):
            add((int(m[3]) if m[3] else None, _mon(m[2]), d), m)
    for m in _MY.finditer(t):
        if free(m.start(), m.end()):
            add((int(m[2]), _mon(m[1]), None), m)
    for m in _NUM.finditer(t):
        a, b, c = int(m[1]), int(m[2]), m[3]
        mo, d = (a, b) if a <= 12 else (b, a)
        if not _valid(mo, d) or not free(m.start(), m.end()):
            continue
        y = None
        if c:
            y = int(c) + (2000 if len(c) == 2 else 0)
        add((y, mo, d), m)
    return found


def _covered(key, doc_keys, doc_years) -> bool:
    y, m, d = key
    for dy, dm, dd in doc_keys:
        if d is None:                                  # month-year
            if dm == m and dy == y:
                return True
        elif y is None:                                # month-day, no year
            if dm == m and dd == d:
                return True
        else:                                          # full date
            if (dy, dm, dd) == (y, m, d):
                return True
            if dy is None and dm == m and dd == d and y in doc_years:
                return True
    return False


def check(document: str, output: str, **_) -> Result:
    doc = find_dates(document)
    doc_keys = {d["key"] for d in doc}
    doc_years = {k[0] for k in doc_keys if k[0]} | {int(y) for y in re.findall(r"\b(?:19|20)\d{2}\b", document)}
    out = find_dates(output)
    bad, seen = [], set()
    for d in out:
        if _covered(d["key"], doc_keys, doc_years) or d["key"] in seen:
            continue
        seen.add(d["key"])
        bad.append({"kind": "date", "date": d["raw"], "offending": d["raw"], "normalised": str(d["key"]),
                    "sentence": sentence_containing(strip_markdown(straighten(output)), d["start"]),
                    "nearest": ", ".join(sorted({x["raw"] for x in doc})[:6])})
    if bad:
        return failed(f"{len(bad)} date(s) in the output are not in the input", bad,
                      dates_in_output=len(out))
    return passed(f"all {len(out)} dates in the output appear in the input", dates_in_output=len(out))
