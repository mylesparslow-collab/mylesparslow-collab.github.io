"""Shared helpers: the Result type, text normalisation, sentence splitting."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field, asdict

PASS, FAIL, WARN, NA = "pass", "fail", "warn", "na"


@dataclass
class Result:
    status: str                      # pass | fail | warn | na
    message: str = ""
    evidence: list[dict] = field(default_factory=list)
    stats: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def passed(message="", **stats) -> Result:
    return Result(PASS, message, [], stats)


def failed(message, evidence, **stats) -> Result:
    return Result(FAIL, message, evidence, stats)


def not_applicable(message) -> Result:
    return Result(NA, message)


_QUOTE_MAP = str.maketrans({
    "“": '"', "”": '"', "„": '"', "«": '"', "»": '"',
    "‘": "'", "’": "'", "‚": "'", "′": "'",
    "–": "-", "—": "-", "‑": "-", "−": "-",
    " ": " ", " ": " ", " ": " ",
})


def straighten(text: str) -> str:
    """Curly quotes, dashes and odd spaces to plain ASCII. Keeps line breaks."""
    return unicodedata.normalize("NFKC", text).translate(_QUOTE_MAP).replace("…", "...")


def strip_markdown(text: str) -> str:
    return re.sub(r"[*`\\]", "", text)


def normalize(text: str) -> str:
    """Whitespace, quote-mark and markdown-emphasis normalisation (case kept)."""
    return re.sub(r"\s+", " ", strip_markdown(straighten(text))).strip()


def tidy_edges(text: str) -> str:
    return text.strip(" \t\n.,;:!?-")


def words(text: str) -> list[str]:
    return normalize(text).split()


_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'(\[*|])")


def sentences(text: str) -> list[dict]:
    """Split into sentences, remembering the 1-based line each starts on."""
    out = []
    for n, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        if line.startswith("|"):          # a table row is one unit
            out.append({"text": line, "line": n})
            continue
        for part in _SENT_SPLIT.split(line):
            if part.strip():
                out.append({"text": part.strip(), "line": n})
    return out


def sentence_containing(text: str, start: int) -> str:
    """The sentence (or table row / line) of `text` that contains offset `start`."""
    ls = text.rfind("\n", 0, start) + 1
    le = text.find("\n", start)
    le = len(text) if le < 0 else le
    line = text[ls:le]
    if line.lstrip().startswith("|"):
        return line.strip()
    pos = start - ls
    s = 0
    for m in re.finditer(r"(?<=[.!?])\s+(?=[A-Z\"'(\[*|])", line):
        if m.end() <= pos:
            s = m.end()
        else:
            return line[s:m.start()].strip()
    return line[s:].strip()


def word_diff(quote: str, source: str) -> str:
    """Compact word-level diff: [-in quote only-] [+in source only+]."""
    import difflib
    a, b = quote.split(), source.split()
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    parts = []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            parts.append(" ".join(a[i1:i2]))
        else:
            if i2 > i1:
                parts.append("[-" + " ".join(a[i1:i2]) + "-]")
            if j2 > j1:
                parts.append("[+" + " ".join(b[j1:j2]) + "+]")
    return " ".join(parts)


def nearest_span(fragment: str, doc_norm: str, pad: int = 6) -> dict:
    """Best-matching window of the document for a fragment that is not in it."""
    import difflib
    q, d = fragment.split(), doc_norm.split()
    n = len(q)
    if not d or not n:
        return {"text": "", "ratio": 0.0, "diff": ""}
    qset = set(q)
    scored = []
    for i in range(max(1, len(d) - n + 1)):
        w = d[i:i + n]
        scored.append((len(qset & set(w)), i))
    scored.sort(reverse=True)
    best = (0.0, 0)
    for _, i in scored[:8]:
        w = d[i:i + n]
        r = difflib.SequenceMatcher(None, q, w, autojunk=False).ratio()
        if r > best[0]:
            best = (r, i)
    r, i = best
    window = " ".join(d[i:i + n])
    context = " ".join(d[max(0, i - pad): i + n + pad])
    return {"text": window, "context": context, "ratio": round(r, 3), "diff": word_diff(fragment, window)}
