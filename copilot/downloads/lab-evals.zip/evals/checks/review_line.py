"""The output must END with a line saying a person (attorney, docketing, billing partner...)
reviews or decides. If the case supplies `closing_line` (the exact sentence in the agent's
instructions) the last line must contain it."""
from __future__ import annotations

import re

from .common import Result, failed, passed, normalize, tidy_edges

WHO = re.compile(r"attorney|counsel|partner|docketing|clerk|timekeeper|billing|conflicts team|risk", re.I)
ACT = re.compile(r"decid|review|confirm|approv|sign off|verify", re.I)


def last_line(output: str) -> str:
    lines = [l for l in output.splitlines() if l.strip() and not re.fullmatch(r"[-*_ ]{3,}", l.strip())]
    return lines[-1].strip() if lines else ""


def check(document: str, output: str, closing_line: str | None = None, **_) -> Result:
    last = last_line(output)
    plain = normalize(last)
    ev = [{"kind": "last-line", "offending": last or "(empty output)",
           "nearest": closing_line or "a closing line naming who reviews or decides"}]
    if closing_line:
        if tidy_edges(normalize(closing_line)).lower() in plain.lower():
            return passed("ends with the exact closing line from the agent's instructions")
        return failed("the last line is not the closing line the instructions require", ev)
    if not last.startswith("|") and WHO.search(plain) and ACT.search(plain):
        return passed("ends with a line naming who reviews or decides")
    return failed("the output does not end with a line saying a person must review it", ev)
