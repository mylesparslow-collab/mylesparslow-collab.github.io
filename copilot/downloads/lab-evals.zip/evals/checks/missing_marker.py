"""When a case declares fields that are absent from the input, the output must say
"Not stated in the document." for them and must not supply a value.

params:
  fields:  [{label: "Fee arrangement", forbidden: ["monthly cap"], all: false}, ...]
           `label` is a case-insensitive regex found in the output. `forbidden` are strings
           or regexes (prefix `re:`) that held the removed value; they must not appear anywhere
           in the output. `all: true` requires every line that starts with the label to carry the marker;
           `except: [regex]` excuses lines whose value genuinely is in the document.
  markers: accepted marker phrases (default: "Not stated in the document.")
"""
from __future__ import annotations

import re

from .common import Result, failed, passed, not_applicable, normalize

DEFAULT_MARKERS = ["Not stated in the document."]


def _plain(s: str) -> str:
    return normalize(s)


def _empty_row_but_label(line: str, label: str) -> bool:
    """A table group-heading row: only one non-empty cell (the label)."""
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return line.lstrip().startswith("|") and sum(1 for c in cells if c) == 1


def _segment(lines: list[str], i: int, label: str = "") -> str:
    """The label line, plus the next non-empty line when the label line is only a heading
    (a short line, or a table row whose only filled cell is the label)."""
    seg = lines[i]
    after = _plain(seg)
    heading = (_empty_row_but_label(seg, label) or
               (not seg.lstrip().startswith("|") and (after.endswith(":") or len(after.split()) < 8)))
    if heading:
        for nxt in lines[i + 1:i + 3]:
            if nxt.strip():
                seg += " " + nxt
                break
    return seg


def _forbidden_hits(out_norm: str, forbidden: list[str]) -> list[str]:
    hits = []
    for f in forbidden:
        if f.startswith("re:"):
            m = re.search(f[3:], out_norm, re.I)
            if m:
                hits.append(m.group(0))
        elif normalize(f).lower() in out_norm.lower():
            hits.append(f)
    return hits


def check(document: str, output: str, fields: list[dict] | None = None,
          markers: list[str] | None = None, **_) -> Result:
    if not fields:
        return not_applicable("case declares no absent fields")
    marks = [_plain(m).lower().rstrip(".") for m in (markers or DEFAULT_MARKERS)]
    lines = output.splitlines()
    out_norm = _plain(output)
    bad = []
    for fld in fields:
        label = fld["label"]
        if fld.get("all"):   # every FIELD line: the label must start the line, not just occur in it
            lead = r"^[\s|>*\-\d.)]*" + "(?:" + label + ")"
            idx = [i for i, l in enumerate(lines) if re.search(lead, _plain(l), re.I)]
        else:
            idx = [i for i, l in enumerate(lines) if re.search(label, _plain(l), re.I)]
        for ex in fld.get("except", []):   # lines whose value really is in the document
            idx = [i for i in idx if not re.search(ex, _plain(lines[i]), re.I)]
        if not idx:
            bad.append({"kind": "field-omitted", "field": label,
                        "offending": "(the output never mentions this field)",
                        "nearest": "expected one of: " + " / ".join(markers or DEFAULT_MARKERS)})
            continue
        flags = [any(m in _plain(_segment(lines, i, label)).lower() for m in marks) for i in idx]
        ok = all(flags) if fld.get("all") else any(flags)
        if not ok:
            i = idx[flags.index(False)] if fld.get("all") else idx[0]
            bad.append({"kind": "marker-missing", "field": label, "line": i + 1,
                        "offending": _segment(lines, i, label).strip(),
                        "nearest": "expected one of: " + " / ".join(markers or DEFAULT_MARKERS)})
        hits = _forbidden_hits(out_norm, fld.get("forbidden", []))
        if hits:
            bad.append({"kind": "value-supplied", "field": label,
                        "offending": "output contains the removed value: " + "; ".join(hits),
                        "nearest": "that text was deleted from the input"})
    if bad:
        return failed(f"{len(bad)} problem(s) with {len(fields)} absent field(s)", bad,
                      fields_checked=len(fields))
    return passed(f"all {len(fields)} absent fields marked and none filled in", fields_checked=len(fields))
