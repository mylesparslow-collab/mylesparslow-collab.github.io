import subprocess
import tempfile

from .base import Provider

DENY = "Bash,Read,Write,Edit,Glob,Grep,WebFetch,WebSearch,Agent"


class ClaudeCLI(Provider):
    """`claude -p` with the agent's instructions as the system prompt, every tool denied,
    and the document on stdin. Runs in an empty temp directory."""
    name = "claude-cli"

    def __init__(self, model: str = "haiku", timeout: int = 300):
        self.model, self.timeout = model, timeout

    def generate(self, system_prompt: str, user_text: str) -> str:
        cmd = ["claude", "-p", "--model", self.model, "--system-prompt", system_prompt,
               "--disallowedTools", DENY, "--no-session-persistence", "--disable-slash-commands",
               "--strict-mcp-config"]
        with tempfile.TemporaryDirectory() as cwd:
            r = subprocess.run(cmd, input=user_text, capture_output=True, text=True,
                               timeout=self.timeout, cwd=cwd)
        if r.returncode != 0 or not r.stdout.strip():
            raise RuntimeError(f"claude exited {r.returncode}: {(r.stderr or r.stdout)[:300]}")
        return r.stdout
