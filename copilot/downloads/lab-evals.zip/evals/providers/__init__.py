"""Model providers: anything with generate(system_prompt, user_text) -> str."""
from .base import Provider
from .claude_cli import ClaudeCLI
from .azure_openai import AzureOpenAI

PROVIDERS = {"claude-cli": ClaudeCLI, "azure-openai": AzureOpenAI}


def get(name: str, **kw) -> Provider:
    return PROVIDERS[name](**kw)
