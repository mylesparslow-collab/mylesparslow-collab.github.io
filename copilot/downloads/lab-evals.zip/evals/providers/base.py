class Provider:
    """Interface the runner uses. `name` and `model` go into the cache key and the results file."""
    name = "base"
    model = ""

    def generate(self, system_prompt: str, user_text: str) -> str:
        raise NotImplementedError
