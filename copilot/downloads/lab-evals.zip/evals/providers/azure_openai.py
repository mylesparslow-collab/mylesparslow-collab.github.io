"""UNTESTED STUB: swap this in to evaluate the agents on an Azure OpenAI deployment (or any
Copilot evaluation endpoint) instead of Claude Haiku.

Nothing here has been run: there is no Azure resource behind this lab. The agents' real
home is Microsoft 365 Copilot, which has no public "run this agent on this text" API, so
an Azure OpenAI chat deployment given the same instructions is the closest stand-in, and it
is NOT the same model or orchestration. A real Copilot evaluation would need to drive the
agent through Copilot Studio test tooling and paste its replies into results/ as saved
outputs, which `run.py --saved` can then score.

To finish it: set the three variables in .env.example, `uv add openai`, replace the body of
generate() with a chat.completions call (system = instructions, user = document,
temperature 0), and run `python run.py --live --provider azure-openai ...`.
"""
import os

from .base import Provider


class AzureOpenAI(Provider):
    name = "azure-openai"

    def __init__(self, model: str | None = None, **_):
        self.model = model or os.environ.get("AZURE_OPENAI_DEPLOYMENT", "")

    def generate(self, system_prompt: str, user_text: str) -> str:
        raise NotImplementedError(
            "AzureOpenAI provider is a stub and has never been run. See the docstring in "
            "providers/azure_openai.py for what to fill in.")
