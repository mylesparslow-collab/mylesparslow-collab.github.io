// One-off generator for docket.json, time_entries.json, billing_rules.json. Output is committed; the server only reads the JSON.
import { writeFileSync } from "node:fs";
const w = (f, o) => writeFileSync(new URL(f, import.meta.url), JSON.stringify(o, null, 1) + "\n");

// ---- billing rules (Outside Counsel Guidelines, invented) ----
const R = (client, code, severity, ref, text, params = {}) => ({ id: `R-${client.slice(2)}-${code}`, client_id: client, code, severity, guideline_ref: ref, text, params });
const BB = (c, ref) => R(c, "BLOCK_BILLING", "hard", ref, "Each task must be recorded as a separate time entry. Block billing, meaning several tasks combined in one entry, is not permitted.");
const INC = (c, ref, inc) => R(c, "INCREMENT", "hard", ref, inc === 0.1 ? "Time must be recorded in tenth-of-an-hour (0.1) increments." : "Time must be recorded in quarter-hour (0.25) increments.", { increment: inc });
const CL = (c, ref) => R(c, "CLERICAL", "hard", ref, "Clerical or administrative tasks, including copying, scanning, filing, calendaring and scheduling, are overhead and will not be paid.");
const TR = (c, ref, f) => R(c, "TRAVEL", "adjust", ref, f === 0.5 ? "Non-working travel time is payable at fifty percent (50%) of the timekeeper's rate." : "Local travel time is not payable.", { factor: f });
const VG = (c, ref, n) => R(c, "VAGUE", "hard", ref, `Each entry must describe the task with enough specificity to evaluate it (at least ${n} words). Generic descriptions such as "attention to file" or "work on matter" will be rejected.`, { min_words: n });
const MX = (c, ref, h) => R(c, "MAX_ENTRY", "warn", ref, `Any single entry above ${h.toFixed(1)} hours requires advance approval by the client's claims manager.`, { max_hours: h });
w("billing_rules.json", [
  BB("C-100", "OCG 4.1"), INC("C-100", "OCG 4.2", 0.1), VG("C-100", "OCG 4.3", 5), CL("C-100", "OCG 4.5"), TR("C-100", "OCG 4.7", 0.5),
  BB("C-101", "Panel Policy 6(a)"), INC("C-101", "Panel Policy 6(b)", 0.1), CL("C-101", "Panel Policy 6(d)"), TR("C-101", "Panel Policy 6(f)", 0), VG("C-101", "Panel Policy 6(c)", 6),
  BB("C-102", "Billing Terms 3.1"), INC("C-102", "Billing Terms 3.2", 0.1), CL("C-102", "Billing Terms 3.4"), MX("C-102", "Billing Terms 3.6", 6),
  BB("C-103", "Fee Protocol 2.1"), INC("C-103", "Fee Protocol 2.2", 0.1), CL("C-103", "Fee Protocol 2.3"),
  BB("C-104", "Panel Guidelines 5.1"), INC("C-104", "Panel Guidelines 5.2", 0.1), VG("C-104", "Panel Guidelines 5.3", 5), CL("C-104", "Panel Guidelines 5.5"), TR("C-104", "Panel Guidelines 5.8", 0.5), MX("C-104", "Panel Guidelines 5.9", 8),
  BB("C-105", "Counsel Terms 7.1"), INC("C-105", "Counsel Terms 7.2", 0.1), CL("C-105", "Counsel Terms 7.4"), MX("C-105", "Counsel Terms 7.7", 8),
  BB("C-106", "Engagement Billing Rules 1"), INC("C-106", "Engagement Billing Rules 2", 0.1), CL("C-106", "Engagement Billing Rules 4"),
  BB("C-107", "Billing Addendum 2.1"), INC("C-107", "Billing Addendum 2.2", 0.25), CL("C-107", "Billing Addendum 2.5"), TR("C-107", "Billing Addendum 2.6", 0.5)
]);

// ---- docket (dates as given; computed_by is always "docketing") ----
const D = (id, m, entry_date, entry_type, description, due_date, status, basis, src) => ({ id, matter_id: m, entry_date, entry_type, description, due_date, status, computed_by: due_date ? "docketing" : null, docketed_by: due_date ? "Renata Okafor (Docketing)" : null, date_basis: basis, source_ref: src });
const docket = [
 D("DK-0412-01","M-0412","2026-03-09","filing","Complaint filed",null,"done",null,"Complaint"),
 D("DK-0412-02","M-0412","2026-05-04","filing","District's answer and cross-complaint filed and served",null,"done",null,"Cross-complaint"),
 D("DK-0412-03","M-0412","2026-10-30","order","Case management order issued: expert disclosure and mediation dates set",null,"done",null,"CMC order 10/30/2026"),
 D("DK-0412-04","M-0412","2026-10-30","deadline","Opposition to District's motion for summary adjudication due","2026-11-17","open","Court order dated 2026-10-30, paragraph 4 (date stated by the court)","CMC order 10/30/2026 para. 4"),
 D("DK-0412-05","M-0412","2026-10-30","deadline","Initial expert disclosure exchange","2026-11-20","open","Court order dated 2026-10-30, paragraph 6 (date stated by the court)","CMC order 10/30/2026 para. 6"),
 D("DK-0412-06","M-0412","2026-11-02","hearing","Hearing on District's motion for summary adjudication, Dept. 14","2026-12-04","open","Hearing date set by the court clerk per notice of hearing","Notice of hearing 11/02/2026"),
 D("DK-0412-07","M-0412","2026-10-30","deadline","Mediation completed (private mediator, per order)","2026-12-18","open","Court order dated 2026-10-30, paragraph 8 (date stated by the court)","CMC order 10/30/2026 para. 8"),
 D("DK-0388-01","M-0388","2026-02-17","filing","Answer to lien foreclosure complaint filed",null,"done",null,"Answer"),
 D("DK-0388-02","M-0388","2026-10-21","deadline","Responses to Requests for Production, Set Two, due","2026-11-24","open","Calculated by Docketing from service date plus extension agreed by stipulation","Stipulation 10/21/2026; proof of service"),
 D("DK-0388-03","M-0388","2026-10-21","deadline","Cross-complaint against subcontractor: last day to file without leave","2026-12-29","open","Calculated by Docketing from the trial date per the scheduling order","Scheduling order 09/15/2026"),
 D("DK-0917-01","M-0917","2025-09-22","deadline","Agency response to cure-and-correct demand","2025-10-22","done","Calculated by Docketing from date of receipt of demand","Demand letter 09/22/2025"),
 D("DK-0917-02","M-0917","2026-10-28","filing","Petition filed by requestor; served on Agency",null,"done",null,"Petition"),
 D("DK-0917-03","M-0917","2026-10-28","deadline","Agency responsive pleading due","2026-11-27","open","Calculated by Docketing from date of service of petition","Proof of service 10/28/2026"),
 D("DK-0917-04","M-0917","2026-11-02","hearing","Board special meeting: closed-session item on petition","2026-11-19","open","Date of meeting per agency's posted agenda","Posted agenda 11/16/2026"),
 D("DK-0156-01","M-0156","2026-01-26","filing","Validation complaint filed",null,"done",null,"Complaint"),
 D("DK-0156-02","M-0156","2026-10-09","deadline","Last day for interested-party answers per publication order","2026-12-01","open","Calculated by Docketing from last date of publication per the court's order","Publication order 10/09/2026"),
 D("DK-0156-03","M-0156","2026-10-09","hearing","Validation hearing, Dept. 3","2027-01-12","open","Hearing date set by the court","Order setting hearing 10/09/2026"),
 D("DK-0231-01","M-0231","2026-04-02","filing","Notice of defense filed",null,"done",null,"Notice of defense"),
 D("DK-0231-02","M-0231","2026-10-05","deadline","Prehearing brief due to the administrative law judge","2026-11-16","open","Date stated in the notice of hearing","Notice of hearing 10/05/2026"),
 D("DK-0231-03","M-0231","2026-10-05","hearing","Administrative hearing, day one","2026-12-08","open","Date stated in the notice of hearing","Notice of hearing 10/05/2026"),
 D("DK-0294-01","M-0294","2026-05-11","deadline","Client's target date for first restated form, six communities","2026-12-15","open","Date requested by client; not a court or statutory date","Engagement email 05/11/2026"),
 D("DK-0345-01","M-0345","2026-06-03","filing","Answer filed",null,"done",null,"Answer"),
 D("DK-0345-02","M-0345","2026-10-14","deadline","Response to Plaintiff's motion to compel store-level time records","2026-11-13","open","Calculated by Docketing from service of motion","Motion and proof of service 10/14/2026"),
 D("DK-0345-03","M-0345","2026-10-14","deadline","Further case management statement due","2026-11-30","open","Date stated in the court's notice","Notice 10/14/2026"),
 D("DK-0345-04","M-0345","2026-10-14","hearing","Hearing on motion to compel, Dept. 21","2026-12-11","open","Hearing date set by the court","Notice of motion 10/14/2026"),
 D("DK-0360-01","M-0360","2026-08-18","deadline","Executive's counter-proposal response window closes (per term sheet)","2026-11-20","open","Date stated in the term sheet; not a statutory period","Term sheet 11/06/2026"),
 D("DK-0803-01","M-0803","2025-08-04","filing","Complaint filed",null,"done",null,"Complaint"),
 D("DK-0803-02","M-0803","2026-09-29","deadline","Tenant's opposition to motion for partial summary judgment received; reply due","2026-11-12","done","Calculated by Docketing from service of opposition","Opposition and proof of service 09/29/2026"),
 D("DK-0803-03","M-0803","2026-09-29","hearing","Hearing on motion for partial summary judgment, Dept. 17","2026-11-23","open","Hearing date set by the court","Notice of hearing 09/29/2026"),
 D("DK-0803-04","M-0803","2026-09-29","deadline","Discovery cut-off","2027-01-22","open","Calculated by Docketing from trial date per Code of Civil Procedure","Trial setting order 06/30/2026"),
 D("DK-0119-01","M-0119","2026-01-12","deadline","Due diligence period expires","2026-11-30","open","Date stated in the purchase agreement, section 5.1","Purchase agreement s. 5.1"),
 D("DK-0119-02","M-0119","2026-01-12","deadline","Closing date","2026-12-22","open","Date stated in the purchase agreement, section 8.2","Purchase agreement s. 8.2"),
 D("DK-0402-01","M-0402","2026-07-14","filing","Complaint filed",null,"done",null,"Complaint"),
 D("DK-0402-02","M-0402","2026-10-26","deadline","Defendant's demurrer opposition due","2026-11-18","open","Calculated by Docketing from service of demurrer","Demurrer and proof of service 10/26/2026"),
 D("DK-0402-03","M-0402","2026-10-26","hearing","Hearing on demurrer, Dept. 11","2026-12-02","open","Hearing date set by the court","Notice of hearing 10/26/2026"),
 D("DK-0402-04","M-0402","2026-10-26","deadline","Joint inspection of fire scene (evidence preservation protocol)","2026-11-19","open","Date agreed by stipulation between counsel","Stipulation 10/20/2026"),
 D("DK-0421-01","M-0421","2026-09-08","deadline","Interim findings memorandum to Board counsel","2026-11-30","open","Date stated in the engagement letter; not a statutory period","Engagement letter 09/08/2026"),
 D("DK-0421-02","M-0421","2026-09-08","deadline","Hotline records preservation notice follow-up","2026-11-18","open","Date set by the responsible attorney","Internal note 09/08/2026")
];
w("docket.json", docket);

// ---- time entries (deterministic pseudo-random) ----
let seed = 7; const rnd = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
const pick = (a) => a[Math.floor(rnd() * a.length)];
const narr = {
 "M-0412": ["Reviewed project schedule updates and prepared delay-analysis chart for expert","Drafted opposition to motion for summary adjudication, statement of disputed facts","Analyzed daily reports for weather-delay entries, Harbor Middle School","Prepared for call with scheduling expert regarding critical-path analysis","Revised declaration of project manager regarding owner-directed change orders"],
 "M-0388": ["Reviewed subcontractor lien notice and pay applications for compliance","Drafted responses to Requests for Production, Set Two","Researched stop-notice timing requirements for private works"],
 "M-0917": ["Reviewed agenda posting records for the August board meeting","Drafted response to cure-and-correct demand","Analyzed petition allegations regarding agenda description"],
 "M-0156": ["Revised validation complaint exhibits, bond resolution authority","Reviewed publication affidavit and proof of service"],
 "M-0231": ["Reviewed incident report and medication administration records","Drafted prehearing brief, statement of facts section"],
 "M-0294": ["Reviewed entrance-fee agreement refund provisions across communities","Drafted comparison chart of refund terms for six communities"],
 "M-0345": ["Analyzed store-level time records produced by client","Drafted opposition to motion to compel time records","Prepared witness outline for store manager interview"],
 "M-0360": ["Reviewed executive employment agreement severance terms","Drafted counter-proposal to term sheet"],
 "M-0803": ["Reviewed percentage-rent audit workpapers for anchor tenant","Drafted reply brief in support of motion for partial summary judgment"],
 "M-0119": ["Reviewed preliminary title report and exceptions for the parcel","Drafted purchase agreement amendment regarding survey contingency"],
 "M-0402": ["Reviewed fire investigator report and origin analysis","Drafted opposition to demurrer, causes of action for negligence","Analyzed roofing contractor hot-work permit records"],
 "M-0421": ["Reviewed hotline report and compliance committee minutes","Prepared interview outline for compliance officer"]
};
const teams = {}; const matters = JSON.parse((await import("node:fs")).readFileSync(new URL("matters.json", import.meta.url)));
const users = JSON.parse((await import("node:fs")).readFileSync(new URL("users.json", import.meta.url)));
const rate = Object.fromEntries(users.map(u => [u.id, u.rate_cents]));
const entries = []; let n = 1;
for (const m of matters) {
  const tks = m.team.filter(t => rate[t.user_id] > 0).map(t => t.user_id);
  const k = m.id === "M-0412" ? 7 : 3;
  for (let i = 0; i < k; i++) {
    const u = pick(tks); const day = 1 + Math.floor(rnd() * 11); const hours = Math.round((0.5 + rnd() * 5) * 10) / 10;
    entries.push({ id: `TE-${String(n++).padStart(4,"0")}`, matter_id: m.id, user_id: u, work_date: `2026-11-${String(day).padStart(2,"0")}`, hours, billable_hours: hours, narrative: pick(narr[m.id]), status: "unbilled", rate_cents: rate[u] });
  }
}
w("time_entries.json", entries);

// ---- invoices (open receivables) ----
const inv = [];
const base = { "M-0412": [128450.0, 0], "M-0388": [41200.0, 20000.0], "M-0917": [18750.5, 0], "M-0156": [32400.0, 32400.0], "M-0231": [27600.0, 10000.0], "M-0294": [15300.0, 15300.0], "M-0345": [96800.0, 30000.0], "M-0360": [9400.0, 9400.0], "M-0803": [74320.0, 0], "M-0119": [22100.0, 22100.0], "M-0402": [58900.0, 25000.0], "M-0421": [36250.0, 0] };
let k = 1; for (const [m, [a, p]] of Object.entries(base)) inv.push({ id: `INV-${2026}-${String(k).padStart(3,"0")}`, matter_id: m, issued_date: "2026-10-31", amount_cents: Math.round(a * 100), paid_cents: Math.round(p * 100) }), k++;
w("invoices.json", inv);
console.log("entries", entries.length, "docket", docket.length);
