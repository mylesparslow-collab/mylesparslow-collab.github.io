import { test, after } from "node:test";
import assert from "node:assert/strict";
import { makeApp, NOW } from "./helpers.ts";
import { DERIVED_KEY_WINDOW_MS } from "../src/server.ts";

const t = await makeApp();
after(() => t.close());
const entry = { matter_id: "M-0412", work_date: "2026-11-13", hours: 1.2, narrative: "Reviewed daily reports for weather delay entries" };
const count = () => (t.db.prepare("SELECT COUNT(*) AS n FROM time_entries").get() as any).n;

test("same Idempotency-Key twice creates one row and replays the response", async () => {
  const n0 = count();
  const a = await t.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-0001" }, body: entry });
  const b = await t.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-0001" }, body: entry });
  assert.equal(a.status, 201); assert.equal(b.status, 201);
  assert.deepEqual(b.body, a.body);
  assert.equal(b.headers.get("idempotent-replayed"), "true");
  assert.equal(a.headers.get("idempotent-replayed"), null);
  assert.equal(count(), n0 + 1);
  assert.equal((t.db.prepare("SELECT COUNT(*) AS n FROM audit_log WHERE action = 'time_entry.created'").get() as any).n, 1);
});

test("same key with a different body is 422 and writes nothing", async () => {
  const n0 = count();
  const r = await t.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-0001" }, body: { ...entry, hours: 2.0 } });
  assert.equal(r.status, 422);
  assert.ok(r.body.type.endsWith("/idempotency-key-reuse"));
  assert.equal(count(), n0);
});

test("different keys create different rows", async () => {
  const n0 = count();
  await t.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-0002" }, body: entry });
  assert.equal(count(), n0 + 1);
});

test("without a header the server derives a key, so an identical retry never double-posts", async () => {
  const n0 = count();
  const body = { ...entry, work_date: "2026-11-12" };
  const a = await t.call("POST", "/time-entries", { body });
  const b = await t.call("POST", "/time-entries", { body });
  assert.equal(a.status, 201);
  assert.deepEqual(b.body, a.body);
  assert.equal(count(), n0 + 1);
});

test("keys are scoped per user", async () => {
  const n0 = count();
  await t.call("POST", "/time-entries", { as: "aanya", headers: { "idempotency-key": "idem-key-0001" }, body: entry });
  assert.equal(count(), n0 + 1);
});

test("idempotency holds for holds and reminders too", async () => {
  const body = { title: "Cedar Ridge project documents", scope_description: "All Cedar Ridge project documents.", custodians: [{ name: "Pat Quill", email: "pat.quill@halvorsen-builders.example" }] };
  const h = () => t.call("POST", "/matters/M-0388/lit-holds", { headers: { "idempotency-key": "idem-hold-0001" }, body });
  const [a, b] = [await h(), await h()];
  assert.equal(a.body.id, b.body.id);
  assert.equal((t.db.prepare("SELECT COUNT(*) AS n FROM holds").get() as any).n, 3);
  const r1 = await t.call("POST", "/lit-holds/H-1001/acknowledge-reminders", { headers: { "idempotency-key": "idem-rem-00001" }, body: {} });
  const r2 = await t.call("POST", "/lit-holds/H-1001/acknowledge-reminders", { headers: { "idempotency-key": "idem-rem-00001" }, body: {} });
  assert.deepEqual(r2.body, r1.body);
  assert.equal((t.db.prepare("SELECT reminder_count AS n FROM hold_custodians WHERE hold_id = 'H-1001' AND name = 'Bennett Okoye'").get() as any).n, 3);
});

test("writes are audit-logged with who, what, when and before/after", async () => {
  const row = t.db.prepare("SELECT * FROM audit_log WHERE action = 'lit_hold.reminders_sent'").get() as any;
  assert.equal(row.user_id, "u-jordan");
  assert.equal(row.ts, "2026-11-13T17:00:00.000Z");
  const d = JSON.parse(row.detail);
  assert.ok(d.before && d.after);
  assert.equal(row.idempotency_key, "idem-rem-00001");
});

test("derived keys expire after the window: same request replays inside it and runs again after", async () => {
  let clock = new Date(NOW);
  const t2 = await makeApp(() => clock);
  try {
    const rows = () => (t2.db.prepare("SELECT reminder_count AS n FROM hold_custodians WHERE hold_id = 'H-1001' AND name = 'Bennett Okoye'").get() as any).n;
    const n0 = rows();
    const a = await t2.call("POST", "/lit-holds/H-1001/acknowledge-reminders", { body: {} });
    clock = new Date(clock.getTime() + DERIVED_KEY_WINDOW_MS - 1000);
    const b = await t2.call("POST", "/lit-holds/H-1001/acknowledge-reminders", { body: {} });
    assert.equal(b.headers.get("idempotent-replayed"), "true");
    assert.deepEqual(b.body, a.body);
    assert.equal(rows(), n0 + 1);
    clock = new Date(clock.getTime() + 2000); // now past the window since the original write
    const c = await t2.call("POST", "/lit-holds/H-1001/acknowledge-reminders", { body: {} });
    assert.equal(c.status, 200);
    assert.equal(c.headers.get("idempotent-replayed"), null);
    assert.equal(rows(), n0 + 2);
  } finally { await t2.close(); }
});

test("explicit Idempotency-Key is not subject to the derived-key window", async () => {
  let clock = new Date(NOW);
  const t2 = await makeApp(() => clock);
  try {
    const body = { ...entry, work_date: "2026-11-11" };
    const a = await t2.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-long1" }, body });
    clock = new Date(clock.getTime() + 30 * DERIVED_KEY_WINDOW_MS);
    const b = await t2.call("POST", "/time-entries", { headers: { "idempotency-key": "idem-key-long1" }, body });
    assert.equal(b.headers.get("idempotent-replayed"), "true");
    assert.deepEqual(b.body, a.body);
  } finally { await t2.close(); }
});
