import { test, after } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { Ajv } from "ajv";
import { renderCard } from "../src/template.ts";
import { makeApp } from "./helpers.ts";
import { fns } from "../scripts/plugin-def.ts";

const schema = JSON.parse(readFileSync(new URL("../vendor/adaptive-card.schema.json", import.meta.url), "utf8"));
const ajv = new Ajv({ strict: false, allErrors: true });
// The published schema is draft-06 with an https $schema URI that ajv does not ship; its keywords are a subset of draft-07, so drop the URI.
delete schema.$schema; delete schema.id;
const validate = ajv.compile(schema);
const dir = new URL("../plugin/adaptive-cards/", import.meta.url);
const files = readdirSync(dir).filter((f) => f.endsWith(".json"));
const load = (f: string) => JSON.parse(readFileSync(new URL(f, dir), "utf8"));
const stripDirectives = (n: any): any => Array.isArray(n) ? n.map(stripDirectives) : n && typeof n === "object" ? Object.fromEntries(Object.entries(n).filter(([k]) => k !== "$data" && k !== "$when").map(([k, v]) => [k, stripDirectives(v)])) : n;
const errs = () => JSON.stringify(validate.errors?.slice(0, 4));

test("every card template is Adaptive Cards 1.5 and validates against the vendored schema", () => {
  assert.ok(files.length >= 7);
  for (const f of files) {
    const c = load(f);
    assert.equal(c.version, "1.5", f);
    assert.equal(c.$schema, "http://adaptivecards.io/schemas/adaptive-card.json", f);
    assert.ok(validate(stripDirectives(c)), `${f}: ${errs()}`);
  }
});

test("every card referenced by a function exists", () => {
  for (const f of fns) if (f.card) assert.ok(files.includes(f.card.file), f.card.file);
});

test("the templating step: bindings, repeat, when, comparisons", () => {
  const tpl = { type: "AdaptiveCard", body: [
    { type: "TextBlock", text: "${n} items, ${if(ok, 'yes', 'no')}" },
    { type: "TextBlock", $data: "${rows}", text: "${$index}:${name}" },
    { type: "TextBlock", $when: "${n > 5}", text: "big" },
    { type: "TextBlock", $when: "${n == 2 && ok == true}", text: "both" },
    { type: "TextBlock", text: "${formatNumber(amt, 2)} ${length(rows)}" }] };
  const out = renderCard(tpl, { n: 2, ok: true, rows: [{ name: "a" }, { name: "b" }], amt: 3 });
  assert.deepEqual(out.body.map((b: any) => b.text), ["2 items, yes", "0:a", "1:b", "both", "3.00 2"]);
});

const t = await makeApp();
after(() => t.close());
const G = (p: string, as = "jordan") => t.call("GET", p, { as });
const P = (p: string, body: unknown, key: string, as = "jordan") => t.call("POST", p, { as, body, headers: { "idempotency-key": key } });
const bad = { matter_id: "M-0412", work_date: "2026-11-13", hours: 3.5, narrative: "Reviewed contract; drafted email to client; call with opposing counsel re: extension" };
const sources: Record<string, () => Promise<any>> = {
  "matter-summary.json": () => G("/matters/M-0412"),
  "matter-list.json": () => G("/matters?query=halvorsen"),
  "deadline-list.json": () => G("/matters/M-0412/deadlines?due_within_days=14"),
  "check-result.json": () => t.call("POST", "/time-entries/check", { body: { ...bad, narrative: bad.narrative + "; traveled to courthouse" } }),
  "time-entry-recorded.json": () => P("/time-entries", { ...bad, hours: 1.2, narrative: "Traveled to courthouse for hearing on motion" }, "cards-test-te01"),
  "hold-status.json": () => G("/matters/M-0412/lit-holds"),
  "hold-issued.json": () => P("/matters/M-0388/lit-holds", { title: "Cedar Ridge project documents", scope_description: "All Cedar Ridge project documents and communications.", custodians: [{ name: "Pat Quill", email: "pat.quill@halvorsen-builders.example", role: "Project engineer" }] }, "cards-test-hold1"),
  "hold-reminders.json": () => P("/lit-holds/H-1001/acknowledge-reminders", {}, "cards-test-rem01")
};

test("every template merged with a real response renders a valid Adaptive Card with no leftover bindings", async () => {
  assert.deepEqual(Object.keys(sources).sort(), [...files].sort());
  for (const f of files) {
    const r = await sources[f]();
    assert.ok(r.status < 300, `${f} source call ${r.status}`);
    const card = renderCard(load(f), r.body);
    const text = JSON.stringify(card);
    assert.ok(!text.includes("${"), `${f} has unresolved binding: ${text.match(/.{30}\$\{.{30}/)?.[0]}`);
    assert.ok(!text.includes('"$data"') && !text.includes('"$when"'), f);
    assert.ok(validate(card), `${f}: ${errs()}`);
  }
});

test("rendered cards carry the real data: deadline date, who computed it, violation rule text", async () => {
  const dl = JSON.stringify(renderCard(load("deadline-list.json"), (await G("/matters/M-0412/deadlines")).body));
  assert.ok(dl.includes("2026-11-17") && dl.includes("docketing: Renata Okafor (Docketing)"));
  const ck = JSON.stringify(renderCard(load("check-result.json"), (await t.call("POST", "/time-entries/check", { body: bad })).body));
  assert.ok(ck.includes("NOT ALLOWED: BLOCK_BILLING (OCG 4.1)") && ck.includes("Block billing, meaning several tasks combined"));
  assert.ok(ck.includes("Cannot be recorded as written"));
  const ok = JSON.stringify(renderCard(load("check-result.json"), (await t.call("POST", "/time-entries/check", { body: { ...bad, hours: 0.8, narrative: "Reviewed project schedule updates to identify owner-caused delay" } })).body));
  assert.ok(ok.includes("No rule violations"));
});

test("the committed demo cards (real data, from npm run demo) validate against the schema", () => {
  const demo = new URL("../demo/cards/", import.meta.url);
  const out = readdirSync(demo).filter((f) => f.endsWith(".json"));
  assert.ok(out.length >= 8, "run npm run demo first");
  for (const f of out) {
    const c = JSON.parse(readFileSync(new URL(f, demo), "utf8"));
    assert.ok(validate(c), `${f}: ${errs()}`);
    assert.ok(!JSON.stringify(c).includes("${"), f);
  }
});
