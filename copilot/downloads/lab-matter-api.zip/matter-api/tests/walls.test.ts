import { test, after } from "node:test";
import assert from "node:assert/strict";
import { makeApp, validateResponse } from "./helpers.ts";

const t = await makeApp();
after(() => t.close());
const WALL = "This matter is behind an ethical wall. Contact the General Counsel's office.";
const audit = (action = "wall.denied") => t.db.prepare("SELECT * FROM audit_log WHERE action = ? ORDER BY id").all(action) as any[];

test("walled user gets 403 with a relayable body and an audit row on matter read", async () => {
  const r = await t.call("GET", "/matters/M-0421", { as: "marcus" });
  assert.equal(r.status, 403);
  assert.match(r.contentType, /application\/problem\+json/);
  assert.equal(r.body.detail, WALL);
  assert.ok(r.body.type.endsWith("/ethical-wall"));
  assert.deepEqual(validateResponse("GET", "/matters/{matter_id}", 403, r.body), []);
  const rows = audit();
  assert.equal(rows.length, 1);
  assert.equal(rows[0].user_id, "u-marcus");
  assert.equal(rows[0].matter_id, "M-0421");
  assert.equal(rows[0].outcome, "denied");
});

test("every route that touches the walled matter returns 403 and is audited", async () => {
  const before = audit().length;
  const calls: [string, string, unknown?][] = [
    ["GET", "/matters/M-0421"], ["GET", "/matters/TG-2026-0421"], ["GET", "/matters/M-0421/deadlines"], ["GET", "/matters/M-0421/docket"], ["GET", "/matters/M-0421/lit-holds"],
    ["POST", "/time-entries/check", { matter_id: "M-0421", work_date: "2026-11-13", hours: 1, narrative: "Reviewed hotline report and committee minutes" }],
    ["POST", "/time-entries", { matter_id: "M-0421", work_date: "2026-11-13", hours: 1, narrative: "Reviewed hotline report and committee minutes" }],
    ["POST", "/matters/M-0421/lit-holds", { title: "Hotline records", scope_description: "All hotline records and minutes.", custodians: [{ name: "A B", email: "a.b@pelicanbay.example" }] }]
  ];
  for (const [m, p, body] of calls) {
    const r = await t.call(m, p, { as: "marcus", body, headers: { "idempotency-key": "wall-test-" + p.length } });
    assert.equal(r.status, 403, `${m} ${p}`);
    assert.equal(r.body.detail, WALL);
  }
  assert.equal(audit().length - before, calls.length);
});

test("walled invalid body still gets 403 (the wall runs before validation)", async () => {
  const r = await t.call("POST", "/time-entries/check", { as: "sofia", body: { matter_id: "M-0421" } });
  assert.equal(r.status, 403);
});

test("search omits the walled matter for excluded users and shows it to others", async () => {
  const walled = await t.call("GET", "/matters?query=whistleblower", { as: "marcus" });
  assert.equal(walled.body.total, 0);
  const all = await t.call("GET", "/matters", { as: "marcus" });
  assert.equal(all.body.matters.some((m: any) => m.id === "M-0421"), false);
  assert.equal(all.body.total, 11);
  const allowed = await t.call("GET", "/matters?query=whistleblower", { as: "priya" });
  assert.equal(allowed.body.total, 1);
  assert.equal((await t.call("GET", "/matters", { as: "priya" })).body.total, 12);
});

test("non-excluded users, including the General Counsel, can read the matter", async () => {
  for (const as of ["priya", "lena", "elaine"]) assert.equal((await t.call("GET", "/matters/M-0421", { as })).status, 200, as);
});

test("a walled hold cannot be reminded through the hold route either", async () => {
  // Create a hold on the walled matter as an allowed user, then try to remind as an excluded user.
  const made = await t.call("POST", "/matters/M-0421/lit-holds", { as: "priya", headers: { "idempotency-key": "wall-hold-0001" }, body: { title: "Hotline records", scope_description: "All hotline records and minutes.", custodians: [{ name: "A B", email: "a.b@pelicanbay.example" }] } });
  assert.equal(made.status, 201);
  const r = await t.call("POST", `/lit-holds/${made.body.id}/acknowledge-reminders`, { as: "marcus", headers: { "idempotency-key": "wall-hold-0002" }, body: {} });
  assert.equal(r.status, 403);
  assert.equal(r.body.detail, WALL);
  assert.equal((t.db.prepare("SELECT COUNT(*) AS n FROM hold_custodians WHERE hold_id = ? AND reminder_count > 0").get(made.body.id) as any).n, 0);
});

test("denied attempts write nothing else", async () => {
  assert.equal((t.db.prepare("SELECT COUNT(*) AS n FROM time_entries WHERE matter_id = 'M-0421'").get() as any).n, 3);
});
