import { Ajv } from "ajv";
import addFormats from "ajv-formats";
import { createApp } from "../src/server.ts";
import { buildOpenApi } from "../src/openapi.ts";

export const NOW = new Date("2026-11-13T17:00:00Z");

export async function makeApp(now: () => Date = () => NOW) {
  const app = createApp({ now });
  await new Promise<void>((r) => app.server.listen(0, "127.0.0.1", r));
  const port = (app.server.address() as { port: number }).port;
  async function call(method: string, path: string, opts: { as?: string; body?: unknown; headers?: Record<string, string>; noAuth?: boolean } = {}) {
    const headers: Record<string, string> = { "content-type": "application/json", ...opts.headers };
    if (!opts.noAuth) headers.authorization = `Bearer FAKE-DEMO-TOKEN-${opts.as ?? "jordan"}`;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers, body: opts.body === undefined ? undefined : JSON.stringify(opts.body) });
    const text = await res.text();
    return { status: res.status, headers: res.headers, body: text ? JSON.parse(text) : undefined, contentType: res.headers.get("content-type") ?? "" };
  }
  return { app, db: app.db, call, close: () => new Promise<void>((r) => { app.server.close(() => r()); app.server.closeAllConnections(); }) };
}

// Validate real responses against the generated OpenAPI schemas.
const spec = buildOpenApi() as any;
const ajv = new Ajv({ strict: false, allErrors: true });
(addFormats as any).default ? (addFormats as any).default(ajv) : (addFormats as any)(ajv);
export function validateResponse(method: string, path: string, status: number, body: unknown): string[] {
  const op = spec.paths[path]?.[method.toLowerCase()];
  if (!op) return [`no OpenAPI operation for ${method} ${path}`];
  const resp = op.responses[String(status)];
  if (!resp) return [`status ${status} is not documented for ${method} ${path}`];
  const media = resp.content?.["application/json"] ?? resp.content?.["application/problem+json"];
  const v = ajv.compile({ ...media.schema, components: spec.components });
  return v(body) ? [] : (v.errors ?? []).map((e) => `${e.instancePath} ${e.message}`);
}
