import { test, after } from "node:test";
import assert from "node:assert/strict";
import { makeApp, validateResponse } from "./helpers.ts";

const t = await makeApp();
after(() => t.close());
const ok = (method: string, tmpl: string, r: { status: number; body: unknown }) => assert.deepEqual(validateResponse(method, tmpl, r.status, r.body), [], `${method} ${tmpl} response does not match openapi`);

test("GET /me resolves the caller from the bearer token", async () => {
  const r = await t.call("GET", "/me", { as: "jordan" });
  assert.equal(r.status, 200); ok("GET", "/me", r);
  assert.equal(r.body.name, "Jordan Reyes");
});

test("requests without a valid token get 401 problem+json", async () => {
  const none = await t.call("GET", "/me", { noAuth: true });
  assert.equal(none.status, 401);
  assert.match(none.contentType, /application\/problem\+json/);
  assert.equal(none.body.status, 401);
  assert.ok(none.headers.get("www-authenticate"));
  const bad = await t.call("GET", "/matters", { headers: { authorization: "Bearer nope" }, noAuth: true });
  assert.equal(bad.status, 401);
});

test("search finds Halvorsen matters and carries next deadline as stored", async () => {
  const r = await t.call("GET", "/matters?query=halvorsen");
  assert.equal(r.status, 200); ok("GET", "/matters", r);
  assert.deepEqual(r.body.matters.map((m: any) => m.number), ["TG-2026-0388", "TG-2026-0412"]);
  const m = r.body.matters.find((x: any) => x.id === "M-0412");
  assert.equal(m.next_deadline.due_date, "2026-11-17");
  assert.equal(m.next_deadline.computed_by, "docketing");
});

test("search filters: client, status, mine", async () => {
  assert.equal((await t.call("GET", "/matters?client=Calloway")).body.total, 2);
  assert.equal((await t.call("GET", "/matters?status=closed")).body.total, 0);
  const mine = await t.call("GET", "/matters?mine=true", { as: "omar" });
  assert.deepEqual(mine.body.matters.map((m: any) => m.id).sort(), ["M-0119", "M-0803"]);
});

test("GET /matters/{id} returns summary, team, deadlines, WIP/AR (id or number)", async () => {
  const r = await t.call("GET", "/matters/M-0412");
  assert.equal(r.status, 200); ok("GET", "/matters/{matter_id}", r);
  assert.equal(r.body.client.name, "Halvorsen Pacific Builders, Inc.");
  assert.ok(r.body.team.length >= 3);
  assert.equal(r.body.totals.ar_amount, 128450);
  assert.ok(r.body.totals.wip_amount > 0);
  assert.ok(r.body.next_deadlines.every((d: any) => d.due_date >= "2026-11-13"));
  const byNumber = await t.call("GET", "/matters/TG-2026-0412");
  assert.equal(byNumber.body.id, "M-0412");
});

test("unknown matter is 404 problem+json", async () => {
  const r = await t.call("GET", "/matters/M-9999");
  assert.equal(r.status, 404); assert.match(r.contentType, /problem\+json/); ok("GET", "/matters/{matter_id}", r);
});

test("deadlines: dates are returned exactly as stored, flagged computed_by docketing, window filters only", async () => {
  const all = await t.call("GET", "/matters/M-0412/deadlines");
  assert.equal(all.status, 200); ok("GET", "/matters/{matter_id}/deadlines", all);
  assert.deepEqual(all.body.deadlines.map((d: any) => d.due_date), ["2026-11-17", "2026-11-20", "2026-12-04", "2026-12-18"]);
  assert.ok(all.body.deadlines.every((d: any) => d.computed_by === "docketing" && d.docketed_by));
  const week = await t.call("GET", "/matters/M-0412/deadlines?due_within_days=7");
  assert.deepEqual(week.body.deadlines.map((d: any) => d.due_date), ["2026-11-17", "2026-11-20"]);
  assert.deepEqual(week.body.window, { from: "2026-11-13", to: "2026-11-20" });
  assert.match(week.body.note, /not recompute/);
});

test("docket lists every entry, newest first", async () => {
  const r = await t.call("GET", "/matters/M-0412/docket");
  assert.equal(r.status, 200); ok("GET", "/matters/{matter_id}/docket", r);
  assert.equal(r.body.count, 7);
  assert.equal(r.body.entries[0].entry_date >= r.body.entries.at(-1).entry_date, true);
});

test("billing rules quote the guideline text", async () => {
  const r = await t.call("GET", "/clients/C-100/billing-rules");
  assert.equal(r.status, 200); ok("GET", "/clients/{client_id}/billing-rules", r);
  const bb = r.body.rules.find((x: any) => x.code === "BLOCK_BILLING");
  assert.equal(bb.text, "Each task must be recorded as a separate time entry. Block billing, meaning several tasks combined in one entry, is not permitted.");
  assert.equal((await t.call("GET", "/clients/C-999/billing-rules")).status, 404);
});

test("check endpoint is a dry run: nothing is written", async () => {
  const before = (t.db.prepare("SELECT COUNT(*) AS n FROM time_entries").get() as any).n;
  const r = await t.call("POST", "/time-entries/check", { body: { matter_id: "M-0412", work_date: "2026-11-13", hours: 0.8, narrative: "Reviewed project schedule updates to identify owner-caused delay" } });
  assert.equal(r.status, 200); ok("POST", "/time-entries/check", r);
  assert.equal(r.body.ok, true);
  assert.equal((t.db.prepare("SELECT COUNT(*) AS n FROM time_entries").get() as any).n, before);
});

test("write endpoints record and return 201 matching the schema", async () => {
  const r = await t.call("POST", "/time-entries", { headers: { "idempotency-key": "routes-test-0001" }, body: { matter_id: "M-0412", work_date: "2026-11-13", hours: 0.8, narrative: "Reviewed project schedule updates to identify owner-caused delay" } });
  assert.equal(r.status, 201); ok("POST", "/time-entries", r);
  assert.match(r.body.time_entry.id, /^TE-\d{4}$/);
  const hold = await t.call("POST", "/matters/M-0388/lit-holds", { headers: { "idempotency-key": "routes-test-hold1" }, body: { title: "Cedar Ridge project documents", scope_description: "All Cedar Ridge project documents and communications.", custodians: [{ name: "Pat Quill", email: "pat.quill@halvorsen-builders.example", role: "Project engineer" }] } });
  assert.equal(hold.status, 201); ok("POST", "/matters/{matter_id}/lit-holds", hold);
  assert.equal(hold.body.id, "H-1003");
  assert.match(hold.body.notice_text, /Attorney review|attorney must review/i);
  assert.equal(hold.body.pending_count, 1);
  const rem = await t.call("POST", `/lit-holds/H-1001/acknowledge-reminders`, { headers: { "idempotency-key": "routes-test-rem01" }, body: {} });
  assert.equal(rem.status, 200); ok("POST", "/lit-holds/{hold_id}/acknowledge-reminders", rem);
  assert.deepEqual(rem.body.reminded.map((x: any) => x.name), ["Bennett Okoye", "Maribel Santos"]);
  assert.equal(rem.body.reminded[0].reminder_count, 3);
  const list = await t.call("GET", "/matters/M-0412/lit-holds");
  assert.equal(list.status, 200); ok("GET", "/matters/{matter_id}/lit-holds", list);
  assert.equal(list.body.outstanding_total, 2);
});

test("validation errors are RFC 9457 problem+json with pointers", async () => {
  const r = await t.call("POST", "/time-entries/check", { body: { matter_id: "M-0412", work_date: "13/11/2026", hours: -1 } });
  assert.equal(r.status, 400); assert.match(r.contentType, /problem\+json/); ok("POST", "/time-entries/check", r);
  assert.ok(r.body.type.startsWith("https://"));
  assert.ok(r.body.errors.some((e: any) => e.pointer === "body/work_date"));
  assert.ok(r.body.errors.some((e: any) => e.pointer === "body/narrative" || /narrative/.test(e.message)));
  const q = await t.call("GET", "/matters/M-0412/deadlines?due_within_days=abc");
  assert.equal(q.status, 400);
  const bad = await t.call("POST", "/time-entries/check", { body: undefined, headers: {} });
  assert.equal(bad.status, 400);
});

test("hard violations are rejected on write with the rule quoted", async () => {
  const r = await t.call("POST", "/time-entries", { headers: { "idempotency-key": "routes-test-bad01" }, body: { matter_id: "M-0412", work_date: "2026-11-13", hours: 3.5, narrative: "Reviewed contract; drafted email to client; call with opposing counsel re: extension" } });
  assert.equal(r.status, 422); assert.match(r.contentType, /problem\+json/); ok("POST", "/time-entries", r);
  assert.equal(r.body.violations[0].code, "BLOCK_BILLING");
  assert.match(r.body.violations[0].rule_text, /Block billing/);
  const rows = t.db.prepare("SELECT * FROM audit_log WHERE action = 'time_entry.rejected'").all();
  assert.equal(rows.length, 1);
});

test("unknown route and wrong method", async () => {
  assert.equal((await t.call("GET", "/nope")).status, 404);
  assert.equal((await t.call("DELETE", "/me")).status, 405);
});
