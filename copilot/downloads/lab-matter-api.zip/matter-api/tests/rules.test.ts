import { test } from "node:test";
import assert from "node:assert/strict";
import { checkEntry, splitTasks, type Rule } from "../src/rules.ts";

const R = (code: string, severity: Rule["severity"], params: Rule["params"] = {}, text = `text for ${code}`): Rule => ({ id: `R-${code}`, client_id: "C", code, severity, guideline_ref: "OCG 1", text, params });
const ALL = [R("BLOCK_BILLING", "hard"), R("INCREMENT", "hard", { increment: 0.1 }), R("CLERICAL", "hard"), R("TRAVEL", "adjust", { factor: 0.5 }), R("VAGUE", "hard", { min_words: 5 }), R("MAX_ENTRY", "warn", { max_hours: 8 })];
const codes = (n: string, h: number, rules = ALL) => checkEntry(rules, { narrative: n, hours: h }).violations.map((v) => v.code);

test("clean entry passes", () => {
  const r = checkEntry(ALL, { narrative: "Reviewed project schedule updates to identify owner-caused delay", hours: 0.8 });
  assert.equal(r.ok, true); assert.equal(r.can_post, true); assert.equal(r.billable_hours, 0.8); assert.deepEqual(r.violations, []);
});

test("block billing: semicolons and verb-led clauses", () => {
  const n = "Reviewed contract; drafted email to client; call with opposing counsel re: extension";
  assert.deepEqual(splitTasks(n), ["Reviewed contract", "drafted email to client", "call with opposing counsel re: extension"]);
  const r = checkEntry(ALL, { narrative: n, hours: 3.5 });
  assert.deepEqual(r.violations.map((v) => v.code), ["BLOCK_BILLING"]);
  assert.equal(r.can_post, false);
  assert.equal(r.suggested_splits.length, 3);
  assert.deepEqual(codes("Reviewed lease and drafted amendment to the lease", 1.0), ["BLOCK_BILLING"]);
  assert.deepEqual(codes("Drafted opposition to motion for summary adjudication, statement of disputed facts", 2.0), []);
});

test("violation quotes the rule text verbatim", () => {
  const rules = [R("BLOCK_BILLING", "hard", {}, "Each task must be recorded as a separate time entry.")];
  assert.equal(checkEntry(rules, { narrative: "Reviewed a; drafted b", hours: 1 }).violations[0].rule_text, "Each task must be recorded as a separate time entry.");
});

test("increment: 0.1 and 0.25 grids", () => {
  assert.deepEqual(codes("Reviewed project schedule updates for delay analysis", 0.75), ["INCREMENT"]);
  assert.deepEqual(codes("Reviewed project schedule updates for delay analysis", 0.7), []);
  assert.deepEqual(codes("Reviewed project schedule updates for delay analysis", 1.3, [R("INCREMENT", "hard", { increment: 0.25 })]), ["INCREMENT"]);
  assert.deepEqual(codes("Reviewed project schedule updates for delay analysis", 1.25, [R("INCREMENT", "hard", { increment: 0.25 })]), []);
  assert.deepEqual(codes("Reviewed project schedule updates for delay analysis", 0.3), []); // float safe
});

test("clerical tasks are rejected", () => {
  for (const n of ["Scanned and organized exhibits for production binder", "Photocopied deposition exhibits for the hearing", "Calendared hearing dates and scheduled a call with client", "Bates stamped production set one"])
    assert.ok(codes(n, 1.0).includes("CLERICAL"), n);
  assert.deepEqual(codes("Analyzed daily reports for weather delay entries", 1.0), []);
});

test("travel adjusts billable hours at the rule's factor and does not block", () => {
  const r = checkEntry(ALL, { narrative: "Traveled to courthouse for hearing on motion", hours: 1.2 });
  assert.equal(r.billable_hours, 0.6); assert.equal(r.can_post, true); assert.equal(r.ok, false);
  assert.equal(r.violations[0].severity, "adjust");
  assert.equal(checkEntry([R("TRAVEL", "adjust", { factor: 0 })], { narrative: "Drove to the agency office for the board meeting", hours: 1.0 }).billable_hours, 0);
});

test("vague narratives: generic phrase or too few words", () => {
  assert.deepEqual(codes("Attention to file", 0.5), ["VAGUE"]);
  assert.deepEqual(codes("Reviewed documents", 0.5), ["VAGUE"]);
  assert.deepEqual(codes("Worked on matter for the client today", 0.5), ["VAGUE"]);
});

test("max entry is a warning, still postable", () => {
  const r = checkEntry(ALL, { narrative: "Analyzed store-level time records produced by client", hours: 9 });
  assert.deepEqual(r.violations.map((v) => [v.code, v.severity]), [["MAX_ENTRY", "warn"]]);
  assert.equal(r.can_post, true);
});

test("only the client's own rules apply", () => {
  assert.deepEqual(codes("Scanned and filed documents", 0.75, [R("BLOCK_BILLING", "hard")]), []);
});
