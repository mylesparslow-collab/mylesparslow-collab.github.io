import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import YAML from "yaml";
import { Validator } from "@seriousme/openapi-schema-validator";
import { routes } from "../src/routes.ts";
import { buildOpenApi } from "../src/openapi.ts";
import { openApiYaml } from "../scripts/build.ts";
import { agents } from "../scripts/plugin-def.ts";

const file = (p: string) => readFileSync(new URL(`../${p}`, import.meta.url), "utf8");

test("openapi.yaml is exactly what the routes generate (no drift)", () => {
  assert.equal(file("openapi.yaml"), openApiYaml(), "openapi.yaml is stale: run npm run build");
});

test("each agent's pruned spec is exactly what the routes generate", () => {
  for (const a of agents) assert.equal(file(`agents/${a.slug}/appPackage/apiSpecificationFile/openapi.yaml`), openApiYaml(a.fns), `${a.slug} spec is stale: run npm run build`);
});

test("openapi.yaml passes a real OpenAPI 3.0 validator (root and every agent copy)", async () => {
  for (const p of ["openapi.yaml", ...agents.map((a) => `agents/${a.slug}/appPackage/apiSpecificationFile/openapi.yaml`)]) {
    const v = new Validator();
    const r = await v.validate(YAML.parse(file(p)));
    assert.equal(r.valid, true, `${p}: ${JSON.stringify(r.errors)}`);
    assert.equal(v.version, "3.0");
  }
});

test("every route in the server is in the spec and every spec operation is a route (method, path, operationId)", () => {
  const spec = YAML.parse(file("openapi.yaml"));
  const fromSpec = new Set<string>(); const fromRoutes = new Set<string>();
  for (const [p, item] of Object.entries<any>(spec.paths)) for (const [m, op] of Object.entries<any>(item)) fromSpec.add(`${m.toUpperCase()} ${p} ${op.operationId}`);
  for (const r of routes) fromRoutes.add(`${r.method} ${r.path} ${r.operationId}`);
  assert.deepEqual([...fromSpec].sort(), [...fromRoutes].sort());
  assert.equal(new Set(routes.map((r) => r.operationId)).size, routes.length, "operationIds are unique");
});

test("every operation documents its auth, success, 401/403/404 and problem+json errors", () => {
  const spec = buildOpenApi() as any;
  for (const item of Object.values<any>(spec.paths)) for (const op of Object.values<any>(item)) {
    assert.ok(op.security?.length, op.operationId);
    for (const code of ["401", "403", "404"]) assert.ok(op.responses[code]?.content?.["application/problem+json"], `${op.operationId} ${code}`);
  }
});

test("every write operation takes an optional Idempotency-Key header", () => {
  for (const r of routes.filter((x) => x.write)) {
    const op = (buildOpenApi() as any).paths[r.path][r.method.toLowerCase()];
    assert.ok(op.parameters.some((p: any) => p.name === "Idempotency-Key" && p.in === "header"), r.operationId);
  }
});
