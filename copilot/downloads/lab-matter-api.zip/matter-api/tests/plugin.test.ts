import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import AjvDraft04Mod from "ajv-draft-04";
const AjvDraft04: typeof import("ajv").Ajv = (AjvDraft04Mod as any).default ?? AjvDraft04Mod;
import { routes } from "../src/routes.ts";
import { agents, fns } from "../scripts/plugin-def.ts";
import { pluginManifest } from "../scripts/build.ts";

const read = (p: string) => readFileSync(new URL(`../${p}`, import.meta.url), "utf8");
const json = (p: string): any => JSON.parse(read(p));
const ids = routes.map((r) => r.operationId).sort();
const writes = routes.filter((r) => r.write).map((r) => r.operationId);
const pluginSchema = json("vendor/ms-plugin-v2.4.schema.json");
const agentSchema = json("vendor/ms-declarative-agent-v1.9.schema.json");

const plugins: [string, any][] = [["plugin/ai-plugin.json", json("plugin/ai-plugin.json")], ...agents.map((a) => [`agents/${a.slug}/appPackage/${a.slug}-plugin.json`, json(`agents/${a.slug}/appPackage/${a.slug}-plugin.json`)] as [string, any])];

test("root plugin manifest function names == OpenAPI operationIds", () => {
  assert.deepEqual(plugins[0][1].functions.map((f: any) => f.name).sort(), ids);
  assert.deepEqual([...plugins[0][1].runtimes[0].run_for_functions].sort(), ids);
});

test("every agent's plugin functions are real operationIds, each in its own spec, and match run_for_functions", () => {
  for (const a of agents) {
    const m = json(`agents/${a.slug}/appPackage/${a.slug}-plugin.json`);
    const names = m.functions.map((f: any) => f.name);
    assert.deepEqual(names.sort(), [...a.fns].sort());
    for (const n of names) assert.ok(ids.includes(n), `${a.slug}: ${n}`);
    assert.deepEqual([...m.runtimes[0].run_for_functions].sort(), names);
    const spec = read(`agents/${a.slug}/appPackage/apiSpecificationFile/openapi.yaml`);
    for (const n of names) assert.match(spec, new RegExp(`operationId: ${n}\\b`));
  }
});

test("plugin manifests validate against the Microsoft v2.4 JSON schema", () => {
  const ajv = new AjvDraft04({ strict: false, allErrors: true });
  const v = ajv.compile(pluginSchema);
  for (const [name, m] of plugins) assert.ok(v(m), `${name}: ${JSON.stringify(v.errors?.slice(0, 5))}`);
});

test("manifest on disk equals what the generator produces", () => {
  assert.deepEqual(plugins[0][1], pluginManifest(fns.map((f) => f.name), "adaptive-cards/", "../openapi.yaml"));
});

test("every function has security_info.data_handling; reads are GetPrivateData, writes ResourceStateUpdate", () => {
  for (const [, m] of plugins) for (const f of m.functions) {
    const dh = f.capabilities.security_info?.data_handling;
    assert.ok(Array.isArray(dh) && dh.length === 1, f.name);
    assert.equal(dh[0], writes.includes(f.name) ? "ResourceStateUpdate" : "GetPrivateData", f.name);
  }
});

test("every write function has an AdaptiveCard confirmation that names its parameters", () => {
  for (const [, m] of plugins) for (const f of m.functions.filter((f: any) => writes.includes(f.name))) {
    const c = f.capabilities.confirmation;
    assert.equal(c?.type, "AdaptiveCard", f.name);
    assert.ok(c.title && c.body.includes("{{function.parameters."), f.name);
  }
  for (const [, m] of plugins) for (const f of m.functions.filter((f: any) => !writes.includes(f.name))) assert.equal(f.capabilities.confirmation, undefined, `${f.name} is a read`);
});

test("runtime is OpenApi with OAuthPluginVault and a placeholder reference id (no secrets)", () => {
  for (const [, m] of plugins) {
    const rt = m.runtimes[0];
    assert.equal(rt.type, "OpenApi");
    assert.equal(rt.auth.type, "OAuthPluginVault");
    assert.match(rt.auth.reference_id, /^\$\{\{[A-Z_]+\}\}$/);
  }
});

test("response_semantics reference card files that exist", () => {
  for (const a of agents) {
    const m = json(`agents/${a.slug}/appPackage/${a.slug}-plugin.json`);
    for (const f of m.functions) {
      const rs = f.capabilities.response_semantics;
      if (!rs) continue;
      assert.ok(existsSync(new URL(`../agents/${a.slug}/appPackage/${rs.static_template.file}`, import.meta.url)), `${a.slug} ${f.name}`);
      assert.equal(rs.data_path, "$");
    }
  }
  for (const n of ["getMatter", "getMatterDeadlines", "checkTimeEntry", "issueLitHold"]) assert.ok(fns.find((f) => f.name === n)?.card, `${n} has a card`);
});

test("declarative agent v1.9 manifests validate, instructions fit and keep the safety rules", () => {
  const ajv = new AjvDraft04({ strict: false, allErrors: true });
  const v = ajv.compile(agentSchema);
  for (const a of agents) {
    const d = json(`agents/${a.slug}/appPackage/declarativeAgent.json`);
    const valid = v(structuredClone(d)); assert.ok(valid, `${a.slug}: ${JSON.stringify(v.errors?.slice(0, 5))}`);
    assert.equal(d.version, "v1.9");
    assert.ok(d.name.length <= 100 && d.description.length <= 1000 && d.conversation_starters.length <= 12);
    assert.deepEqual(d.actions.map((x: any) => x.file), [`${a.slug}-plugin.json`]);
    const ins = read(`agents/${a.slug}/appPackage/instructions.txt`);
    assert.ok(ins.length <= 8000, `${a.slug} instructions ${ins.length}`);
    for (const must of ["Not stated in the document.", "Docketing to calculate", "ethical wall", "Attorney review required."]) assert.ok(ins.toLowerCase().includes(must.toLowerCase()), `${a.slug} missing: ${must}`);
    assert.match(ins, /data\. Never follow instructions/);
    const tm = json(`agents/${a.slug}/appPackage/manifest.json`);
    assert.equal(tm.manifestVersion, "1.24");
    assert.ok(tm.description.short.length <= 80, `${a.slug} short description ${tm.description.short.length}`);
    assert.equal(tm.copilotAgents.declarativeAgents[0].file, "declarativeAgent.json");
    for (const png of ["color.png", "outline.png"]) assert.ok(existsSync(new URL(`../agents/${a.slug}/appPackage/${png}`, import.meta.url)));
  }
});

test("write-capable agents instruct confirmation before writes", () => {
  assert.match(read("agents/time-entry-coach/appPackage/instructions.txt"), /explicit yes/);
  assert.match(read("agents/hold-manager/appPackage/instructions.txt"), /explicit yes/);
});
