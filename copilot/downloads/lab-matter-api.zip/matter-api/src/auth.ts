// Authentication. The demo maps a seeded fake bearer token to a seeded user.
// Production: replace `demoAuthenticator` with an Entra ID access-token validator
// (verify signature against the tenant JWKS, check iss/aud/exp, then map the `oid`
// claim to users.entra_oid). The rest of the server only ever sees an `AuthUser`.
import type { DatabaseSync } from "node:sqlite";
import { HttpProblem } from "./problem.ts";

export interface AuthUser { id: string; name: string; email: string; title: string; role: string; practice_group: string; rate_cents: number }

export function demoAuthenticator(db: DatabaseSync) {
  const q = db.prepare("SELECT u.* FROM demo_tokens t JOIN users u ON u.id = t.user_id WHERE t.token = ?");
  return (authorization: string | undefined): AuthUser => {
    const m = /^Bearer\s+(\S+)$/i.exec(authorization ?? "");
    const row = m ? (q.get(m[1]) as unknown as AuthUser | undefined) : undefined;
    if (!row) {
      throw new HttpProblem(401, "unauthorized", "Authentication required", "A valid bearer token is required.", { www_authenticate: 'Bearer realm="matter-desk"' });
    }
    return row;
  };
}
