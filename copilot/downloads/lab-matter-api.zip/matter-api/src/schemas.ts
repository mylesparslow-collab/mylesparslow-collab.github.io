// Single source of truth for request/response shapes. Used at runtime to validate requests,
// to generate openapi.yaml, and in tests to validate responses.
type S = Record<string, unknown>;
const str = (description: string, extra: S = {}): S => ({ type: "string", description, ...extra });
const nstr = (description: string, extra: S = {}): S => ({ type: "string", nullable: true, description, ...extra });
const num = (description: string, extra: S = {}): S => ({ type: "number", description, ...extra });
const int = (description: string, extra: S = {}): S => ({ type: "integer", description, ...extra });
const bool = (description: string): S => ({ type: "boolean", description });
const date = (description: string, nullable = false): S => ({ type: "string", format: "date", description, ...(nullable ? { nullable: true } : {}) });
const arr = (items: S, extra: S = {}): S => ({ type: "array", items, ...extra });
const ref = (n: string): S => ({ $ref: `#/components/schemas/${n}` });
const obj = (properties: Record<string, S>, required: string[] = Object.keys(properties), extra: S = {}): S => ({ type: "object", properties, ...(required.length ? { required } : {}), additionalProperties: false, ...extra });

const matterRef = obj({ id: str("Matter id."), number: str("Matter number."), name: str("Matter name.") });

export const components: Record<string, S> = {
  Problem: obj({
    type: str("URI identifying the problem type."), title: str("Short summary."), status: int("HTTP status."), detail: str("Explanation safe to relay to the user."), instance: str("The request path."),
    errors: arr(obj({ pointer: str("Where."), message: str("What is wrong.") })),
    violations: arr(ref("Violation"))
  }, ["type", "title", "status", "detail", "instance"], { additionalProperties: true }),
  Me: obj({ id: str("User id."), name: str("Full name."), email: str("Email."), title: str("Job title."), role: str("Role.", { enum: ["partner", "associate", "paralegal", "docketing", "general_counsel"] }), practice_group: str("Practice group.") }),
  DocketEntry: obj({
    id: str("Docket entry id."), matter_id: str("Matter id."), entry_date: date("Date the entry was made."), entry_type: str("Kind of entry.", { enum: ["filing", "order", "hearing", "deadline"] }),
    description: str("What the entry is."), due_date: date("The date exactly as stored. Never recomputed by this API.", true), status: str("Entry status.", { enum: ["open", "done"] }),
    computed_by: nstr("Who computed or set the date. Always 'docketing' for dated entries.", { enum: ["docketing", null] }), docketed_by: nstr("Name of the docketing person."),
    date_basis: nstr("The stated basis for the date, as written by docketing."), source_ref: nstr("Source document reference.")
  }),
  MatterListItem: obj({ id: str("Matter id."), number: str("Matter number."), name: str("Matter name."), client_name: str("Client."), practice_area: str("Practice area."), status: str("Status."), responsible_attorney: str("Responsible attorney."), next_deadline: ref("DocketEntry") }, ["id", "number", "name", "client_name", "practice_area", "status", "responsible_attorney"]),
  MatterList: obj({ total: int("Number of matters returned."), matters: arr(ref("MatterListItem")) }),
  MatterSummary: obj({
    id: str("Matter id."), number: str("Matter number."), name: str("Matter name."), client: obj({ id: str("Client id."), name: str("Client name.") }), practice_area: str("Practice area."), status: str("Status."),
    opened_date: date("Date opened."), court: nstr("Court, if any."), description: str("Description."), responsible_attorney: obj({ id: str("User id."), name: str("Name.") }),
    team: arr(obj({ id: str("User id."), name: str("Name."), role: str("Role on the matter.") })), next_deadlines: arr(ref("DocketEntry")),
    totals: obj({ currency: str("Currency."), wip_amount: num("Unbilled time at timekeeper rates."), wip_hours: num("Unbilled hours."), ar_amount: num("Open receivables."), ar_invoice_count: int("Invoices with a balance.") })
  }),
  DeadlineList: obj({ matter: matterRef, as_of: date("The server's current date."), window: { ...obj({ from: date("Window start."), to: date("Window end.") }), nullable: true }, note: str("Reminder that dates are shown as stored."), count: int("Deadlines returned."), deadlines: arr(ref("DocketEntry")) }),
  DocketList: obj({ matter: matterRef, count: int("Entries returned."), entries: arr(ref("DocketEntry")) }),
  Rule: obj({ id: str("Rule id."), code: str("Rule code.", { enum: ["BLOCK_BILLING", "INCREMENT", "CLERICAL", "TRAVEL", "VAGUE", "MAX_ENTRY"] }), severity: str("hard rejects, adjust changes billable hours, warn informs.", { enum: ["hard", "warn", "adjust"] }), guideline_ref: str("Section of the client's guidelines."), text: str("The rule text, quoted verbatim.") }),
  BillingRules: obj({ client: obj({ id: str("Client id."), name: str("Client name.") }), source: str("Where the rules come from."), rules: arr(ref("Rule")) }),
  TimeEntryDraft: obj({ matter_id: str("Matter id or matter number.", { minLength: 1 }), work_date: date("Date the work was done."), hours: num("Hours worked.", { minimum: 0.1, maximum: 24 }), narrative: str("The time entry narrative.", { minLength: 1, maxLength: 1000 }) }),
  Violation: obj({ rule_id: str("Rule id."), code: str("Rule code."), severity: str("Severity.", { enum: ["hard", "warn", "adjust"] }), guideline_ref: str("Guideline section."), rule_text: str("The rule text, quoted verbatim."), message: str("What this entry did wrong."), matched_text: nstr("The text that triggered the rule.") }),
  TimeEntryCheck: obj({
    matter: matterRef, client: obj({ id: str("Client id."), name: str("Client name.") }), draft: obj({ work_date: date("Work date."), hours: num("Hours."), narrative: str("Narrative.") }),
    ok: bool("No violations of any kind."), can_post: bool("No hard violations; the entry can be recorded."), billable_hours: num("Hours after any adjustment rules."), violations: arr(ref("Violation")),
    suggested_splits: arr(str("One task."), { description: "When block billing is found, the narrative split into separate tasks. Hours are not allocated." }), rules_checked: int("Rules evaluated.")
  }),
  TimeEntry: obj({ id: str("Time entry id."), matter_id: str("Matter id."), user_id: str("Timekeeper."), work_date: date("Work date."), hours: num("Hours."), billable_hours: num("Billable hours."), narrative: str("Narrative."), status: str("Billing status.", { enum: ["unbilled", "billed"] }), recorded_at: str("When recorded.", { format: "date-time" }) }),
  TimeEntryResult: obj({ time_entry: ref("TimeEntry"), matter: matterRef, client: obj({ id: str("Client id."), name: str("Client name.") }), notes: arr(ref("Violation"), { description: "Non-blocking rule results (adjustments and warnings)." }) }),
  HoldRequest: obj({
    title: str("Short title for the hold.", { minLength: 3, maxLength: 200 }), scope_description: str("What must be preserved.", { minLength: 10, maxLength: 2000 }),
    custodians: arr(obj({ name: str("Custodian name.", { minLength: 1 }), email: str("Custodian email.", { format: "email" }), role: str("Custodian role.") }, ["name", "email"]), { minItems: 1, maxItems: 50 })
  }),
  Custodian: obj({ name: str("Name."), email: str("Email."), role: nstr("Role."), status: str("Acknowledgment status.", { enum: ["pending", "acknowledged"] }), acknowledged_at: nstr("When acknowledged.", { format: "date-time" }), reminder_count: int("Reminders sent."), last_reminded_at: nstr("Last reminder.", { format: "date-time" }) }),
  Hold: obj({
    id: str("Hold id."), matter: matterRef, title: str("Title."), scope_description: str("Scope."), issued_by: str("Issuer."), issued_at: str("Issued at.", { format: "date-time" }),
    pending_count: int("Custodians who have not acknowledged."), custodians: arr(ref("Custodian")), notice_text: str("The hold notice text."), distribution: str("How the notice was distributed.")
  }),
  HoldList: obj({ matter: matterRef, holds: arr(obj({ id: str("Hold id."), title: str("Title."), issued_by: str("Issuer."), issued_at: str("Issued at.", { format: "date-time" }), pending_count: int("Unacknowledged."), custodians: arr(ref("Custodian")) })), outstanding_total: int("Unacknowledged across all holds.") }),
  ReminderRequest: obj({ custodian_emails: arr(str("A custodian email.", { format: "email" }), { description: "Limit reminders to these custodians; omit to remind everyone who has not acknowledged." }) }, []),
  ReminderResult: obj({ hold_id: str("Hold id."), reminded: arr(obj({ name: str("Name."), email: str("Email."), reminder_count: int("Reminders sent, including this one.") })), already_acknowledged: arr(str("Email.")), distribution: str("How reminders were distributed.") })
};
