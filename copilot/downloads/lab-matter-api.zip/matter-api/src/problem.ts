// RFC 9457 problem details.
export const PROBLEM_BASE = "https://matterdesk.thornwoodgarza.example/problems/";
export const WALL_MESSAGE = "This matter is behind an ethical wall. Contact the General Counsel's office.";

export interface AuditNote {
  action: string;
  resource_type: string;
  resource_id: string | null;
  matter_id: string | null;
  outcome: string;
  detail?: unknown;
}

export class HttpProblem extends Error {
  status: number;
  slug: string;
  title: string;
  detail: string;
  ext: Record<string, unknown>;
  audit?: AuditNote;
  constructor(status: number, slug: string, title: string, detail: string, ext: Record<string, unknown> = {}, audit?: AuditNote) {
    super(detail);
    this.status = status;
    this.slug = slug;
    this.title = title;
    this.detail = detail;
    this.ext = ext;
    this.audit = audit;
  }
  toBody(instance: string) {
    return { type: PROBLEM_BASE + this.slug, title: this.title, status: this.status, detail: this.detail, instance, ...this.ext };
  }
}

export const notFound = (what: string) => new HttpProblem(404, "not-found", "Not found", `${what} was not found.`);
