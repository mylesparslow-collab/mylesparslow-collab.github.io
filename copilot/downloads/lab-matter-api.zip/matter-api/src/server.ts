import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { createHash } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { Ajv } from "ajv";
import addFormats from "ajv-formats";
import { openDb } from "./db.ts";
import { demoAuthenticator, type AuthUser } from "./auth.ts";
import { HttpProblem, WALL_MESSAGE, type AuditNote } from "./problem.ts";
import { canonicalMatterId, isWalledOff, routes, type Result, type RouteDef } from "./routes.ts";
import { components } from "./schemas.ts";

/** Derived idempotency keys (no Idempotency-Key header) only dedupe for this long. Explicit keys are kept for the life of the database. */
export const DERIVED_KEY_WINDOW_MS = 10 * 60 * 1000;

export interface AppOptions { db?: DatabaseSync; now?: () => Date }

const ajvBody = new Ajv({ strict: false, allErrors: true });
const ajvQuery = new Ajv({ strict: false, allErrors: true, coerceTypes: true });
addFormats.default ? (addFormats.default as any)(ajvBody) : (addFormats as any)(ajvBody);
addFormats.default ? (addFormats.default as any)(ajvQuery) : (addFormats as any)(ajvQuery);
const bodyValidators = new Map<string, ReturnType<Ajv["compile"]>>();
const queryValidators = new Map<string, ReturnType<Ajv["compile"]>>();
for (const r of routes) {
  if (r.requestBody) bodyValidators.set(r.operationId, ajvBody.compile({ $ref: `#/components/schemas/${r.requestBody}`, components: { schemas: components } }));
  const props = Object.fromEntries((r.query ?? []).map((q) => [q.name, q.schema]));
  queryValidators.set(r.operationId, ajvQuery.compile({ type: "object", properties: props }));
}

const compile = (path: string) => new RegExp("^" + path.replace(/\{(\w+)\}/g, "(?<$1>[^/]+)") + "/?$");
const matchers = routes.map((r) => ({ r, re: compile(r.path) }));

const canonical = (v: unknown): string => JSON.stringify(v, (_k, x) => (x && typeof x === "object" && !Array.isArray(x) ? Object.fromEntries(Object.entries(x).sort(([a], [b]) => a.localeCompare(b))) : x));
const sha = (s: string) => createHash("sha256").update(s).digest("hex");

interface Out { status: number; body: unknown; headers?: Record<string, string>; problem: boolean }

export function createApp(opts: AppOptions = {}) {
  const db = opts.db ?? openDb(process.env.DB_PATH || ":memory:");
  const now = opts.now ?? (() => (process.env.DEMO_NOW ? new Date(process.env.DEMO_NOW) : new Date()));
  const authenticate = demoAuthenticator(db);

  const writeAudit = (userId: string | null, a: AuditNote, key: string | null) =>
    db.prepare("INSERT INTO audit_log (ts, user_id, action, resource_type, resource_id, matter_id, outcome, detail, idempotency_key) VALUES (?,?,?,?,?,?,?,?,?)")
      .run(now().toISOString(), userId, a.action, a.resource_type, a.resource_id, a.matter_id, a.outcome, JSON.stringify(a.detail ?? null), key);

  async function readBody(req: IncomingMessage): Promise<unknown> {
    const chunks: Buffer[] = []; let size = 0;
    for await (const ch of req) {
      size += (ch as Buffer).length;
      if (size > 256_000) throw new HttpProblem(413, "payload-too-large", "Payload too large", "Request body is limited to 256 KB.");
      chunks.push(ch as Buffer);
    }
    const text = Buffer.concat(chunks).toString("utf8");
    if (!text.trim()) return undefined;
    try { return JSON.parse(text); } catch { throw new HttpProblem(400, "validation", "Invalid JSON", "The request body is not valid JSON."); }
  }

  async function dispatch(req: IncomingMessage): Promise<Out> {
    const url = new URL(req.url ?? "/", "http://localhost");
    const instance = url.pathname;
    let key: string | null = null; let user: AuthUser | null = null; let route: RouteDef | null = null;
    try {
      let params: Record<string, string> = {};
      let pathExists = false;
      for (const { r, re } of matchers) {
        const m = re.exec(url.pathname);
        if (!m) continue;
        pathExists = true;
        if (r.method === req.method) { route = r; params = { ...m.groups }; break; }
      }
      if (!route) throw pathExists ? new HttpProblem(405, "method-not-allowed", "Method not allowed", `${req.method} is not supported on ${instance}.`) : new HttpProblem(404, "not-found", "Not found", `No route ${instance}.`);
      user = authenticate(req.headers.authorization);
      const body = route.method === "POST" ? await readBody(req) : undefined;

      // Ethical wall: enforced here, before validation or any handler, for every route that touches a matter.
      const matterId = canonicalMatterId(db, route.matter(db, params, body as any));
      if (matterId && isWalledOff(db, matterId, user.id)) {
        throw new HttpProblem(403, "ethical-wall", "Ethical wall", WALL_MESSAGE, {},
          { action: "wall.denied", resource_type: "matter", resource_id: matterId, matter_id: matterId, outcome: "denied", detail: { method: req.method, path: instance, operation: route.operationId } });
      }

      const query = Object.fromEntries(url.searchParams);
      const errors: { pointer: string; message: string }[] = [];
      const qv = queryValidators.get(route.operationId)!;
      if (!qv(query)) for (const e of qv.errors ?? []) errors.push({ pointer: "query" + (e.instancePath || ""), message: e.message ?? "invalid" });
      const bv = bodyValidators.get(route.operationId);
      if (bv) {
        const input = body === undefined && route.operationId === "sendHoldReminders" ? {} : body;
        if (!bv(input)) for (const e of bv.errors ?? []) errors.push({ pointer: "body" + (e.instancePath || ""), message: e.message ?? "invalid" });
      }
      if (errors.length) throw new HttpProblem(400, "validation", "Request validation failed", "The request does not match the API schema.", { errors });

      const ctx = { db, user, params, query: query as Record<string, string>, body: body ?? {}, now: now(), today: now().toISOString().slice(0, 10) };
      if (!route.write) { const r = route.handler(ctx); return { status: r.status, body: r.body, problem: false }; }

      // Writes: idempotent, transactional, audited.
      const headerKey = req.headers["idempotency-key"];
      const derived = !(typeof headerKey === "string" && headerKey);
      key = !derived ? (headerKey as string) : "derived:" + sha(`${user.id}|${req.method}|${instance}|${canonical(body ?? {})}`);
      const hash = sha(canonical(body ?? {}));
      const routeKey = `${req.method} ${instance}`;
      let prior = db.prepare("SELECT * FROM idempotency WHERE key = ? AND user_id = ? AND route = ?").get(key, user.id, routeKey) as any;
      // A derived key is a retry guard, not a permanent no-op: after the window the same request is a new request.
      if (prior && derived && now().getTime() - new Date(prior.created_at).getTime() >= DERIVED_KEY_WINDOW_MS) {
        db.prepare("DELETE FROM idempotency WHERE key = ? AND user_id = ? AND route = ?").run(key, user.id, routeKey);
        prior = undefined;
      }
      if (prior) {
        if (prior.request_hash !== hash) throw new HttpProblem(422, "idempotency-key-reuse", "Idempotency key reused", "This Idempotency-Key was already used with a different request body. Use a new key.");
        return { status: prior.status, body: JSON.parse(prior.response_body), headers: { "Idempotent-Replayed": "true" }, problem: false };
      }
      db.exec("BEGIN");
      let result: Result;
      try {
        result = route.handler(ctx);
        if (result.audit) writeAudit(user.id, result.audit, key);
        db.prepare("INSERT INTO idempotency (key, user_id, route, request_hash, status, response_body, created_at) VALUES (?,?,?,?,?,?,?)")
          .run(key, user.id, routeKey, hash, result.status, JSON.stringify(result.body), now().toISOString());
        db.exec("COMMIT");
      } catch (e) { db.exec("ROLLBACK"); throw e; }
      return { status: result.status, body: result.body, problem: false };
    } catch (e) {
      const p = e instanceof HttpProblem ? e : (console.error(e), new HttpProblem(500, "internal", "Internal error", "Something went wrong on the server."));
      if (p.audit) writeAudit(user?.id ?? null, p.audit, key);
      const headers: Record<string, string> = {};
      if (p.status === 401) headers["WWW-Authenticate"] = 'Bearer realm="matter-desk"';
      return { status: p.status, body: p.toBody(instance), headers, problem: true };
    }
  }

  const handle = async (req: IncomingMessage, res: ServerResponse) => {
    const out = await dispatch(req);
    res.writeHead(out.status, { "Content-Type": out.problem ? "application/problem+json" : "application/json", "Cache-Control": "no-store", ...out.headers });
    res.end(JSON.stringify(out.body));
  };
  const server: Server = createServer((req, res) => { handle(req, res).catch(() => { res.writeHead(500); res.end(); }); });
  return { db, server, handle };
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], "file://").href) {
  const port = Number(process.env.PORT || 8722);
  const app = createApp();
  app.server.listen(port, "127.0.0.1", () => console.log(`Matter Desk listening on http://127.0.0.1:${port} (demo data, fake tokens)`));
}
