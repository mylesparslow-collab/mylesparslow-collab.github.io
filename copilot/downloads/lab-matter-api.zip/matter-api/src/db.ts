import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";

const seed = (f: string) => JSON.parse(readFileSync(new URL(`../seed/${f}`, import.meta.url), "utf8"));

const SCHEMA = `
CREATE TABLE users (id TEXT PRIMARY KEY, name TEXT, email TEXT, title TEXT, role TEXT, practice_group TEXT, rate_cents INTEGER, entra_oid TEXT);
CREATE TABLE demo_tokens (token TEXT PRIMARY KEY, user_id TEXT);
CREATE TABLE clients (id TEXT PRIMARY KEY, name TEXT, industry TEXT);
CREATE TABLE matters (id TEXT PRIMARY KEY, number TEXT UNIQUE, name TEXT, client_id TEXT, practice_area TEXT, status TEXT, responsible_id TEXT, opened_date TEXT, court TEXT, description TEXT);
CREATE TABLE matter_team (matter_id TEXT, user_id TEXT, role TEXT);
CREATE TABLE docket (id TEXT PRIMARY KEY, matter_id TEXT, entry_date TEXT, entry_type TEXT, description TEXT, due_date TEXT, status TEXT, computed_by TEXT, docketed_by TEXT, date_basis TEXT, source_ref TEXT);
CREATE TABLE time_entries (id TEXT PRIMARY KEY, matter_id TEXT, user_id TEXT, work_date TEXT, hours REAL, billable_hours REAL, narrative TEXT, status TEXT, rate_cents INTEGER, recorded_at TEXT);
CREATE TABLE invoices (id TEXT PRIMARY KEY, matter_id TEXT, issued_date TEXT, amount_cents INTEGER, paid_cents INTEGER);
CREATE TABLE billing_rules (id TEXT PRIMARY KEY, client_id TEXT, code TEXT, severity TEXT, guideline_ref TEXT, text TEXT, params TEXT);
CREATE TABLE walls (id TEXT PRIMARY KEY, matter_id TEXT, reason TEXT, created_date TEXT);
CREATE TABLE wall_excluded (wall_id TEXT, user_id TEXT);
CREATE TABLE holds (id TEXT PRIMARY KEY, matter_id TEXT, title TEXT, scope_description TEXT, issued_by TEXT, issued_at TEXT, notice_text TEXT);
CREATE TABLE hold_custodians (hold_id TEXT, name TEXT, email TEXT, role TEXT, status TEXT, acknowledged_at TEXT, reminder_count INTEGER, last_reminded_at TEXT);
CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, user_id TEXT, action TEXT, resource_type TEXT, resource_id TEXT, matter_id TEXT, outcome TEXT, detail TEXT, idempotency_key TEXT);
CREATE TABLE idempotency (key TEXT, user_id TEXT, route TEXT, request_hash TEXT, status INTEGER, response_body TEXT, created_at TEXT, PRIMARY KEY (key, user_id, route));
`;

type SqlVal = string | number | null;
function insert(db: DatabaseSync, table: string, rows: Record<string, SqlVal>[]) {
  if (!rows.length) return;
  const cols = Object.keys(rows[0]);
  const st = db.prepare(`INSERT INTO ${table} (${cols.join(",")}) VALUES (${cols.map(() => "?").join(",")})`);
  for (const r of rows) st.run(...cols.map((c) => r[c] ?? null));
}

export function openDb(path = ":memory:"): DatabaseSync {
  const db = new DatabaseSync(path);
  db.exec(SCHEMA);
  insert(db, "users", seed("users.json"));
  insert(db, "demo_tokens", Object.entries(seed("tokens.json").tokens as Record<string, string>).map(([token, user_id]) => ({ token, user_id })));
  insert(db, "clients", seed("clients.json"));
  for (const m of seed("matters.json")) {
    const { team, ...row } = m;
    insert(db, "matters", [row]);
    insert(db, "matter_team", team.map((t: { user_id: string; role: string }) => ({ matter_id: m.id, ...t })));
  }
  insert(db, "docket", seed("docket.json"));
  insert(db, "time_entries", seed("time_entries.json").map((e: Record<string, SqlVal>) => ({ ...e, recorded_at: "2026-11-12T00:00:00Z" })));
  insert(db, "invoices", seed("invoices.json"));
  insert(db, "billing_rules", seed("billing_rules.json").map((r: { params: unknown }) => ({ ...r, params: JSON.stringify(r.params) })));
  for (const w of seed("walls.json")) {
    insert(db, "walls", [{ id: w.id, matter_id: w.matter_id, reason: w.reason, created_date: w.created_date }]);
    insert(db, "wall_excluded", w.excluded_user_ids.map((user_id: string) => ({ wall_id: w.id, user_id })));
  }
  for (const h of seed("holds.json")) {
    const { custodians, ...row } = h;
    insert(db, "holds", [{ ...row, notice_text: "(seeded hold; notice text not stored)" }]);
    insert(db, "hold_custodians", custodians.map((c: Record<string, SqlVal>) => ({ hold_id: h.id, ...c })));
  }
  return db;
}
