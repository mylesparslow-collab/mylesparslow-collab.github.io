// Builds the OpenAPI 3.0 document from the route registry and schemas.
import { routes } from "./routes.ts";
import { components } from "./schemas.ts";

const ref = (n: string) => ({ $ref: `#/components/schemas/${n}` });
const problem = (description: string) => ({ description, content: { "application/problem+json": { schema: ref("Problem") } } });

export function buildOpenApi() {
  const paths: Record<string, Record<string, unknown>> = {};
  for (const r of routes) {
    const parameters: unknown[] = [];
    for (const m of r.path.matchAll(/\{(\w+)\}/g)) parameters.push({ name: m[1], in: "path", required: true, description: m[1] === "matter_id" ? "Matter id (for example M-0412) or matter number (for example TG-2026-0412)." : m[1] === "hold_id" ? "Litigation hold id, for example H-1001." : "Client id, for example C-100.", schema: { type: "string" } });
    for (const q of r.query ?? []) parameters.push({ name: q.name, in: "query", required: false, description: q.description, schema: q.schema });
    if (r.idempotent) parameters.push({ name: "Idempotency-Key", in: "header", required: false, description: "Client-chosen unique key. Repeating a request with the same key and body returns the original response and writes nothing twice. A key you send is remembered indefinitely. If omitted, the server derives a key from the caller, route and body and treats an identical request as a retry for 10 minutes only; after that the same request runs again.", schema: { type: "string", minLength: 8, maxLength: 128 } });
    const responses: Record<string, unknown> = {
      [String(r.successStatus)]: { description: "Success.", content: { "application/json": { schema: ref(r.response) } } },
      "401": problem("Missing or invalid bearer token."),
      "403": problem("The caller is excluded from this matter by an ethical wall. The detail text can be relayed to the user."),
      "404": problem("Not found."),
      "400": problem("The request failed schema validation.")
    };
    if (r.operationId === "createTimeEntry") { responses["422"] = problem("The entry violates the client's billing rules (hard violations are listed in `violations`), or an idempotency key was reused with a different body."); responses["409"] = problem("The matter is not open."); }
    if (r.operationId === "issueLitHold") responses["422"] = problem("Duplicate custodian, or an idempotency key was reused with a different body.");
    if (r.operationId === "sendHoldReminders") responses["422"] = problem("An idempotency key was reused with a different body.");
    const op: Record<string, unknown> = {
      operationId: r.operationId, summary: r.summary, description: r.description, tags: [r.tag], parameters,
      security: [{ entraOAuth: [r.write ? "api://matterdesk-demo/matters.write" : "api://matterdesk-demo/matters.read"] }], responses
    };
    if (!parameters.length) delete op.parameters;
    if (r.requestBody) op.requestBody = { required: r.requestBody !== "ReminderRequest", content: { "application/json": { schema: ref(r.requestBody) } } };
    (paths[r.path] ??= {})[r.method.toLowerCase()] = op;
  }
  return {
    openapi: "3.0.3",
    info: {
      title: "Matter Desk API", version: "0.1.0",
      description: "Demo matter-management API for the invented law firm Thornwood Garza LLP. Fake data only. Ethical walls are enforced by the server, not by the caller or the model. Dates are shown exactly as docketed and are never recomputed here."
    },
    servers: [{ url: "https://matterdesk.thornwoodgarza.example", description: "Placeholder production host" }, { url: "http://localhost:8722", description: "Local demo" }],
    tags: [{ name: "Matters" }, { name: "Billing" }, { name: "Litigation holds" }, { name: "Identity" }],
    paths,
    components: {
      securitySchemes: {
        entraOAuth: {
          type: "oauth2", description: "Microsoft Entra ID, authorization code flow. In Microsoft 365 Copilot this is registered in the Teams developer portal as an OAuth client registration and referenced from the plugin manifest through OAuthPluginVault.",
          flows: { authorizationCode: {
            authorizationUrl: "https://login.microsoftonline.com/00000000-0000-0000-0000-000000000000/oauth2/v2.0/authorize",
            tokenUrl: "https://login.microsoftonline.com/00000000-0000-0000-0000-000000000000/oauth2/v2.0/token",
            scopes: { "api://matterdesk-demo/matters.read": "Read matters, deadlines, billing rules and holds the caller may see.", "api://matterdesk-demo/matters.write": "Record time entries and issue litigation holds as the caller." }
          } }
        }
      },
      schemas: components
    }
  };
}
