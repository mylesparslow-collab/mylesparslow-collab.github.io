import type { DatabaseSync } from "node:sqlite";
import type { AuthUser } from "./auth.ts";
import { HttpProblem, notFound, type AuditNote } from "./problem.ts";
import { checkEntry, type Rule } from "./rules.ts";

export interface Ctx { db: DatabaseSync; user: AuthUser; params: Record<string, string>; query: Record<string, string>; body: any; now: Date; today: string }
export interface Result { status: number; body: unknown; audit?: AuditNote }
interface QueryParam { name: string; description: string; schema: Record<string, unknown> }
export interface RouteDef {
  operationId: string; method: "GET" | "POST"; path: string; summary: string; description: string; tag: string;
  write: boolean; idempotent: boolean; successStatus: number; query?: QueryParam[]; requestBody?: string; response: string;
  /** Raw matter id or number this request touches, so the wall check runs before anything else. */
  matter: (db: DatabaseSync, params: Record<string, string>, body: any) => string | null;
  handler: (c: Ctx) => Result;
}

type Row = Record<string, any>;
const all = (db: DatabaseSync, sql: string, ...a: any[]) => db.prepare(sql).all(...a) as Row[];
const one = (db: DatabaseSync, sql: string, ...a: any[]) => db.prepare(sql).get(...a) as Row | undefined;
const dollars = (cents: number) => Math.round(cents) / 100;

export function canonicalMatterId(db: DatabaseSync, idOrNumber: unknown): string | null {
  if (typeof idOrNumber !== "string") return null;
  return (one(db, "SELECT id FROM matters WHERE id = ? OR number = ?", idOrNumber, idOrNumber)?.id as string) ?? null;
}
export function isWalledOff(db: DatabaseSync, matterId: string, userId: string): boolean {
  return !!one(db, "SELECT 1 FROM walls w JOIN wall_excluded e ON e.wall_id = w.id WHERE w.matter_id = ? AND e.user_id = ?", matterId, userId);
}
const ref = (db: DatabaseSync, id: string) => { const m = one(db, "SELECT id, number, name FROM matters WHERE id = ?", id)!; return { id: m.id, number: m.number, name: m.name }; };
const requireMatter = (c: Ctx, raw: string): Row => {
  const id = canonicalMatterId(c.db, raw);
  if (!id) throw notFound(`Matter ${raw}`);
  return one(c.db, "SELECT m.*, c.name AS client_name, u.name AS responsible_name FROM matters m JOIN clients c ON c.id = m.client_id JOIN users u ON u.id = m.responsible_id WHERE m.id = ?", id)!;
};
const docketOut = (r: Row) => ({ id: r.id, matter_id: r.matter_id, entry_date: r.entry_date, entry_type: r.entry_type, description: r.description, due_date: r.due_date, status: r.status, computed_by: r.computed_by, docketed_by: r.docketed_by, date_basis: r.date_basis, source_ref: r.source_ref });
const openDeadlines = (db: DatabaseSync, matterId: string, from?: string, to?: string) =>
  all(db, "SELECT * FROM docket WHERE matter_id = ? AND due_date IS NOT NULL AND status = 'open' AND (? IS NULL OR due_date >= ?) AND (? IS NULL OR due_date <= ?) ORDER BY due_date, id", matterId, from ?? null, from ?? null, to ?? null, to ?? null).map(docketOut);
const addDays = (iso: string, n: number) => { const d = new Date(iso + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const nextId = (db: DatabaseSync, table: string, prefix: string, width: number) => {
  const max = all(db, `SELECT id FROM ${table}`).reduce((n, r) => Math.max(n, Number(String(r.id).slice(prefix.length)) || 0), 0);
  return prefix + String(max + 1).padStart(width, "0");
};
const rulesFor = (db: DatabaseSync, clientId: string): Rule[] => all(db, "SELECT * FROM billing_rules WHERE client_id = ? ORDER BY id", clientId).map((r) => ({ ...r, params: JSON.parse(r.params) }) as Rule);

const pathMatter = (_db: DatabaseSync, p: Record<string, string>) => p.matter_id ?? null;

const searchMatters = (c: Ctx): Result => {
  const { query: q, client, status, mine } = c.query;
  const like = (s: string) => `%${s.toLowerCase()}%`;
  const rows = all(c.db, `SELECT m.*, cl.name AS client_name, u.name AS responsible_name FROM matters m JOIN clients cl ON cl.id = m.client_id JOIN users u ON u.id = m.responsible_id
    WHERE NOT EXISTS (SELECT 1 FROM walls w JOIN wall_excluded e ON e.wall_id = w.id WHERE w.matter_id = m.id AND e.user_id = ?)
      AND (? IS NULL OR lower(m.name || ' ' || m.number || ' ' || m.description || ' ' || cl.name) LIKE ?)
      AND (? IS NULL OR lower(cl.name) LIKE ? OR cl.id = ?)
      AND (? IS NULL OR m.status = ?)
      AND (? IS NULL OR m.id IN (SELECT matter_id FROM matter_team WHERE user_id = ?))
    ORDER BY m.number`, c.user.id, q ?? null, q ? like(q) : null, client ?? null, client ? like(client) : null, client ?? null, status ?? null, status ?? null, String(mine) === "true" ? 1 : null, c.user.id);
  const matters = rows.map((m) => ({
    id: m.id, number: m.number, name: m.name, client_name: m.client_name, practice_area: m.practice_area, status: m.status, responsible_attorney: m.responsible_name,
    ...(openDeadlines(c.db, m.id, c.today)[0] ? { next_deadline: openDeadlines(c.db, m.id, c.today)[0] } : {})
  }));
  return { status: 200, body: { total: matters.length, matters } };
};

const getMatter = (c: Ctx): Result => {
  const m = requireMatter(c, c.params.matter_id);
  const team = all(c.db, "SELECT u.id, u.name, t.role FROM matter_team t JOIN users u ON u.id = t.user_id WHERE t.matter_id = ? ORDER BY u.name", m.id);
  const wip = one(c.db, "SELECT COALESCE(SUM(billable_hours * rate_cents), 0) AS cents, COALESCE(SUM(billable_hours), 0) AS hours FROM time_entries WHERE matter_id = ? AND status = 'unbilled'", m.id)!;
  const ar = one(c.db, "SELECT COALESCE(SUM(amount_cents - paid_cents), 0) AS cents, COUNT(*) AS n FROM invoices WHERE matter_id = ? AND amount_cents > paid_cents", m.id)!;
  return { status: 200, body: {
    id: m.id, number: m.number, name: m.name, client: { id: m.client_id, name: m.client_name }, practice_area: m.practice_area, status: m.status, opened_date: m.opened_date, court: m.court, description: m.description,
    responsible_attorney: { id: m.responsible_id, name: m.responsible_name }, team, next_deadlines: openDeadlines(c.db, m.id, c.today).slice(0, 5),
    totals: { currency: "USD", wip_amount: dollars(wip.cents), wip_hours: Math.round(wip.hours * 10) / 10, ar_amount: dollars(ar.cents), ar_invoice_count: ar.n }
  } };
};

const getDeadlines = (c: Ctx): Result => {
  const m = requireMatter(c, c.params.matter_id);
  const within = c.query.due_within_days ? Number(c.query.due_within_days) : null;
  const from = c.query.from ?? (within !== null ? c.today : undefined);
  const to = c.query.to ?? (within !== null ? addDays(c.today, within) : undefined);
  const deadlines = openDeadlines(c.db, m.id, from, to);
  return { status: 200, body: {
    matter: ref(c.db, m.id), as_of: c.today, window: from || to ? { from: from ?? "", to: to ?? "" } : null,
    note: "Dates are shown exactly as docketed. Docketing computed or set each one; this system does not recompute them.", count: deadlines.length, deadlines
  } };
};

const getDocket = (c: Ctx): Result => {
  const m = requireMatter(c, c.params.matter_id);
  const entries = all(c.db, "SELECT * FROM docket WHERE matter_id = ? ORDER BY entry_date DESC, id DESC", m.id).map(docketOut);
  return { status: 200, body: { matter: ref(c.db, m.id), count: entries.length, entries } };
};

const getBillingRules = (c: Ctx): Result => {
  const client = one(c.db, "SELECT * FROM clients WHERE id = ?", c.params.client_id);
  if (!client) throw notFound(`Client ${c.params.client_id}`);
  const rules = rulesFor(c.db, client.id).map(({ id, code, severity, guideline_ref, text }) => ({ id, code, severity, guideline_ref, text }));
  return { status: 200, body: { client: { id: client.id, name: client.name }, source: "Outside counsel guidelines on file for this client (demo data).", rules } };
};

const checkDraft = (c: Ctx) => {
  const d = c.body as { matter_id: string; work_date: string; hours: number; narrative: string };
  const m = requireMatter(c, d.matter_id);
  const result = checkEntry(rulesFor(c.db, m.client_id), d);
  return { m, d, result };
};

const checkTimeEntry = (c: Ctx): Result => {
  const { m, d, result } = checkDraft(c);
  return { status: 200, body: { matter: ref(c.db, m.id), client: { id: m.client_id, name: m.client_name }, draft: { work_date: d.work_date, hours: d.hours, narrative: d.narrative }, ...result } };
};

const createTimeEntry = (c: Ctx): Result => {
  const { m, d, result } = checkDraft(c);
  if (m.status !== "open") throw new HttpProblem(409, "matter-not-open", "Matter is not open", `Matter ${m.number} is ${m.status}; time cannot be recorded.`);
  if (!result.can_post) {
    const hard = result.violations.filter((v) => v.severity === "hard");
    throw new HttpProblem(422, "billing-rule-violation", "Entry violates client billing rules", `The entry was not recorded: ${hard.length} billing rule violation(s). Fix the entry and check it again.`,
      { violations: result.violations }, { action: "time_entry.rejected", resource_type: "time_entry", resource_id: null, matter_id: m.id, outcome: "rejected", detail: { draft: d, violations: result.violations.map((v) => v.rule_id) } });
  }
  const id = nextId(c.db, "time_entries", "TE-", 4);
  const recorded_at = c.now.toISOString();
  c.db.prepare("INSERT INTO time_entries (id, matter_id, user_id, work_date, hours, billable_hours, narrative, status, rate_cents, recorded_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
    .run(id, m.id, c.user.id, d.work_date, d.hours, result.billable_hours, d.narrative, "unbilled", c.user.rate_cents, recorded_at);
  const te = { id, matter_id: m.id, user_id: c.user.id, work_date: d.work_date, hours: d.hours, billable_hours: result.billable_hours, narrative: d.narrative, status: "unbilled", recorded_at };
  return { status: 201, body: { time_entry: te, matter: ref(c.db, m.id), client: { id: m.client_id, name: m.client_name }, notes: result.violations },
    audit: { action: "time_entry.created", resource_type: "time_entry", resource_id: id, matter_id: m.id, outcome: "ok", detail: { before: null, after: te } } };
};

const custodianOut = (r: Row) => ({ name: r.name, email: r.email, role: r.role, status: r.status, acknowledged_at: r.acknowledged_at, reminder_count: r.reminder_count, last_reminded_at: r.last_reminded_at });
const holdCustodians = (db: DatabaseSync, holdId: string) => all(db, "SELECT * FROM hold_custodians WHERE hold_id = ? ORDER BY rowid", holdId).map(custodianOut);

export function noticeText(p: { id: string; matterName: string; number: string; title: string; scope: string; issuer: string; issuedOn: string }): string {
  return [
    "PRIVILEGED AND CONFIDENTIAL. ATTORNEY-CLIENT COMMUNICATION.",
    `LITIGATION HOLD NOTICE ${p.id}: ${p.title}`,
    `Matter: ${p.matterName} (${p.number})`,
    `Issued: ${p.issuedOn} by ${p.issuer}, Thornwood Garza LLP`,
    "",
    "You are receiving this notice because you may have documents or data relevant to the matter above. Effective immediately, you must preserve, and must not delete, alter, overwrite or discard, anything within the scope below, in any form: paper, email, text and chat messages, files on shared drives and personal devices, calendars, photographs and voicemail.",
    "",
    `Scope: ${p.scope}`,
    "",
    "Suspend any automatic deletion that could affect these materials. If you are unsure whether something is covered, preserve it and ask. This hold remains in effect until you are told in writing that it has been released.",
    "Please reply to confirm that you have received and will comply with this notice.",
    "",
    "DRAFT FOR ATTORNEY REVIEW: an attorney must review this notice before it is relied on."
  ].join("\n");
}

const issueLitHold = (c: Ctx): Result => {
  const m = requireMatter(c, c.params.matter_id);
  const b = c.body as { title: string; scope_description: string; custodians: { name: string; email: string; role?: string }[] };
  const emails = b.custodians.map((x) => x.email.toLowerCase());
  if (new Set(emails).size !== emails.length) throw new HttpProblem(422, "duplicate-custodian", "Duplicate custodian", "Each custodian email may appear only once.");
  const holdId = nextId(c.db, "holds", "H-", 4);
  const notice = noticeText({ id: holdId, matterName: m.name, number: m.number, title: b.title, scope: b.scope_description, issuer: c.user.name, issuedOn: c.today });
  const issued_at = c.now.toISOString();
  c.db.prepare("INSERT INTO holds (id, matter_id, title, scope_description, issued_by, issued_at, notice_text) VALUES (?,?,?,?,?,?,?)").run(holdId, m.id, b.title, b.scope_description, c.user.id, issued_at, notice);
  const ins = c.db.prepare("INSERT INTO hold_custodians (hold_id, name, email, role, status, acknowledged_at, reminder_count, last_reminded_at) VALUES (?,?,?,?,'pending',NULL,0,NULL)");
  for (const x of b.custodians) ins.run(holdId, x.name, x.email, x.role ?? null);
  const custodians = holdCustodians(c.db, holdId);
  const body = { id: holdId, matter: ref(c.db, m.id), title: b.title, scope_description: b.scope_description, issued_by: c.user.name, issued_at, pending_count: custodians.length, custodians, notice_text: notice,
    distribution: "Simulated: this demo records the hold and returns the notice text; no email is sent." };
  return { status: 201, body, audit: { action: "lit_hold.issued", resource_type: "lit_hold", resource_id: holdId, matter_id: m.id, outcome: "ok", detail: { before: null, after: { id: holdId, title: b.title, custodians: emails } } } };
};

const listLitHolds = (c: Ctx): Result => {
  const m = requireMatter(c, c.params.matter_id);
  const holds = all(c.db, "SELECT h.*, u.name AS issuer FROM holds h JOIN users u ON u.id = h.issued_by WHERE h.matter_id = ? ORDER BY h.issued_at", m.id).map((h) => {
    const custodians = holdCustodians(c.db, h.id);
    return { id: h.id, title: h.title, issued_by: h.issuer, issued_at: h.issued_at, pending_count: custodians.filter((x) => x.status === "pending").length, custodians };
  });
  return { status: 200, body: { matter: ref(c.db, m.id), holds, outstanding_total: holds.reduce((n, h) => n + h.pending_count, 0) } };
};

const sendHoldReminders = (c: Ctx): Result => {
  const h = one(c.db, "SELECT * FROM holds WHERE id = ?", c.params.hold_id)!;
  const only = ((c.body?.custodian_emails ?? []) as string[]).map((e) => e.toLowerCase());
  const all_ = holdCustodians(c.db, h.id);
  const targets = all_.filter((x) => x.status === "pending" && (only.length === 0 || only.includes(x.email.toLowerCase())));
  const before = all_.map((x) => ({ email: x.email, reminder_count: x.reminder_count }));
  const upd = c.db.prepare("UPDATE hold_custodians SET reminder_count = reminder_count + 1, last_reminded_at = ? WHERE hold_id = ? AND email = ?");
  for (const t of targets) upd.run(c.now.toISOString(), h.id, t.email);
  const reminded = targets.map((t) => ({ name: t.name, email: t.email, reminder_count: t.reminder_count + 1 }));
  return { status: 200, body: { hold_id: h.id, reminded, already_acknowledged: all_.filter((x) => x.status === "acknowledged" && (only.length === 0 || only.includes(x.email.toLowerCase()))).map((x) => x.email), distribution: "Simulated: this demo records the reminder; no email is sent." },
    audit: { action: "lit_hold.reminders_sent", resource_type: "lit_hold", resource_id: h.id, matter_id: h.matter_id, outcome: "ok", detail: { before, after: reminded.map((r) => ({ email: r.email, reminder_count: r.reminder_count })) } } };
};

const getMe = (c: Ctx): Result => {
  const u = c.user;
  return { status: 200, body: { id: u.id, name: u.name, email: u.email, title: u.title, role: u.role, practice_group: u.practice_group } };
};

const MATTER_ID_DESC = "Matter id (for example M-0412) or matter number (for example TG-2026-0412).";
export const routes: RouteDef[] = [
  { operationId: "searchMatters", method: "GET", path: "/matters", tag: "Matters", summary: "Search matters", write: false, idempotent: false, successStatus: 200, response: "MatterList", matter: () => null, handler: searchMatters,
    description: "Search the matters the caller may see. Matters behind an ethical wall that excludes the caller are omitted. Each result carries its next open deadline exactly as docketed.",
    query: [
      { name: "query", description: "Free text matched against matter name, number, description and client name.", schema: { type: "string" } },
      { name: "client", description: "Client name fragment or client id.", schema: { type: "string" } },
      { name: "status", description: "Matter status.", schema: { type: "string", enum: ["open", "closed"] } },
      { name: "mine", description: "When true, only matters where the caller is on the team.", schema: { type: "boolean" } }] },
  { operationId: "getMatter", method: "GET", path: "/matters/{matter_id}", tag: "Matters", summary: "Get a matter summary", write: false, idempotent: false, successStatus: 200, response: "MatterSummary", matter: pathMatter, handler: getMatter,
    description: `${MATTER_ID_DESC} Returns the summary, team, next open deadlines (dates as docketed) and unbilled (WIP) and receivable (AR) totals.` },
  { operationId: "getMatterDeadlines", method: "GET", path: "/matters/{matter_id}/deadlines", tag: "Matters", summary: "List open deadlines for a matter", write: false, idempotent: false, successStatus: 200, response: "DeadlineList", matter: pathMatter, handler: getDeadlines,
    description: "Open dated docket entries, earliest first. Each date is exactly as stored and carries who computed it (computed_by) and its stated basis. This API never recomputes a date; the due_within_days, from and to parameters only filter on stored dates.",
    query: [
      { name: "due_within_days", description: "Only deadlines from today through this many days ahead.", schema: { type: "integer", minimum: 0, maximum: 365 } },
      { name: "from", description: "Earliest stored due date to include (YYYY-MM-DD).", schema: { type: "string", format: "date" } },
      { name: "to", description: "Latest stored due date to include (YYYY-MM-DD).", schema: { type: "string", format: "date" } }] },
  { operationId: "getMatterDocket", method: "GET", path: "/matters/{matter_id}/docket", tag: "Matters", summary: "Get the docket for a matter", write: false, idempotent: false, successStatus: 200, response: "DocketList", matter: pathMatter, handler: getDocket,
    description: "Every docket entry (filings, orders, hearings, deadlines), newest first, with dates as stored." },
  { operationId: "getClientBillingRules", method: "GET", path: "/clients/{client_id}/billing-rules", tag: "Billing", summary: "Get a client's outside-counsel billing rules", write: false, idempotent: false, successStatus: 200, response: "BillingRules", matter: () => null, handler: getBillingRules,
    description: "The client's billing guidelines as rules, with the rule text quoted verbatim and the guideline section." },
  { operationId: "checkTimeEntry", method: "POST", path: "/time-entries/check", tag: "Billing", summary: "Dry-run a draft time entry against the client's billing rules", write: false, idempotent: false, successStatus: 200, requestBody: "TimeEntryDraft", response: "TimeEntryCheck", matter: (db, _p, b) => b?.matter_id ?? null, handler: checkTimeEntry,
    description: "Checks a draft narrative and hours against the matter's client's rules. Nothing is recorded. Each violation quotes the rule text. Use this before createTimeEntry." },
  { operationId: "createTimeEntry", method: "POST", path: "/time-entries", tag: "Billing", summary: "Record a time entry", write: true, idempotent: true, successStatus: 201, requestBody: "TimeEntryDraft", response: "TimeEntryResult", matter: (db, _p, b) => b?.matter_id ?? null, handler: createTimeEntry,
    description: "Records a time entry for the caller. Re-runs the billing rules and rejects hard violations with 422. Idempotent." },
  { operationId: "listLitHolds", method: "GET", path: "/matters/{matter_id}/lit-holds", tag: "Litigation holds", summary: "List litigation holds and who has not acknowledged", write: false, idempotent: false, successStatus: 200, response: "HoldList", matter: pathMatter, handler: listLitHolds,
    description: "Holds issued on the matter with each custodian's acknowledgment status and reminder count." },
  { operationId: "issueLitHold", method: "POST", path: "/matters/{matter_id}/lit-holds", tag: "Litigation holds", summary: "Issue a litigation hold to named custodians", write: true, idempotent: true, successStatus: 201, requestBody: "HoldRequest", response: "Hold", matter: pathMatter, handler: issueLitHold,
    description: "Creates a hold and returns its id and the notice text. In this demo no email is sent. Idempotent." },
  { operationId: "sendHoldReminders", method: "POST", path: "/lit-holds/{hold_id}/acknowledge-reminders", tag: "Litigation holds", summary: "Remind custodians who have not acknowledged a hold", write: true, idempotent: true, successStatus: 200, requestBody: "ReminderRequest", response: "ReminderResult",
    matter: (db, p) => (one(db, "SELECT matter_id FROM holds WHERE id = ?", p.hold_id)?.matter_id as string) ?? null,
    handler: (c) => { if (!one(c.db, "SELECT 1 FROM holds WHERE id = ?", c.params.hold_id)) throw notFound(`Hold ${c.params.hold_id}`); return sendHoldReminders(c); },
    description: "Sends a reminder to every custodian who has not acknowledged (or only the listed emails). In this demo the reminder is recorded, not emailed. Idempotent." },
  { operationId: "getMe", method: "GET", path: "/me", tag: "Identity", summary: "Who is calling", write: false, idempotent: false, successStatus: 200, response: "Me", matter: () => null, handler: getMe,
    description: "The caller, as resolved by the authentication layer." }
];
