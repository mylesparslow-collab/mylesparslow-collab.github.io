// A small Adaptive Cards templating step: merges a card template with response data.
// Supported (the subset our cards use, same syntax as the Adaptive Cards Templating Language):
//   "${path}"            value; a string that is exactly one binding keeps the value's type
//   "text ${a} ${b}"     interpolation
//   "$data": "${path}"   repeat the element for each array item (or scope into an object)
//   "$when": "${expr}"   drop the element when false
//   expressions: path, $data, $root, $index, literals ('x', 1, true, null), == != > < >= <=, && ||,
//                if(cond, a, b), formatNumber(path, digits), length(path)
// The Adaptive Cards SDK does the real rendering inside Copilot; this exists so the demo can show what the user would see.
type Scope = { data: unknown; root: unknown; index: number };

function splitTop(s: string, sep: string): string[] {
  const out: string[] = []; let depth = 0; let q = ""; let cur = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) { cur += ch; if (ch === q) q = ""; continue; }
    if (ch === "'") { q = ch; cur += ch; continue; }
    if (ch === "(") depth++;
    if (ch === ")") depth--;
    if (depth === 0 && s.startsWith(sep, i)) { out.push(cur); cur = ""; i += sep.length - 1; continue; }
    cur += ch;
  }
  out.push(cur);
  return out;
}

function path(expr: string, sc: Scope): unknown {
  if (expr === "$data") return sc.data;
  if (expr === "$root") return sc.root;
  if (expr === "$index") return sc.index;
  let parts = expr.split(".");
  let cur: any = sc.data;
  if (parts[0] === "$root") { cur = sc.root; parts = parts.slice(1); }
  else if (parts[0] === "$data") parts = parts.slice(1);
  for (const p of parts) { if (cur === null || cur === undefined) return undefined; cur = cur[p]; }
  return cur;
}

export function evalExpr(raw: string, sc: Scope): unknown {
  const e = raw.trim();
  const or = splitTop(e, "||"); if (or.length > 1) return or.some((x) => truthy(evalExpr(x, sc)));
  const and = splitTop(e, "&&"); if (and.length > 1) return and.every((x) => truthy(evalExpr(x, sc)));
  for (const op of ["==", "!=", ">=", "<=", ">", "<"]) {
    const parts = splitTop(e, op);
    if (parts.length === 2 && !(op === ">" && parts[1].startsWith("=")) && !(op === "<" && parts[1].startsWith("="))) {
      const a = evalExpr(parts[0], sc) ?? null, b = evalExpr(parts[1], sc) ?? null;
      switch (op) { case "==": return a === b; case "!=": return a !== b; case ">=": return (a as number) >= (b as number); case "<=": return (a as number) <= (b as number); case ">": return (a as number) > (b as number); default: return (a as number) < (b as number); }
    }
  }
  let m: RegExpExecArray | null;
  if ((m = /^if\((.*)\)$/s.exec(e))) { const [c, a, b] = splitTop(m[1], ","); return truthy(evalExpr(c, sc)) ? evalExpr(a, sc) : evalExpr(b, sc); }
  if ((m = /^formatNumber\((.*)\)$/s.exec(e))) { const [v, d] = splitTop(m[1], ","); return Number(evalExpr(v, sc)).toFixed(Number(evalExpr(d, sc))); }
  if ((m = /^length\((.*)\)$/s.exec(e))) { const v = evalExpr(m[1], sc) as { length?: number } | undefined; return v?.length ?? 0; }
  if ((m = /^'(.*)'$/s.exec(e))) return m[1];
  if (/^-?\d+(\.\d+)?$/.test(e)) return Number(e);
  if (e === "true") return true;
  if (e === "false") return false;
  if (e === "null") return null;
  return path(e, sc);
}
const truthy = (v: unknown) => !(v === false || v === null || v === undefined || v === 0 || v === "");

function expandString(s: string, sc: Scope): unknown {
  if (s.startsWith("${") && s.endsWith("}") && s.indexOf("${", 2) === -1 && s.indexOf("}") === s.length - 1) return evalExpr(s.slice(2, -1), sc);
  return s.replace(/\$\{([^}]*)\}/g, (_m, ex) => { const v = evalExpr(ex, sc); return v === undefined || v === null ? "" : String(v); });
}

function expand(node: unknown, sc: Scope): unknown {
  if (typeof node === "string") return expandString(node, sc);
  if (Array.isArray(node)) {
    const out: unknown[] = [];
    for (const item of node) {
      if (item && typeof item === "object" && !Array.isArray(item) && "$data" in (item as object)) {
        const { $data, ...rest } = item as Record<string, unknown>;
        const bound = expandString($data as string, sc);
        const list = Array.isArray(bound) ? bound : bound === undefined || bound === null ? [] : [bound];
        list.forEach((d, i) => { const r = expandObject(rest, { data: d, root: sc.root, index: i }); if (r !== DROP) out.push(r); });
      } else {
        const r = item && typeof item === "object" && !Array.isArray(item) ? expandObject(item as Record<string, unknown>, sc) : expand(item, sc);
        if (r !== DROP) out.push(r);
      }
    }
    return out;
  }
  if (node && typeof node === "object") return expandObject(node as Record<string, unknown>, sc);
  return node;
}
const DROP = Symbol("drop");
function expandObject(o: Record<string, unknown>, sc: Scope): unknown {
  if ("$when" in o && !truthy(expandString(o.$when as string, sc))) return DROP;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(o)) if (k !== "$when") out[k] = expand(v, sc);
  return out;
}

export function renderCard(template: unknown, data: unknown): any {
  return expand(template, { data, root: data, index: 0 });
}
