// Outside-counsel-guideline rule engine. Pure functions, no I/O.
export interface Rule { id: string; client_id: string; code: string; severity: "hard" | "warn" | "adjust"; guideline_ref: string; text: string; params: Record<string, number> }
export interface Violation { rule_id: string; code: string; severity: "hard" | "warn" | "adjust"; guideline_ref: string; rule_text: string; message: string; matched_text: string | null }
export interface CheckResult { ok: boolean; can_post: boolean; billable_hours: number; violations: Violation[]; suggested_splits: string[]; rules_checked: number }

const VERBS = "draft(?:ed|ing)?|prepar(?:e|ed|ing)|review(?:ed|ing)?|analy[sz](?:e|ed|ing)|research(?:ed|ing)?|revis(?:e|ed|ing)|call(?:ed|ing)?|telephon(?:e|ed)|confer(?:red|ring)?|e-?mail(?:ed|ing)?|correspond(?:ed|ing)?|attend(?:ed|ing)?|meet(?:ing)?|met|negotiat(?:e|ed|ing)|interview(?:ed|ing)?|summariz(?:e|ed|ing)|edit(?:ed|ing)?|finaliz(?:e|ed|ing)|updat(?:e|ed|ing)";
const CLAUSE_SPLIT = new RegExp(`\\s*;\\s*|\\s*,\\s*(?:and\\s+)?(?=(?:${VERBS})\\b)|\\s+and\\s+(?=(?:${VERBS})\\b)|\\s+then\\s+(?=(?:${VERBS})\\b)`, "i");
const CLERICAL = /\b(?:cop(?:y|ied|ying)|scan(?:ned|ning)?|photocop(?:y|ied|ying)|print(?:ed|ing)?|bates[- ]stamp(?:ed|ing)?|calendar(?:ed|ing)?|schedul(?:e|ed|ing) (?:a |the )?(?:meeting|call|hearing|deposition)|organiz(?:e|ed|ing) (?:the )?(?:file|files|folder|folders|binder)|filing (?:the )?(?:documents?|papers)|data entry|mail(?:ed|ing) (?:out )?(?:the )?(?:package|letter|documents?)|fax(?:ed|ing)?)\b/i;
const TRAVEL = /\b(?:travel(?:ed|ing|l?ed)?|commut(?:e|ed|ing)|drove|driving|drive to|flight to|train to)\b/i;
const VAGUE = /\b(?:attention to (?:the )?(?:file|matter)|work(?:ed|ing)? on (?:the )?(?:file|matter|case)|various (?:tasks|matters|issues)|misc(?:ellaneous)?|case management|general (?:work|matters))\b/i;

export function splitTasks(narrative: string): string[] {
  return narrative.split(CLAUSE_SPLIT).map((s) => s.trim().replace(/[.,;]+$/, "")).filter(Boolean);
}
const words = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;
const round1 = (n: number) => Math.round(n * 10) / 10;

export function checkEntry(rules: Rule[], draft: { hours: number; narrative: string }): CheckResult {
  const violations: Violation[] = [];
  let billable = draft.hours;
  const splits = splitTasks(draft.narrative);
  let suggested: string[] = [];
  const add = (r: Rule, message: string, matched: string | null) => violations.push({ rule_id: r.id, code: r.code, severity: r.severity, guideline_ref: r.guideline_ref, rule_text: r.text, message, matched_text: matched });
  for (const r of rules) {
    switch (r.code) {
      case "BLOCK_BILLING":
        if (splits.length >= 2) { add(r, `The narrative combines ${splits.length} tasks in one entry. Record each task as its own entry.`, splits.join(" | ")); suggested = splits; }
        break;
      case "INCREMENT": {
        const inc = r.params.increment ?? 0.1;
        const steps = draft.hours / inc;
        if (Math.abs(steps - Math.round(steps)) > 1e-9) add(r, `${draft.hours} hours is not a multiple of ${inc}.`, String(draft.hours));
        break;
      }
      case "CLERICAL": {
        const m = CLERICAL.exec(draft.narrative);
        if (m) add(r, "The narrative describes a clerical or administrative task, which is not billable to this client.", m[0]);
        break;
      }
      case "TRAVEL": {
        const m = TRAVEL.exec(draft.narrative);
        if (m) {
          const f = r.params.factor ?? 0.5;
          billable = round1(draft.hours * f);
          add(r, `Travel is payable at ${Math.round(f * 100)}%: ${draft.hours} hours records as ${billable} billable hours.`, m[0]);
        }
        break;
      }
      case "VAGUE": {
        const min = r.params.min_words ?? 5;
        const m = VAGUE.exec(draft.narrative);
        if (m) add(r, "The narrative is a generic description.", m[0]);
        else if (words(draft.narrative) < min) add(r, `The narrative has ${words(draft.narrative)} words; at least ${min} are required.`, draft.narrative);
        break;
      }
      case "MAX_ENTRY":
        if (draft.hours > (r.params.max_hours ?? 8)) add(r, `${draft.hours} hours exceeds ${r.params.max_hours} hours for a single entry.`, String(draft.hours));
        break;
    }
  }
  return {
    ok: violations.length === 0,
    can_post: !violations.some((v) => v.severity === "hard"),
    billable_hours: billable,
    violations,
    suggested_splits: suggested,
    rules_checked: rules.length
  };
}
