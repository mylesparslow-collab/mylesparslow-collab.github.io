// Definition of the Matter Desk API plugin: functions, cards, confirmations, and which agent gets which functions.
export type DataHandling = "GetPublicData" | "GetPrivateData" | "DataTransform" | "ResourceStateUpdate";
export interface FnDef {
  name: string; description: string; handling: DataHandling[];
  card?: { file: string; data_path: string; title: string; subtitle?: string };
  confirmation?: { title: string; body: string };
}

export const fns: FnDef[] = [
  { name: "getMe", handling: ["GetPrivateData"], description: "Returns who the signed-in user is (name, title, role, practice group). Call this when the user says 'my matters' or asks who they are." },
  { name: "searchMatters", handling: ["GetPrivateData"], description: "Find matters by name, number, client or keyword; optionally only the user's own matters (mine=true). Matters behind an ethical wall that excludes the user never appear. Returns each matter's next open deadline exactly as docketed. Use to resolve a name like 'Halvorsen' to a matter id; if more than one matches, ask the user which.",
    card: { file: "matter-list.json", data_path: "$", title: "$.matters[0].name", subtitle: "$.matters[0].number" } },
  { name: "getMatter", handling: ["GetPrivateData"], description: "Get the summary of one matter by id or matter number: client, responsible attorney, team, next open deadlines (dates as docketed and who computed them), and WIP and AR totals. If the response is a 403 ethical-wall error, relay its detail text and stop.",
    card: { file: "matter-summary.json", data_path: "$", title: "$.name", subtitle: "$.number" } },
  { name: "getMatterDeadlines", handling: ["GetPrivateData"], description: "List a matter's open deadlines, earliest first, each with its date exactly as stored, who computed it, and its stated basis. Use due_within_days for 'due this week'. Never recompute, adjust or add to these dates.",
    card: { file: "deadline-list.json", data_path: "$", title: "$.matter.name", subtitle: "$.matter.number" } },
  { name: "getMatterDocket", handling: ["GetPrivateData"], description: "Get the full docket of a matter (filings, orders, hearings, deadlines), newest first, with dates as stored." },
  { name: "getClientBillingRules", handling: ["GetPrivateData"], description: "Get a client's outside-counsel billing rules, with the rule text quoted verbatim and the guideline section. Quote rules exactly; do not paraphrase them." },
  { name: "checkTimeEntry", handling: ["GetPrivateData"], description: "Dry run: check a draft time entry (matter, date, hours, narrative) against the client's billing rules. Records nothing. Returns violations with the rule text quoted, and a suggested split when tasks are combined. Always call this before createTimeEntry.",
    card: { file: "check-result.json", data_path: "$", title: "$.matter.name", subtitle: "$.matter.number" } },
  { name: "createTimeEntry", handling: ["ResourceStateUpdate"], description: "Record a time entry for the signed-in user. Only call after checkTimeEntry shows no hard violations AND the user has confirmed the exact narrative and hours. The server re-checks the rules and rejects hard violations.",
    confirmation: { title: "Record this time entry?", body: "Record {{function.parameters.hours}} hour(s) on matter {{function.parameters.matter_id}} for {{function.parameters.work_date}}?\n\n**Narrative:** {{function.parameters.narrative}}\n\nThis writes to the time system as you." },
    card: { file: "time-entry-recorded.json", data_path: "$", title: "$.matter.name", subtitle: "$.time_entry.id" } },
  { name: "listLitHolds", handling: ["GetPrivateData"], description: "List the litigation holds on a matter and which custodians have not acknowledged, with reminder counts.",
    card: { file: "hold-status.json", data_path: "$", title: "$.matter.name", subtitle: "$.matter.number" } },
  { name: "issueLitHold", handling: ["ResourceStateUpdate"], description: "Issue a litigation hold on a matter to named custodians (name and email each). Only call after the user has confirmed the title, scope and custodian list. Returns the hold id and the notice text.",
    confirmation: { title: "Issue this litigation hold?", body: "Issue the hold **{{function.parameters.title}}** on matter {{function.parameters.matter_id}} to the custodians listed in this request?\n\n**Scope:** {{function.parameters.scope_description}}\n\nThis creates a hold record under your name." },
    card: { file: "hold-issued.json", data_path: "$", title: "$.title", subtitle: "$.id" } },
  { name: "sendHoldReminders", handling: ["ResourceStateUpdate"], description: "Send reminders to custodians who have not acknowledged a hold (all of them, or only the listed emails). Only call after the user confirms.",
    confirmation: { title: "Send hold reminders?", body: "Send reminders for hold {{function.parameters.hold_id}} to custodians who have not acknowledged it?" },
    card: { file: "hold-reminders.json", data_path: "$", title: "$.hold_id" } }
];

export interface AgentDef { slug: string; name: string; short: string; full: string; accent: string; fns: string[]; starters: { title: string; text: string }[]; manifestId: string; agentId: string }
export const agents: AgentDef[] = [
  { slug: "matter-desk", name: "Matter Desk", accent: "#1F4E79", manifestId: "f3a1c0d2-6b41-4c1a-9d7e-2a1b5c8e0b01", agentId: "matter_desk_5d1a77c3",
    short: "Live matter status, deadlines and docket, with dates exactly as docketed.",
    full: "Looks up the firm's matter system for a matter's status, team, next deadlines, docket, unbilled time and receivables. Dates are shown exactly as docketed with who computed them, and are never recomputed. Matters behind an ethical wall are refused by the system.",
    fns: ["getMe", "searchMatters", "getMatter", "getMatterDeadlines", "getMatterDocket"],
    starters: [
      { title: "Where are we?", text: "Where are we on the Halvorsen matter?" },
      { title: "Due this week", text: "What's due this week on my matters?" },
      { title: "Docket", text: "Show me the docket for TG-2026-0412, newest first." },
      { title: "Find a matter", text: "Find our open matters for Marlow Valley Water Agency." }] },
  { slug: "time-entry-coach", name: "Time Entry Coach", accent: "#2E7D32", manifestId: "f3a1c0d2-6b41-4c1a-9d7e-2a1b5c8e0b02", agentId: "time_entry_coach_9be40a1f",
    short: "Turns plain words into a time entry that passes the client's billing rules.",
    full: "You describe the work in plain words. The coach drafts the narrative, checks it against the client's outside-counsel billing rules, shows any violation with the rule quoted, and records the entry only after you confirm the exact text and hours.",
    fns: ["getMe", "searchMatters", "getMatter", "getClientBillingRules", "checkTimeEntry", "createTimeEntry"],
    starters: [
      { title: "Log my time", text: "Log 0.8 hours on the Halvorsen Harbor Middle School matter for today: I reviewed the schedule updates." },
      { title: "Check a messy entry", text: "Check this entry for TG-2026-0412, 3.5 hours today: Reviewed contract; drafted email to client; call with opposing counsel re: extension." },
      { title: "What are the rules?", text: "What are Halvorsen Pacific Builders' billing rules?" },
      { title: "Travel time", text: "I drove to the courthouse for the hearing on the Halvorsen matter, 1.2 hours. How does that bill?" }] },
  { slug: "hold-manager", name: "Hold Manager", accent: "#8A4B08", manifestId: "f3a1c0d2-6b41-4c1a-9d7e-2a1b5c8e0b03", agentId: "hold_manager_c27d3e90",
    short: "Issues litigation holds and chases custodians who have not acknowledged.",
    full: "Drafts a litigation hold from your description, issues it to named custodians only after you confirm, and lists who has not acknowledged each hold, with an option to send reminders. The notice always says an attorney must review it.",
    fns: ["getMe", "searchMatters", "getMatter", "listLitHolds", "issueLitHold", "sendHoldReminders"],
    starters: [
      { title: "Who hasn't acknowledged?", text: "Who hasn't acknowledged the hold on the Halvorsen Harbor Middle School matter?" },
      { title: "Draft a hold", text: "Draft a litigation hold for TG-2026-0388 covering Cedar Ridge project documents. Custodians: Pat Quill (pat.quill@halvorsen-builders.example), project engineer." },
      { title: "Send reminders", text: "Send reminders to everyone who hasn't acknowledged the hold on TG-2026-0412." },
      { title: "All holds", text: "List all litigation holds on TG-2026-0803." }] }
];
