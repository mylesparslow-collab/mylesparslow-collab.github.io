// Starts the real server, drives a scripted scenario over HTTP, and saves what happened:
//   demo/transcript.json, demo/transcript.md, demo/cards/*.json (each card template merged with the real response).
// Run: npm run demo
import { spawn } from "node:child_process";
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { renderCard } from "../src/template.ts";
import { fns } from "./plugin-def.ts";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const PORT = 8722;
const BASE = `http://127.0.0.1:${PORT}`;
const NOW = "2026-11-13T17:00:00Z";
const work = mkdtempSync(join(tmpdir(), "matter-desk-demo-"));
const dbPath = join(work, "demo.db");

const server = spawn(process.execPath, ["--experimental-strip-types", "--disable-warning=ExperimentalWarning", join(root, "src/server.ts")], { env: { ...process.env, PORT: String(PORT), DB_PATH: dbPath, DEMO_NOW: NOW }, stdio: ["ignore", "pipe", "inherit"] });
const stop = () => new Promise<void>((r) => { server.once("exit", () => r()); server.kill("SIGTERM"); });
try {
  for (let i = 0; i < 50; i++) { try { await fetch(`${BASE}/me`); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }

  interface Step { n: number; title: string; why: string; op: string | null; request: any; response: any }
  const steps: Step[] = [];
  async function step(title: string, why: string, op: string | null, as: string, method: string, path: string, body?: unknown, key?: string) {
    const headers: Record<string, string> = { authorization: `Bearer FAKE-DEMO-TOKEN-${as}`, "content-type": "application/json" };
    if (key) headers["idempotency-key"] = key;
    const res = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await res.text();
    const s: Step = {
      n: steps.length + 1, title, why, op,
      request: { as, method, path, headers: { Authorization: `Bearer FAKE-DEMO-TOKEN-${as}`, ...(key ? { "Idempotency-Key": key } : {}) }, ...(body !== undefined ? { body } : {}) },
      response: { status: res.status, content_type: res.headers.get("content-type"), ...(res.headers.get("idempotent-replayed") ? { idempotent_replayed: true } : {}), body: JSON.parse(text) }
    };
    steps.push(s);
    return s;
  }

  const bad = { matter_id: "M-0412", work_date: "2026-11-13", hours: 3.5, narrative: "Reviewed contract; drafted email to client; call with opposing counsel re: extension" };
  const fixed = { matter_id: "M-0412", work_date: "2026-11-13", hours: 1.2, narrative: "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements" };

  await step("Who am I?", "The agent asks the auth layer who is calling.", "getMe", "jordan", "GET", "/me");
  await step("Find the Halvorsen matter", "Two matters match, so the agent must ask which one.", "searchMatters", "jordan", "GET", "/matters?query=halvorsen");
  await step("Where are we on the Harbor Middle School matter?", "Live status: team, next deadlines exactly as docketed, WIP and AR.", "getMatter", "jordan", "GET", "/matters/M-0412");
  await step("What is due in the next 7 days on that matter?", "Dates are stored values filtered by a window; docketing is named as the source.", "getMatterDeadlines", "jordan", "GET", "/matters/M-0412/deadlines?due_within_days=7");
  await step("A walled user searches for the whistleblower matter", "The search silently omits the matter.", "searchMatters", "marcus", "GET", "/matters?query=whistleblower");
  await step("The same walled user asks for the matter directly", "The server refuses, with text the agent can relay, and writes an audit row.", "getMatter", "marcus", "GET", "/matters/M-0421");
  await step("A walled user tries to record time on the walled matter", "Writes are refused the same way, before validation.", "createTimeEntry", "marcus", "POST", "/time-entries", { matter_id: "M-0421", work_date: "2026-11-13", hours: 1.0, narrative: "Reviewed hotline report and compliance committee minutes" }, "demo-walled-write-0001");
  await step("An allowed partner opens the same matter", "Same route, different caller.", "getMatter", "priya", "GET", "/matters/M-0421");
  await step("What are Halvorsen's billing rules?", "The rules the entry will be checked against, text verbatim.", "getClientBillingRules", "jordan", "GET", "/clients/C-100/billing-rules");
  await step("Dry-run a messy entry", "Block billing: three tasks in one entry. Nothing is recorded.", "checkTimeEntry", "jordan", "POST", "/time-entries/check", bad);
  await step("Try to record it anyway", "The server re-checks and rejects hard violations.", "createTimeEntry", "jordan", "POST", "/time-entries", bad, "demo-time-bad-0001");
  await step("Dry-run a travel entry", "Travel is not a violation; it is adjusted to 50% by the client's rule.", "checkTimeEntry", "jordan", "POST", "/time-entries/check", { matter_id: "M-0412", work_date: "2026-11-13", hours: 1.2, narrative: "Traveled to courthouse for hearing on motion for summary adjudication" });
  await step("Dry-run the corrected entry", "One task, valid increment, specific narrative.", "checkTimeEntry", "jordan", "POST", "/time-entries/check", fixed);
  await step("Record the corrected entry (after the user confirms)", "The write. The user confirmed in Copilot before this call.", "createTimeEntry", "jordan", "POST", "/time-entries", fixed, "demo-time-good-0001");
  await step("The client retries the same request", "Same Idempotency-Key: the original response is replayed and nothing is written twice.", "createTimeEntry", "jordan", "POST", "/time-entries", fixed, "demo-time-good-0001");
  await step("Who has not acknowledged the existing hold?", "Hold Manager's first question.", "listLitHolds", "jordan", "GET", "/matters/M-0412/lit-holds");
  await step("Issue a new litigation hold (after the user confirms)", "Creates the hold and returns its id and notice text.", "issueLitHold", "jordan", "POST", "/matters/M-0388/lit-holds",
    { title: "Cedar Ridge project documents", scope_description: "All documents and ESI relating to the Cedar Ridge mixed-use project: contracts, pay applications, lien and stop-notice correspondence, schedules and daily reports.", custodians: [{ name: "Pat Quill", email: "pat.quill@halvorsen-builders.example", role: "Project engineer" }, { name: "Imani Brooks", email: "imani.brooks@halvorsen-builders.example", role: "Controller" }] }, "demo-hold-new-0001");
  await step("Remind custodians who have not acknowledged the first hold (after the user confirms)", "Only the pending custodians are reminded.", "sendHoldReminders", "jordan", "POST", "/lit-holds/H-1001/acknowledge-reminders", {}, "demo-reminders-0001");

  // Audit log, read straight from the server's database after it stops.
  await stop();
  const db = new DatabaseSync(dbPath, { readOnly: true });
  const audit = (db.prepare("SELECT id, ts, user_id, action, resource_type, resource_id, matter_id, outcome, idempotency_key, detail FROM audit_log ORDER BY id").all() as any[]).map((r) => ({ ...r, detail: JSON.parse(r.detail) }));
  db.close();

  mkdirSync(join(root, "demo/cards"), { recursive: true });
  const cards: { file: string; step: number; op: string }[] = [];
  for (const s of steps) {
    const fn = fns.find((f) => f.name === s.op);
    if (!fn?.card || s.response.status >= 300) continue;
    const tpl = JSON.parse(readFileSync(join(root, "plugin/adaptive-cards", fn.card.file), "utf8"));
    const file = `${String(s.n).padStart(2, "0")}-${s.op}.json`;
    writeFileSync(join(root, "demo/cards", file), JSON.stringify(renderCard(tpl, s.response.body), null, 2) + "\n");
    cards.push({ file, step: s.n, op: s.op! });
  }

  writeFileSync(join(root, "demo/transcript.json"), JSON.stringify({ about: "Real requests and responses from the Matter Desk API running locally on node:http. Fake data and fake demo tokens only. Server clock fixed to 2026-11-13T17:00:00Z for a repeatable run.", server_clock: NOW, base_url: BASE, steps, audit_log: audit, cards }, null, 2) + "\n");

  const md: string[] = ["# Matter Desk demo transcript", "", "Real requests and responses from a local run (`npm run demo`). Fake data, fake demo tokens, server clock fixed to 2026-11-13. Nothing here ran in Microsoft 365 Copilot.", ""];
  for (const s of steps) {
    md.push(`## ${s.n}. ${s.title}`, "", s.why, "", "```http", `${s.request.method} ${s.request.path}`, ...Object.entries(s.request.headers).map(([k, v]) => `${k}: ${v}`), "```");
    if (s.request.body !== undefined) md.push("", "```json", JSON.stringify(s.request.body, null, 2), "```");
    md.push("", `**Response ${s.response.status}** (${s.response.content_type})${s.response.idempotent_replayed ? ", header `Idempotent-Replayed: true`" : ""}`, "", "```json", JSON.stringify(s.response.body, null, 2), "```", "");
    const c = cards.find((x) => x.step === s.n);
    if (c) md.push(`Adaptive Card the user would see: \`cards/${c.file}\``, "");
  }
  md.push("## Audit log (from the server's database after the run)", "", "| # | user | action | matter | outcome | idempotency key |", "|---|---|---|---|---|---|", ...audit.map((a) => `| ${a.id} | ${a.user_id} | ${a.action} | ${a.matter_id ?? ""} | ${a.outcome} | ${a.idempotency_key ?? ""} |`), "");
  writeFileSync(join(root, "demo/transcript.md"), md.join("\n"));
  console.log(`demo done: ${steps.length} steps, ${audit.length} audit rows, ${cards.length} merged cards`);
  console.log(steps.map((s) => `${String(s.n).padStart(2)} ${s.response.status} ${s.request.method} ${s.request.path}`).join("\n"));
} finally {
  if (!server.killed && server.exitCode === null) await stop();
  rmSync(work, { recursive: true, force: true });
}
