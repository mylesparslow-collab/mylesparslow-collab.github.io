# Hold Manager agent

Drafts and issues litigation holds to named custodians after you confirm, and lists who has not acknowledged each hold, with an option to send reminders.

- **Functions:** getMe, searchMatters, getMatter, listLitHolds, issueLitHold (write), sendHoldReminders (write); both writes carry an AdaptiveCard confirmation.
- **Rules it keeps:** never invents custodians or emails; does not decide whether a hold is required or when to release it (attorney decisions); keeps the attorney-review line on notice text.
- **In this demo** the hold is recorded and the notice text returned; no email is sent, and the response says so (`distribution`).
- **Cards:** hold-issued (custodians table, toggle for the notice text), hold-status, hold-reminders.
- **Try in the demo:** `demo/transcript.md` steps 16 to 18.
- **Not verified:** nothing has run in Copilot.
