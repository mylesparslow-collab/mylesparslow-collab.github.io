# Matter Desk agent

Answers "where are we on the Halvorsen matter" and "what's due this week on my matters" from the live matter system, as Adaptive Cards. Read-only.

- **Functions:** getMe, searchMatters, getMatter, getMatterDeadlines, getMatterDocket (`appPackage/matter-desk-plugin.json`, spec in `appPackage/apiSpecificationFile/openapi.yaml`).
- **Dates:** shown exactly as docketed with `computed_by` and `docketed_by`; the agent is told never to add days, count days remaining, or recompute.
- **Walls:** a 403 from the server is relayed and the agent stops; it cannot work around it because the server decides.
- **Cards:** matter-summary (FactSet plus deadlines table), deadline-list, matter-list.
- **Provision:** package `appPackage/` with Microsoft 365 Agents Toolkit after setting `MATTER_DESK_OAUTH_REFERENCE_ID` and pointing `servers` at a hosted API. Not done here; nothing has run in a tenant.
- **Try in the demo:** `demo/transcript.md` steps 2 to 8 show the same calls.
