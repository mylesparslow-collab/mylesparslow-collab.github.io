# Time Entry Coach agent

You describe work in plain words; the agent drafts the narrative, runs the client's billing rules, shows each violation with the rule text quoted, and records the entry only after you confirm the exact text and hours.

- **Functions:** getMe, searchMatters, getMatter, getClientBillingRules, checkTimeEntry (dry run), createTimeEntry (write, with an AdaptiveCard confirmation).
- **The loop:** identify matter, draft, `checkTimeEntry`, show violations, fix (it asks you for hours when splitting block-billed entries; it never allocates hours), read back, explicit yes, `createTimeEntry`. The server re-checks and returns 422 if a hard violation slips through.
- **Cards:** check-result (green, amber or red banner plus violations with rule text) and time-entry-recorded.
- **Try in the demo:** `demo/transcript.md` steps 9 to 15: block-billing rejection, travel adjusted to 50%, corrected entry recorded, retry replayed without a second row.
- **Not verified:** nothing has run in Copilot. The `check` function is a POST that records nothing, so it has no confirmation dialog; only the write does.
