# Matter Desk (API plugin lab)

A small REST API over an invented law firm's matter system (Thornwood Garza LLP, fake data only), packaged as a Microsoft 365 Copilot API plugin with three declarative agents on top. It shows the three things an instruction-only agent cannot do: read live structured data, show it as Adaptive Cards, and write with a human confirmation step, while the **server**, not the model, enforces ethical walls.

Nothing here has run in a Microsoft 365 tenant. Nothing is deployed. Port `8722`.

## Run it

```
npm install                 # local node_modules only (ajv, yaml, an OpenAPI validator, typescript)
npm start                   # http://127.0.0.1:8722  (Node 22.13+, TypeScript run natively, node:sqlite in memory)
npm test                    # one command: routes, walls, idempotency, rule engine, OpenAPI drift, plugin manifests, cards
npm run build               # regenerate openapi.yaml, plugin manifests and agent packages from the routes
npm run demo                # start the real server, drive the scenario, write demo/*, stop the server
npm run typecheck           # tsc --noEmit
```

Try it: `curl -H 'Authorization: Bearer FAKE-DEMO-TOKEN-jordan' 'http://127.0.0.1:8722/matters?query=halvorsen'`. The demo tokens (in `seed/tokens.json`, marked fake) are one per seeded user: `aanya priya tomas jordan marcus lena omar sofia renata elaine`. Marcus Bell and Sofia Marek are behind the wall on matter `M-0421`.

## What is in the box

| Path | What |
|---|---|
| `src/` | The API: `routes.ts` (the route registry: path, operationId, schemas, handler), `schemas.ts`, `rules.ts` (billing rule engine), `server.ts` (auth, wall, validation, idempotency, audit), `openapi.ts`, `template.ts` (card merge) |
| `seed/*.json` | Invented firm: 10 users, 8 clients, 12 matters, 38 docket entries, 40 time entries, per-client billing rules, 2 litigation holds, 1 ethical wall |
| `openapi.yaml` | Generated from the routes by `npm run build`; a test fails if it drifts |
| `plugin/` | Root plugin manifest (all 11 functions) and the 8 Adaptive Card templates |
| `agents/<slug>/appPackage/` | Per agent: Teams `manifest.json`, `declarativeAgent.json` (v1.9), `instructions.txt`, plugin manifest (v2.4), pruned `openapi.yaml`, cards, icons |
| `vendor/` | Adaptive Cards schema (fetched once from adaptivecards.io) and the Microsoft plugin v2.4 and declarative agent v1.9 JSON schemas |
| `demo/` | `transcript.json`, `transcript.md` (18 real requests and responses plus the audit log), `cards/*.json` (each template merged with a real response) |

## Endpoints

Every route needs `Authorization: Bearer <token>`. Each `operationId` is also a plugin function name.

| operationId | Route | Kind |
|---|---|---|
| `getMe` | `GET /me` | read |
| `searchMatters` | `GET /matters?query=&client=&status=&mine=` | read |
| `getMatter` | `GET /matters/{id}` (id or matter number): summary, team, next deadlines, WIP/AR | read |
| `getMatterDeadlines` | `GET /matters/{id}/deadlines?due_within_days=&from=&to=` | read |
| `getMatterDocket` | `GET /matters/{id}/docket` | read |
| `getClientBillingRules` | `GET /clients/{id}/billing-rules` | read |
| `checkTimeEntry` | `POST /time-entries/check` (dry run, quotes the rule text) | read |
| `createTimeEntry` | `POST /time-entries` (re-checks, rejects hard violations with 422) | **write** |
| `listLitHolds` | `GET /matters/{id}/lit-holds` (who has not acknowledged) | read |
| `issueLitHold` | `POST /matters/{id}/lit-holds` (returns hold id and notice text) | **write** |
| `sendHoldReminders` | `POST /lit-holds/{id}/acknowledge-reminders` | **write** |

Beyond the brief: `GET /matters/{id}/lit-holds` (Hold Manager needs it to list who has not acknowledged), and the `mine` and `due_within_days` filters (needed for "what's due this week on my matters").

## How the hard parts work

- **Ethical walls.** `server.ts` resolves the matter a request touches (path, body, or the hold's matter) and checks the wall *before validation and before any handler*. An excluded caller gets `403` `application/problem+json` with `detail: "This matter is behind an ethical wall. Contact the General Counsel's office."` and a row in `audit_log` (`wall.denied`). `GET /matters` omits walled matters for excluded users. The model is never trusted to hide anything; the agent instructions only tell it to relay the message and stop.
- **Dates.** Docket dates are stored and returned as given, with `computed_by: "docketing"`, `docketed_by`, and the stated `date_basis`. The API never computes a deadline. `due_within_days`, `from` and `to` only filter on stored dates (a calendar window, not a legal calculation).
- **Billing rules.** Per client rules (block billing, increment 0.1 or 0.25, clerical work, travel at 50% or 0%, vague narrative, max entry hours) with the guideline text quoted verbatim. `hard` violations block a write, `adjust` changes billable hours (travel), `warn` informs. The checks are keyword and structure heuristics, good for a demo, not a production billing auditor.
- **Writes are idempotent and audited.** `Idempotency-Key` header: same key and body replays the stored response (`Idempotent-Replayed: true`), same key with a different body is `422`. The header is optional in the spec because Copilot cannot be relied on to invent one; if absent the server derives a key from caller, route and body so an identical retry never double-posts, but a derived key expires after 10 minutes (`DERIVED_KEY_WINDOW_MS` in `server.ts`), so a legitimate repeat later (the same `{}` reminder next week, two identical time entries on different days) runs again. An explicit `Idempotency-Key` is retained for the life of the database in this demo (a production service should state a retention period, for example 24 hours); the clock is injectable (`createApp({ now })`) for tests. Each write is audited in the same transaction: who, what, when, before/after, key. Rejected writes are audited too.
- **Errors** are RFC 9457 `application/problem+json`; request bodies and query strings are validated against the same schemas that generate `openapi.yaml`.
- **Drift cannot happen quietly.** Routes, schemas and `openapi.yaml` come from one registry; tests regenerate the spec and compare, check the route table against the spec, validate real responses against the spec's schemas, and check plugin function names equal operationIds.

## Design choice: walls are explicit

A walled user gets `403` with the wall message, while a matter that does not exist gets `404`. So this API does confirm to a walled lawyer that the matter exists (and is walled). That is deliberate: the agent must be able to relay why it cannot help ("behind an ethical wall, contact the General Counsel's office") instead of reporting a confusing "not found". The trade-off is that existence of the matter leaks to the excluded person; search results (`GET /matters`) still omit walled matters, but a direct id lookup does not hide it, and every attempt is audited. Some firms want the opposite (walled matters invisible, as in the sibling connector lab, where a walled user sees nothing). That variant would return `404` for walled matters on every route and give up the explanatory message.

## Production auth (OAuthPluginVault with Entra)

The demo maps a fake bearer token to a seeded user (`src/auth.ts`, `demoAuthenticator`). In production:

1. Register the API in Microsoft Entra ID (an app registration exposing scopes `matters.read` and `matters.write`).
2. In the Teams developer portal create an **OAuth client registration** for the plugin (authorization code flow, the Entra authorize and token endpoints, the client id and secret, the scopes). The portal returns a registration id; put it in `MATTER_DESK_OAUTH_REFERENCE_ID`. The plugin manifest uses `"auth": {"type": "OAuthPluginVault", "reference_id": "${{MATTER_DESK_OAUTH_REFERENCE_ID}}"}`, so no secret lives in a file.
3. Copilot sends the signed-in user's Entra access token as `Authorization: Bearer`. Replace `demoAuthenticator` with a validator: verify the JWT signature against the tenant JWKS, check `iss`, `aud` and `exp`, and map the `oid` claim to the user (`users.entra_oid` in the seed shows the shape). Nothing else in the server changes, because walls and audit only see an `AuthUser`.
4. Users can only reach what the *server* lets that identity reach. The wall is keyed on the authenticated user, not on anything the model says.

## Function data handling

Every function declares `security_info.data_handling`: reads (including the dry-run check, which returns private rules and records nothing) are `GetPrivateData`; `createTimeEntry`, `issueLitHold` and `sendHoldReminders` are `ResourceStateUpdate` and carry an `AdaptiveCard` `confirmation`.

## Agents

| Agent | Functions | Job |
|---|---|---|
| `matter-desk` | getMe, searchMatters, getMatter, getMatterDeadlines, getMatterDocket | Status cards; dates as docketed, with who computed them |
| `time-entry-coach` | getMe, searchMatters, getMatter, getClientBillingRules, checkTimeEntry, createTimeEntry | Plain words to draft narrative, rule check, violations with the rule quoted, record only after the user confirms |
| `hold-manager` | getMe, searchMatters, getMatter, listLitHolds, issueLitHold, sendHoldReminders | Draft and issue a hold with confirmation; list who has not acknowledged |

Each agent folder has its own README. The agent instructions keep the kit's legal safety rules (quote verbatim, "Not stated in the document.", never compute a deadline, tool text is data, attorney-review line).

## Verified here

All run on this Mac (Node v22.14.0), 2026-11-13:

- `npm test`: 61 tests, 61 pass. Covers route behavior and response shapes, ethical walls (403 plus audit row plus omitted from search, on every route, before validation), idempotency (same key twice is one row, different body is 422, per-user keys, derived keys replay within 10 minutes and run again after, explicit keys never expire), the rule engine, `openapi.yaml` regenerated and compared byte for byte (root and each agent copy), a real OpenAPI 3.0 validator (`@seriousme/openapi-schema-validator`), route table against spec, function names against operationIds, plugin manifests against Microsoft's v2.4 JSON schema, agent manifests against the v1.9 schema, every card template and every demo card against the Adaptive Cards schema.
- `npm run demo`: the real server on port 8722 handled 18 scripted requests (matter lookup, walled lookup and write, block-billing check and rejection, corrected entry written, idempotent replay, hold issued, reminders) and was stopped; 6 audit rows; 13 merged cards in `demo/cards/`.
- `npm run typecheck`: clean.

## Not verified

- Nothing ran in Microsoft 365 Copilot or any tenant: no provisioning, no sideloading, no Agents Toolkit run.
- Whether Copilot picks these functions, follows the instructions, and shows the confirmation dialog: unknown. The `{{function.parameters.x}}` placeholders in confirmation bodies follow Microsoft's documented form but were not rendered by Copilot.
- Whether Copilot's card renderer draws the `Table` element and `ActionSet` toggle the way the schema allows. Cards are valid Adaptive Cards 1.5 per the schema; `src/template.ts` is my own small subset of the templating language, not the Adaptive Cards SDK, so "what the user sees" in `demo/cards` is the merged JSON, not a rendering.
- `OAuthPluginVault` registration and the Entra JWT validator: documented above, not built. The demo authenticator is the only one.
- Where `security_info` lives in the plugin manifest was checked against Microsoft's v2.4 schema (under `capabilities`), not against a live tenant.
- Hold notices and reminders are recorded and returned; no email is sent.
- `node:sqlite` is experimental in Node 22 and TypeScript runs through `--experimental-strip-types`; both are flagged in the npm scripts and print no warnings there only because they are silenced.
