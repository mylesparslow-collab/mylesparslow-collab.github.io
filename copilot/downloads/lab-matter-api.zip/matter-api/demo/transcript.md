# Matter Desk demo transcript

Real requests and responses from a local run (`npm run demo`). Fake data, fake demo tokens, server clock fixed to 2026-11-13. Nothing here ran in Microsoft 365 Copilot.

## 1. Who am I?

The agent asks the auth layer who is calling.

```http
GET /me
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "id": "u-jordan",
  "name": "Jordan Reyes",
  "email": "jordan.reyes@thornwoodgarza.example",
  "title": "Senior Associate",
  "role": "associate",
  "practice_group": "Construction"
}
```

## 2. Find the Halvorsen matter

Two matters match, so the agent must ask which one.

```http
GET /matters?query=halvorsen
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "total": 2,
  "matters": [
    {
      "id": "M-0388",
      "number": "TG-2026-0388",
      "name": "Halvorsen Pacific Builders: Cedar Ridge mixed-use lien defense",
      "client_name": "Halvorsen Pacific Builders, Inc.",
      "practice_area": "Construction",
      "status": "open",
      "responsible_attorney": "Aanya Desai",
      "next_deadline": {
        "id": "DK-0388-02",
        "matter_id": "M-0388",
        "entry_date": "2026-10-21",
        "entry_type": "deadline",
        "description": "Responses to Requests for Production, Set Two, due",
        "due_date": "2026-11-24",
        "status": "open",
        "computed_by": "docketing",
        "docketed_by": "Renata Okafor (Docketing)",
        "date_basis": "Calculated by Docketing from service date plus extension agreed by stipulation",
        "source_ref": "Stipulation 10/21/2026; proof of service"
      }
    },
    {
      "id": "M-0412",
      "number": "TG-2026-0412",
      "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)",
      "client_name": "Halvorsen Pacific Builders, Inc.",
      "practice_area": "Construction",
      "status": "open",
      "responsible_attorney": "Aanya Desai",
      "next_deadline": {
        "id": "DK-0412-04",
        "matter_id": "M-0412",
        "entry_date": "2026-10-30",
        "entry_type": "deadline",
        "description": "Opposition to District's motion for summary adjudication due",
        "due_date": "2026-11-17",
        "status": "open",
        "computed_by": "docketing",
        "docketed_by": "Renata Okafor (Docketing)",
        "date_basis": "Court order dated 2026-10-30, paragraph 4 (date stated by the court)",
        "source_ref": "CMC order 10/30/2026 para. 4"
      }
    }
  ]
}
```

Adaptive Card the user would see: `cards/02-searchMatters.json`

## 3. Where are we on the Harbor Middle School matter?

Live status: team, next deadlines exactly as docketed, WIP and AR.

```http
GET /matters/M-0412
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "id": "M-0412",
  "number": "TG-2026-0412",
  "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)",
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "practice_area": "Construction",
  "status": "open",
  "opened_date": "2026-03-09",
  "court": "Superior Court, Harbor County, Dept. 14",
  "description": "Claim for delay and disruption damages on the Harbor Middle School modernization; district cross-claims for liquidated damages.",
  "responsible_attorney": {
    "id": "u-aanya",
    "name": "Aanya Desai"
  },
  "team": [
    {
      "id": "u-aanya",
      "name": "Aanya Desai",
      "role": "Responsible attorney"
    },
    {
      "id": "u-jordan",
      "name": "Jordan Reyes",
      "role": "Senior associate"
    },
    {
      "id": "u-renata",
      "name": "Renata Okafor",
      "role": "Docketing"
    },
    {
      "id": "u-sofia",
      "name": "Sofia Marek",
      "role": "Paralegal"
    }
  ],
  "next_deadlines": [
    {
      "id": "DK-0412-04",
      "matter_id": "M-0412",
      "entry_date": "2026-10-30",
      "entry_type": "deadline",
      "description": "Opposition to District's motion for summary adjudication due",
      "due_date": "2026-11-17",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Court order dated 2026-10-30, paragraph 4 (date stated by the court)",
      "source_ref": "CMC order 10/30/2026 para. 4"
    },
    {
      "id": "DK-0412-05",
      "matter_id": "M-0412",
      "entry_date": "2026-10-30",
      "entry_type": "deadline",
      "description": "Initial expert disclosure exchange",
      "due_date": "2026-11-20",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Court order dated 2026-10-30, paragraph 6 (date stated by the court)",
      "source_ref": "CMC order 10/30/2026 para. 6"
    },
    {
      "id": "DK-0412-06",
      "matter_id": "M-0412",
      "entry_date": "2026-11-02",
      "entry_type": "hearing",
      "description": "Hearing on District's motion for summary adjudication, Dept. 14",
      "due_date": "2026-12-04",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Hearing date set by the court clerk per notice of hearing",
      "source_ref": "Notice of hearing 11/02/2026"
    },
    {
      "id": "DK-0412-07",
      "matter_id": "M-0412",
      "entry_date": "2026-10-30",
      "entry_type": "deadline",
      "description": "Mediation completed (private mediator, per order)",
      "due_date": "2026-12-18",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Court order dated 2026-10-30, paragraph 8 (date stated by the court)",
      "source_ref": "CMC order 10/30/2026 para. 8"
    }
  ],
  "totals": {
    "currency": "USD",
    "wip_amount": 12243.5,
    "wip_hours": 20.1,
    "ar_amount": 128450,
    "ar_invoice_count": 1
  }
}
```

Adaptive Card the user would see: `cards/03-getMatter.json`

## 4. What is due in the next 7 days on that matter?

Dates are stored values filtered by a window; docketing is named as the source.

```http
GET /matters/M-0412/deadlines?due_within_days=7
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "as_of": "2026-11-13",
  "window": {
    "from": "2026-11-13",
    "to": "2026-11-20"
  },
  "note": "Dates are shown exactly as docketed. Docketing computed or set each one; this system does not recompute them.",
  "count": 2,
  "deadlines": [
    {
      "id": "DK-0412-04",
      "matter_id": "M-0412",
      "entry_date": "2026-10-30",
      "entry_type": "deadline",
      "description": "Opposition to District's motion for summary adjudication due",
      "due_date": "2026-11-17",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Court order dated 2026-10-30, paragraph 4 (date stated by the court)",
      "source_ref": "CMC order 10/30/2026 para. 4"
    },
    {
      "id": "DK-0412-05",
      "matter_id": "M-0412",
      "entry_date": "2026-10-30",
      "entry_type": "deadline",
      "description": "Initial expert disclosure exchange",
      "due_date": "2026-11-20",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Court order dated 2026-10-30, paragraph 6 (date stated by the court)",
      "source_ref": "CMC order 10/30/2026 para. 6"
    }
  ]
}
```

Adaptive Card the user would see: `cards/04-getMatterDeadlines.json`

## 5. A walled user searches for the whistleblower matter

The search silently omits the matter.

```http
GET /matters?query=whistleblower
Authorization: Bearer FAKE-DEMO-TOKEN-marcus
```

**Response 200** (application/json)

```json
{
  "total": 0,
  "matters": []
}
```

Adaptive Card the user would see: `cards/05-searchMatters.json`

## 6. The same walled user asks for the matter directly

The server refuses, with text the agent can relay, and writes an audit row.

```http
GET /matters/M-0421
Authorization: Bearer FAKE-DEMO-TOKEN-marcus
```

**Response 403** (application/problem+json)

```json
{
  "type": "https://matterdesk.thornwoodgarza.example/problems/ethical-wall",
  "title": "Ethical wall",
  "status": 403,
  "detail": "This matter is behind an ethical wall. Contact the General Counsel's office.",
  "instance": "/matters/M-0421"
}
```

## 7. A walled user tries to record time on the walled matter

Writes are refused the same way, before validation.

```http
POST /time-entries
Authorization: Bearer FAKE-DEMO-TOKEN-marcus
Idempotency-Key: demo-walled-write-0001
```

```json
{
  "matter_id": "M-0421",
  "work_date": "2026-11-13",
  "hours": 1,
  "narrative": "Reviewed hotline report and compliance committee minutes"
}
```

**Response 403** (application/problem+json)

```json
{
  "type": "https://matterdesk.thornwoodgarza.example/problems/ethical-wall",
  "title": "Ethical wall",
  "status": 403,
  "detail": "This matter is behind an ethical wall. Contact the General Counsel's office.",
  "instance": "/time-entries"
}
```

## 8. An allowed partner opens the same matter

Same route, different caller.

```http
GET /matters/M-0421
Authorization: Bearer FAKE-DEMO-TOKEN-priya
```

**Response 200** (application/json)

```json
{
  "id": "M-0421",
  "number": "TG-2026-0421",
  "name": "Pelican Bay Health District: internal whistleblower investigation",
  "client": {
    "id": "C-106",
    "name": "Pelican Bay Health District"
  },
  "practice_area": "Public Agency",
  "status": "open",
  "opened_date": "2026-09-08",
  "court": null,
  "description": "Privileged investigation of a compliance hotline report. Access restricted by ethical wall.",
  "responsible_attorney": {
    "id": "u-priya",
    "name": "Priya Nair"
  },
  "team": [
    {
      "id": "u-lena",
      "name": "Lena Fischer",
      "role": "Associate"
    },
    {
      "id": "u-priya",
      "name": "Priya Nair",
      "role": "Responsible attorney"
    }
  ],
  "next_deadlines": [
    {
      "id": "DK-0421-02",
      "matter_id": "M-0421",
      "entry_date": "2026-09-08",
      "entry_type": "deadline",
      "description": "Hotline records preservation notice follow-up",
      "due_date": "2026-11-18",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Date set by the responsible attorney",
      "source_ref": "Internal note 09/08/2026"
    },
    {
      "id": "DK-0421-01",
      "matter_id": "M-0421",
      "entry_date": "2026-09-08",
      "entry_type": "deadline",
      "description": "Interim findings memorandum to Board counsel",
      "due_date": "2026-11-30",
      "status": "open",
      "computed_by": "docketing",
      "docketed_by": "Renata Okafor (Docketing)",
      "date_basis": "Date stated in the engagement letter; not a statutory period",
      "source_ref": "Engagement letter 09/08/2026"
    }
  ],
  "totals": {
    "currency": "USD",
    "wip_amount": 8823,
    "wip_hours": 13.2,
    "ar_amount": 36250,
    "ar_invoice_count": 1
  }
}
```

Adaptive Card the user would see: `cards/08-getMatter.json`

## 9. What are Halvorsen's billing rules?

The rules the entry will be checked against, text verbatim.

```http
GET /clients/C-100/billing-rules
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "source": "Outside counsel guidelines on file for this client (demo data).",
  "rules": [
    {
      "id": "R-100-BLOCK_BILLING",
      "code": "BLOCK_BILLING",
      "severity": "hard",
      "guideline_ref": "OCG 4.1",
      "text": "Each task must be recorded as a separate time entry. Block billing, meaning several tasks combined in one entry, is not permitted."
    },
    {
      "id": "R-100-CLERICAL",
      "code": "CLERICAL",
      "severity": "hard",
      "guideline_ref": "OCG 4.5",
      "text": "Clerical or administrative tasks, including copying, scanning, filing, calendaring and scheduling, are overhead and will not be paid."
    },
    {
      "id": "R-100-INCREMENT",
      "code": "INCREMENT",
      "severity": "hard",
      "guideline_ref": "OCG 4.2",
      "text": "Time must be recorded in tenth-of-an-hour (0.1) increments."
    },
    {
      "id": "R-100-TRAVEL",
      "code": "TRAVEL",
      "severity": "adjust",
      "guideline_ref": "OCG 4.7",
      "text": "Non-working travel time is payable at fifty percent (50%) of the timekeeper's rate."
    },
    {
      "id": "R-100-VAGUE",
      "code": "VAGUE",
      "severity": "hard",
      "guideline_ref": "OCG 4.3",
      "text": "Each entry must describe the task with enough specificity to evaluate it (at least 5 words). Generic descriptions such as \"attention to file\" or \"work on matter\" will be rejected."
    }
  ]
}
```

## 10. Dry-run a messy entry

Block billing: three tasks in one entry. Nothing is recorded.

```http
POST /time-entries/check
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 3.5,
  "narrative": "Reviewed contract; drafted email to client; call with opposing counsel re: extension"
}
```

**Response 200** (application/json)

```json
{
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "draft": {
    "work_date": "2026-11-13",
    "hours": 3.5,
    "narrative": "Reviewed contract; drafted email to client; call with opposing counsel re: extension"
  },
  "ok": false,
  "can_post": false,
  "billable_hours": 3.5,
  "violations": [
    {
      "rule_id": "R-100-BLOCK_BILLING",
      "code": "BLOCK_BILLING",
      "severity": "hard",
      "guideline_ref": "OCG 4.1",
      "rule_text": "Each task must be recorded as a separate time entry. Block billing, meaning several tasks combined in one entry, is not permitted.",
      "message": "The narrative combines 3 tasks in one entry. Record each task as its own entry.",
      "matched_text": "Reviewed contract | drafted email to client | call with opposing counsel re: extension"
    }
  ],
  "suggested_splits": [
    "Reviewed contract",
    "drafted email to client",
    "call with opposing counsel re: extension"
  ],
  "rules_checked": 5
}
```

Adaptive Card the user would see: `cards/10-checkTimeEntry.json`

## 11. Try to record it anyway

The server re-checks and rejects hard violations.

```http
POST /time-entries
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
Idempotency-Key: demo-time-bad-0001
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 3.5,
  "narrative": "Reviewed contract; drafted email to client; call with opposing counsel re: extension"
}
```

**Response 422** (application/problem+json)

```json
{
  "type": "https://matterdesk.thornwoodgarza.example/problems/billing-rule-violation",
  "title": "Entry violates client billing rules",
  "status": 422,
  "detail": "The entry was not recorded: 1 billing rule violation(s). Fix the entry and check it again.",
  "instance": "/time-entries",
  "violations": [
    {
      "rule_id": "R-100-BLOCK_BILLING",
      "code": "BLOCK_BILLING",
      "severity": "hard",
      "guideline_ref": "OCG 4.1",
      "rule_text": "Each task must be recorded as a separate time entry. Block billing, meaning several tasks combined in one entry, is not permitted.",
      "message": "The narrative combines 3 tasks in one entry. Record each task as its own entry.",
      "matched_text": "Reviewed contract | drafted email to client | call with opposing counsel re: extension"
    }
  ]
}
```

## 12. Dry-run a travel entry

Travel is not a violation; it is adjusted to 50% by the client's rule.

```http
POST /time-entries/check
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 1.2,
  "narrative": "Traveled to courthouse for hearing on motion for summary adjudication"
}
```

**Response 200** (application/json)

```json
{
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "draft": {
    "work_date": "2026-11-13",
    "hours": 1.2,
    "narrative": "Traveled to courthouse for hearing on motion for summary adjudication"
  },
  "ok": false,
  "can_post": true,
  "billable_hours": 0.6,
  "violations": [
    {
      "rule_id": "R-100-TRAVEL",
      "code": "TRAVEL",
      "severity": "adjust",
      "guideline_ref": "OCG 4.7",
      "rule_text": "Non-working travel time is payable at fifty percent (50%) of the timekeeper's rate.",
      "message": "Travel is payable at 50%: 1.2 hours records as 0.6 billable hours.",
      "matched_text": "Traveled"
    }
  ],
  "suggested_splits": [],
  "rules_checked": 5
}
```

Adaptive Card the user would see: `cards/12-checkTimeEntry.json`

## 13. Dry-run the corrected entry

One task, valid increment, specific narrative.

```http
POST /time-entries/check
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 1.2,
  "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements"
}
```

**Response 200** (application/json)

```json
{
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "draft": {
    "work_date": "2026-11-13",
    "hours": 1.2,
    "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements"
  },
  "ok": true,
  "can_post": true,
  "billable_hours": 1.2,
  "violations": [],
  "suggested_splits": [],
  "rules_checked": 5
}
```

Adaptive Card the user would see: `cards/13-checkTimeEntry.json`

## 14. Record the corrected entry (after the user confirms)

The write. The user confirmed in Copilot before this call.

```http
POST /time-entries
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
Idempotency-Key: demo-time-good-0001
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 1.2,
  "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements"
}
```

**Response 201** (application/json)

```json
{
  "time_entry": {
    "id": "TE-0041",
    "matter_id": "M-0412",
    "user_id": "u-jordan",
    "work_date": "2026-11-13",
    "hours": 1.2,
    "billable_hours": 1.2,
    "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements",
    "status": "unbilled",
    "recorded_at": "2026-11-13T17:00:00.000Z"
  },
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "notes": []
}
```

Adaptive Card the user would see: `cards/14-createTimeEntry.json`

## 15. The client retries the same request

Same Idempotency-Key: the original response is replayed and nothing is written twice.

```http
POST /time-entries
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
Idempotency-Key: demo-time-good-0001
```

```json
{
  "matter_id": "M-0412",
  "work_date": "2026-11-13",
  "hours": 1.2,
  "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements"
}
```

**Response 201** (application/json), header `Idempotent-Replayed: true`

```json
{
  "time_entry": {
    "id": "TE-0041",
    "matter_id": "M-0412",
    "user_id": "u-jordan",
    "work_date": "2026-11-13",
    "hours": 1.2,
    "billable_hours": 1.2,
    "narrative": "Reviewed owner-directed change order provisions in prime contract to assess delay-claim notice requirements",
    "status": "unbilled",
    "recorded_at": "2026-11-13T17:00:00.000Z"
  },
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "client": {
    "id": "C-100",
    "name": "Halvorsen Pacific Builders, Inc."
  },
  "notes": []
}
```

Adaptive Card the user would see: `cards/15-createTimeEntry.json`

## 16. Who has not acknowledged the existing hold?

Hold Manager's first question.

```http
GET /matters/M-0412/lit-holds
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
```

**Response 200** (application/json)

```json
{
  "matter": {
    "id": "M-0412",
    "number": "TG-2026-0412",
    "name": "Halvorsen Pacific Builders v. Marlow Unified School District (Harbor Middle School delay claim)"
  },
  "holds": [
    {
      "id": "H-1001",
      "title": "Harbor Middle School project documents",
      "issued_by": "Aanya Desai",
      "issued_at": "2026-03-12T16:00:00Z",
      "pending_count": 2,
      "custodians": [
        {
          "name": "Dale Whitaker",
          "email": "dale.whitaker@halvorsen-builders.example",
          "role": "Project manager",
          "status": "acknowledged",
          "acknowledged_at": "2026-03-13T15:20:00Z",
          "reminder_count": 0,
          "last_reminded_at": null
        },
        {
          "name": "Rosa Lindqvist",
          "email": "rosa.lindqvist@halvorsen-builders.example",
          "role": "Project controls engineer",
          "status": "acknowledged",
          "acknowledged_at": "2026-03-14T18:05:00Z",
          "reminder_count": 0,
          "last_reminded_at": null
        },
        {
          "name": "Bennett Okoye",
          "email": "bennett.okoye@halvorsen-builders.example",
          "role": "Site superintendent",
          "status": "pending",
          "acknowledged_at": null,
          "reminder_count": 2,
          "last_reminded_at": "2026-03-28T17:00:00Z"
        },
        {
          "name": "Maribel Santos",
          "email": "maribel.santos@halvorsen-builders.example",
          "role": "Accounting manager",
          "status": "pending",
          "acknowledged_at": null,
          "reminder_count": 1,
          "last_reminded_at": "2026-03-21T17:00:00Z"
        }
      ]
    }
  ],
  "outstanding_total": 2
}
```

Adaptive Card the user would see: `cards/16-listLitHolds.json`

## 17. Issue a new litigation hold (after the user confirms)

Creates the hold and returns its id and notice text.

```http
POST /matters/M-0388/lit-holds
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
Idempotency-Key: demo-hold-new-0001
```

```json
{
  "title": "Cedar Ridge project documents",
  "scope_description": "All documents and ESI relating to the Cedar Ridge mixed-use project: contracts, pay applications, lien and stop-notice correspondence, schedules and daily reports.",
  "custodians": [
    {
      "name": "Pat Quill",
      "email": "pat.quill@halvorsen-builders.example",
      "role": "Project engineer"
    },
    {
      "name": "Imani Brooks",
      "email": "imani.brooks@halvorsen-builders.example",
      "role": "Controller"
    }
  ]
}
```

**Response 201** (application/json)

```json
{
  "id": "H-1003",
  "matter": {
    "id": "M-0388",
    "number": "TG-2026-0388",
    "name": "Halvorsen Pacific Builders: Cedar Ridge mixed-use lien defense"
  },
  "title": "Cedar Ridge project documents",
  "scope_description": "All documents and ESI relating to the Cedar Ridge mixed-use project: contracts, pay applications, lien and stop-notice correspondence, schedules and daily reports.",
  "issued_by": "Jordan Reyes",
  "issued_at": "2026-11-13T17:00:00.000Z",
  "pending_count": 2,
  "custodians": [
    {
      "name": "Pat Quill",
      "email": "pat.quill@halvorsen-builders.example",
      "role": "Project engineer",
      "status": "pending",
      "acknowledged_at": null,
      "reminder_count": 0,
      "last_reminded_at": null
    },
    {
      "name": "Imani Brooks",
      "email": "imani.brooks@halvorsen-builders.example",
      "role": "Controller",
      "status": "pending",
      "acknowledged_at": null,
      "reminder_count": 0,
      "last_reminded_at": null
    }
  ],
  "notice_text": "PRIVILEGED AND CONFIDENTIAL. ATTORNEY-CLIENT COMMUNICATION.\nLITIGATION HOLD NOTICE H-1003: Cedar Ridge project documents\nMatter: Halvorsen Pacific Builders: Cedar Ridge mixed-use lien defense (TG-2026-0388)\nIssued: 2026-11-13 by Jordan Reyes, Thornwood Garza LLP\n\nYou are receiving this notice because you may have documents or data relevant to the matter above. Effective immediately, you must preserve, and must not delete, alter, overwrite or discard, anything within the scope below, in any form: paper, email, text and chat messages, files on shared drives and personal devices, calendars, photographs and voicemail.\n\nScope: All documents and ESI relating to the Cedar Ridge mixed-use project: contracts, pay applications, lien and stop-notice correspondence, schedules and daily reports.\n\nSuspend any automatic deletion that could affect these materials. If you are unsure whether something is covered, preserve it and ask. This hold remains in effect until you are told in writing that it has been released.\nPlease reply to confirm that you have received and will comply with this notice.\n\nDRAFT FOR ATTORNEY REVIEW: an attorney must review this notice before it is relied on.",
  "distribution": "Simulated: this demo records the hold and returns the notice text; no email is sent."
}
```

Adaptive Card the user would see: `cards/17-issueLitHold.json`

## 18. Remind custodians who have not acknowledged the first hold (after the user confirms)

Only the pending custodians are reminded.

```http
POST /lit-holds/H-1001/acknowledge-reminders
Authorization: Bearer FAKE-DEMO-TOKEN-jordan
Idempotency-Key: demo-reminders-0001
```

```json
{}
```

**Response 200** (application/json)

```json
{
  "hold_id": "H-1001",
  "reminded": [
    {
      "name": "Bennett Okoye",
      "email": "bennett.okoye@halvorsen-builders.example",
      "reminder_count": 3
    },
    {
      "name": "Maribel Santos",
      "email": "maribel.santos@halvorsen-builders.example",
      "reminder_count": 2
    }
  ],
  "already_acknowledged": [
    "dale.whitaker@halvorsen-builders.example",
    "rosa.lindqvist@halvorsen-builders.example"
  ],
  "distribution": "Simulated: this demo records the reminder; no email is sent."
}
```

Adaptive Card the user would see: `cards/18-sendHoldReminders.json`

## Audit log (from the server's database after the run)

| # | user | action | matter | outcome | idempotency key |
|---|---|---|---|---|---|
| 1 | u-marcus | wall.denied | M-0421 | denied |  |
| 2 | u-marcus | wall.denied | M-0421 | denied |  |
| 3 | u-jordan | time_entry.rejected | M-0412 | rejected | demo-time-bad-0001 |
| 4 | u-jordan | time_entry.created | M-0412 | ok | demo-time-good-0001 |
| 5 | u-jordan | lit_hold.issued | M-0388 | ok | demo-hold-new-0001 |
| 6 | u-jordan | lit_hold.reminders_sent | M-0412 | ok | demo-reminders-0001 |
