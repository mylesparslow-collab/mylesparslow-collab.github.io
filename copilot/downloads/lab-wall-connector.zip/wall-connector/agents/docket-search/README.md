# Docket Search (agent)

Declarative agent v1.9 grounded on the `thornwooddocket` Graph connector (capability `GraphConnectors`, `connection_id: thornwooddocket`). It answers "what was filed last in the Pruitt case" with the entry title, court, case number, filed date and link, and answers "No docket entries you have access to match that." instead of guessing. It never reveals whether a walled matter exists, because the index never returns walled items to the asker. `behavior_overrides.special_instructions.discourage_model_knowledge` is `true`.

There is no plugin manifest: knowledge comes from the connector capability, not an action. The connector itself is built and tested one level up (`../../README.md`).

Files: `appPackage/manifest.json`, `declarativeAgent.json`, `instructions.txt`, `color.png`, `outline.png`.

Not verified: the package has not been uploaded to a tenant, and the connection `thornwooddocket` has never existed in one. The manifest is checked only against the v1.9 properties listed in the kit conventions (JSON parses; instructions under 8000 characters).
