import json

import httpx
import pytest

from connector.graph import DryRunTransport, GraphClient, GraphError
from connector.sync import Syncer
from seed.firm import snapshot

from .conftest import uid


def test_full_sync_counts(syncer, mock):
    rep = syncer.run(snapshot("t0"), "full")
    s = rep.summary()
    assert (s["item_puts"], s["groups_created"], s["connection_created"], s["schema_patched"]) == (50, 10, True, True)
    # m06 team: 4 listed, okafor walled out -> 3; m04: 4 listed, lindqvist walled out -> 3
    assert len(mock.connections["thornwooddocket"]["groups"]["m06team"]["members"]) == 3
    assert len(mock.connections["thornwooddocket"]["items"]) == 50


def test_second_full_run_sends_zero_item_puts(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    puts_before = mock.count("PUT")
    rep = syncer.run(snapshot("t0"), "full")
    assert mock.count("PUT") == puts_before
    assert rep.summary()["item_puts"] == 0 and rep.skipped_unchanged == 50
    assert not rep.schema_patched and not rep.groups_created and rep.members_added == 0


def test_state_file_survives_a_new_process(client, tmp_path, mock):
    Syncer(client, tmp_path / "s.json", poll_interval=0).run(snapshot("t0"), "full")
    n = mock.count("PUT")
    Syncer(client, tmp_path / "s.json", poll_interval=0).run(snapshot("t0"), "full")
    assert mock.count("PUT") == n


def test_incremental_diff(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    rep = syncer.run(snapshot("t1"), "incremental")
    # amended entry, new entry, and every item of the newly walled matter (4 docket entries + 1 note)
    m03_items = {f"m03e0{i}" for i in range(1, 5)} | {"m03n01"}
    assert set(rep.item_puts) == {"m02e04", "m01e05"} | m03_items
    assert rep.item_deletes == ["m08e04"]
    assert rep.wall_added_matters == ["m03"]
    assert (rep.members_removed, rep.members_added) == (3, 1)  # out: brandt, gallagher, delacroix (walled); in: espinoza
    assert "m08e04" not in mock.connections["thornwooddocket"]["items"]


def test_new_wall_items_pushed_before_any_group_change(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    mark = len(mock.log)
    syncer.run(snapshot("t1"), "incremental")
    seq = mock.log[mark:]
    first_group_op = next(i for i, (m, p) in enumerate(seq) if "/groups" in p)
    wall_puts = [i for i, (m, p) in enumerate(seq) if m == "PUT" and "/items/m03" in p]
    assert wall_puts and max(wall_puts) < first_group_op


def test_incremental_twice_is_quiet(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    syncer.run(snapshot("t1"), "incremental")
    n = mock.count("PUT")
    rep = syncer.run(snapshot("t1"), "incremental")
    assert mock.count("PUT") == n and rep.summary()["item_deletes"] == 0


def test_full_crawl_also_deletes_missing_items(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    rep = syncer.run(snapshot("t1"), "full")
    assert rep.item_deletes == ["m08e04"]


def test_429_is_retried_honouring_retry_after(syncer, mock, client):
    mock.inject_429(3, retry_after=7, when=lambda r: r.method == "PUT")
    rep = syncer.run(snapshot("t0"), "full")
    assert rep.retries == 3 and client.slept.count(7.0) == 3
    assert len(mock.connections["thornwooddocket"]["items"]) == 50


def test_429_without_retry_after_uses_jittered_backoff(mock):
    import random
    slept = []
    c = GraphClient(base_url=mock.base, token=lambda: "t", transport=mock.transport(), sleep=slept.append,
                    rng=random.Random(1))
    mock.inject_429(2)
    mock._inject[0]["ra"] = ""   # header present but not a number -> backoff path
    c.request("GET", "/external/connections")
    assert len(slept) == 2 and all(0 <= s <= 30 for s in slept)


def test_gives_up_after_max_retries(mock):
    c = GraphClient(base_url=mock.base, token=lambda: "t", transport=mock.transport(), sleep=lambda s: None, max_retries=2)
    mock.inject_429(99)
    with pytest.raises(GraphError) as e:
        c.request("GET", "/external/connections")
    assert e.value.status == 429


def test_schema_202_is_polled_until_completed(syncer, mock, client):
    syncer.run(snapshot("t0"), "full")
    polls = mock.count("GET", "/operations/")
    assert polls == mock.polls + 1          # notStarted, running, then completed
    assert mock.connections["thornwooddocket"]["schema"]


def test_schema_operation_failure_raises(mock):
    c = GraphClient(base_url=mock.base, token=lambda: "t", transport=httpx.MockTransport(
        lambda r: httpx.Response(200, json={"status": "failed", "error": {"message": "boom"}})), sleep=lambda s: None)
    with pytest.raises(GraphError, match="failed"):
        c.wait_operation("https://x/operations/1", 0)


def test_paging_follows_nextlink(mock, client):
    for i in range(5):
        client.request("POST", "/external/connections", {"id": f"conn{i}", "name": "x"})
    assert [c["id"] for c in client.get_all("/external/connections")] == [f"conn{i}" for i in range(5)]
    assert mock.count("GET", "/connections") == 3   # page size 2 -> 3 pages


def test_existing_connection_is_not_recreated(syncer, mock, client):
    client.request("POST", "/external/connections", {"id": "thornwooddocket", "name": "pre-existing"})
    rep = syncer.run(snapshot("t0"), "full")
    assert not rep.connection_created


def test_dry_run_writes_requests_and_sends_nothing(tmp_path):
    out = tmp_path / "requests"
    c = GraphClient(token=lambda: "x", transport=DryRunTransport(out))
    s = Syncer(c, tmp_path / "state.json", dry_run=True, poll_interval=0)
    rep = s.run(snapshot("t0"), "full")
    files = sorted(out.glob("*.json"))
    assert len(files) > 90 and rep.summary()["item_puts"] == 50
    assert not (tmp_path / "state.json").exists()          # dry run never records state
    put = json.loads(next(f for f in files if "PUT-" in f.name).read_text())
    assert put["method"] == "PUT" and put["body"]["acl"][0]["type"] == "externalGroup"
    assert "authorization" not in {k.lower() for k in put["headers"]}
