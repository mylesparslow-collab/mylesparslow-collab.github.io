import json
from pathlib import Path

from connector.sync import CONNECTION_ID

A = Path(__file__).resolve().parent.parent / "agents" / "docket-search" / "appPackage"
ALLOWED = {"$schema", "version", "name", "description", "instructions", "conversation_starters", "capabilities",
           "actions", "behavior_overrides", "disclaimer", "sensitivity_label", "editorial_answers", "agent_skills",
           "worker_agents", "user_overrides"}


def test_declarative_agent_v19():
    d = json.loads((A / "declarativeAgent.json").read_text())
    assert d["version"] == "v1.9" and "v1.9" in d["$schema"]
    assert set(d) <= ALLOWED and len(d["name"]) <= 100 and len(d["description"]) <= 1000
    assert len(d["conversation_starters"]) <= 12
    cap = d["capabilities"][0]
    assert cap == {"name": "GraphConnectors", "connections": [{"connection_id": CONNECTION_ID}]}
    assert d["behavior_overrides"]["special_instructions"]["discourage_model_knowledge"] is True
    ins = (A / "instructions.txt").read_text()
    assert len(ins) <= 8000
    for must in ("No docket entries you have access to match that.", "Not stated in the document.",
                 "Docketing to calculate", "An attorney must review this"):
        assert must in ins
