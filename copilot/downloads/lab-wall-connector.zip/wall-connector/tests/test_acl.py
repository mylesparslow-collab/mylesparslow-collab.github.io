import random
import uuid

from connector import acl
from mockgraph import MockGraph


def _conn(gid, members):
    return {"groups": {gid: {"members": {("user", m) for m in members}}}}


def test_acl_shape():
    a = acl.build_acl("m06", ["u2", "u1"])
    assert a[0] == {"type": "externalGroup", "value": "m06team", "accessType": "grant"}
    assert a[1:] == [{"type": "user", "value": "u1", "accessType": "deny"},
                     {"type": "user", "value": "u2", "accessType": "deny"}]
    assert acl.group_id("m06").isalnum()


def test_property_walled_user_never_granted_and_deny_always_present():
    rng = random.Random(8723)
    m = MockGraph()
    for _ in range(500):
        universe = [str(uuid.UUID(int=rng.getrandbits(128))) for _ in range(rng.randint(1, 15))]
        team = rng.sample(universe, rng.randint(0, len(universe)))
        walled = rng.sample(universe, rng.randint(0, len(universe)))   # may overlap the team: stale staffing
        a = acl.build_acl("mx", walled)
        members = acl.group_members(team, walled)
        denies = {e["value"] for e in a if e["accessType"] == "deny"}
        assert denies == set(walled)                                   # deny present for each walled user
        assert all(e["type"] == "user" for e in a if e["accessType"] == "deny")
        conn = _conn("mxteam", members)
        stale = _conn("mxteam", set(members) | set(walled))            # wall must hold even if membership is wrong
        for u in universe:
            expected = u in team and u not in walled
            assert m.acl_allows(conn, a, u) == expected
            if u in walled:
                assert not m.acl_allows(conn, a, u) and not m.acl_allows(stale, a, u)
                assert u not in members
