import pytest

from connector.graph import GraphClient
from connector.sync import CONNECTION_ID, Syncer
from mockgraph import MockGraph
from seed.firm import USERS, snapshot, upn


@pytest.fixture
def mock():
    return MockGraph()


@pytest.fixture
def client(mock):
    """Client wired to the mock; sleeps are recorded, not performed."""
    c = GraphClient(base_url=mock.base, token=lambda: "test-token", transport=mock.transport(),
                    sleep=lambda s: c.slept.append(s))
    c.slept = []
    return c


@pytest.fixture
def syncer(client, tmp_path):
    return Syncer(client, tmp_path / "state.json", poll_interval=0)


def uid(last: str) -> str:
    return USERS[upn(last)]["id"]


def hits(mock, last: str, q: str):
    return mock.search(CONNECTION_ID, uid(last), q)


__all__ = ["snapshot", "uid", "hits"]
