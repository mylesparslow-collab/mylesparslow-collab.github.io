"""A bad answer for one group must not stop the run, and must never leave access open."""
from connector.sync import CONNECTION_ID, Syncer

from .conftest import hits, snapshot, uid


def groups(mock):
    return mock.connections[CONNECTION_ID]["groups"]


def delete_of(last, gid):
    return lambda r: r.method == "DELETE" and f"/groups/{gid}/members/{uid(last)}" in r.url.path


def test_404_on_member_delete_is_already_done(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    groups(mock)["m01team"]["members"] = {x for x in groups(mock)["m01team"]["members"] if x[1] != uid("brandt")}
    rep = syncer.run(snapshot("t1"), "incremental")          # brandt is removed from m01 at t1, but is already gone
    assert not rep.errors and any("404" in a and "m01team" in a for a in rep.already_done)
    assert (rep.members_removed, rep.members_added) == (2, 1)  # the other removals and the add still happened
    assert hits(mock, "brandt", "Pruitt") == []
    assert hits(mock, "delacroix", "Calder") == [] and hits(mock, "gallagher", "Calder") == []
    assert syncer.state["groups"]["m01team"] == sorted(x[1] for x in groups(mock)["m01team"]["members"])


def test_injected_404_then_next_run_is_clean(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    mock.inject_error(404, when=delete_of("brandt", "m01team"))
    rep = syncer.run(snapshot("t1"), "incremental")
    assert not rep.errors and len(rep.already_done) == 1
    # (the injected 404 is a lie, so brandt really stays in the mock group; this test is about the run
    # completing and the other groups being handled, the real-404 test above checks the access result)
    assert hits(mock, "delacroix", "Calder") == []
    again = syncer.run(snapshot("t1"), "incremental")
    assert not again.errors and not again.already_done and again.item_puts == []


def test_409_on_group_create_after_state_loss(client, mock, tmp_path):
    Syncer(client, tmp_path / "a.json", poll_interval=0).run(snapshot("t0"), "full")
    fresh = Syncer(client, tmp_path / "lost.json", poll_interval=0)      # state file lost
    rep = fresh.run(snapshot("t0"), "full")
    assert not rep.errors and len([a for a in rep.already_done if "create group" in a]) == 10
    assert hits(mock, "okafor", "Quillon") == []
    nxt = Syncer(client, tmp_path / "lost.json", poll_interval=0).run(snapshot("t0"), "full")
    assert not nxt.errors and not nxt.already_done and nxt.item_puts == []


def test_injected_409_on_one_group_create(syncer, mock):
    rep0 = syncer.run(snapshot("t0"), "full")
    assert not rep0.errors
    syncer.state["groups"].pop("m05team")                # state drift: we forget one group that does exist
    mock.inject_error(409, when=lambda r: r.method == "POST" and r.url.path.endswith("/groups"))
    rep = syncer.run(snapshot("t0"), "full")
    assert not rep.errors and len(rep.already_done) == 1 and rep.groups_created == []
    assert len(syncer.state["groups"]) == 10


def test_failed_removal_continues_other_groups_and_blocks_adds_for_that_group(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    mock.inject_error(403, times=99, when=delete_of("brandt", "m01team"))      # hard failure, not ignorable
    mark = len(mock.log)
    rep = syncer.run(snapshot("t1"), "incremental")
    seq = mock.log[mark:]
    assert len(rep.errors) == 1 and "m01team" in rep.errors[0]
    # other groups' removals and all item pushes still happened
    assert hits(mock, "delacroix", "Calder") == [] and hits(mock, "gallagher", "Calder") == []
    assert set(rep.item_puts) >= {"m01e05", "m02e04", "m03e01"} and rep.item_deletes == ["m08e04"]
    # nothing was granted to m01team after the failed removal
    assert not any(m == "POST" and p.endswith("/groups/m01team/members") for m, p in seq)
    # state keeps the stale member so the next run retries the removal
    assert uid("brandt") in syncer.state["groups"]["m01team"]
    assert syncer.state["groups"]["m03team"] == sorted(x[1] for x in groups(mock)["m03team"]["members"])
    mock._inject.clear()
    fixed = syncer.run(snapshot("t1"), "incremental")
    assert not fixed.errors and fixed.members_removed == 1
    assert hits(mock, "brandt", "Pruitt") == []
    assert not syncer.run(snapshot("t1"), "incremental").errors


def test_walled_user_still_denied_when_group_step_is_stuck(syncer, mock):
    """Wall added at t1 for m03; the m03 group removals fail, yet the re-pushed items carry the deny."""
    syncer.run(snapshot("t0"), "full")
    mock.inject_error(403, times=99, when=lambda r: r.method == "DELETE" and "/groups/m03team/" in r.url.path)
    rep = syncer.run(snapshot("t1"), "incremental")
    assert any("m03team" in e for e in rep.errors)
    assert {"m03e01", "m03n01"} <= set(rep.item_puts)
    assert hits(mock, "delacroix", "Calder") == []          # still in the group, still blocked by the deny entry
    assert len(hits(mock, "farouk", "Calder")) == 5


def test_failed_item_put_is_retried_next_run(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    mock.inject_error(403, when=lambda r: r.method == "PUT" and "/items/m02e04" in r.url.path)
    rep = syncer.run(snapshot("t1"), "incremental")
    assert any("m02e04" in e for e in rep.errors) and "m02e04" not in rep.item_puts
    fixed = syncer.run(snapshot("t1"), "incremental")
    assert not fixed.errors and fixed.item_puts == ["m02e04"]
