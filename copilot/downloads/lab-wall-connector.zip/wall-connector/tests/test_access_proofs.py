"""The point of the demo: confidentiality is enforced by the index, not by the prompt.
Each test runs a real sync against the mock Graph and then asks 'search as user X'."""
from connector.sync import CONNECTION_ID

from .conftest import hits, snapshot, uid


def test_proof1_walled_user_gets_zero_hits_even_though_staffing_lists_them(syncer, mock):
    s = snapshot("t0")
    assert any(u.startswith("chidi.okafor") for u in s.matters["m06"]["team"])   # stale staffing entry
    syncer.run(s, "full")
    assert hits(mock, "okafor", "Quillon") == []
    assert hits(mock, "okafor", "Mereweather") == []


def test_proof2_team_member_gets_hits(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    h = hits(mock, "castellanos", "Quillon")
    assert len(h) == 5 and all("Quillon" in x["matter"] for x in h)   # 4 docket entries + 1 matter note
    assert hits(mock, "castellanos", "Pruitt") == []                  # not on that team


def test_proof3_user_removed_from_team_loses_access_after_incremental(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    assert len(hits(mock, "brandt", "Pruitt")) == 5
    syncer.run(snapshot("t1"), "incremental")
    assert hits(mock, "brandt", "Pruitt") == []
    assert hits(mock, "ashby", "Pruitt")[0]["id"] == "m01e05"         # remaining team sees newest entry first


def test_proof4_newly_added_wall_takes_effect(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    assert len(hits(mock, "delacroix", "Calder")) == 5                 # on the team, no wall yet
    syncer.run(snapshot("t1"), "incremental")
    assert hits(mock, "delacroix", "Calder") == []
    assert len(hits(mock, "farouk", "Calder")) == 5                    # rest of the team unaffected


def test_deny_beats_a_manually_added_group_member(syncer, mock):
    """Someone adds a walled user to the group by hand: the item-level deny still wins."""
    syncer.run(snapshot("t0"), "full")
    mock.connections[CONNECTION_ID]["groups"]["m06team"]["members"].add(("user", uid("okafor")))
    assert hits(mock, "okafor", "Quillon") == []


def test_unwalled_matters_still_visible_to_walled_user(syncer, mock):
    syncer.run(snapshot("t0"), "full")
    assert len(hits(mock, "okafor", "Fennimore")) > 0                  # wall is per-matter, not per-person
