import copy

from connector import schema


def test_shipped_schema_is_valid():
    assert schema.validate(schema.build_schema()["properties"]) == []
    assert len(schema.PROPERTIES) <= 128


def test_every_label_used_once_on_retrievable_prop():
    labels = [l for p in schema.PROPERTIES for l in p.get("labels", [])]
    assert len(labels) == len(set(labels))
    assert all(p["isRetrievable"] for p in schema.PROPERTIES if p.get("labels"))
    assert {"title", "url", "createdDateTime", "lastModifiedDateTime", "authors", "containerName", "containerUrl"} <= set(labels)


def _bad(**over):
    p = copy.deepcopy(schema.PROPERTIES)
    p[0].update(over)
    return schema.validate(p)


def test_rules_reject_violations():
    assert any("name must match" in e for e in _bad(name="bad-name"))
    assert any("name must match" in e for e in _bad(name="x" * 33))
    assert any("isSearchable only" in e for e in _bad(type="dateTime", labels=[]))
    assert any("isRefinable cannot" in e for e in _bad(isRefinable=True))
    assert any("requires isRetrievable" in e for e in _bad(isRetrievable=False))
    assert any("unknown label" in e for e in _bad(labels=["nonsense"]))
    assert any("needs type" in e for e in _bad(labels=["authors"]))


def test_duplicate_label_and_count_limit():
    p = copy.deepcopy(schema.PROPERTIES)
    p[1]["labels"] = ["title"]
    assert any("used on both" in e for e in schema.validate(p))
    many = [{"name": f"p{i}", "type": "string", "isRetrievable": True} for i in range(129)]
    assert any("outside 1..128" in e for e in schema.validate(many))
    assert any("outside 1..128" in e for e in schema.validate([]))
