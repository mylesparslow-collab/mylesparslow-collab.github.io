"""Optional: serve the mock on a local port (default 8723) so the CLI can run against it.
    uv run --python 3.12 python -m mockgraph --port 8723
Extra endpoint (not Graph): GET /_search?conn=thornwooddocket&user=<guid>&q=<text>."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

import httpx

from .mock import MockGraph


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8723)
    a = ap.parse_args()
    mock = MockGraph(base=f"http://127.0.0.1:{a.port}/v1.0")

    class H(BaseHTTPRequestHandler):
        def _do(self):
            n = int(self.headers.get("Content-Length") or 0)
            data = self.rfile.read(n) if n else b""
            u = urlparse(self.path)
            if u.path == "/_search":
                q = parse_qs(u.query)
                out = json.dumps(mock.search(q["conn"][0], q["user"][0], q.get("q", [""])[0])).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
                return
            req = httpx.Request(self.command, f"http://127.0.0.1:{a.port}{self.path}", headers=dict(self.headers), content=data)
            r = mock.handle(req)
            self.send_response(r.status_code)
            for k, v in r.headers.items():
                if k.lower() not in ("content-length", "transfer-encoding"):
                    self.send_header(k, v)
            self.send_header("Content-Length", str(len(r.content))); self.end_headers(); self.wfile.write(r.content)
        do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = _do
        def log_message(self, *args): pass

    print(f"mock Graph on http://127.0.0.1:{a.port}/v1.0 (Ctrl-C to stop)")
    HTTPServer(("127.0.0.1", a.port), H).serve_forever()


if __name__ == "__main__":
    main()
