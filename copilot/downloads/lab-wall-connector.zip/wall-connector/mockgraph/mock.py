"""In-memory mock of the Graph endpoints the connector uses, plus "search as user X".

It is a mock written from the Learn docs, not from observing the real service. The access
model it applies to search results (this is the part the tests rely on):
  * an ACE of type user matches that user's id;
  * an ACE of type externalGroup matches users who are members of that group (nested
    externalGroup members are expanded; Entra "group" members are NOT expanded here);
  * type everyone / everyoneExceptGuests match every (non-guest) user;
  * the item is visible only if some grant matches AND no deny matches: deny wins.
"""
from __future__ import annotations

import json
import re
import uuid
from typing import Callable

import httpx

from connector import schema as schemamod


class MockGraph:
    def __init__(self, base="https://mock.graph.test/v1.0", page_size=2, polls_before_complete=2):
        self.base, self.page_size, self.polls = base, page_size, polls_before_complete
        self.connections: dict[str, dict] = {}
        self.ops: dict[str, dict] = {}
        self.log: list[tuple[str, str]] = []          # (method, path) of every request seen
        self._inject: list[dict] = []

    # -- test hooks ----------------------------------------------------------------------
    def inject_429(self, times: int, retry_after: int = 1, when: Callable[[httpx.Request], bool] = lambda r: True):
        self._inject.append({"left": times, "ra": retry_after, "when": when})

    def inject_error(self, status: int, times: int = 1, when: Callable[[httpx.Request], bool] = lambda r: True):
        """Answer the next `times` matching requests with this status instead of handling them."""
        self._inject.append({"left": times, "status": status, "when": when})

    def count(self, method: str, contains: str = "") -> int:
        return sum(1 for m, p in self.log if m == method and contains in p)

    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self.handle)

    # -- search as a user ----------------------------------------------------------------
    def _members(self, conn, gid, seen=None) -> set[str]:
        seen = seen or set()
        if gid in seen or gid not in conn["groups"]:
            return set()
        seen.add(gid)
        out = set()
        for typ, mid in conn["groups"][gid]["members"]:
            if typ == "user":
                out.add(mid)
            elif typ == "externalGroup":
                out |= self._members(conn, mid, seen)
        return out

    def can_see(self, conn_id: str, item_id: str, user_id: str) -> bool:
        conn = self.connections[conn_id]
        return self.acl_allows(conn, conn["items"][item_id]["acl"], user_id)

    def acl_allows(self, conn, acl, user_id) -> bool:
        def match(a):
            t, v = a["type"], a["value"]
            return (t == "user" and v == user_id) or t in ("everyone", "everyoneExceptGuests") \
                or (t == "externalGroup" and user_id in self._members(conn, v))
        return any(match(a) for a in acl if a["accessType"] == "grant") and \
            not any(match(a) for a in acl if a["accessType"] == "deny")

    def search(self, conn_id: str, user_id: str, query: str) -> list[dict]:
        conn = self.connections[conn_id]
        terms = re.findall(r"\w+", query.lower())
        hits = []
        for iid, it in conn["items"].items():
            if not self.acl_allows(conn, it["acl"], user_id):
                continue
            p = it["properties"]
            hay = " ".join(str(p.get(k, "")) for k in ("title", "summary", "caseNumber", "matterName", "documentType")
                           ) + " " + " ".join(p.get("authors", [])) + " " + it.get("content", {}).get("value", "")
            if all(t in hay.lower() for t in terms):
                hits.append({"id": iid, "title": p["title"], "url": p["url"], "filedDate": p["filedDate"],
                             "matter": p["matterName"], "documentType": p["documentType"]})
        return sorted(hits, key=lambda h: h["filedDate"], reverse=True)

    # -- HTTP surface --------------------------------------------------------------------
    def handle(self, req: httpx.Request) -> httpx.Response:
        path = req.url.path
        self.log.append((req.method, path))
        if not req.headers.get("authorization", "").startswith("Bearer "):
            return self._err(401, "InvalidAuthenticationToken")
        for inj in self._inject:
            if inj["left"] > 0 and inj["when"](req):
                inj["left"] -= 1
                if "status" in inj:
                    return self._err(inj["status"], "injected")
                return httpx.Response(429, headers={"Retry-After": str(inj["ra"])}, json={"error": {"code": "TooManyRequests"}})
        p = path.split("/v1.0", 1)[-1]
        body = json.loads(req.content) if req.content else None
        m = req.method
        if p == "/external/connections":
            return self._connections(m, req, body)
        mt = re.match(r"^/external/connections/([^/]+)(/.*)?$", p)
        if not mt:
            return self._err(404, "NotFound")
        cid, rest = mt.group(1), mt.group(2) or ""
        conn = self.connections.get(cid)
        if conn is None:
            return self._err(404, "ResourceNotFound")
        if rest == "" and m == "GET":
            return httpx.Response(200, json={"id": cid, "name": conn["name"], "state": "ready"})
        if rest == "/schema" and m == "PATCH":
            errs = schemamod.validate(body.get("properties", [])) if body.get("baseType") == "microsoft.graph.externalItem" \
                else ["baseType must be microsoft.graph.externalItem"]
            if errs:
                return self._err(400, "; ".join(errs))
            conn["pending_schema"] = body["properties"]
            op = str(uuid.uuid4())
            self.ops[op] = {"cid": cid, "polls": 0}
            return httpx.Response(202, headers={"Location": f"{self.base}/external/connections/{cid}/operations/{op}"})
        if (mo := re.match(r"^/operations/([^/]+)$", rest)) and m == "GET":
            op = self.ops.get(mo.group(1))
            if not op:
                return self._err(404, "NotFound")
            op["polls"] += 1
            if op["polls"] > self.polls:
                conn["schema"] = conn.get("pending_schema")
                return httpx.Response(200, json={"id": mo.group(1), "status": "completed"})
            return httpx.Response(200, json={"id": mo.group(1), "status": "running" if op["polls"] > 1 else "notStarted"})
        if rest == "/groups" and m == "POST":
            if not re.fullmatch(r"[A-Za-z0-9]{1,128}", body.get("id", "")):
                return self._err(400, "group id must be alphanumeric, <=128")
            if body["id"] in conn["groups"]:
                return self._err(409, "group exists")
            conn["groups"][body["id"]] = {"displayName": body.get("displayName"), "members": set()}
            return httpx.Response(201, json=body)
        if (mg := re.match(r"^/groups/([^/]+)/members(?:/([^/]+))?$", rest)):
            g = conn["groups"].get(mg.group(1))
            if g is None:
                return self._err(404, "group not found")
            if m == "POST":
                if body.get("type") not in ("user", "group", "externalGroup") or not body.get("id"):
                    return self._err(400, "bad identity")
                g["members"].add((body["type"], body["id"]))
                return httpx.Response(201, json=body)
            if m == "DELETE":
                before = len(g["members"])
                g["members"] = {x for x in g["members"] if x[1] != mg.group(2)}
                return httpx.Response(204) if len(g["members"]) < before else self._err(404, "member not found")
        if (mi := re.match(r"^/items/([^/]+)$", rest)):
            iid = mi.group(1)
            if m == "PUT":
                if conn.get("schema") is None:
                    return self._err(400, "schema not registered")
                if not body.get("acl") or not body.get("properties"):
                    return self._err(400, "acl and properties required")
                known = {x["name"] for x in conn["schema"]}
                bad = [k for k in body["properties"] if not k.endswith("@odata.type") and k not in known]
                if bad:
                    return self._err(400, f"properties not in schema: {bad}")
                conn["items"][iid] = body
                return httpx.Response(200)
            if m == "DELETE":
                return httpx.Response(204) if conn["items"].pop(iid, None) is not None else self._err(404, "item not found")
        return self._err(404, "NotFound")

    def _connections(self, m, req, body):
        if m == "POST":
            if body["id"] in self.connections:
                return self._err(409, "exists")
            self.connections[body["id"]] = {"name": body.get("name"), "schema": None, "groups": {}, "items": {}}
            return httpx.Response(201, json=body)
        if m == "GET":  # paged with $skip in nextLink
            skip = int(req.url.params.get("$skip", 0))
            ids = sorted(self.connections)
            page = [{"id": i, "name": self.connections[i]["name"]} for i in ids[skip:skip + self.page_size]]
            out = {"value": page}
            if skip + self.page_size < len(ids):
                out["@odata.nextLink"] = f"{self.base}/external/connections?$skip={skip + self.page_size}"
            return httpx.Response(200, json=out)
        return self._err(405, "method")

    @staticmethod
    def _err(code, msg):
        return httpx.Response(code, json={"error": {"code": str(code), "message": msg}})
