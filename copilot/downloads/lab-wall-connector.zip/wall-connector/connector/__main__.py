"""CLI.  Examples (all fake data):
  python -m connector --source t0 --mode full --dry-run            writes out/requests/*.json, sends nothing
  python -m connector --source t0 --mode full --mock               runs against an in-process mock Graph
  python -m connector --source t1 --mode incremental --base-url http://127.0.0.1:8723/v1.0 --state out/state.json
Without --mock/--dry-run/--base-url it would call the real Graph using the env vars in graph.py (never done here)."""
import argparse
import json
import shutil
import sys
from pathlib import Path

from mockgraph import MockGraph
from seed.firm import snapshot

from .graph import DryRunTransport, GraphClient
from .sync import Syncer


def main(argv=None):
    ap = argparse.ArgumentParser(prog="connector")
    ap.add_argument("--source", choices=["t0", "t1"], default="t0")
    ap.add_argument("--mode", choices=["full", "incremental"], default="full")
    ap.add_argument("--dry-run", action="store_true", help="write requests to out/requests, send nothing")
    ap.add_argument("--mock", action="store_true", help="in-process mock Graph (no network)")
    ap.add_argument("--base-url")
    ap.add_argument("--state", default="out/state.json")
    ap.add_argument("--out", default="out")
    a = ap.parse_args(argv)
    if a.dry_run:
        req_dir = Path(a.out) / "requests"
        shutil.rmtree(req_dir, ignore_errors=True)
        client = GraphClient(transport=DryRunTransport(req_dir), token=lambda: "dry-run")
    elif a.mock:
        client = GraphClient(base_url="https://mock.graph.test/v1.0", token=lambda: "mock", transport=MockGraph().transport())
    else:
        client = GraphClient(base_url=a.base_url, token=(lambda: "mock") if a.base_url else None)
    rep = Syncer(client, a.state, dry_run=a.dry_run, poll_interval=0.2 if (a.mock or a.base_url) else 5).run(snapshot(a.source), a.mode)
    print(json.dumps(rep.summary(), indent=2))
    for e in rep.errors:
        print("ERROR:", e, file=sys.stderr)
    return 1 if rep.errors else 0


if __name__ == "__main__":
    sys.exit(main())
