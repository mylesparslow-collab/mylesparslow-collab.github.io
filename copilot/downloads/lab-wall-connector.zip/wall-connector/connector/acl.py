"""Pure functions: matter team + ethical wall -> external group membership + item ACL.

Shapes (Microsoft Learn, checked 2026-11-13):
  acl            https://learn.microsoft.com/graph/api/resources/externalconnectors-acl
                 {type: user|group|everyone|everyoneExceptGuests|externalGroup, accessType: grant|deny,
                  value: Entra object id for user/group, or the externalGroup id}   (CONFIRMED)
  externalGroup  https://learn.microsoft.com/graph/api/externalconnectors-externalconnection-post-groups
                 POST /external/connections/{id}/groups {id (alphanumeric, <=128), displayName, description} -> 201 (CONFIRMED)
  member         https://learn.microsoft.com/graph/api/externalconnectors-externalgroup-post-members
                 POST /external/connections/{id}/groups/{gid}/members {id, type: user|group|externalGroup} -> 201 (CONFIRMED)
NOT CONFIRMED by me: the exact semantics "deny wins over grant" (taken from the lab brief; the
mock implements it) and the DELETE .../members/{id} path used to remove a member.

Defence in depth: a walled user is (1) never put in the matter's group AND (2) named in an
explicit deny entry. Either alone would hide the matter; both mean a stale staffing list or a
manually added member cannot open the wall.
"""
from __future__ import annotations


def group_id(matter_id: str) -> str:
    return f"{matter_id}team"  # alphanumeric, as the API requires


def group_members(team_user_ids: list[str], walled_user_ids: list[str]) -> list[str]:
    walled = set(walled_user_ids)
    return sorted(u for u in set(team_user_ids) if u not in walled)


def build_acl(matter_id: str, walled_user_ids: list[str]) -> list[dict]:
    acl = [{"type": "externalGroup", "value": group_id(matter_id), "accessType": "grant"}]
    acl += [{"type": "user", "value": u, "accessType": "deny"} for u in sorted(set(walled_user_ids))]
    return acl
