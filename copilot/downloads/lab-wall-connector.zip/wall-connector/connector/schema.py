"""Connection schema for the docket index plus an offline validator.

Sources (Microsoft Learn, checked 2026-11-13):
  Update schema (PATCH .../schema, 202 + Location header, baseType externalItem, 1..128 properties):
    https://learn.microsoft.com/graph/api/externalconnectors-schema-update
  Semantic labels / property rules:
    https://learn.microsoft.com/graph/api/resources/externalconnectors-property
Offline rules enforced below. CONFIRMED on Learn: 1..128 properties, baseType, 202+Location.
NOT RE-CONFIRMED by me (written from memory of the property resource page; check before a real run):
  name pattern ^[A-Za-z0-9]{1,32}$, label/type compatibility table, "a label is used once",
  "labelled properties must be retrievable", "refinable and searchable are mutually exclusive",
  "searchable only on string / stringCollection".
"""
from __future__ import annotations

import re

NAME_RE = re.compile(r"^[A-Za-z0-9]{1,32}$")
MAX_PROPERTIES = 128
TYPES = {"string", "int64", "double", "dateTime", "boolean", "stringCollection",
         "int64Collection", "doubleCollection", "dateTimeCollection"}
SEARCHABLE_TYPES = {"string", "stringCollection"}
LABEL_TYPES = {  # label -> allowed property type(s)
    "title": {"string"}, "url": {"string"}, "createdBy": {"string"}, "lastModifiedBy": {"string"},
    "authors": {"stringCollection"}, "createdDateTime": {"dateTime"}, "lastModifiedDateTime": {"dateTime"},
    "fileName": {"string"}, "fileExtension": {"string"}, "iconUrl": {"string"},
    "containerName": {"string"}, "containerUrl": {"string"},
}


def _p(name, type_, *, s=False, q=False, r=False, f=False, labels=()):
    p = {"name": name, "type": type_, "isSearchable": s, "isQueryable": q, "isRetrievable": r, "isRefinable": f}
    if labels:
        p["labels"] = list(labels)
    return p


PROPERTIES = [
    _p("title", "string", s=True, r=True, labels=["title"]),
    _p("url", "string", r=True, labels=["url"]),
    _p("summary", "string", s=True, r=True),
    _p("caseNumber", "string", s=True, q=True, r=True),
    _p("court", "string", q=True, r=True, f=True),
    _p("documentType", "string", q=True, r=True, f=True),
    _p("itemKind", "string", q=True, r=True, f=True),
    _p("matterId", "string", q=True, r=True),
    _p("matterName", "string", s=True, r=True, labels=["containerName"]),
    _p("matterUrl", "string", r=True, labels=["containerUrl"]),
    _p("filedDate", "dateTime", q=True, r=True, f=True, labels=["createdDateTime"]),
    _p("lastModified", "dateTime", q=True, r=True, labels=["lastModifiedDateTime"]),
    _p("authors", "stringCollection", s=True, r=True, labels=["authors"]),
]


def build_schema() -> dict:
    return {"baseType": "microsoft.graph.externalItem", "properties": PROPERTIES}


def validate(props: list[dict]) -> list[str]:
    errs: list[str] = []
    if not 1 <= len(props) <= MAX_PROPERTIES:
        errs.append(f"property count {len(props)} outside 1..{MAX_PROPERTIES}")
    names, seen_labels = set(), {}
    for p in props:
        n = p.get("name", "")
        if not NAME_RE.match(n):
            errs.append(f"{n!r}: name must match {NAME_RE.pattern}")
        if n in names:
            errs.append(f"{n!r}: duplicate property name")
        names.add(n)
        t = p.get("type")
        if t not in TYPES:
            errs.append(f"{n}: unknown type {t!r}")
        if p.get("isSearchable") and t not in SEARCHABLE_TYPES:
            errs.append(f"{n}: isSearchable only valid on string/stringCollection (is {t})")
        if p.get("isRefinable") and p.get("isSearchable"):
            errs.append(f"{n}: isRefinable cannot be combined with isSearchable")
        for lab in p.get("labels", []):
            if lab not in LABEL_TYPES:
                errs.append(f"{n}: unknown label {lab!r}")
                continue
            if lab in seen_labels:
                errs.append(f"label {lab!r} used on both {seen_labels[lab]} and {n}")
            seen_labels[lab] = n
            if not p.get("isRetrievable"):
                errs.append(f"{n}: label {lab!r} requires isRetrievable")
            if t not in LABEL_TYPES[lab]:
                errs.append(f"{n}: label {lab!r} needs type {sorted(LABEL_TYPES[lab])}, got {t}")
    return errs
