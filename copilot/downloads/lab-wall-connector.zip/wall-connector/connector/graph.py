"""Thin Microsoft Graph REST client (httpx). Never used against the real Graph in this lab.

Environment variables for a REAL run (see .env.example):
  GRAPH_TENANT_ID, GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET   client-credentials app registration
  GRAPH_BASE_URL                                          default https://graph.microsoft.com/v1.0
Application permissions needed (Learn, per API pages): ExternalConnection.ReadWrite.OwnedBy and
ExternalItem.ReadWrite.OwnedBy. Token endpoint: login.microsoftonline.com/{tenant}/oauth2/v2.0/token,
scope https://graph.microsoft.com/.default (standard client-credentials flow; MSAL not required).

Resilience: 429 and 502/503/504 are retried, honouring Retry-After (seconds) when present,
otherwise exponential backoff with full jitter. 202 long-running operations are polled.
"""
from __future__ import annotations

import json
import os
import random
import time
from pathlib import Path
from typing import Callable, Iterator

import httpx

DEFAULT_BASE = "https://graph.microsoft.com/v1.0"
RETRY_STATUS = {429, 502, 503, 504}


class GraphError(RuntimeError):
    def __init__(self, status: int, message: str):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status


class ClientCredentials:
    """Fetches and caches an app-only token. Reads the env vars above."""

    def __init__(self, http: httpx.Client | None = None, env=os.environ):
        self.env, self.http, self._tok, self._exp = env, http or httpx.Client(), None, 0.0

    def __call__(self) -> str:
        if self._tok and time.time() < self._exp - 60:
            return self._tok
        tenant = self.env["GRAPH_TENANT_ID"]
        r = self.http.post(
            f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
            data={"grant_type": "client_credentials", "client_id": self.env["GRAPH_CLIENT_ID"],
                  "client_secret": self.env["GRAPH_CLIENT_SECRET"], "scope": "https://graph.microsoft.com/.default"},
        )
        r.raise_for_status()
        j = r.json()
        self._tok, self._exp = j["access_token"], time.time() + int(j.get("expires_in", 3600))
        return self._tok


class DryRunTransport(httpx.BaseTransport):
    """Writes every request it is handed to out_dir/NNNN-METHOD-name.json and answers with a
    plausible success, so the sync logic can run end to end without sending anything."""

    def __init__(self, out_dir: str | Path):
        self.dir, self.n = Path(out_dir), 0
        self.dir.mkdir(parents=True, exist_ok=True)

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        self.n += 1
        path = request.url.path.split("/v1.0", 1)[-1]
        slug = "-".join(p for p in path.split("/") if p and p != "external")[-60:] or "root"
        body = json.loads(request.content) if request.content else None
        rec = {"method": request.method, "url": str(request.url),
               "headers": {k: v for k, v in request.headers.items() if k.lower() in ("content-type", "prefer")},
               "body": body}
        (self.dir / f"{self.n:04d}-{request.method}-{slug}.json").write_text(json.dumps(rec, indent=2))
        m, base = request.method, str(request.url).split("/external")[0]
        if m == "GET" and path.endswith("/connections"):
            return httpx.Response(200, json={"value": []})
        if m == "GET" and "/operations/" in path:
            return httpx.Response(200, json={"status": "completed"})
        if m == "PATCH" and path.endswith("/schema"):
            cid = path.split("/connections/")[1].split("/")[0]
            return httpx.Response(202, headers={"Location": f"{base}/external/connections/{cid}/operations/dryrun"})
        if m == "DELETE":
            return httpx.Response(204)
        return httpx.Response(201 if m == "POST" else 200, json=body or {})


class GraphClient:
    def __init__(self, base_url: str | None = None, token: Callable[[], str] | None = None,
                 transport: httpx.BaseTransport | None = None, max_retries: int = 6,
                 sleep: Callable[[float], None] = time.sleep, rng: random.Random | None = None):
        self.base = (base_url or os.environ.get("GRAPH_BASE_URL") or DEFAULT_BASE).rstrip("/")
        self.token = token or ClientCredentials()
        self.http = httpx.Client(transport=transport, timeout=30)
        self.max_retries, self.sleep, self.rng = max_retries, sleep, rng or random.Random()
        self.retries = 0  # observable by tests / sync report

    def _url(self, path: str) -> str:
        return path if path.startswith("http") else self.base + path

    def backoff(self, attempt: int, retry_after: str | None) -> float:
        if retry_after and retry_after.isdigit():
            return float(retry_after)
        return self.rng.uniform(0, min(30.0, 0.5 * 2 ** attempt))  # full jitter

    def request(self, method: str, path: str, json_body=None, headers=None, ok=(200, 201, 202, 204)) -> httpx.Response:
        for attempt in range(self.max_retries + 1):
            h = {"Authorization": f"Bearer {self.token()}", **(headers or {})}
            try:
                r = self.http.request(method, self._url(path), json=json_body, headers=h)
            except httpx.TransportError as e:
                if attempt == self.max_retries:
                    raise GraphError(0, f"transport error: {e}") from e
                self.retries += 1
                self.sleep(self.backoff(attempt, None))
                continue
            if r.status_code in RETRY_STATUS and attempt < self.max_retries:
                self.retries += 1
                self.sleep(self.backoff(attempt, r.headers.get("Retry-After")))
                continue
            if r.status_code not in ok:
                raise GraphError(r.status_code, r.text[:300])
            return r
        raise GraphError(0, "unreachable")

    def get_all(self, path: str) -> Iterator[dict]:
        """Follow @odata.nextLink until exhausted."""
        url: str | None = path
        while url:
            j = self.request("GET", url).json()
            yield from j.get("value", [])
            url = j.get("@odata.nextLink")

    def wait_operation(self, location: str, interval: float = 5.0, max_polls: int = 120) -> dict:
        """Poll a connectionOperation until completed/failed (schema registration can take minutes)."""
        for _ in range(max_polls):
            op = self.request("GET", location).json()
            if op.get("status") == "completed":
                return op
            if op.get("status") == "failed":
                raise GraphError(0, f"operation failed: {op.get('error')}")
            self.sleep(interval)
        raise GraphError(0, "operation polling timed out")
