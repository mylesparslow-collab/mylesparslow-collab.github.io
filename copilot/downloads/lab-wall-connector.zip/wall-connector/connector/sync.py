"""Full and incremental crawl of a seed Snapshot into a Graph external connection.

State file (JSON) remembers: schema hash, group memberships, walls, per-item content hash,
and a watermark. Order of operations in one run (the order matters for confidentiality):
  1. connection + schema (202, poll the operation)
  2. items of matters whose wall was ADDED since last sync (so the deny lands first)
  3. groups: create, then remove members before adding members
  4. every other new/changed item
  5. deletes (full: anything in state but not at source; incremental: source tombstones)
Full crawl looks at every source item. Incremental looks only at items modified after the
watermark or whose matter's wall changed, plus tombstones. Both skip unchanged hashes, so a
second run of either sends zero item PUTs.

Failure handling (each group and each item is independent; one failure never aborts the run):
  * 404 on a member DELETE, 409 on a group create and 409 on a member add mean "already done":
    logged, counted in Report.already_done, treated as success.
  * Any other GraphError on a group, item PUT or item DELETE is recorded in Report.errors and the
    run carries on. State is saved for everything that succeeded; the CLI exits non-zero if any
    error was recorded. Connection/schema failures are fatal (nothing can proceed without them).
  * SAFETY ORDERING. Inside one group, removals run first and member adds only run if every
    removal succeeded; if a removal failed (or the group could not be created) nothing is granted
    for that group in this run, and its state keeps the stale member so the next run retries the
    removal. A matter whose wall-bearing item PUT failed also gets no member adds this run.
  * Items are pushed even when their matter's group update failed. The item ACL carries the
    explicit deny entries for walled users, and deny wins over any group grant, so re-pushing the
    items is the backstop that still closes a wall while group membership is stuck. (A user merely
    taken off a team, not walled, is only closed by the group removal, so that stays an error.)
  * Items whose PUT failed are retried next run: the watermark is not advanced and the stored
    wall for that matter is not updated, so an incremental run re-evaluates them.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

from . import acl as aclmod
from . import items as itemmod
from . import schema as schemamod
from .graph import GraphClient, GraphError

CONNECTION_ID = "thornwooddocket"
log = logging.getLogger("connector.sync")


@dataclass
class Report:
    mode: str
    schema_patched: bool = False
    connection_created: bool = False
    groups_created: list = field(default_factory=list)
    members_added: int = 0
    members_removed: int = 0
    item_puts: list = field(default_factory=list)
    item_deletes: list = field(default_factory=list)
    skipped_unchanged: int = 0
    wall_added_matters: list = field(default_factory=list)
    retries: int = 0
    already_done: list = field(default_factory=list)   # 404 member delete / 409 create or add
    errors: list = field(default_factory=list)         # non-ignorable failures; run continued

    def summary(self) -> dict:
        return {"mode": self.mode, "connection_created": self.connection_created,
                "schema_patched": self.schema_patched, "groups_created": len(self.groups_created),
                "members_added": self.members_added, "members_removed": self.members_removed,
                "item_puts": len(self.item_puts), "item_deletes": len(self.item_deletes),
                "skipped_unchanged": self.skipped_unchanged, "wall_added_matters": self.wall_added_matters,
                "http_retries": self.retries,
                "already_done": len(self.already_done), "errors": len(self.errors)}


def _empty_state() -> dict:
    return {"connection": False, "schema_hash": None, "groups": {}, "walls": {}, "items": {}, "watermark": ""}


class Syncer:
    def __init__(self, client: GraphClient, state_path: str | Path, dry_run: bool = False,
                 connection_id: str = CONNECTION_ID, poll_interval: float = 5.0):
        self.c, self.path, self.dry, self.cid, self.poll = client, Path(state_path), dry_run, connection_id, poll_interval
        self.state = json.loads(self.path.read_text()) if self.path.exists() else _empty_state()

    def save(self) -> None:
        if not self.dry:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.state, indent=1, sort_keys=True))

    # -- steps -------------------------------------------------------------------------
    def _ensure_connection(self, rep: Report) -> None:
        if self.state["connection"]:
            return
        existing = {c["id"] for c in self.c.get_all("/external/connections")}  # paged
        if self.cid not in existing:
            self.c.request("POST", "/external/connections", {
                "id": self.cid, "name": "Thornwood Garza docket",
                "description": "Docket entries and matter notes with ethical-wall ACLs (demo data)"})
            rep.connection_created = True
        self.state["connection"] = True

    def _ensure_schema(self, rep: Report) -> None:
        body = schemamod.build_schema()
        errs = schemamod.validate(body["properties"])
        if errs:
            raise ValueError("schema invalid: " + "; ".join(errs))
        h = itemmod.content_hash(body)
        if self.state["schema_hash"] == h:
            return
        r = self.c.request("PATCH", f"/external/connections/{self.cid}/schema", body,
                           headers={"Prefer": "respond-async"}, ok=(202,))
        self.c.wait_operation(r.headers["Location"], self.poll)
        self.state["schema_hash"] = h
        rep.schema_patched = True

    def _put(self, iid: str, body: dict, h: str, rep: Report) -> None:
        self.c.request("PUT", f"/external/connections/{self.cid}/items/{iid}", body, ok=(200, 201, 204))
        self.state["items"][iid] = h
        rep.item_puts.append(iid)

    def _already(self, rep: Report, what: str) -> None:
        log.warning("already done, treated as success: %s", what)
        rep.already_done.append(what)

    def _sync_group(self, base: str, gid: str, m: dict, mid: str, want: list, allow_adds: bool, rep: Report) -> None:
        have = self.state["groups"].get(gid)
        if have is None:
            try:
                self.c.request("POST", base, {"id": gid, "displayName": f"{m['name']} team",
                                              "description": f"Matter team for {mid}"})
                rep.groups_created.append(gid)
            except GraphError as e:
                if e.status != 409:
                    raise
                # Group exists (state file lost). Its real members are unknown, so we assume none; see README.
                self._already(rep, f"create group {gid}: 409")
            have = []
            self.state["groups"][gid] = []
        have = list(have)
        for uid in sorted(set(have) - set(want)):           # removals first: closing access is urgent
            try:
                self.c.request("DELETE", f"{base}/{gid}/members/{uid}")
                rep.members_removed += 1
            except GraphError as e:
                if e.status != 404:
                    raise                                    # stale member stays in state; adds below never run
                self._already(rep, f"remove member {uid} from {gid}: 404")
            have.remove(uid)
            self.state["groups"][gid] = sorted(have)
        if not allow_adds:
            raise GraphError(0, f"{gid}: adds skipped, wall item push failed for this matter")
        for uid in sorted(set(want) - set(have)):
            try:
                self.c.request("POST", f"{base}/{gid}/members", {"id": uid, "type": "user"})
                rep.members_added += 1
            except GraphError as e:
                if e.status != 409:
                    raise
                self._already(rep, f"add member {uid} to {gid}: 409")
            have.append(uid)
            self.state["groups"][gid] = sorted(have)

    def _sync_groups(self, snap, rep: Report, no_adds: set = frozenset()) -> set:
        """Each group on its own; returns the ids of matters whose group update failed."""
        base = f"/external/connections/{self.cid}/groups"
        failed = set()
        for mid, m in snap.matters.items():
            gid = aclmod.group_id(mid)
            want = aclmod.group_members([snap.users[u]["id"] for u in m["team"]],
                                        [snap.users[u]["id"] for u in snap.walls.get(mid, [])])
            try:
                self._sync_group(base, gid, m, mid, want, mid not in no_adds, rep)
            except GraphError as e:
                failed.add(mid)
                rep.errors.append(f"group {gid}: {e}")
                log.error("group %s failed, continuing: %s", gid, e)
        return failed

    # -- run ---------------------------------------------------------------------------
    def run(self, snap, mode: str = "full") -> Report:
        assert mode in ("full", "incremental")
        rep = Report(mode)
        r0 = self.c.retries
        try:
            self._ensure_connection(rep)
            self._ensure_schema(rep)

            uid = lambda u: snap.users[u]["id"]
            walls_now = {m: sorted(uid(u) for u in snap.walls.get(m, [])) for m in snap.matters}
            old_walls = self.state["walls"]
            added = [m for m in snap.matters if m in old_walls and set(walls_now[m]) - set(old_walls[m])]
            changed_wall = {m for m in snap.matters if m in old_walls and walls_now[m] != old_walls[m]}
            rep.wall_added_matters = added

            desired = {}
            for e in snap.entries:
                m = snap.matters[e["matter"]]
                if mode == "incremental" and e["modified"] <= self.state["watermark"] and m["id"] not in changed_wall \
                        and e["id"] in self.state["items"]:
                    continue
                body = itemmod.build_item(e, m, aclmod.build_acl(m["id"], walls_now[m["id"]]))
                desired[e["id"]] = (e["matter"], body, itemmod.content_hash(body))

            item_failed = set()                                      # matters with a failed item PUT

            def push(ids):
                for iid in ids:
                    mid, body, h = desired[iid]
                    if self.state["items"].get(iid) == h:
                        rep.skipped_unchanged += 1
                        continue
                    try:
                        self._put(iid, body, h, rep)
                    except GraphError as e:
                        item_failed.add(mid)
                        rep.errors.append(f"item {iid}: {e}")
                        log.error("item %s failed, continuing: %s", iid, e)

            first = [i for i, (m, _, _) in desired.items() if m in added]
            push(first)                                              # 2. new walls land first
            self._sync_groups(snap, rep, no_adds=item_failed)        # 3. per group; removals before adds
            push([i for i in desired if i not in set(first)])        # 4. even if the group step failed: deny is the backstop

            if mode == "full":                                       # 5.
                gone = [i for i in self.state["items"] if i not in {e["id"] for e in snap.entries}]
            else:
                gone = [i for i in snap.tombstones if i in self.state["items"]]
            for iid in gone:
                try:
                    self.c.request("DELETE", f"/external/connections/{self.cid}/items/{iid}")
                except GraphError as e:
                    if e.status != 404:
                        rep.errors.append(f"delete item {iid}: {e}")
                        continue
                    self._already(rep, f"delete item {iid}: 404")
                self.state["items"].pop(iid, None)
                rep.item_deletes.append(iid)

            # Matters whose items failed keep their old stored wall so the next run still sees the change.
            walls_save = {m: (old_walls[m] if m in item_failed and m in old_walls else w)
                          for m, w in walls_now.items() if not (m in item_failed and m not in old_walls)}
            self.state["walls"] = walls_save
            if not item_failed:                                      # else re-evaluate everything modified since
                self.state["watermark"] = snap.as_of
        finally:
            rep.retries = self.c.retries - r0
            self.save()
        return rep
