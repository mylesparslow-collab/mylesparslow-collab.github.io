"""Source record -> externalItem body. Shape per
https://learn.microsoft.com/graph/api/externalconnectors-externalconnection-put-items (CONFIRMED):
body {acl, properties, content{value,type}}; dateTime values ISO 8601; collection properties need
"<name>@odata.type": "Collection(String)"."""
from __future__ import annotations

import hashlib
import json

BASE = "https://dockets.thornwoodgarza.example"


def item_id(entry: dict) -> str:
    return entry["id"]


def build_item(entry: dict, matter: dict, acl: list[dict]) -> dict:
    kind = "Docket entry" if entry["kind"] == "docket" else "Matter note"
    return {
        "acl": acl,
        "properties": {
            "title": entry["title"],
            "url": f"{BASE}/matters/{matter['id']}/entries/{entry['id']}",
            "summary": entry["text"][:200],
            "caseNumber": matter["caseNumber"],
            "court": matter["court"],
            "documentType": entry["docType"],
            "itemKind": kind,
            "matterId": matter["id"],
            "matterName": matter["name"],
            "matterUrl": f"{BASE}/matters/{matter['id']}",
            "filedDate": entry["filed"] + "T00:00:00Z",
            "lastModified": entry["modified"],
            "authors@odata.type": "Collection(String)",
            "authors": entry["authors"],
        },
        "content": {"value": f"{entry['title']}. {entry['text']}", "type": "text"},
    }


def content_hash(body: dict) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:16]
