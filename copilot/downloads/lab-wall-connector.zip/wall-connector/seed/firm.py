"""Invented firm "Thornwood Garza LLP": users, matters, teams, walls, docket entries.

Everything here is fictional. Two snapshots are exposed:
  snapshot("t0")  the state at the first sync
  snapshot("t1")  the state at the next sync, after: two people leave teams, one joins,
                  a wall is ADDED to a matter, one entry is amended, one removed, one added.
"""
from __future__ import annotations

import copy
import uuid
from dataclasses import dataclass, field

DOMAIN = "thornwoodgarza.example"
_NS = uuid.UUID("7b0f6a52-3c1e-4f0a-9d55-0a1b2c3d4e5f")  # fixed namespace -> stable fake GUIDs

_PEOPLE = [
    "Imogen Ashby", "Teodor Vance", "Priya Raman", "Lars Lindqvist", "Chidi Okafor",
    "Marta Brandt", "Rafael Castellanos", "Odile Delacroix", "Sol Espinoza",
    "Nadia Farouk", "Declan Gallagher", "Wren Hollis",
]


def _user(name: str) -> dict:
    first, last = name.lower().split()
    upn = f"{first}.{last}@{DOMAIN}"
    return {"id": str(uuid.uuid5(_NS, upn)), "name": name, "upn": upn}


USERS = {u["upn"]: u for u in map(_user, _PEOPLE)}


def upn(last: str) -> str:
    return next(k for k in USERS if k.split("@")[0].endswith("." + last.lower()))


# id, name, case number, court, team (last names)
_MATTERS = [
    ("m01", "Pruitt v. Alder Mutual Insurance Co.", "24-CV-004417", "Marlow County Superior Court", ["ashby", "vance", "raman", "brandt"]),
    ("m02", "Halvorsen Tools, Inc. v. Brightwater Logistics LLC", "25-CV-001093", "Marlow County Superior Court", ["vance", "lindqvist", "gallagher"]),
    ("m03", "In re Calder Ridge Holdings LP", "25-BK-30218", "U.S. Bankruptcy Court, Eastern District of Marlow", ["ashby", "delacroix", "farouk", "hollis"]),
    ("m04", "Okonkwo v. Delmar Health Systems", "24-CV-007782", "U.S. District Court, Eastern District of Marlow", ["raman", "espinoza", "farouk", "lindqvist"]),
    ("m05", "Fennimore Pharma Antitrust Litigation", "23-MD-02041", "U.S. District Court, Eastern District of Marlow", ["ashby", "okafor", "hollis", "gallagher"]),
    ("m06", "Quillon Biologics v. Mereweather Labs", "25-CV-005560", "U.S. District Court, Eastern District of Marlow", ["lindqvist", "castellanos", "espinoza", "okafor"]),
    ("m07", "State ex rel. Tarrant v. Lowell Aggregate Co.", "25-CV-002871", "Marlow County Superior Court", ["castellanos", "brandt", "delacroix"]),
    ("m08", "Sutherland Family Trust, Petition for Accounting", "25-PR-000612", "Marlow County Probate Court", ["farouk", "gallagher", "hollis"]),
    ("m09", "Vasquez-Bright v. Northfield Transit Authority", "24-CV-009034", "Marlow County Superior Court", ["raman", "okafor", "castellanos"]),
    ("m10", "Ironbark Capital Partners v. Seaward Industrial Trust", "AAA 01-25-0004-7712", "American Arbitration Association (Marlow panel)", ["ashby", "vance", "espinoza"]),
]

# Ethical walls at t0: matter -> excluded last names. Okafor (Fennimore team) is screened
# off the Quillon matter and Lindqvist off Okonkwo. Both still appear on the staffing
# team lists, as happens when a staffing system lags behind the conflicts desk: the wall
# must win anyway. That is the point of the demo.
_WALLS_T0 = {"m06": ["okafor"], "m04": ["lindqvist"]}

# matter, seq, filed, doc type, title, text, filed-by (last name)
_E = [
 ("m01", 1, "2024-09-03", "Complaint", "Complaint for Breach of Contract and Bad Faith", "Plaintiff Dana Pruitt alleges Alder Mutual denied a fire-damage claim on the Pruitt warehouse without a reasonable investigation. Seeks policy benefits of $1,240,000 and damages.", "ashby"),
 ("m01", 2, "2024-10-21", "Answer", "Defendant's Answer and Affirmative Defenses", "Alder Mutual denies bad faith and pleads the concealment and cooperation conditions of the policy.", "vance"),
 ("m01", 3, "2025-03-14", "Motion", "Motion to Compel Production of Claim File", "Plaintiff moves for the complete claim file, adjuster notes, and reserve history.", "raman"),
 ("m01", 4, "2025-05-02", "Order", "Order Granting in Part Motion to Compel", "Court orders production of the adjuster notes within 30 days and denies the request for reserve history without prejudice.", "ashby"),
 ("m02", 1, "2025-02-11", "Complaint", "Complaint for Breach of Carriage Contract", "Halvorsen alleges Brightwater failed to deliver 14 pallets of precision tooling and seeks $386,500.", "vance"),
 ("m02", 2, "2025-03-27", "Answer", "Answer and Counterclaim for Unpaid Freight", "Brightwater counterclaims $41,200 in unpaid freight charges.", "lindqvist"),
 ("m02", 3, "2025-07-08", "Stipulation", "Stipulation Extending Discovery Cutoff", "Parties stipulate to extend the fact-discovery cutoff by 45 days.", "gallagher"),
 ("m02", 4, "2025-08-19", "Notice", "Notice of Deposition of Brightwater Dispatch Manager", "Deposition noticed for the Brightwater dispatch manager at counsel's offices.", "lindqvist"),
 ("m03", 1, "2025-01-09", "Petition", "Voluntary Petition under Chapter 11", "Calder Ridge Holdings LP files a voluntary Chapter 11 petition listing 212 creditors.", "ashby"),
 ("m03", 2, "2025-02-04", "Motion", "Motion to Use Cash Collateral on an Interim Basis", "Debtor seeks interim use of cash collateral to fund payroll and property taxes.", "delacroix"),
 ("m03", 3, "2025-04-22", "Order", "Order Approving Disclosure Statement", "Court approves the disclosure statement and sets the confirmation hearing.", "ashby"),
 ("m03", 4, "2025-06-30", "Notice", "Notice of Filing Plan Supplement", "Debtor files the plan supplement including the assumed-contract schedule.", "farouk"),
 ("m04", 1, "2024-11-18", "Complaint", "Complaint for Medical Negligence", "Plaintiff Ada Okonkwo alleges a delayed diagnosis at a Delmar Health Systems clinic.", "raman"),
 ("m04", 2, "2025-01-30", "Motion", "Motion to Dismiss Corporate Negligence Count", "Delmar moves to dismiss the corporate-negligence count for failure to plead a duty.", "espinoza"),
 ("m04", 3, "2025-04-09", "Order", "Order Denying Motion to Dismiss", "Court finds the duty allegations sufficient at the pleading stage.", "raman"),
 ("m04", 4, "2025-09-12", "Declaration", "Declaration of Dr. Henrik Soto Regarding Standard of Care", "Retained expert opines on the standard of care for follow-up imaging.", "farouk"),
 ("m05", 1, "2023-06-05", "Complaint", "Consolidated Class Action Complaint", "Direct purchasers allege Fennimore Pharma delayed generic entry through sham patent settlements.", "ashby"),
 ("m05", 2, "2023-09-14", "Motion", "Motion to Dismiss Consolidated Complaint", "Defendants move to dismiss for failure to allege an unlawful reverse payment.", "gallagher"),
 ("m05", 3, "2024-02-26", "Order", "Order on Motion to Dismiss", "Motion denied as to the reverse-payment theory, granted as to the monopolization count.", "ashby"),
 ("m05", 4, "2025-10-01", "Minute Entry", "Minute Entry: Case Management Conference", "Court sets expert disclosures and a class-certification briefing schedule.", "hollis"),
 ("m06", 1, "2025-04-02", "Complaint", "Complaint for Trade Secret Misappropriation", "Quillon Biologics alleges Mereweather Labs hired two scientists who took cell-line protocols.", "lindqvist"),
 ("m06", 2, "2025-05-16", "Motion", "Motion for Preliminary Injunction", "Quillon seeks to bar Mereweather from using the Quillon cell-line protocols pending trial.", "castellanos"),
 ("m06", 3, "2025-07-23", "Order", "Order Granting Stipulated Protective Order", "Court enters a two-tier protective order covering confidential and attorneys'-eyes-only material.", "espinoza"),
 ("m06", 4, "2025-09-30", "Declaration", "Declaration of Quillon Chief Scientist in Support of Injunction", "Declarant describes the development of the protocols and access controls.", "castellanos"),
 ("m07", 1, "2025-03-03", "Complaint", "Complaint for Public Nuisance and Civil Penalties", "The State alleges Lowell Aggregate's quarry blasting and dust exceeded permit limits.", "castellanos"),
 ("m07", 2, "2025-04-17", "Answer", "Answer of Lowell Aggregate Co.", "Lowell denies exceedances and asserts compliance with its operating permit.", "brandt"),
 ("m07", 3, "2025-08-05", "Notice", "Notice of Site Inspection", "Parties notice a joint inspection of the quarry and monitoring stations.", "delacroix"),
 ("m07", 4, "2025-10-12", "Stipulation", "Stipulation Regarding Air-Monitoring Data", "Parties stipulate to the authenticity of the 2023 to 2025 monitoring data.", "brandt"),
 ("m08", 1, "2025-05-06", "Petition", "Petition for Accounting and Surcharge", "Beneficiary petitions for an accounting of the Sutherland Family Trust and surcharge of the trustee.", "farouk"),
 ("m08", 2, "2025-06-20", "Objection", "Trustee's Objection to Petition", "Trustee objects that the petition is untimely and the accounting was already delivered.", "gallagher"),
 ("m08", 3, "2025-09-09", "Order", "Order Setting Evidentiary Hearing", "Court sets an evidentiary hearing on the trustee's accounts.", "hollis"),
 ("m08", 4, "2025-10-28", "Notice", "Notice of Lodging of Trust Instrument", "The trust instrument and two amendments are lodged under seal.", "farouk"),
 ("m09", 1, "2024-07-15", "Complaint", "Complaint for Personal Injury (Government Claim)", "Plaintiff Luz Vasquez-Bright alleges she was injured boarding a Northfield Transit bus.", "raman"),
 ("m09", 2, "2024-09-30", "Answer", "Answer of Northfield Transit Authority", "Authority asserts governmental immunity and comparative fault.", "okafor"),
 ("m09", 3, "2025-06-04", "Motion", "Motion for Summary Judgment on Immunity", "Authority moves for summary judgment on its immunity defense.", "castellanos"),
 ("m09", 4, "2025-08-27", "Order", "Order Denying Summary Judgment", "Court finds a triable issue on the maintenance exception to immunity.", "okafor"),
 ("m10", 1, "2025-06-10", "Demand", "Demand for Arbitration", "Ironbark Capital Partners demands arbitration of a $9.8 million indemnity dispute under the purchase agreement.", "ashby"),
 ("m10", 2, "2025-07-24", "Answer", "Answering Statement and Counterclaim", "Seaward Industrial Trust denies liability and counterclaims for a working-capital adjustment.", "vance"),
 ("m10", 3, "2025-09-17", "Order", "Procedural Order No. 2 (Document Production)", "Panel orders staged document production and a privilege-log exchange.", "espinoza"),
 ("m10", 4, "2025-10-05", "Notice", "Notice of Hearing", "Final hearing noticed before the three-member panel.", "vance"),
]

_NOTES = {
    "m01": "Client contact is the Pruitt family's risk manager. Settlement authority has not been granted. Adjuster deposition is the priority.",
    "m02": "Counterclaim exposure is modest. Watch the carrier-liability cap in the freight contract.",
    "m03": "Cash-collateral budget approved by the lender. Plan supplement holds the assumed-contract schedule.",
    "m04": "Expert on standard of care retained. Hospital has offered early mediation.",
    "m05": "Class certification expert needs economist review. Document volume is roughly 4 million pages.",
    "m06": "Injunction hearing prep. Cell-line protocol evidence is attorneys'-eyes-only.",
    "m07": "State seeks civil penalties only. Air-monitoring data is the core evidence.",
    "m08": "Trustee relationship is strained. Trust instrument amendments are under seal.",
    "m09": "Immunity issue resolved at summary judgment. Mediation with the Authority is being scheduled.",
    "m10": "Panel selected. Privilege-log exchange due before the final hearing.",
}


@dataclass
class Snapshot:
    as_of: str
    users: dict
    matters: dict            # id -> {id,name,caseNumber,court,team:[upn]}
    walls: dict              # matter id -> [upn]
    entries: list            # source records (docket entries and matter notes)
    tombstones: list = field(default_factory=list)  # item ids deleted at source since last sync


def _base() -> Snapshot:
    matters = {
        mid: {"id": mid, "name": name, "caseNumber": case, "court": court, "team": [upn(l) for l in team]}
        for mid, name, case, court, team in _MATTERS
    }
    entries = []
    for mid, seq, filed, dtype, title, text, by in _E:
        entries.append({
            "id": f"{mid}e{seq:02d}", "matter": mid, "kind": "docket", "docType": dtype, "title": title,
            "text": text, "filed": filed, "authors": [USERS[upn(by)]["name"]], "modified": filed + "T16:00:00Z",
        })
    for mid, text in _NOTES.items():
        entries.append({
            "id": f"{mid}n01", "matter": mid, "kind": "note", "docType": "Matter note",
            "title": f"Matter note: {matters[mid]['name']}", "text": text, "filed": "2025-11-01",
            "authors": [USERS[matters[mid]["team"][0]]["name"]], "modified": "2025-11-01T09:00:00Z",
        })
    walls = {m: [upn(l) for l in ls] for m, ls in _WALLS_T0.items()}
    return Snapshot("2025-11-01T12:00:00Z", dict(USERS), matters, walls, entries)


def snapshot(which: str = "t0") -> Snapshot:
    s = _base()
    if which == "t0":
        return s
    if which != "t1":
        raise ValueError(which)
    s = copy.deepcopy(s)
    s.as_of = "2025-11-15T12:00:00Z"
    t = s.matters
    t["m01"]["team"].remove(upn("brandt"))           # Brandt leaves the Pruitt team
    t["m08"]["team"].remove(upn("gallagher"))        # Gallagher leaves the Sutherland team
    t["m02"]["team"].append(upn("espinoza"))         # Espinoza joins Halvorsen
    s.walls["m03"] = [upn("delacroix")]              # NEW WALL: Delacroix screened off Calder Ridge
    by_id = {e["id"]: e for e in s.entries}
    by_id["m02e04"]["text"] += " Deposition rescheduled to the following week at the witness's request."
    by_id["m02e04"]["modified"] = "2025-11-10T10:00:00Z"
    s.entries.remove(by_id["m08e04"])                # lodged-under-seal notice withdrawn from the index
    s.tombstones.append("m08e04")
    s.entries.append({
        "id": "m01e05", "matter": "m01", "kind": "docket", "docType": "Order",
        "title": "Order Setting Trial Date and Pretrial Schedule",
        "text": "Court sets a jury trial and orders the parties to exchange witness lists.",
        "filed": "2025-11-12", "authors": [USERS[upn("ashby")]["name"]], "modified": "2025-11-12T15:00:00Z",
    })
    return s
