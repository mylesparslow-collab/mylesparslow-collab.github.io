# Docket Connector (Microsoft 365 Copilot connector)

An invented firm, Thornwood Garza LLP, has court docket entries and matter notes. This lab indexes them into Microsoft Search through a Microsoft Graph external connection (`thornwooddocket`) so Copilot can use them. Every item carries an access list built from the matter team and the firm's ethical walls, so Copilot can only ground an answer on matters the asking person may see. Confidentiality is enforced by the index, not by the prompt.

All data is fake. Nothing here has touched the real Microsoft Graph.

## How it works

- `seed/firm.py`: 12 invented users (fake GUIDs, UPNs at `thornwoodgarza.example`), 10 matters, 40 docket entries plus 10 matter notes, teams, walls. Snapshot `t0` is the first sync; `t1` is the next, with two people leaving teams, one joining, a new wall, an amended entry, a removed entry and a new entry. Two walled users are deliberately still on the staffing lists, to show the wall wins.
- `connector/schema.py`: the connection schema (13 properties, semantic labels title, url, createdDateTime, lastModifiedDateTime, authors, containerName, containerUrl) and an offline validator.
- `connector/acl.py`: pure functions. One external group per matter team (granted), minus walled users; an explicit `deny` entry for each walled user. A walled user is both kept out of the group and denied.
- `connector/sync.py`: full and incremental crawl with a content hash per item in a state file. Order: connection and schema (202 plus polling), items of matters whose wall was added, group changes (removals before additions), other changed items, deletes.
  - Failure handling: each group and each item is handled on its own, so one bad answer never stops the run. A 404 on a member delete (already removed by hand) and a 409 on a group create or member add (already exists, e.g. after the state file was lost) count as already done: logged and carried on. Any other error is recorded, the run continues, state is saved for everything that succeeded, and the command prints every error and exits 1.
  - Safety ordering: within a group, removals run first and nobody is added unless every removal succeeded; a group whose removal failed gets no grants this run and keeps the stale member in state, so the next run retries it. Items are still pushed for that matter with their deny entries (deny wins over the group grant), so a wall closes even while group membership is stuck. A user only taken off a team (not walled) is closed by the group removal alone, so that remains an error until it succeeds. Items whose push failed are retried next run (watermark and stored wall are not advanced).
  - Known gap: after a lost state file the connector assumes an existing group (409) is empty, so members added earlier who have since left the team are not removed until the group is rebuilt. Walled users are still blocked by item deny entries.
- `connector/graph.py`: thin httpx client; client-credentials token; retries 429/502/503/504 with Retry-After or jittered backoff; paging; operation polling; dry-run transport.
- `mockgraph/`: local mock of the Graph endpoints used, 429 and arbitrary-status (404, 409, 403...) injectors, and `search(user, query)` applying grant-by-group-membership with deny winning.
- `agents/docket-search/`: declarative agent v1.9 with the `GraphConnectors` capability. See its README.

## Run

```
cd copilot-kit/labs/wall-connector
uv run --python 3.12 pytest -q                                   # all tests (one command)
uv run --python 3.12 python demo/run_demo.py                     # regenerates demo/
uv run --python 3.12 python -m connector --source t0 --mode full --dry-run   # writes out/requests/*.json, sends nothing
uv run --python 3.12 python -m connector --source t0 --mode full --mock      # in-process mock Graph
uv run --python 3.12 python -m mockgraph --port 8723             # optional: mock over HTTP, then use --base-url http://127.0.0.1:8723/v1.0
```

For a real tenant (never done here) set the variables in `.env.example`: `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`, optional `GRAPH_BASE_URL`, with application permissions `ExternalConnection.ReadWrite.OwnedBy` and `ExternalItem.ReadWrite.OwnedBy`. Keep `--base-url` and `--mock` off so the real endpoint is used.

## Verified here

- `uv run --python 3.12 pytest -q`: 35 passed. Covers the schema rules, ACL property tests over 500 random teams and walls (a walled user is never granted; deny is always present; the wall holds even when group membership is wrong), sync idempotency (a second full run sends zero item PUTs), the incremental diff, request order (new-wall items before any group change), 429 with Retry-After, 202 schema polling, paging, dry run, and the agent manifest.
- The four access proofs run end to end against the mock: a walled user gets zero hits; a team member gets hits; a user removed from the team loses access after the next incremental sync; a newly added wall takes effect.
- `python -m connector ... --dry-run` wrote 97 request files and sent nothing; `python -m mockgraph --port 8723` plus `--base-url` ran a full sync over real HTTP on localhost, then the server was stopped.
- `python demo/run_demo.py` produced `demo/sync-log.md`, `demo/access-proof.md` and `demo/samples/*.json`.

## Not verified

- It has never talked to the real Microsoft Graph. The mock was written from Microsoft Learn pages, not from observing the service, so passing tests prove the connector is consistent with the mock, not with Graph.
- Nothing ran in a Microsoft 365 tenant; the agent was never loaded into Copilot and the connection never exists in a tenant.
- Confirmed on Learn (2026-11-13): acl shape (`type`, `accessType`, `value`), create externalGroup, add member (`id`, `type`), PUT item body (`acl`, `properties`, `content`; `Collection(String)` type specifier), schema PATCH returning 202 plus `Location`.
- Not confirmed: deny-wins semantics against group grants (taken from the brief); the `DELETE .../groups/{id}/members/{memberId}` path and that it answers 404 for an absent member, and that a duplicate member add or group create answers 409 (assumed, handled as already done); the schema validator rules beyond the 128-property limit and baseType (name pattern, label/type table, label-once, refinable vs searchable, searchable types), written from memory; the connection-creation body; the `connectionOperation` status values and polling cadence; the schema PATCH was read from the beta page, v1.0 assumed identical.
- Not modelled: Entra group nesting, guest users, very large teams, item-count and throttling limits of the real service, and how long ACL changes take to propagate in the real index.
- The incremental crawl trusts the source's modified timestamps; a source that edits an item without bumping its timestamp would be missed until a full crawl.

Sources: https://learn.microsoft.com/graph/api/resources/externalconnectors-acl , .../externalconnectors-externalconnection-post-groups , .../externalconnectors-externalgroup-post-members , .../externalconnectors-externalconnection-put-items , .../externalconnectors-schema-update
