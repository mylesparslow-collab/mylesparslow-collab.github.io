# Access proof (search as user, against the mock index)

The mock applies the access model from `connector/acl.py`: grant via external-group membership, explicit deny wins.
Nothing in a prompt is involved. The index decides what each user can ever be shown.

## Same query, three users: `Quillon` (matter m06, Quillon Biologics v. Mereweather Labs)

| user | result |
|---|---|
| Rafael Castellanos (on the m06 team) | 5 hit(s): Matter note: Quillon Biologics v. Mereweather Labs; Declaration of Quillon Chief Scientist in Support of Injunction ... |
| Chidi Okafor (screened by ethical wall, but still on the staffing list) | 0 hit(s) |
| Imogen Ashby (not on the m06 team) | 0 hit(s) |

Okafor and Ashby both get zero results, and nothing in the result distinguishes `walled` from `no such matter`.
That is deliberate: the agent cannot reveal that a walled matter exists because the index never returns it.

## A user removed from the team (incremental sync t0 to t1)

Query `Pruitt` as Marta Brandt:

| user | result |
|---|---|
| before (t0) | 5 hit(s): Matter note: Pruitt v. Alder Mutual Insurance Co.; Order Granting in Part Motion to Compel ... |
| after incremental sync (t1) | 0 hit(s) |

## A wall added between syncs

Query `Calder Ridge` as Odile Delacroix (on the team; wall added at t1):

| user | result |
|---|---|
| before (t0) | 5 hit(s): Matter note: In re Calder Ridge Holdings LP; Notice of Filing Plan Supplement ... |
| after incremental sync (t1) | 0 hit(s) |

## What the agent would ground on for 'what was filed last in the Pruitt case' (Ashby, after t1)

Top hit: **Order Setting Trial Date and Pretrial Schedule**, filed 2025-11-12, https://dockets.thornwoodgarza.example/matters/m01/entries/m01e05
