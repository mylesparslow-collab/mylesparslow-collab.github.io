"""Produces demo/sync-log.md, demo/access-proof.md and demo/samples/*.json by really running the
connector against the in-process mock Graph. Run: uv run --python 3.12 python demo/run_demo.py"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from connector.graph import DryRunTransport, GraphClient  # noqa: E402
from connector.sync import CONNECTION_ID, Syncer  # noqa: E402
from mockgraph import MockGraph  # noqa: E402
from seed.firm import USERS, snapshot, upn  # noqa: E402

D = ROOT / "demo"
tmp = Path(tempfile.mkdtemp())

# 1. dry run -> request bodies
req_dir = tmp / "requests"
Syncer(GraphClient(token=lambda: "x", transport=DryRunTransport(req_dir)), tmp / "dry.json", dry_run=True, poll_interval=0).run(snapshot("t0"), "full")
for pat, name in [("*PATCH*schema*", "schema-patch.json"), ("*POST*groups.json", "group-create.json"),
                  ("*POST*m06team-members*", "group-member-add.json"), ("*PUT*m06e02*", "item-put-with-wall.json"),
                  ("*PUT*m01e01*", "item-put-plain-team.json")]:
    shutil.copy(sorted(req_dir.glob(pat))[0], D / "samples" / name)
n_dry = len(list(req_dir.glob("*.json")))

# 2. real runs against the mock
mock = MockGraph()
c = GraphClient(base_url=mock.base, token=lambda: "mock", transport=mock.transport(), sleep=lambda s: None)
sy = Syncer(c, tmp / "state.json", poll_interval=0)
mock.inject_429(2, retry_after=3, when=lambda r: r.method == "PUT")
steps = []


def run(label, snap, mode):
    mark = len(mock.log)
    rep = sy.run(snap, mode)
    steps.append((label, rep, mock.log[mark:]))
    return rep


def who(last):
    return USERS[upn(last)]


def ask(last, q):
    return mock.search(CONNECTION_ID, who(last)["id"], q)


proof = []
run("Run 1: full crawl, source snapshot t0", snapshot("t0"), "full")
before = {k: ask(*k) for k in [("brandt", "Pruitt"), ("delacroix", "Calder Ridge")]}
t0_q = {u: ask(u, "Quillon") for u in ("castellanos", "okafor", "ashby")}
run("Run 2: full crawl again, nothing changed", snapshot("t0"), "full")
run("Run 3: incremental crawl, source snapshot t1", snapshot("t1"), "incremental")
run("Run 4: incremental crawl again, nothing changed", snapshot("t1"), "incremental")
after = {k: ask(*k) for k in before}

# sync-log.md
L = ["# Sync log (real run against the mock Graph, fake data)", "",
     f"Dry run first: `--dry-run` wrote {n_dry} request files and sent nothing (samples in `demo/samples/`).", "",
     "Two 429 responses (Retry-After: 3) were injected on item PUTs during run 1; the client waited and retried.", ""]
for label, rep, log in steps:
    s = rep.summary()
    L += [f"## {label}", "", "| what | count |", "|---|---|"] + [f"| {k} | {v} |" for k, v in s.items()] + [""]
    if rep.item_puts:
        L.append("Items PUT: " + ", ".join(rep.item_puts[:60]))
    if rep.item_deletes:
        L.append("Items DELETEd: " + ", ".join(rep.item_deletes))
    if label.startswith("Run 3"):
        L += ["", "Request order (item PUTs for the newly walled matter m03 come before any group change):", "```"]
        L += [f"{m} {p.split('/v1.0')[-1]}" for m, p in log]
        L += ["```"]
    L.append("")
(D / "sync-log.md").write_text("\n".join(L))

# access-proof.md
def table(rows):
    out = ["| user | result |", "|---|---|"]
    for name, h in rows:
        out.append(f"| {name} | {len(h)} hit(s)" + (": " + "; ".join(x['title'] for x in h[:2]) + (" ..." if len(h) > 2 else "") if h else "") + " |")
    return out

P = ["# Access proof (search as user, against the mock index)", "",
     "The mock applies the access model from `connector/acl.py`: grant via external-group membership, explicit deny wins.",
     "Nothing in a prompt is involved. The index decides what each user can ever be shown.", "",
     "## Same query, three users: `Quillon` (matter m06, Quillon Biologics v. Mereweather Labs)", ""]
P += table([("Rafael Castellanos (on the m06 team)", t0_q["castellanos"]),
            ("Chidi Okafor (screened by ethical wall, but still on the staffing list)", t0_q["okafor"]),
            ("Imogen Ashby (not on the m06 team)", t0_q["ashby"])])
P += ["", "Okafor and Ashby both get zero results, and nothing in the result distinguishes `walled` from `no such matter`.",
      "That is deliberate: the agent cannot reveal that a walled matter exists because the index never returns it.", "",
      "## A user removed from the team (incremental sync t0 to t1)", "", "Query `Pruitt` as Marta Brandt:", ""]
P += table([("before (t0)", before[("brandt", "Pruitt")]), ("after incremental sync (t1)", after[("brandt", "Pruitt")])])
P += ["", "## A wall added between syncs", "", "Query `Calder Ridge` as Odile Delacroix (on the team; wall added at t1):", ""]
P += table([("before (t0)", before[("delacroix", "Calder Ridge")]), ("after incremental sync (t1)", after[("delacroix", "Calder Ridge")])])
newest = mock.search(CONNECTION_ID, who("ashby")["id"], "Pruitt")[0]
P += ["", "## What the agent would ground on for 'what was filed last in the Pruitt case' (Ashby, after t1)", "",
      f"Top hit: **{newest['title']}**, filed {newest['filedDate'][:10]}, {newest['url']}", ""]
(D / "access-proof.md").write_text("\n".join(P))
print("\n".join(P))
