# Sync log (real run against the mock Graph, fake data)

Dry run first: `--dry-run` wrote 97 request files and sent nothing (samples in `demo/samples/`).

Two 429 responses (Retry-After: 3) were injected on item PUTs during run 1; the client waited and retried.

## Run 1: full crawl, source snapshot t0

| what | count |
|---|---|
| mode | full |
| connection_created | True |
| schema_patched | True |
| groups_created | 10 |
| members_added | 33 |
| members_removed | 0 |
| item_puts | 50 |
| item_deletes | 0 |
| skipped_unchanged | 0 |
| wall_added_matters | [] |
| http_retries | 2 |
| already_done | 0 |
| errors | 0 |

Items PUT: m01e01, m01e02, m01e03, m01e04, m02e01, m02e02, m02e03, m02e04, m03e01, m03e02, m03e03, m03e04, m04e01, m04e02, m04e03, m04e04, m05e01, m05e02, m05e03, m05e04, m06e01, m06e02, m06e03, m06e04, m07e01, m07e02, m07e03, m07e04, m08e01, m08e02, m08e03, m08e04, m09e01, m09e02, m09e03, m09e04, m10e01, m10e02, m10e03, m10e04, m01n01, m02n01, m03n01, m04n01, m05n01, m06n01, m07n01, m08n01, m09n01, m10n01

## Run 2: full crawl again, nothing changed

| what | count |
|---|---|
| mode | full |
| connection_created | False |
| schema_patched | False |
| groups_created | 0 |
| members_added | 0 |
| members_removed | 0 |
| item_puts | 0 |
| item_deletes | 0 |
| skipped_unchanged | 50 |
| wall_added_matters | [] |
| http_retries | 0 |
| already_done | 0 |
| errors | 0 |


## Run 3: incremental crawl, source snapshot t1

| what | count |
|---|---|
| mode | incremental |
| connection_created | False |
| schema_patched | False |
| groups_created | 0 |
| members_added | 1 |
| members_removed | 3 |
| item_puts | 7 |
| item_deletes | 1 |
| skipped_unchanged | 0 |
| wall_added_matters | ['m03'] |
| http_retries | 0 |
| already_done | 0 |
| errors | 0 |

Items PUT: m03e01, m03e02, m03e03, m03e04, m03n01, m02e04, m01e05
Items DELETEd: m08e04

Request order (item PUTs for the newly walled matter m03 come before any group change):
```
PUT /external/connections/thornwooddocket/items/m03e01
PUT /external/connections/thornwooddocket/items/m03e02
PUT /external/connections/thornwooddocket/items/m03e03
PUT /external/connections/thornwooddocket/items/m03e04
PUT /external/connections/thornwooddocket/items/m03n01
DELETE /external/connections/thornwooddocket/groups/m01team/members/7ce5cc24-60ef-56e7-b99a-977d68a78ac2
POST /external/connections/thornwooddocket/groups/m02team/members
DELETE /external/connections/thornwooddocket/groups/m03team/members/65680114-bdc8-52d2-b131-5bf6eaeef164
DELETE /external/connections/thornwooddocket/groups/m08team/members/a1fe51de-07d3-516f-a436-4e937cc4721c
PUT /external/connections/thornwooddocket/items/m02e04
PUT /external/connections/thornwooddocket/items/m01e05
DELETE /external/connections/thornwooddocket/items/m08e04
```

## Run 4: incremental crawl again, nothing changed

| what | count |
|---|---|
| mode | incremental |
| connection_created | False |
| schema_patched | False |
| groups_created | 0 |
| members_added | 0 |
| members_removed | 0 |
| item_puts | 0 |
| item_deletes | 0 |
| skipped_unchanged | 0 |
| wall_added_matters | [] |
| http_retries | 0 |
| already_done | 0 |
| errors | 0 |

